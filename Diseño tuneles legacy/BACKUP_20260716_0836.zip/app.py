from flask import Flask, render_template, request, jsonify, send_file
from werkzeug.utils import secure_filename
import os
from datetime import datetime
from modules.excel_handler import ExcelHandler
from modules.validators import DataValidator
from modules.tunnel.engine import run_tunnel_calculation
from config import (
    DEBUG, UPLOAD_FOLDER, DOWNLOAD_FOLDER, ALLOWED_EXTENSIONS,
    MAX_CONTENT_LENGTH, VALIDATION_CONFIG
)

app = Flask(__name__)

# Cargar configuración
app.config['DEBUG'] = DEBUG
app.config['UPLOAD_FOLDER'] = UPLOAD_FOLDER
app.config['MAX_CONTENT_LENGTH'] = MAX_CONTENT_LENGTH
app.config['VALIDATION_CONFIG'] = VALIDATION_CONFIG

# Crear directorios si no existen
os.makedirs(UPLOAD_FOLDER, exist_ok=True)
os.makedirs(DOWNLOAD_FOLDER, exist_ok=True)

excel_handler = ExcelHandler()
validator = DataValidator()

def allowed_file(filename):
    return '.' in filename and filename.rsplit('.', 1)[1].lower() in ALLOWED_EXTENSIONS

@app.route('/')
def index():
    """Página principal con formulario"""
    return render_template('index.html')

@app.route('/debug')
def debug():
    """Página de debug para diagnosticar problemas"""
    return render_template('debug.html')

@app.route('/api/submit-form', methods=['POST'])
def submit_form():
    """Recibe datos del formulario en modo manual y genera Excel"""
    try:
        data = request.get_json()
        print(f"DEBUG: Datos recibidos: {list(data.keys())}")

        errors = validator.validate_form_data(data)
        if errors:
            print(f"DEBUG: Errores de validación: {errors}")
            error_message = " | ".join(errors)
            return jsonify({
                'success': False,
                'error': f'Errores en el formulario: {error_message}',
                'errors': errors
            }), 200

        filename = f"estudio_{datetime.now().strftime('%Y%m%d_%H%M%S')}.xlsx"
        filepath = os.path.join(DOWNLOAD_FOLDER, filename)

        print(f"DEBUG: Creando archivo en: {filepath}")
        excel_handler.create_study_from_form(data, filepath)

        if not os.path.exists(filepath):
            print(f"ERROR: Archivo no fue creado en {filepath}")
            return jsonify({'success': False, 'error': f'Archivo no fue creado'}), 500

        file_size = os.path.getsize(filepath)
        print(f"DEBUG: Archivo creado exitosamente. Tamaño: {file_size} bytes")

        return jsonify({
            'success': True,
            'message': f'Excel generado correctamente ({file_size} bytes)',
            'download_url': f'/api/download/{filename}',
            'filename': filename
        }), 200

    except Exception as e:
        import traceback
        error_trace = traceback.format_exc()
        print(f"ERROR en submit_form: {str(e)}")
        print(f"Traceback: {error_trace}")
        return jsonify({'success': False, 'error': str(e), 'traceback': error_trace}), 500

@app.route('/api/upload-excel', methods=['POST'])
def upload_excel():
    """Recibe Excel con múltiples estudios y lo procesa"""
    try:
        if 'file' not in request.files:
            return jsonify({'success': False, 'error': 'No file provided'}), 400

        file = request.files['file']

        if file.filename == '':
            return jsonify({'success': False, 'error': 'No file selected'}), 400

        if not allowed_file(file.filename):
            return jsonify({'success': False, 'error': 'Only .xlsx and .xls files allowed'}), 400

        filename = secure_filename(file.filename)
        upload_path = os.path.join(UPLOAD_FOLDER, filename)
        file.save(upload_path)

        results = excel_handler.process_imported_excel(upload_path)

        output_filename = f"resultados_{datetime.now().strftime('%Y%m%d_%H%M%S')}.xlsx"
        output_path = os.path.join(DOWNLOAD_FOLDER, output_filename)

        excel_handler.create_results_excel(results, output_path)

        os.remove(upload_path)

        return jsonify({
            'success': True,
            'message': f'Excel procesado: {len(results)} estudios encontrados',
            'download_url': f'/api/download/{output_filename}'
        }), 200

    except Exception as e:
        return jsonify({'success': False, 'error': str(e)}), 500

@app.route('/api/download-template', methods=['GET'])
def download_template():
    """Descarga la plantilla Excel vacía para múltiples estudios"""
    try:
        filename = 'plantilla_app_salvilux.xlsx'
        assets_folder = getattr(app.config, 'ASSETS_FOLDER', os.path.join(os.path.dirname(__file__), 'assets'))
        filepath = os.path.join(assets_folder, filename)

        if not os.path.exists(filepath):
            alt_paths = [
                os.path.join(os.path.dirname(__file__), 'assets', filename),
                os.path.join(os.getcwd(), 'assets', filename),
                filename
            ]
            for alt_path in alt_paths:
                if os.path.exists(alt_path):
                    filepath = alt_path
                    break
            else:
                return jsonify({'success': False, 'error': f'Template not found in {assets_folder}'}), 404

        return send_file(filepath, as_attachment=True, download_name=filename, mimetype='application/vnd.openxmlformats-officedocument.spreadsheetml.sheet')

    except Exception as e:
        return jsonify({'success': False, 'error': f'Error downloading template: {str(e)}'}), 500

@app.route('/api/download-ldts', methods=['GET'])
def download_ldts():
    """Descarga la librería de LDTs comprimida"""
    try:
        filename = 'LDTs_luminarias.zip'
        assets_folder = getattr(app.config, 'ASSETS_FOLDER', os.path.join(os.path.dirname(__file__), 'assets'))
        filepath = os.path.join(assets_folder, filename)

        if not os.path.exists(filepath):
            alt_paths = [
                os.path.join(os.path.dirname(__file__), 'assets', filename),
                os.path.join(os.getcwd(), 'assets', filename),
                filename
            ]
            for alt_path in alt_paths:
                if os.path.exists(alt_path):
                    filepath = alt_path
                    break
            else:
                return jsonify({'success': False, 'error': f'LDT library not found in {assets_folder}'}), 404

        return send_file(filepath, as_attachment=True, download_name=filename, mimetype='application/zip')

    except Exception as e:
        return jsonify({'success': False, 'error': f'Error downloading LDTs: {str(e)}'}), 500

@app.route('/api/download/<filename>', methods=['GET'])
def download_file(filename):
    """Descarga archivos generados"""
    try:
        safe_filename = secure_filename(filename)
        filepath = os.path.join(DOWNLOAD_FOLDER, safe_filename)

        if not os.path.exists(filepath):
            return jsonify({'success': False, 'error': f'File not found: {filepath}'}), 404

        file_size = os.path.getsize(filepath)
        return send_file(filepath, as_attachment=True, download_name=filename, mimetype='application/vnd.openxmlformats-officedocument.spreadsheetml.sheet')

    except Exception as e:
        import traceback
        error_trace = traceback.format_exc()
        return jsonify({'success': False, 'error': str(e), 'traceback': error_trace}), 500

@app.route('/api/health', methods=['GET'])
def health():
    """Health check endpoint"""
    return jsonify({'status': 'ok', 'timestamp': datetime.now().isoformat()}), 200


# ══════════════════════════════════════════════════════════════════
# SALVI TUNNEL ENGINE — Rutas API (CIE 88:2004)
# ══════════════════════════════════════════════════════════════════

@app.route('/tunnel')
def tunnel_index():
    """Página principal del módulo de túneles.
    Se sirve directamente (sin Jinja2) para preservar la sintaxis JSX {{ }}."""
    import os
    from flask import send_from_directory
    templates_dir = os.path.join(os.path.dirname(__file__), 'templates')
    return send_from_directory(templates_dir, 'tunnel.html')


@app.route('/api/tunnel/calculate', methods=['POST'])
def tunnel_calculate():
    """
    Calcula el diseño completo de un túnel según CIE 88:2004.
    Body JSON: ver run_tunnel_calculation() en modules/tunnel/engine.py
    """
    try:
        data = request.get_json()
        if not data:
            return jsonify({'success': False, 'error': 'No se recibieron datos JSON'}), 400

        result = run_tunnel_calculation(data)
        status_code = 200 if result.get('success') else 422
        return jsonify(result), status_code

    except Exception as e:
        import traceback
        return jsonify({
            'success': False,
            'error': str(e),
            'traceback': traceback.format_exc()
        }), 500


@app.route('/api/tunnel/classify', methods=['POST'])
def tunnel_classify():
    """
    Solo clasifica el túnel (TUN-CLS-001 a 003).
    Útil para feedback rápido mientras el usuario rellena el formulario.
    """
    try:
        data = request.get_json()
        from modules.tunnel.classification import classify_tunnel
        from modules.tunnel.design_speed import calculate_design_speed

        length_m  = float(data.get('length_m', 300))
        speed_kmh = float(data.get('speed_kmh', 80))
        gradient  = float(data.get('gradient_pct', 0.0))
        exit_vis  = bool(data.get('exit_visible', False))
        daylight  = data.get('daylight_penetration', 'poor')
        traffic   = int(data.get('traffic_veh_h', 500))
        has_ped   = bool(data.get('has_pedestrians', False))
        curv      = data.get('curvature_radius_m', None)

        speed_r = calculate_design_speed(speed_kmh, gradient)
        SD = speed_r.stopping_distance_m

        cls = classify_tunnel(
            length_m=length_m,
            stopping_distance_m=SD,
            exit_visible=exit_vis,
            daylight_penetration=daylight,
            traffic_veh_h=traffic,
            has_pedestrians=has_ped,
            speed_kmh=speed_kmh,
            curvature_radius_m=float(curv) if curv else None,
            gradient_pct=gradient
        )

        return jsonify({
            'success': True,
            'geometric': cls.geometric_category.value,
            'optical': cls.optical_category.value,
            'daylighting': cls.daylighting_need.value,
            'SD_m': SD,
            'justification': cls.justification
        })

    except Exception as e:
        return jsonify({'success': False, 'error': str(e)}), 500


@app.route('/api/tunnel/lth', methods=['POST'])
def tunnel_lth():
    """
    Calcula L20, Lseq y Lth para preview rápido.
    """
    try:
        data = request.get_json()
        from modules.tunnel.l20_lseq_lth import (
            calculate_L20_model, calculate_L20_table,
            calculate_Lseq, calculate_Lth
        )
        from modules.tunnel.models import PortalOrientation, SkyCondition

        speed_kmh = float(data.get('speed_kmh', 80))
        traffic   = int(data.get('traffic_veh_h', 500))
        orient    = PortalOrientation(data.get('portal_orientation', 'S'))
        sky       = SkyCondition(data.get('sky_condition', 'clear'))
        env_type  = data.get('environment_type', 'open_country_flat')
        method    = data.get('l20_method', 'model')

        if method == 'table':
            l20_r = calculate_L20_table(env_type, orient)
        else:
            l20_r = calculate_L20_model(env_type, orient, sky)

        lseq_r = calculate_Lseq(l20_r.L20)
        lth_r  = calculate_Lth(l20_r, speed_kmh, traffic)

        return jsonify({
            'success': True,
            'L20': round(l20_r.L20, 0),
            'Lseq': round(lseq_r.Lseq, 0),
            'Lth': round(lth_r.Lth, 1),
            'k_factor': round(lth_r.k_factor, 4),
            'qc': round(lth_r.qc, 3),
            'l20_note': l20_r.note
        })

    except Exception as e:
        return jsonify({'success': False, 'error': str(e)}), 500


@app.route('/api/tunnel/control', methods=['POST'])
def tunnel_control():
    """
    Genera el plan de control completo (escenas, grupos, curvas, DALI/Smartec).
    Puede llamarse de forma independiente con los parámetros del diseño,
    o los datos vienen del resultado de /api/tunnel/calculate.

    Body JSON mínimo:
        L20_design, Lth_design, Lin, L_night, k_factor,
        speed_kmh, zones (dict), n_transition_groups, protocol
    """
    try:
        data = request.get_json()
        from modules.tunnel.control import build_control_plan, export_dali, export_smartec
        from modules.tunnel.zones import build_zones
        from modules.tunnel.models import TrafficDirection

        # Si llegan los parámetros completos, recalcular todo con el engine
        if data.get('recalculate'):
            from modules.tunnel.engine import run_tunnel_calculation
            result = run_tunnel_calculation(data)
            if not result.get('success'):
                return jsonify(result), 422
            ctrl = result['control']
        else:
            # Usar parámetros pre-calculados
            from modules.tunnel.engine import run_tunnel_calculation
            result = run_tunnel_calculation(data)
            if not result.get('success'):
                return jsonify(result), 422
            ctrl = result['control']

        # Export según protocolo solicitado
        protocol = data.get('protocol', data.get('control_protocol', 'DALI'))
        from modules.tunnel.control import TunnelControlPlan, ControlProtocol, ControlScene, ControlGroup, RegulationCurve, SceneType, ZoneType as CZoneType
        # El export ya está en el resultado del engine — lo devolvemos enriquecido
        return jsonify({
            'success': True,
            'control': ctrl,
            'summary': result.get('summary', {})
        })

    except Exception as e:
        import traceback
        return jsonify({'success': False, 'error': str(e),
                        'traceback': traceback.format_exc()}), 500


@app.route('/api/tunnel/export-excel', methods=['POST'])
def tunnel_export_excel():
    """
    Genera y devuelve el libro Excel completo del cálculo de túnel.
    Body JSON:
        <parámetros normales del túnel>  +
        luminaire: { ... }  (opcional — si viene, incluye hoja Luminarias)
        road_width_m: float (opcional)
    """
    try:
        import io
        from modules.tunnel.excel_export import generate_excel

        data = request.get_json()
        if not data:
            return jsonify({'success': False, 'error': 'No se recibieron datos JSON'}), 400

        # Cálculo completo del túnel
        result = run_tunnel_calculation(data)
        if not result.get('success'):
            return jsonify(result), 422

        # Luminarias (opcionales)
        lum_dict = None
        if data.get('luminaire'):
            try:
                from modules.tunnel.luminaires import calculate_luminaire_layout
                zones_raw    = result.get('zones', {})
                zones_list   = list(zones_raw.values()) if isinstance(zones_raw, dict) else zones_raw
                road_width_m = float(data.get('road_width_m', data.get('width_m', 7.0)))
                tube_length  = float(result['summary'].get('length_m', 300))
                tube_id      = result['summary'].get('tube_id', 'T1')
                lum_r = calculate_luminaire_layout(
                    zones_list       = zones_list,
                    luminaire_params = data['luminaire'],
                    road_width_m     = road_width_m,
                    tube_length_m    = tube_length,
                    tube_id          = tube_id,
                )
                lum_dict = lum_r.to_dict()
            except Exception:
                pass  # Si falla la hoja de luminarias, el Excel sigue generándose

        xls_bytes = generate_excel(result, data, lum_dict)

        tube_id  = result.get('summary', {}).get('tube_id', 'T1')
        filename = f"calculo_tunel_{tube_id}.xlsx"

        return send_file(
            io.BytesIO(xls_bytes),
            as_attachment=True,
            download_name=filename,
            mimetype='application/vnd.openxmlformats-officedocument.spreadsheetml.sheet'
        )

    except Exception as e:
        import traceback
        return jsonify({
            'success': False,
            'error': str(e),
            'traceback': traceback.format_exc()
        }), 500


@app.route('/api/tunnel/export-excel-combined', methods=['POST'])
def tunnel_export_excel_combined():
    """
    Genera un Excel con todos los tubos, cada uno en sus propias hojas.
    Body JSON:
        tubes: { T1: { form: {...} }, T2: { form: {...} }, ... }
    """
    try:
        import io
        from modules.tunnel.excel_export import generate_excel_combined

        data = request.get_json()
        if not data or not data.get('tubes'):
            return jsonify({'success': False, 'error': 'Se requiere "tubes"'}), 400

        tubes_data = []
        for tube_id, tube in data['tubes'].items():
            form   = tube.get('form', {})
            result = run_tunnel_calculation(form)
            if not result.get('success'):
                return jsonify({'success': False,
                                'error': f'Error calculando tubo {tube_id}: {result.get("errors")}'}), 422
            tubes_data.append({'result': result, 'params': form})

        xls_bytes = generate_excel_combined(tubes_data)
        project   = (data.get('project_name') or 'tunel').replace(' ', '_')[:40]
        filename  = f"calculo_{project}_completo.xlsx"

        return send_file(
            io.BytesIO(xls_bytes),
            as_attachment=True,
            download_name=filename,
            mimetype='application/vnd.openxmlformats-officedocument.spreadsheetml.sheet'
        )

    except Exception as e:
        import traceback
        return jsonify({'success': False, 'error': str(e),
                        'traceback': traceback.format_exc()}), 500


@app.route('/api/tunnel/report-combined', methods=['POST'])
def tunnel_report_combined():
    """
    Genera un informe Word combinado con todos los tubos del proyecto.
    Body JSON:
        tubes: { T1: { form: {...} }, T2: { form: {...} }, ... }
        project_name: str (opcional)
    """
    try:
        import io
        from modules.tunnel.report import generate_combined_report

        data = request.get_json()
        if not data or not data.get('tubes'):
            return jsonify({'success': False, 'error': 'Se requiere "tubes"'}), 400

        tubes_raw    = data['tubes']
        project_name = data.get('project_name', '')

        tubes_data = []
        for tube_id, tube in tubes_raw.items():
            form = tube.get('form', {})
            result = run_tunnel_calculation(form)
            if not result.get('success'):
                return jsonify({'success': False,
                                'error': f'Error calculando tubo {tube_id}: {result.get("errors")}'}), 422

            # ── Verificación fotométrica CIE 140 por tubo ──────────────────
            photometric = None
            try:
                from modules.tunnel.luminaires import calculate_luminaire_layout
                from modules.tunnel.photometric_verify import verify_luminaire_result
                luminaire_raw = form.get('luminaire', {})
                if luminaire_raw.get('I_max_mA') or luminaire_raw.get('cct'):
                    lum_params = dict(luminaire_raw)
                    lum_params['speed_kmh'] = float(form.get('speed_kmh', 80))
                    lum_params['Lth']       = float(result['summary'].get('Lth', 0))
                    lum_params['Lin']       = float(result['summary'].get('Lin', 0))
                    zones_raw  = result.get('zones', {})
                    zones_list = list(zones_raw.values()) if isinstance(zones_raw, dict) else zones_raw
                    lum_r = calculate_luminaire_layout(
                        zones_list       = zones_list,
                        luminaire_params = lum_params,
                        road_width_m     = float(form.get('road_width_m', form.get('width_m', 7.0))),
                        tube_length_m    = float(result['summary'].get('length_m', 300)),
                        tube_id          = tube_id,
                    )
                    photometric = verify_luminaire_result(lum_r, lum_params)
            except Exception:
                photometric = None

            tubes_data.append({'result': result, 'params': form, 'photometric': photometric})

        doc_bytes = generate_combined_report(tubes_data, project_name=project_name)

        safe_name = (project_name or 'tunel').replace(' ', '_').replace('/', '_')[:40]
        filename  = f"informe_{safe_name}_completo.docx"

        return send_file(
            io.BytesIO(doc_bytes),
            as_attachment=True,
            download_name=filename,
            mimetype='application/vnd.openxmlformats-officedocument.wordprocessingml.document'
        )

    except Exception as e:
        import traceback
        return jsonify({'success': False, 'error': str(e),
                        'traceback': traceback.format_exc()}), 500


@app.route('/api/tunnel/luminaires', methods=['POST'])
def tunnel_luminaires():
    """
    Calcula el diseño de luminarias por zona (espaciado, nº, potencia).
    Body JSON:
        <parámetros normales del túnel>  +
        luminaire: { flux_lm, power_w, efficiency, mounting_height_m,
                     arrangement, maintenance_factor, name, road_surface }
        road_width_m: float
    """
    try:
        from modules.tunnel.luminaires import calculate_luminaire_layout

        data = request.get_json()
        if not data:
            return jsonify({'success': False, 'error': 'No se recibieron datos JSON'}), 400

        # Calcular el túnel completo para obtener las zonas
        result = run_tunnel_calculation(data)
        if not result.get('success'):
            return jsonify(result), 422

        zones_raw   = result.get('zones', {})
        zones_list  = list(zones_raw.values()) if isinstance(zones_raw, dict) else zones_raw

        luminaire_params = dict(data.get('luminaire', {}))
        # Pasar velocidad y luminancias CIE 88 al módulo de luminarias
        # para que pueda calcular el perfil exacto de la zona de transición
        luminaire_params['speed_kmh']      = float(data.get('speed_kmh', 80))
        luminaire_params['Lth']             = float(result['summary'].get('Lth', 0))
        luminaire_params['Lin']             = float(result['summary'].get('Lin', 0))
        luminaire_params['tilt_overrides']  = data.get('tilt_overrides', {}) or {}
        road_width_m     = float(data.get('road_width_m', data.get('width_m', 7.0)))
        tube_length_m    = float(result['summary'].get('length_m', 300))
        tube_id          = result['summary'].get('tube_id', 'T1')

        lum_result = calculate_luminaire_layout(
            zones_list       = zones_list,
            luminaire_params = luminaire_params,
            road_width_m     = road_width_m,
            tube_length_m    = tube_length_m,
            tube_id          = tube_id,
        )

        # ── Verificación fotométrica CIE 140:2019 ──────────────────────────
        photometric = {}
        try:
            from modules.tunnel.photometric_verify import verify_luminaire_result
            photometric = verify_luminaire_result(lum_result, luminaire_params)
        except Exception as pe:
            photometric = {"available": False, "error": str(pe)}

        return jsonify({
            'success': True,
            'luminaires': lum_result.to_dict(),
            'photometric': photometric,
            'summary': result.get('summary', {}),
        })

    except Exception as e:
        import traceback
        return jsonify({
            'success': False,
            'error': str(e),
            'traceback': traceback.format_exc()
        }), 500


@app.route('/api/tunnel/report', methods=['POST'])
def tunnel_report():
    """
    Genera el informe técnico Word (CIE 88:2004 + CIE 140:2019) y lo devuelve como descarga.
    Body JSON: mismos parámetros que /api/tunnel/calculate, más opcionalmente
    los parámetros de luminarias (luminaire.*) para incluir verificación CIE 140.
    """
    try:
        import io
        from modules.tunnel.report import generate_report

        data = request.get_json()
        if not data:
            return jsonify({'success': False, 'error': 'No se recibieron datos JSON'}), 400

        # Calcular resultado CIE 88 completo
        result = run_tunnel_calculation(data)
        if not result.get('success'):
            return jsonify(result), 422

        # ── Verificación fotométrica CIE 140 (si hay parámetros de luminaria) ──
        photometric = None
        try:
            from modules.tunnel.luminaires import calculate_luminaire_layout
            from modules.tunnel.photometric_verify import verify_luminaire_result

            luminaire_raw = data.get('luminaire', {})
            if luminaire_raw.get('I_max_mA') or luminaire_raw.get('cct'):
                luminaire_params = dict(luminaire_raw)
                luminaire_params['speed_kmh'] = float(data.get('speed_kmh', 80))
                luminaire_params['Lth']       = float(result['summary'].get('Lth', 0))
                luminaire_params['Lin']       = float(result['summary'].get('Lin', 0))

                zones_raw  = result.get('zones', {})
                zones_list = list(zones_raw.values()) if isinstance(zones_raw, dict) else zones_raw
                road_width = float(data.get('road_width_m', data.get('width_m', 7.0)))
                tube_len   = float(result['summary'].get('length_m', 300))
                tube_id_l  = result['summary'].get('tube_id', 'T1')

                lum_result = calculate_luminaire_layout(
                    zones_list       = zones_list,
                    luminaire_params = luminaire_params,
                    road_width_m     = road_width,
                    tube_length_m    = tube_len,
                    tube_id          = tube_id_l,
                )
                photometric = verify_luminaire_result(lum_result, luminaire_params)
        except Exception:
            photometric = None  # informe sin CIE 140, no es error critico

        # Generar documento Word
        docx_bytes = generate_report(result, data, photometric=photometric)

        tube_id = result.get('summary', {}).get('tube_id', 'T1')
        filename = f"informe_tunel_{tube_id}.docx"

        return send_file(
            io.BytesIO(docx_bytes),
            as_attachment=True,
            download_name=filename,
            mimetype='application/vnd.openxmlformats-officedocument.wordprocessingml.document'
        )

    except Exception as e:
        import traceback
        return jsonify({
            'success': False,
            'error': str(e),
            'traceback': traceback.format_exc()
        }), 500


@app.route('/api/tunnel/osm-proxy', methods=['POST'])
def tunnel_osm_proxy():
    """
    Proxy servidor->Overpass usando urllib (stdlib, sin dependencias externas).
    Body JSON: { "query": "<QL string>" }
    Prueba 3 endpoints en orden; devuelve el primero que responda.
    """
    import urllib.request
    import urllib.parse
    import urllib.error
    import json as _json

    ENDPOINTS = [
        'https://overpass-api.de/api/interpreter',
        'https://overpass.kumi.systems/api/interpreter',
        'https://maps.mail.ru/osm/tools/overpass/api/interpreter',
    ]
    TIMEOUT = 28  # segundos

    try:
        body = request.get_json(silent=True) or {}
        query = body.get('query', '')
        if not query:
            return jsonify({'success': False, 'error': 'Falta el parametro "query"'}), 400

        last_err = 'Sin respuesta'
        for ep in ENDPOINTS:
            try:
                # Overpass espera POST con parámetro de formulario "data=<query>"
                post_data = urllib.parse.urlencode({'data': query}).encode('utf-8')
                req = urllib.request.Request(
                    ep, data=post_data,
                    headers={'User-Agent': 'SALVI-TunnelEngine/1.0',
                             'Content-Type': 'application/x-www-form-urlencoded'}
                )
                with urllib.request.urlopen(req, timeout=TIMEOUT) as resp:
                    raw = resp.read()
                    return jsonify(_json.loads(raw))
            except urllib.error.HTTPError as e:
                last_err = f'HTTP {e.code} desde {ep}'
            except urllib.error.URLError as e:
                last_err = f'Timeout/red en {ep}: {e.reason}'
            except Exception as exc:
                last_err = f'{ep}: {exc}'

        return jsonify({'success': False, 'error': f'Overpass no disponible. {last_err}'}), 502

    except Exception as e:
        import traceback
        return jsonify({'success': False, 'error': str(e),
                        'traceback': traceback.format_exc()}), 500


@app.route('/api/debug/files', methods=['GET'])
def debug_files():
    """Debug endpoint para verificar que los archivos estan accesibles"""
    assets_folder = os.path.join(os.path.dirname(__file__), 'assets')
    files_info = {}
    if os.path.exists(assets_folder):
        for f in os.listdir(assets_folder):
            fp = os.path.join(assets_folder, f)
            files_info[f] = {'size': os.path.getsize(fp), 'exists': True}

    download_folder = os.path.join(os.path.dirname(__file__), 'downloads')
    downloads = []
    if os.path.exists(download_folder):
        downloads = os.listdir(download_folder)

    return jsonify({
        'assets': files_info,
        'downloads': downloads,
        'upload_folder': UPLOAD_FOLDER,
        'download_folder': DOWNLOAD_FOLDER,
    })


@app.errorhandler(413)
def request_entity_too_large(error):
    return jsonify({'success': False, 'error': 'Archivo demasiado grande (max 50MB)'}), 413

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5000, debug=True)
