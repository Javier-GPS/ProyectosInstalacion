"""
SALVI Tunnel Engine — Módulo de Cálculo de Luminarias APHEX
Algoritmo inside-out (CIE 88:2004): diseña desde la zona interior (menor
luminancia requerida) hacia la boca de entrada (mayor luminancia), manteniendo
el espaciado fijo y aumentando corriente/modelo según sea necesario.

Cadena APHEX:  S/50G → M/100G → L/150G
Corrientes:    350 mA → 500 mA → 750 mA (≤ I_max del proyecto)
Ópticas:       F151 (w/h < 0.8)  · F2M2 (0.8 ≤ w/h < 1.6)  · F2MD (w/h ≥ 1.6)

Tablas UF/Ul: calculadas a partir de los ficheros LDT de fotometría real de
las ópticas METRO M H50 (F2M2, F2MD, F151) — cálculo por integración directa.

Referencias:
    CIE 88:2004 §15–16 (criterios de luminancia en túneles)
    Eulumdat photometry files — SALVI (Julio 2026)
"""

import math
from dataclasses import dataclass, field
from typing import List, Dict, Optional, Tuple


# ══════════════════════════════════════════════════════════════════════════════
# SUPERFICIES DE CALZADA
# ══════════════════════════════════════════════════════════════════════════════

ROAD_SURFACES: Dict[str, dict] = {
    "dark_asphalt":   {"label": "Asfalto oscuro (R3)",       "rho": 0.065},
    "medium_asphalt": {"label": "Asfalto medio (R2)",         "rho": 0.085},
    "light_asphalt":  {"label": "Asfalto claro (R1)",         "rho": 0.105},
    "concrete":       {"label": "Hormigón (C1/C2)",           "rho": 0.140},
    "bright_concrete":{"label": "Hormigón claro",             "rho": 0.165},
}

DEFAULT_MF = 0.70

# ══════════════════════════════════════════════════════════════════════════════
# ARREGLOS DE LUMINARIAS
# ══════════════════════════════════════════════════════════════════════════════

ARRANGEMENTS = {
    "central_single": {"label": "Fila central única (eje)",           "n_rows": 1, "lut_key": "central"},
    "central_offset": {"label": "Fila central desplazada del eje",    "n_rows": 1, "lut_key": "central"},
    "central_double": {"label": "Doble fila central",                 "n_rows": 2, "lut_key": "central"},
    "lateral_left":   {"label": "Lateral izquierda (sentido marcha)", "n_rows": 1, "lut_key": "lateral_right"},
    "lateral_right":  {"label": "Lateral derecha (sentido marcha)",   "n_rows": 1, "lut_key": "lateral_right"},
    "bilateral_sym":  {"label": "Bilateral simétrico",                "n_rows": 2, "lut_key": "lateral_right"},
    "bilateral_stag": {"label": "Bilateral en tresbolillo",           "n_rows": 2, "lut_key": "lateral_right"},
    # Legacy
    "bilateral":      {"label": "Bilateral",                          "n_rows": 2, "lut_key": "lateral_right"},
    "unilateral":     {"label": "Unilateral",                         "n_rows": 1, "lut_key": "lateral_right"},
    "staggered":      {"label": "Tresbolillo",                        "n_rows": 2, "lut_key": "lateral_right"},
}


# ══════════════════════════════════════════════════════════════════════════════
# CATÁLOGO APHEX  (verificado contra hoja técnica — Julio 2026)
#
# Cadena S→M→L: sin solape en la unión S/M (M@350mA > S@750mA).
# Nota de producto: L@350mA (56.825/60.559 klm) < M@750mA (73.305/78.123 klm)
#   → el algoritmo inside-out lo gestiona correctamente: al no cubrir el requisito
#     con L@350mA pasa a L@500mA. L@350mA solo se selecciona para requisitos en
#     el rango 56.826–73.304 klm donde M@500mA tampoco llega.
# ══════════════════════════════════════════════════════════════════════════════

APHEX_CATALOG: Dict[str, dict] = {
    "S": {
        "pcb":   "50G",
        "label": "Aphex S",
        "dims_mm": (472, 400, 90),
        "operating_points": {
            "3000K": [
                {"mA": 350, "W":  97, "lm": 18941},
                {"mA": 500, "W": 143, "lm": 26057},
                {"mA": 750, "W": 223, "lm": 36652},
            ],
            "4000K": [
                {"mA": 350, "W":  97, "lm": 20186},
                {"mA": 500, "W": 143, "lm": 27769},
                {"mA": 750, "W": 223, "lm": 39061},
            ],
        },
    },
    "M": {
        "pcb":   "100G",
        "label": "Aphex M",
        "dims_mm": None,
        "operating_points": {
            "3000K": [
                {"mA": 350, "W": 194, "lm": 37883},
                {"mA": 500, "W": 286, "lm": 52114},
                {"mA": 750, "W": 446, "lm": 73305},
            ],
            "4000K": [
                {"mA": 350, "W": 194, "lm": 40372},
                {"mA": 500, "W": 286, "lm": 55539},
                {"mA": 750, "W": 446, "lm": 78123},
            ],
        },
    },
    "L": {
        "pcb":   "150G",
        "label": "Aphex L",
        "dims_mm": None,
        "operating_points": {
            "3000K": [
                {"mA": 350, "W": 292, "lm":  56825},
                {"mA": 500, "W": 429, "lm":  78122},
                {"mA": 750, "W": 670, "lm": 109958},
            ],
            "4000K": [
                {"mA": 350, "W": 292, "lm":  60559},
                {"mA": 500, "W": 429, "lm":  83309},
                {"mA": 750, "W": 670, "lm": 117184},
            ],
        },
    },
}

# Orden de la cadena S → M → L
APHEX_CHAIN_ORDER = ["S", "M", "L"]


# ══════════════════════════════════════════════════════════════════════════════
# TABLAS UF Y d/h_max  (calculadas desde LDT reales — integración directa)
#
# UF: factor de utilización por fila de luminarias (fracción de flujo que
#     llega a la calzada) — casi constante con d/h, se usa valor a d/h=2.0.
# dh_max: máximo d/h que cumple Ul ≥ 0.6 (CIE 88:2004)
#
# Clave de wh: relación ancho_calzada / altura_montaje
# ══════════════════════════════════════════════════════════════════════════════

# Factor de utilización representativo por óptica, arreglo y relación w/h
# Interpolación lineal para valores intermedios de w/h
_UF_TABLE: Dict[str, Dict[str, Dict[str, float]]] = {
    "F2M2": {
        "central": {
            "0.5": 0.2504, "0.8": 0.3819, "1.0": 0.4608,
            "1.2": 0.5334, "1.5": 0.6310, "2.0": 0.7598,
            "2.5": 0.8464, "3.0": 0.8999,
        },
        "lateral_right": {
            "0.5": 0.1993, "0.8": 0.2639, "1.0": 0.2929,
            "1.2": 0.3143, "1.5": 0.3362, "2.0": 0.3559,
            "2.5": 0.3653, "3.0": 0.3701,
        },
    },
    "F2MD": {
        "central": {
            "0.5": 0.2590, "0.8": 0.3819, "1.0": 0.4510,
            "1.2": 0.5162, "1.5": 0.6116, "2.0": 0.7525,
            "2.5": 0.8520, "3.0": 0.9120,
        },
        "lateral_right": {
            "0.5": 0.1615, "0.8": 0.1781, "1.0": 0.1840,
            "1.2": 0.1885, "1.5": 0.1935, "2.0": 0.1987,
            "2.5": 0.2015, "3.0": 0.2031,
        },
    },
    "F151": {
        "central": {
            "0.5": 0.2329, "0.8": 0.3766, "1.0": 0.4656,
            "1.2": 0.5469, "1.5": 0.6539, "2.0": 0.7850,
            "2.5": 0.8632, "3.0": 0.9094,
        },
        "lateral_right": {
            "0.5": 0.1112, "0.8": 0.1333, "1.0": 0.1435,
            "1.2": 0.1511, "1.5": 0.1588, "2.0": 0.1664,
            "2.5": 0.1713, "3.0": 0.1742,
        },
    },
}

# Máximo d/h para Ul ≥ 0.6
_DH_MAX_TABLE: Dict[str, Dict[str, Dict[str, float]]] = {
    "F2M2": {
        "central": {
            "0.5": 2.64, "0.8": 2.64, "1.0": 2.64,
            "1.2": 2.64, "1.5": 2.64, "2.0": 2.64,
            "2.5": 2.64, "3.0": 2.64,
        },
        "lateral_right": {
            "0.5": 2.67, "0.8": 2.67, "1.0": 2.67,
            "1.2": 2.67, "1.5": 2.67, "2.0": 2.67,
            "2.5": 2.67, "3.0": 2.67,
        },
    },
    "F2MD": {
        "central": {
            "0.5": 2.83, "0.8": 2.83, "1.0": 2.83,
            "1.2": 2.83, "1.5": 2.31, "2.0": 2.31,
            "2.5": 2.31, "3.0": 2.32,
        },
        "lateral_right": {
            "0.5": 2.83, "0.8": 2.31, "1.0": 2.31,
            "1.2": 2.31, "1.5": 2.31, "2.0": 2.31,
            "2.5": 2.31, "3.0": 2.31,
        },
    },
    "F151": {
        "central": {
            "0.5": 2.07, "0.8": 2.07, "1.0": 2.08,
            "1.2": 2.07, "1.5": 2.07, "2.0": 2.07,
            "2.5": 2.08, "3.0": 2.08,
        },
        "lateral_right": {
            "0.5": 2.49, "0.8": 2.49, "1.0": 2.49,
            "1.2": 2.49, "1.5": 2.49, "2.0": 2.49,
            "2.5": 2.38, "3.0": 2.38,
        },
    },
}

_WH_BREAKPOINTS = [0.5, 0.8, 1.0, 1.2, 1.5, 2.0, 2.5, 3.0]


def _interp_wh(table_by_wh: Dict[str, float], wh: float) -> float:
    """Interpolación lineal de UF o dh_max según w/h."""
    wh = max(0.5, min(wh, 3.0))
    bps = _WH_BREAKPOINTS
    if wh <= bps[0]:
        return table_by_wh[f"{bps[0]:.1f}"]
    if wh >= bps[-1]:
        return table_by_wh[f"{bps[-1]:.1f}"]
    for i in range(len(bps) - 1):
        lo, hi = bps[i], bps[i + 1]
        if lo <= wh <= hi:
            t = (wh - lo) / (hi - lo)
            v_lo = table_by_wh[f"{lo:.1f}"]
            v_hi = table_by_wh[f"{hi:.1f}"]
            return v_lo + t * (v_hi - v_lo)
    return table_by_wh[f"{bps[-1]:.1f}"]


def _lut_key(arrangement: str) -> str:
    return ARRANGEMENTS.get(arrangement, {}).get("lut_key", "central")


def lookup_uf(optic: str, wh: float, arrangement: str) -> float:
    """Devuelve el factor de utilización (UF) para óptica, geometría y arreglo."""
    key = _lut_key(arrangement)
    tbl = _UF_TABLE.get(optic, _UF_TABLE["F2M2"]).get(key, {})
    return _interp_wh(tbl, wh)


def lookup_dh_max(optic: str, wh: float, arrangement: str) -> float:
    """Devuelve el máximo d/h que cumple Ul ≥ 0.6."""
    key = _lut_key(arrangement)
    tbl = _DH_MAX_TABLE.get(optic, _DH_MAX_TABLE["F2M2"]).get(key, {})
    return _interp_wh(tbl, wh)


def auto_select_optic(optic_pref: str, wh: float) -> str:
    """Selección automática de óptica según relación w/h."""
    if optic_pref not in ("auto", ""):
        return optic_pref
    if wh < 0.8:
        return "F151"
    if wh < 1.6:
        return "F2M2"
    return "F2MD"


def _interp_op(ops: List[dict], target_lm: float) -> dict:
    """
    Interpolación lineal por tramos entre los puntos de operación (350/500/750 mA)
    para obtener la corriente exacta que produce target_lm.
    Devuelve {mA, W, lm} interpolados.
    """
    if target_lm <= ops[0]["lm"]:
        return dict(ops[0])
    if target_lm >= ops[-1]["lm"]:
        return dict(ops[-1])
    for i in range(len(ops) - 1):
        lo, hi = ops[i], ops[i + 1]
        if lo["lm"] <= target_lm <= hi["lm"]:
            t = (target_lm - lo["lm"]) / (hi["lm"] - lo["lm"])
            return {
                "mA": round(lo["mA"] + t * (hi["mA"] - lo["mA"])),
                "W":  round(lo["W"]  + t * (hi["W"]  - lo["W"]),  1),
                "lm": target_lm,
            }
    return dict(ops[-1])


def select_aphex_continuous(
    phi_required: float,
    cct:          str,
    I_max_mA:     int,
) -> dict:
    """
    Selección continua S→M→L con interpolación lineal por tramos.

    Dentro de cada modelo la corriente varía libremente entre 350 mA e I_max_mA
    (sin saltos discretos). Se usa el primer modelo cuyo rango [lm_min, lm_max]
    cubre phi_required. Si phi_required < lm_min del modelo actual se devuelve
    ese modelo a corriente mínima (350 mA). Si supera todos los modelos se
    devuelve L a I_max_mA (insuficiente → el llamador reduce el espaciado).

    Devuelve: {model, pcb, label, mA, W, lm}
    """
    for model_key in APHEX_CHAIN_ORDER:
        cat  = APHEX_CATALOG[model_key]
        ops  = cat["operating_points"].get(cct, [])
        if not ops:
            continue

        # Recortar a I_max_mA (interpolando el punto límite si queda entre dos)
        valid_ops = [op for op in ops if op["mA"] <= I_max_mA]
        if not valid_ops:
            # I_max_mA < 350 mA — usar mínimo disponible
            valid_ops = [ops[0]]

        # Si I_max_mA queda entre dos puntos de catálogo, añadir punto interpolado
        max_cat_mA = valid_ops[-1]["mA"]
        if max_cat_mA < I_max_mA and len(ops) > len(valid_ops):
            next_op = ops[len(valid_ops)]
            lo, hi  = valid_ops[-1], next_op
            t_cut   = (I_max_mA - lo["mA"]) / (hi["mA"] - lo["mA"])
            valid_ops.append({
                "mA": I_max_mA,
                "W":  round(lo["W"] + t_cut * (hi["W"] - lo["W"]), 1),
                "lm": round(lo["lm"] + t_cut * (hi["lm"] - lo["lm"]), 0),
            })

        lm_max = valid_ops[-1]["lm"]

        if phi_required <= lm_max:
            interp = _interp_op(valid_ops, phi_required)
            return {
                "model": model_key,
                "pcb":   cat["pcb"],
                "label": cat["label"],
                **interp,
            }

    # phi_required supera todos los modelos → L a I_max_mA
    cat     = APHEX_CATALOG["L"]
    ops     = cat["operating_points"].get(cct, [])
    valid_ops = [op for op in ops if op["mA"] <= I_max_mA] or [ops[0]]
    if I_max_mA < valid_ops[-1]["mA"] and len(ops) > len(valid_ops):
        next_op = ops[len(valid_ops)]
        lo, hi  = valid_ops[-1], next_op
        t_cut   = (I_max_mA - lo["mA"]) / (hi["mA"] - lo["mA"])
        valid_ops.append({
            "mA": I_max_mA,
            "W":  round(lo["W"] + t_cut * (hi["W"] - lo["W"]), 1),
            "lm": round(lo["lm"] + t_cut * (hi["lm"] - lo["lm"]), 0),
        })
    max_op = valid_ops[-1]
    return {
        "model": "L",
        "pcb":   cat["pcb"],
        "label": cat["label"],
        "mA":    max_op["mA"],
        "W":     max_op["W"],
        "lm":    max_op["lm"],
    }


def build_aphex_chain(cct: str, I_max_mA: int) -> List[dict]:
    """Compat: devuelve los extremos de cada modelo para fijar el espaciado interior."""
    chain = []
    for model in APHEX_CHAIN_ORDER:
        cat = APHEX_CATALOG[model]
        ops = [op for op in cat["operating_points"].get(cct, []) if op["mA"] <= I_max_mA]
        if ops:
            chain.append({
                "model": model, "pcb": cat["pcb"], "label": cat["label"],
                "mA": ops[0]["mA"], "W": ops[0]["W"], "lm": ops[0]["lm"],
            })
    chain.sort(key=lambda x: x["lm"])
    return chain


# ══════════════════════════════════════════════════════════════════════════════
# DATACLASSES
# ══════════════════════════════════════════════════════════════════════════════

@dataclass
class ZoneLuminaireDesign:
    """Diseño de luminarias para una zona del túnel — algoritmo inside-out."""
    zone_type:      str
    zone_name:      str
    s_start:        float
    s_end:          float
    zone_length:    float
    L_required:     float
    E_required:     float
    # Selección de luminaria
    model:          str       # S, M, L
    pcb:            str       # 50G, 100G, 150G
    current_mA:     int
    flux_lm:        float     # flujo por luminaria (lm)
    power_w:        float     # potencia por luminaria (W)
    optic:          str       # F2M2, F2MD, F151
    # Diseño espacial
    d_max_ul:       float     # máximo espaciado por Ul (m)
    d_used:         float     # espaciado efectivo (m)
    n_luminaires:   int       # luminarias en la zona
    # Resultados
    L_estimated:    float
    UF:             float
    # Potencias
    power_zone_w:   float
    flux_zone_lm:   float
    power_density_wm2: float
    # Retrocompat
    d_max:          float = 0.0   # alias de d_used (para motor de cálculo)
    # Perfil por luminaria (solo zonas de transición — DALI individual)
    setpoints:      List[dict] = field(default_factory=list)
    tilt_deg:       float = 0.0   # inclinación hacia el portal (°)

    def to_dict(self) -> dict:
        def _s(v, d=2):
            if v is None or (isinstance(v, float) and not math.isfinite(v)):
                return None
            return round(v, d)
        return {
            "zone_type":          self.zone_type,
            "zone_name":          self.zone_name,
            "s_start":            self.s_start,
            "s_end":              self.s_end,
            "zone_length":        _s(self.zone_length, 1),
            "L_required":         _s(self.L_required, 1),
            "E_required":         _s(self.E_required, 1),
            "model":              self.model,
            "pcb":                self.pcb,
            "current_mA":         self.current_mA,
            "flux_lm":            _s(self.flux_lm, 0),
            "power_w":            _s(self.power_w, 0),
            "optic":              self.optic,
            "d_max_ul":           _s(self.d_max_ul, 2),
            "d_used":             _s(self.d_used, 2),
            "d_max":              _s(self.d_used, 2),
            "n_luminaires":       self.n_luminaires,
            "L_estimated":        _s(self.L_estimated, 1),
            "UF":                 _s(self.UF, 4),
            "power_zone_w":       _s(self.power_zone_w, 0),
            "flux_zone_lm":       _s(self.flux_zone_lm, 0),
            "power_density_wm2":  _s(self.power_density_wm2, 2),
            "margin_pct":         round((self.L_estimated / self.L_required - 1) * 100, 1)
                                  if self.L_required > 0 else 0,
            "setpoints":          self.setpoints,   # lista vacía salvo en transiciones
            "tilt_deg":           _s(self.tilt_deg, 1),
        }


@dataclass
class LuminaireSpec:
    """Parámetros de la luminaria (compat con API existente)."""
    flux_lm:           float
    power_w:           float
    efficiency:        float
    mounting_height_m: float
    arrangement:       str
    maintenance_factor: float = DEFAULT_MF
    name:              str = ""

    @property
    def n_rows(self) -> int:
        return ARRANGEMENTS.get(self.arrangement, {}).get("n_rows", 1)

    @property
    def efficacy_lm_w(self) -> float:
        return self.flux_lm / self.power_w if self.power_w > 0 else 0.0

    def to_dict(self) -> dict:
        return {
            "name":              self.name,
            "flux_lm":           self.flux_lm,
            "power_w":           self.power_w,
            "efficiency":        self.efficiency,
            "mounting_height_m": self.mounting_height_m,
            "arrangement":       self.arrangement,
            "arrangement_label": ARRANGEMENTS.get(self.arrangement, {}).get("label", self.arrangement),
            "n_rows":            self.n_rows,
            "maintenance_factor":self.maintenance_factor,
            "efficacy_lm_w":     round(self.efficacy_lm_w, 1),
        }


@dataclass
class TunnelLuminaireResult:
    """Resultado completo del cálculo de luminarias."""
    tube_id:            str
    luminaire:          Optional[LuminaireSpec]
    road_surface_type:  str
    rho_eff:            float
    road_width_m:       float
    tube_length_m:      float
    optic:              str = ""
    cct:                str = ""
    I_max_mA:           int = 750
    arrangement:        str = ""
    zones:              List[ZoneLuminaireDesign] = field(default_factory=list)
    total_luminaires:   int   = 0
    total_power_w:      float = 0.0
    total_flux_lm:      float = 0.0
    avg_power_density_wm2: float = 0.0
    total_power_kw:     float = 0.0
    warnings:           List[str] = field(default_factory=list)

    def _compute_totals(self):
        self.total_luminaires = sum(z.n_luminaires for z in self.zones)
        self.total_power_w    = sum(z.power_zone_w  for z in self.zones)
        self.total_flux_lm    = sum(z.flux_zone_lm  for z in self.zones)
        self.total_power_kw   = round(self.total_power_w / 1000, 2)
        area = self.tube_length_m * self.road_width_m
        self.avg_power_density_wm2 = round(self.total_power_w / area if area > 0 else 0, 2)

    def to_dict(self) -> dict:
        return {
            "tube_id":       self.tube_id,
            "luminaire":     self.luminaire.to_dict() if self.luminaire else None,
            "optic":         self.optic,
            "cct":           self.cct,
            "I_max_mA":      self.I_max_mA,
            "arrangement":   self.arrangement,
            "road_surface":  {
                "type":  self.road_surface_type,
                "label": ROAD_SURFACES.get(self.road_surface_type, {}).get("label", ""),
                "rho":   self.rho_eff,
            },
            "road_width_m":  self.road_width_m,
            "tube_length_m": self.tube_length_m,
            "zones":         [z.to_dict() for z in self.zones],
            "totals": {
                "n_luminaires":      self.total_luminaires,
                "power_kw":          self.total_power_kw,
                "flux_lm":           round(self.total_flux_lm, 0),
                "power_density_wm2": self.avg_power_density_wm2,
                "installed_lm_per_m": round(
                    self.total_flux_lm / self.tube_length_m
                    if self.tube_length_m > 0 else 0, 1
                ),
            },
            "warnings": self.warnings,
        }


# ══════════════════════════════════════════════════════════════════════════════
# ALGORITMO INSIDE-OUT
# ══════════════════════════════════════════════════════════════════════════════

def _luminance(flux_lm: float, n_rows: int, uf: float, mf: float,
               rho_eff: float, d: float, w: float) -> float:
    """
    L [cd/m²] = Φ × n_rows × UF × MF × ρ_eff / (π × d × w)
    Fórmula de luminancia media CIE para calzada Lambertiana.
    """
    denom = math.pi * d * w
    return (flux_lm * n_rows * uf * mf * rho_eff / denom) if denom > 0 else 0.0


def _cie_L_transition(s: float, s_start: float, Lth: float, Lin: float,
                      speed_kmh: float) -> float:
    """
    Luminancia requerida en la zona de transición según CIE 88:2004 Fig. 6.6.
        L(t) = Lth × (1.9 + t)^(−1.4)
    donde t = tiempo desde inicio de transición = (s − s_start) / v_ms.
    Garantiza L ≥ Lin.
    """
    v_ms = max(speed_kmh / 3.6, 0.1)
    t    = max(0.0, (s - s_start) / v_ms)
    return max(Lth * (1.9 + t) ** (-1.4), Lin)



def _zone_tilt_deg(zone_type: str, L_required: float = 0.0, L_interior: float = 0.0) -> float:
    """Inclinación recomendada de luminarias APHEX por tipo de zona (grados).
    Las zonas de umbral y transición se inclinan hacia el portal para
    aumentar la luminancia efectiva en la zona de adaptación visual.
    """
    t = zone_type.lower()
    if 'interior' in t:
        return 0.0
    if 'exit' in t or 'salida' in t or 'access' in t or 'parting' in t:
        return 0.0
    if 'transition' in t:
        return 5.0
    if 'threshold' in t:
        ratio = L_required / max(L_interior, 1.0)
        if ratio >= 15: return 20.0
        if ratio >= 8:  return 15.0
        if ratio >= 3:  return 10.0
        return 5.0
    return 0.0


def _design_zone_aphex(
    zone_type:   str,
    zone_name:   str,
    s_start:     float,
    s_end:       float,
    L_required:  float,
    chain:       List[dict],   # solo se usa para fallback de zona nula
    d_global:    float,
    d_max_ul:    float,
    uf:          float,
    n_rows:      int,
    mf:          float,
    rho_eff:     float,
    w:           float,
    optic:       str,
    warnings:    List[str],
    cct:         str   = "4000K",
    I_max_mA:    int   = 750,
    speed_kmh:   float = 80.0,
    Lth:         float = 0.0,
    Lin:         float = 0.0,
    L_interior:  float = 0.0,
) -> ZoneLuminaireDesign:
    """
    Diseña una zona con selección CONTINUA de corriente (S→M→L).

    Zonas uniformes (umbral, interior, salida):
        Misma corriente en todas las luminarias. Espaciado = d_global; si la
        luminaria máxima no alcanza se reduce el espaciado.

    Zona de transición:
        Espaciado fijo = d_global (DALI permite dimming individual).
        Cada luminaria recibe la corriente exacta para producir la luminancia
        que indica la curva CIE 88:2004 en su posición.
        El ZoneLuminaireDesign retorna el perfil completo en `setpoints`.
    """
    zone_length = max(0.0, s_end - s_start)

    # Zona sin requisito de luminancia
    if L_required <= 0 or zone_length <= 0:
        op = chain[0] if chain else {"model": "S", "pcb": "50G", "mA": 350, "W": 97, "lm": 0, "label": "Aphex S"}
        return ZoneLuminaireDesign(
            zone_type=zone_type, zone_name=zone_name, s_start=s_start, s_end=s_end,
            zone_length=zone_length, L_required=L_required, E_required=0,
            model=op["model"], pcb=op["pcb"], current_mA=op["mA"],
            flux_lm=op["lm"], power_w=op["W"], optic=optic,
            d_max_ul=d_max_ul, d_used=0, n_luminaires=0,
            L_estimated=0, UF=uf, power_zone_w=0, flux_zone_lm=0, power_density_wm2=0,
            tilt_deg=0.0,
        )

    def phi_needed(d: float, L_req: float) -> float:
        denom = n_rows * uf * mf * rho_eff
        return (L_req * math.pi * d * w) / denom if denom > 0 else 1e9

    # Flujo máximo disponible (L @ I_max_mA)
    _ops_L   = APHEX_CATALOG["L"]["operating_points"].get(cct, [])
    _vops_L  = [op for op in _ops_L if op["mA"] <= I_max_mA] or [_ops_L[0]]
    lm_max_avail = _vops_L[-1]["lm"]

    # ── ZONA DE TRANSICIÓN: corriente individual CIE 88 por luminaria ──────
    is_transition = "transition" in zone_type.lower()
    if is_transition and Lth > 0 and Lin > 0 and speed_kmh > 0:

        # Determinar la corriente máxima necesaria (inicio de transición ~ Lth)
        phi_start = phi_needed(d_global, Lth)
        if phi_start > lm_max_avail:
            denom    = math.pi * w * Lth
            num      = lm_max_avail * n_rows * uf * mf * rho_eff
            d_try    = max(0.5, min(num / denom if denom > 0 else d_global, d_max_ul))
            warnings.append(
                f"Zona {zone_name}: Lth={Lth:.0f} cd/m² no alcanzable con Aphex L "
                f"{I_max_mA} mA al espaciado global — d reducido a {d_try:.1f} m"
            )
        else:
            d_try = d_global

        n_lum    = max(1, math.ceil(zone_length / d_try))
        d_actual = zone_length / n_lum

        # CIE 88 sentido de la transición (Portal A: Lth→Lin; Portal B: Lin→Lth)
        is_b = zone_type.lower() in ("transition_b",)

        setpoints = []
        pwr_zone  = 0.0
        flux_zone = 0.0
        L_sum     = 0.0

        for i in range(n_lum):
            # Posición central del hueco de la luminaria i
            if not is_b:
                s_i = s_start + (i + 0.5) * d_actual
                L_i = _cie_L_transition(s_i, s_start, Lth, Lin, speed_kmh)
            else:
                # Portal B: curva espejada → t medido desde el final
                s_i_mirror = s_end - (i + 0.5) * d_actual
                L_i = _cie_L_transition(s_end - s_i_mirror, s_start,
                                        Lth, Lin, speed_kmh)

            L_i   = max(L_i, Lin)
            phi_i = phi_needed(d_actual, L_i)
            op_i  = select_aphex_continuous(phi_i, cct, I_max_mA)

            pwr_zone  += op_i["W"]
            flux_zone += op_i["lm"]
            L_sum     += L_i
            setpoints.append({
                "idx":       i + 1,
                "s":         round(s_start + (i + 0.5) * d_actual, 1),
                "L_req":     round(L_i, 1),
                "model":     op_i["model"],
                "current_mA": op_i["mA"],
                "power_w":   op_i["W"],
                "flux_lm":   round(op_i["lm"], 0),
            })

        # Representativo: luminaria del extremo de mayor luminancia (inicio)
        dom     = setpoints[0] if not is_b else setpoints[-1]
        L_avg   = L_sum / n_lum
        area    = zone_length * w
        E_req   = L_required / rho_eff if rho_eff > 0 else 0.0

        return ZoneLuminaireDesign(
            zone_type=zone_type, zone_name=zone_name, s_start=s_start, s_end=s_end,
            zone_length=zone_length, L_required=L_required, E_required=round(E_req, 1),
            model=dom["model"], pcb=APHEX_CATALOG[dom["model"]]["pcb"],
            current_mA=dom["current_mA"],
            flux_lm=dom["flux_lm"], power_w=round(dom["power_w"], 1), optic=optic,
            d_max_ul=round(d_max_ul, 2), d_used=round(d_actual, 2),
            n_luminaires=n_lum, L_estimated=round(L_avg, 1),
            UF=round(uf, 4),
            power_zone_w=round(pwr_zone, 0),
            flux_zone_lm=round(flux_zone, 0),
            power_density_wm2=round(pwr_zone / area if area > 0 else 0, 3),
            d_max=round(d_actual, 2),
            setpoints=setpoints,
            tilt_deg=_zone_tilt_deg(zone_type, L_required, L_interior),
        )

    # ── ZONAS UNIFORMES (umbral, interior, salida) ──────────────────────────
    d_try = d_global
    phi   = phi_needed(d_try, L_required)

    D_MIN = 2.5   # m — espaciado mínimo práctico para luminarias de túnel

    if phi > lm_max_avail:
        denom     = math.pi * w * L_required
        num       = lm_max_avail * n_rows * uf * mf * rho_eff
        d_optimal = num / denom if denom > 0 else d_global
        d_try     = max(D_MIN, min(d_optimal, d_max_ul))
        phi       = phi_needed(d_try, L_required)

        if d_optimal < D_MIN:
            # L_required inalcanzable incluso al espaciado mínimo práctico
            L_max_at_dmin = _luminance(lm_max_avail, n_rows, uf, mf, rho_eff, D_MIN, w)
            warnings.append(
                f"⚠️ ZONA {zone_name}: L_req={L_required:.0f} cd/m² NO ALCANZABLE "
                f"con Aphex L {I_max_mA} mA — máximo físico estimado "
                f"~{L_max_at_dmin:.0f} cd/m² a d_min={D_MIN} m. "
                f"Considerar proyectores de alta potencia o reducir la velocidad de diseño."
            )
        else:
            warnings.append(
                f"Zona {zone_name}: luminaria máxima (Aphex L {I_max_mA} mA) insuficiente "
                f"al espaciado global — se reduce a {d_try:.1f} m "
                f"(L_req={L_required:.0f} cd/m²)"
            )

    selected_op = select_aphex_continuous(phi, cct, I_max_mA)

    n_lum    = max(1, math.ceil(zone_length / d_try))
    d_actual = zone_length / n_lum

    L_est    = _luminance(selected_op["lm"], n_rows, uf, mf, rho_eff, d_actual, w)
    E_req    = L_required / rho_eff if rho_eff > 0 else 0.0

    area      = zone_length * w
    pwr_zone  = n_lum * selected_op["W"]
    flux_zone = n_lum * selected_op["lm"]
    pwr_dens  = pwr_zone / area if area > 0 else 0.0

    return ZoneLuminaireDesign(
        zone_type=zone_type, zone_name=zone_name, s_start=s_start, s_end=s_end,
        zone_length=zone_length, L_required=L_required, E_required=round(E_req, 1),
        model=selected_op["model"], pcb=selected_op["pcb"], current_mA=selected_op["mA"],
        flux_lm=selected_op["lm"], power_w=selected_op["W"], optic=optic,
        d_max_ul=round(d_max_ul, 2), d_used=round(d_actual, 2),
        n_luminaires=n_lum, L_estimated=round(L_est, 1),
        UF=round(uf, 4), power_zone_w=round(pwr_zone, 0),
        flux_zone_lm=round(flux_zone, 0), power_density_wm2=round(pwr_dens, 3),
        d_max=round(d_actual, 2),
        tilt_deg=_zone_tilt_deg(zone_type, L_required, L_interior),
    )


def _zone_label(z_type: str, tr_count: int) -> str:
    """Etiqueta normalizada de zona.
    Las zonas bidireccionales del Portal B llevan sufijo ·B.
    """
    t = z_type.lower()
    if t == "threshold_b":              return "CTH·B"
    if t == "transition_b":             return f"CTR{tr_count}·B"
    if "threshold" in t:                return "CTH"
    if "transition" in t:               return f"CTR{tr_count}"
    if "interior" in t:                 return "CIN"
    if "exit" in t or "salida" in t:    return "CEX"
    if "access" in t or "parting" in t: return "ACC"
    return t.upper()[:4]


# ══════════════════════════════════════════════════════════════════════════════
# FUNCIÓN PRINCIPAL — DISEÑO INSIDE-OUT APHEX
# ══════════════════════════════════════════════════════════════════════════════

def design_aphex_tunnel(
    zones_list:    list,
    params:        dict,
    road_width_m:  float,
    tube_length_m: float,
    tube_id:       str = "T1",
) -> TunnelLuminaireResult:
    """
    Algoritmo inside-out CIE 88:2004 con cadena APHEX S→M→L.

    Parámetros relevantes en `params`:
        I_max_mA         : corriente máxima global DALI (int, default 750)
        cct              : temperatura de color "3000K" / "4000K" (default "4000K")
        arrangement      : clave de ARRANGEMENTS (default "central_single")
        mounting_height_m: altura de montaje (m, default 5.0)
        maintenance_factor: MF (default 0.70)
        road_surface     : clave de ROAD_SURFACES (default "medium_asphalt")
        rho_eff          : reflectancia efectiva (si se especifica, sobreescribe road_surface)
        optic            : "F2M2" / "F2MD" / "F151" / "auto" (default "auto")
    """
    warnings: List[str] = []

    # ── Parámetros ──────────────────────────────────────────────────────────
    I_max_mA   = int(params.get("I_max_mA", 750))
    cct        = str(params.get("cct", "4000K"))
    if cct not in ("3000K", "4000K"):
        cct = "4000K"
        warnings.append("CCT no reconocida — se usa 4000K")

    arrangement = str(params.get("arrangement", "central_single"))
    if arrangement not in ARRANGEMENTS:
        arrangement = "central_single"
        warnings.append("Arreglo no reconocido — se usa central_single")

    h    = float(params.get("mounting_height_m", 5.0))
    mf   = float(params.get("maintenance_factor", DEFAULT_MF))
    w    = max(road_width_m, 1.0)
    wh   = w / h if h > 0 else 1.0
    n_rows = ARRANGEMENTS[arrangement]["n_rows"]

    surface_key = str(params.get("road_surface", "medium_asphalt"))
    rho_eff = float(params.get("rho_eff",
                   ROAD_SURFACES.get(surface_key, ROAD_SURFACES["medium_asphalt"])["rho"]))

    optic_pref = str(params.get("optic", "auto"))
    optic      = auto_select_optic(optic_pref, wh)

    # Parámetros CIE 88 para la curva de transición
    speed_kmh = float(params.get("speed_kmh", 80.0))
    Lth_cie   = float(params.get("Lth", 0.0))
    Lin_cie   = float(params.get("Lin", 0.0))

    # ── Tablas fotométricas ─────────────────────────────────────────────────
    uf      = lookup_uf(optic, wh, arrangement)
    dh_max  = lookup_dh_max(optic, wh, arrangement)
    d_max_ul = dh_max * h

    # Límite práctico (túneles grandes) — nunca > 20 m
    d_interior = min(d_max_ul, 20.0)

    # ── Cadena APHEX ─────────────────────────────────────────────────────────
    chain = build_aphex_chain(cct, I_max_mA)
    if not chain:
        warnings.append(f"No hay puntos de operación con I_max={I_max_mA} mA y CCT={cct}")
        chain = build_aphex_chain(cct, 750)

    # ── Diseño por zona ──────────────────────────────────────────────────────
    zone_designs: List[ZoneLuminaireDesign] = []
    tr_count = 0

    # Zona interior = menor L_req → fija el espaciado global
    valid_zones = [z for z in zones_list if float(z.get("L_min_required", 0)) > 0 and
                   float(z.get("s_end", 0)) > float(z.get("s_start", 0))]

    if valid_zones:
        L_interior = min(float(z.get("L_min_required", 0)) for z in valid_zones)
        # Verificar que S/350mA cumple en zona interior con d_interior
        op0 = chain[0]
        L0  = _luminance(op0["lm"], n_rows, uf, mf, rho_eff, d_interior, w)
        if L0 < L_interior:
            # Recalcular d_interior para que el mínimo punto de operación cubra la interior
            denom = math.pi * w * L_interior
            num   = op0["lm"] * n_rows * uf * mf * rho_eff
            d_possible = num / denom if denom > 0 else d_interior
            d_interior = max(2.5, min(d_possible, d_max_ul))
            warnings.append(
                f"El espaciado máximo de uniformidad ({d_max_ul:.1f} m) es demasiado grande "
                f"para cumplir L_int={L_interior:.0f} cd/m² con el menor punto de operación. "
                f"Se usa d={d_interior:.1f} m."
            )
    else:
        warnings.append("No hay zonas con L_req > 0 — se usa espaciado por Ul.")

    for z in zones_list:
        z_type  = str(z.get("zone_type") or z.get("type") or "interior").lower()
        z_start = float(z.get("s_start", 0))
        z_end   = float(z.get("s_end",   0))
        L_req   = float(z.get("L_min_required", 0))

        if "transition" in z_type:
            tr_count += 1
        z_name = _zone_label(z_type, tr_count)

        zd = _design_zone_aphex(
            zone_type=z_type, zone_name=z_name,
            s_start=z_start, s_end=z_end, L_required=L_req,
            chain=chain, d_global=d_interior, d_max_ul=d_max_ul,
            uf=uf, n_rows=n_rows, mf=mf, rho_eff=rho_eff, w=w,
            optic=optic, warnings=warnings,
            cct=cct, I_max_mA=I_max_mA,
            speed_kmh=speed_kmh, Lth=Lth_cie, Lin=Lin_cie,
            L_interior=L_interior if valid_zones else 0.0,
        )
        # Aplicar override de tilt del usuario si existe
        _tilt_ov = params.get("tilt_overrides", {})
        if zd.zone_name in _tilt_ov:
            zd.tilt_deg = float(_tilt_ov[zd.zone_name])
        zone_designs.append(zd)

        # Avisos de diseño
        if zd.d_used < 2.5 and zd.n_luminaires > 0:
            warnings.append(
                f"Zona {z_name}: espaciado {zd.d_used:.2f} m muy reducido — "
                "verificar si es posible la instalación"
            )

    # ── Resultado ────────────────────────────────────────────────────────────
    # LuminaireSpec representativa (zona con mayor L_req)
    if zone_designs:
        dominant = max(zone_designs, key=lambda zd: zd.L_required)
        lum_spec = LuminaireSpec(
            flux_lm           = dominant.flux_lm,
            power_w           = dominant.power_w,
            efficiency        = uf,
            mounting_height_m = h,
            arrangement       = arrangement,
            maintenance_factor= mf,
            name              = f"Aphex {dominant.model}/{dominant.pcb} {dominant.current_mA}mA {cct}",
        )
    else:
        lum_spec = None

    result = TunnelLuminaireResult(
        tube_id           = tube_id,
        luminaire         = lum_spec,
        road_surface_type = surface_key,
        rho_eff           = rho_eff,
        road_width_m      = w,
        tube_length_m     = tube_length_m,
        optic             = optic,
        cct               = cct,
        I_max_mA          = I_max_mA,
        arrangement       = arrangement,
        zones             = zone_designs,
        warnings          = list(set(warnings)),  # deduplicate
    )
    result._compute_totals()
    return result


# ══════════════════════════════════════════════════════════════════════════════
# BACKWARD COMPAT — calculate_luminaire_layout
# Mantiene la interfaz existente del motor; detecta si se usan parámetros
# legacy (flux_lm / efficiency) o nuevos (I_max_mA / cct).
# ══════════════════════════════════════════════════════════════════════════════

def calculate_luminaire_layout(
    zones_list:       list,
    luminaire_params: dict,
    road_width_m:     float,
    tube_length_m:    float,
    tube_id:          str = "T1",
) -> TunnelLuminaireResult:
    """
    Punto de entrada compatible con el motor existente.
    Si luminaire_params contiene 'I_max_mA' delega a design_aphex_tunnel (APHEX).
    Caso contrario usa flujo/eficiencia directamente (modo legacy).
    """
    params = dict(luminaire_params)
    params.setdefault('road_width_m',  road_width_m)
    params.setdefault('tube_length_m', tube_length_m)

    # ── Modo APHEX (I_max_mA presente) ────────────────────────────────────────
    if params.get('I_max_mA') or params.get('cct'):
        return design_aphex_tunnel(
            zones_list    = zones_list,
            params        = params,
            road_width_m  = road_width_m,
            tube_length_m = tube_length_m,
            tube_id       = tube_id,
        )

    # ── Modo legacy (flux_lm / efficiency) ───────────────────────────────────
    warnings: list = []
    flux_lm    = float(params.get('flux_lm',  15000))
    uf         = float(params.get('efficiency', 0.60))
    mf         = float(params.get('maintenance_factor', 0.70))
    h          = float(params.get('mounting_height_m', 5.0))
    w          = road_width_m
    n_rows     = int(params.get('n_rows', 1))
    arrangement = str(params.get('arrangement', 'central_single'))
    rho_eff    = float(params.get('rho_eff', 0.07))
    power_w    = float(params.get('power_w', 200))
    optic      = str(params.get('optic', 'F2MD'))
    cct        = str(params.get('cct', '4000K'))
    I_max_mA   = int(params.get('I_max_mA', 500))

    zone_designs: list = []
    tr_count = 0

    _v_leg = [z for z in zones_list if float(z.get("L_min_required",0)) > 0
              and float(z.get("s_end",0)) > float(z.get("s_start",0))]
    L_interior_legacy = min((float(z.get("L_min_required",0)) for z in _v_leg), default=0.0)

    for z in zones_list:
        z_type   = str(z.get('zone_type') or z.get('type') or 'interior').lower()
        z_start  = float(z.get('s_start', 0))
        z_end    = float(z.get('s_end',   0))
        z_length = max(0.0, z_end - z_start)
        L_req    = float(z.get('L_min_required', 0))

        if 'transition' in z_type:
            tr_count += 1
        z_name = _zone_label(z_type, tr_count)

        if z_length <= 0 or L_req <= 0:
            zone_designs.append(ZoneLuminaireDesign(
                zone_type=z_type, zone_name=z_name,
                s_start=z_start, s_end=z_end,
                zone_length=z_length, L_required=L_req, E_required=0,
                model='M', pcb='F2MD', current_mA=I_max_mA,
                flux_lm=flux_lm, power_w=power_w, optic=optic,
                d_max_ul=10.0, d_used=0, n_luminaires=0,
                L_estimated=0, UF=uf, power_zone_w=0,
                flux_zone_lm=0, power_density_wm2=0, d_max=0,
                tilt_deg=0.0,
            ))
            continue

        denom = math.pi * w * L_req
        num   = flux_lm * n_rows * uf * mf * rho_eff
        d_try = max(2.5, min(num / denom if denom > 0 else 10.0, 20.0))
        n_lum    = max(1, math.ceil(z_length / d_try))
        d_actual = z_length / n_lum
        L_est    = _luminance(flux_lm, n_rows, uf, mf, rho_eff, d_actual, w)
        area     = z_length * w
        pwr_zone = n_lum * power_w

        zone_designs.append(ZoneLuminaireDesign(
            zone_type=z_type, zone_name=z_name,
            s_start=z_start, s_end=z_end,
            zone_length=z_length, L_required=L_req, E_required=0,
            model='M', pcb=optic, current_mA=I_max_mA,
            flux_lm=flux_lm, power_w=power_w, optic=optic,
            d_max_ul=round(d_actual, 2), d_used=round(d_actual, 2),
            n_luminaires=n_lum, L_estimated=round(L_est, 1),
            UF=round(uf, 4), power_zone_w=round(pwr_zone, 0),
            flux_zone_lm=round(n_lum * flux_lm, 0),
            power_density_wm2=round(pwr_zone / area if area > 0 else 0, 3),
            d_max=round(d_actual, 2),
            tilt_deg=_zone_tilt_deg(z_type, L_req, L_interior_legacy),
        ))

    lum_spec = None
    if zone_designs:
        dom = max(zone_designs, key=lambda z: z.L_required)
        lum_spec = LuminaireSpec(
            flux_lm=dom.flux_lm, power_w=dom.power_w,
            efficiency=uf, mounting_height_m=h,
            arrangement=arrangement, maintenance_factor=mf,
            name=f"Legacy {optic} {cct}",
        )

    result = TunnelLuminaireResult(
        tube_id=tube_id, luminaire=lum_spec,
        road_surface_type='medium_asphalt', rho_eff=rho_eff,
        road_width_m=w, tube_length_m=tube_length_m,
        optic=optic, cct=cct, I_max_mA=I_max_mA,
        arrangement=arrangement, zones=zone_designs,
        warnings=warnings,
    )
    result._compute_totals()
    return result
