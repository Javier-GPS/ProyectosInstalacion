"""
modules/tunnel/photometric_verify.py
=====================================
CIE 140:2019 photometric verification for APHEX tunnel zone designs.

After design_aphex_tunnel() selects luminaires for each zone using the
inside-out UF-table algorithm, this module verifies the actual luminance
quality (L_avg, U0, Ul, TI) using the full CIE 140:2019 point-by-point
calculation with real LDT angular distributions and CIE 144:2001 r-tables.

All S/M/L APHEX models share the same photometric distribution (same optics
F2MD/F2M2/F151). The LDT files for APHEX M are used as reference; flux is
scaled to the operating point of each zone's selected luminaire.

Road surface -> r-table mapping (CIE 144:2001):
    dark_asphalt   -> R3
    medium_asphalt -> R2
    light_asphalt  -> R1
    concrete       -> C1
    bright_concrete-> C2
"""
from __future__ import annotations

import sys
import math
from pathlib import Path
from typing import Optional

# ── Resolve project root so photometric_engine is importable ─────────────────
_HERE        = Path(__file__).resolve()
_PROJECT_ROOT = _HERE.parents[2]          # .../CALCULO FOTOMETRICO SALVI/
if str(_PROJECT_ROOT) not in sys.path:
    sys.path.insert(0, str(_PROJECT_ROOT))

_LDT_DIR = _PROJECT_ROOT / "photometric_engine" / "data" / "photometries"

# ── Road surface → CIE 144 r-table ──────────────────────────────────────────
_SURFACE_RTABLE: dict[str, str] = {
    "dark_asphalt":    "R3",
    "medium_asphalt":  "R2",
    "light_asphalt":   "R1",
    "concrete":        "C1",
    "bright_concrete": "C2",
}

# ── Optic → APHEX M LDT filename (all models share the same distribution) ───
_OPTIC_LDT: dict[str, str] = {
    "F2MD": "APHEX_M_H10_40K_F2MD_VDR_SPUW_200W.ldt",
    "F2M2": "APHEX_M_H10_40K_F2M2_VDR_SPUW_200W.ldt",
    "F151": "APHEX_M_H10_40K_F151_VDR_SPUW_200W.ldt",
}

# CIE 140 compliance thresholds
_U0_MIN  = 0.40
_UL_MIN  = 0.60
_TI_MAX  = 15.0


def _is_available() -> bool:
    """Check that photometric_engine can be imported."""
    try:
        import photometric_engine.salvi_photometry.ldt_parser  # noqa: F401
        return True
    except ImportError:
        return False


def verify_luminaire_result(lum_result, params: dict) -> dict:
    """
    Run CIE 140:2019 photometric verification for every zone in a
    TunnelLuminaireResult produced by design_aphex_tunnel().

    Parameters
    ----------
    lum_result : TunnelLuminaireResult
        Output of design_aphex_tunnel() / calculate_luminaire_layout().
    params : dict
        Original luminaire params dict (needs mounting_height_m, maintenance_factor).

    Returns
    -------
    dict with structure:
        {
          "available": bool,
          "error": str | None,
          "rtable": "R2",
          "zones": {
            "CIN": {
              "L_avg": 12.94, "L_min": 7.45,
              "U0": 0.576, "Ul": 0.970, "TI": 1.3,
              "E_h_avg": 165.3,
              "compliant": true, "L_req": 10.0,
              "checks": {"L_avg": true, "U0": true, "Ul": true, "TI": true}
            },
            ...
          },
          "overall_compliant": bool
        }
    """
    out: dict = {"available": False, "error": None, "zones": {}, "overall_compliant": False}

    if not _is_available():
        out["error"] = "photometric_engine no disponible (importación fallida)"
        return out

    try:
        from photometric_engine.salvi_photometry.ldt_parser import load_ldt
        from photometric_engine.salvi_photometry.geometry   import Observer
        from photometric_engine.salvi_photometry.calculator import TunnelCalculator, LuminaireInstance, LuminaireOrientation
    except ImportError as exc:
        out["error"] = f"Error importando photometric_engine: {exc}"
        return out

    # ── Parámetros generales ─────────────────────────────────────────────────
    optic   = lum_result.optic or "F2MD"
    surface = lum_result.road_surface_type or "medium_asphalt"
    rtable  = _SURFACE_RTABLE.get(surface, "R2")
    W       = float(lum_result.road_width_m)
    H       = float(params.get("mounting_height_m", 5.0))
    mf      = float(params.get("maintenance_factor", 0.70))

    # ── LDT file ─────────────────────────────────────────────────────────────
    ldt_fname = _OPTIC_LDT.get(optic, _OPTIC_LDT["F2MD"])
    ldt_path  = _LDT_DIR / ldt_fname
    if not ldt_path.exists():
        out["error"] = f"LDT no encontrado: {ldt_fname}"
        return out

    try:
        phot = load_ldt(ldt_path)
    except Exception as exc:
        out["error"] = f"Error leyendo LDT: {exc}"
        return out

    calc = TunnelCalculator(rtable, mf)
    # Observer at road centre, 60 m ahead (CIE 140 §6.2.2)
    obs  = Observer(lane_y_m=W / 2, d_observer_m=60.0)

    out["available"] = True
    out["rtable"]    = rtable
    out["optic"]     = optic
    out["H_m"]       = H

    zone_results: dict = {}
    all_compliant = True

    for zd in lum_result.zones:
        if zd.n_luminaires <= 0 or zd.zone_length <= 0:
            continue

        S        = float(zd.d_used)
        flux_lm  = float(zd.flux_lm)
        L_req    = float(zd.L_required)
        zone_key = zd.zone_name

        if S <= 0.1 or flux_lm <= 0:
            continue

        # ── Luminaire array: ±5 spans, positions depend on arrangement ─────────
        n_side  = 5
        WALL_Y  = 0.30          # m from wall centre to luminaire (lateral/bilateral)
        arr     = params.get('arrangement', 'central_single') or 'central_single'

        if arr == 'bilateral_stag':
            # Alternating sides: even index → left wall, odd → right wall
            lums = [
                LuminaireInstance(
                    x           = i * S,
                    y           = WALL_Y if abs(i) % 2 == 0 else W - WALL_Y,
                    H           = H,
                    photometry  = phot,
                    flux_lm     = flux_lm,
                    orientation = LuminaireOrientation(tilt_deg=float(getattr(zd,"tilt_deg",0) or 0)),
                )
                for i in range(-n_side, n_side + 1)
            ]
        else:
            # Determine y positions per arrangement
            if arr == 'lateral_left':
                ys = [WALL_Y]
            elif arr == 'lateral_right':
                ys = [W - WALL_Y]
            elif arr == 'bilateral_sym':
                ys = [WALL_Y, W - WALL_Y]
            elif arr == 'central_double':
                ys = [W / 2 - 0.30, W / 2 + 0.30]
            else:                        # central_single / central_offset / auto
                ys = [W / 2]
            lums = [
                LuminaireInstance(
                    x           = i * S,
                    y           = y,
                    H           = H,
                    photometry  = phot,
                    flux_lm     = flux_lm,
                    orientation = LuminaireOrientation(tilt_deg=float(getattr(zd,"tilt_deg",0) or 0)),
                )
                for i in range(-n_side, n_side + 1)
                for y in ys
            ]

        # ── CIE 140 §6.3 calculation grid over one representative span ───────
        n_long, n_trans = 10, 5
        xs  = [(-S / 2) + (i + 0.5) * S / n_long for i in range(n_long)]
        ys  = [(j + 0.5) * W / n_trans             for j in range(n_trans)]
        pts = [(x, y) for x in xs for y in ys]

        try:
            zr = calc.calculate_zone(
                zone_name   = zd.zone_type,
                zone_type   = zd.zone_type,
                s_start     = -S / 2,
                s_end       =  S / 2,
                L_req       = L_req,
                calc_points = pts,
                luminaires  = lums,
                observer    = obs,
            )
            L_ok  = zr.L_avg >= L_req  if L_req > 0 else True
            U0_ok = zr.U0   >= _U0_MIN
            Ul_ok = zr.Ul   >= _UL_MIN
            TI_ok = zr.TI   <= _TI_MAX

            compliant = all([L_ok, U0_ok, Ul_ok, TI_ok])
            if not compliant:
                all_compliant = False

            zone_results[zone_key] = {
                "L_avg":    round(zr.L_avg, 2),
                "L_min":    round(zr.L_min, 2),
                "U0":       round(zr.U0,    3),
                "Ul":       round(zr.Ul,    3),
                "TI":       round(zr.TI,    1),
                "E_h_avg":  round(zr.E_h_avg, 1),
                "L_req":    round(L_req, 1),
                "compliant": compliant,
                "checks": {
                    "L_avg": L_ok,
                    "U0":    U0_ok,
                    "Ul":    Ul_ok,
                    "TI":    TI_ok,
                },
            }
        except Exception as exc:
            zone_results[zone_key] = {
                "error": str(exc),
                "compliant": False,
            }
            all_compliant = False

    out["zones"]            = zone_results
    out["overall_compliant"] = all_compliant and bool(zone_results)
    return out
