"""
SALVI Tunnel Optimizer — CIE 88:2004 inside-out con optimizacion U0/Ul
=======================================================================

Estrategia:

  INTERIOR (ancla):
    Paso 1: para cada (optica, tilt) busqueda binaria del mayor d que cumple
            U0 >= U0_obj Y Ul >= Ul_obj (ratios: independientes del flujo).
    Paso 2: con d_opt fijado, calcular I minima para L_int usando CIE 140.
    Paso 3: si L@I_max < L_int -> reducir d (biseccion) y repetir.

  TRANSICION (interior -> portal):
    Para cada posicion de luminaria (curva CIE 88):
      - d = d_interior (fijo)
      - (optica, tilt, I) con minima corriente que cumple L_req y U0 >= U0_obj
      - Si I > I_max del modelo actual -> escala S->M->L

  UMBRAL:
    Idem transicion con L_req = Lth uniforme.
    Si L@I_max < Lth incluso a d_min -> avisar.

  RETROFIT (posiciones fijas):
    d es input; solo se optimiza (optica, tilt, I).

Corriente continua: I en [I_min_abs, I_max]
  I_min_abs = I_min_pct * 350 mA  (default 30% = 105 mA)
  Por debajo de 350 mA: interpolacion lineal desde catalogo con bonus eficacia.
"""
from __future__ import annotations

import math
import sys
from pathlib import Path

import numpy as np

_PROJECT_ROOT = Path(__file__).resolve().parents[2]
if str(_PROJECT_ROOT) not in sys.path:
    sys.path.insert(0, str(_PROJECT_ROOT))

from photometric_engine.salvi_photometry.ldt_parser import load_ldt, Photometry
from photometric_engine.salvi_photometry.calculator import TunnelCalculator, LuminaireInstance
from photometric_engine.salvi_photometry.geometry import LuminaireOrientation, Observer

# ── LDTs ──────────────────────────────────────────────────────────────────────
_LDT_DIR = _PROJECT_ROOT / "photometric_engine" / "data" / "photometries"
_OPTIC_LDT = {
    "F2MD": "APHEX_M_H10_40K_F2MD_VDR_SPUW_200W.ldt",
    "F2M2": "APHEX_M_H10_40K_F2M2_VDR_SPUW_200W.ldt",
    "F151": "APHEX_M_H10_40K_F151_VDR_SPUW_200W.ldt",
}
OPTICS = list(_OPTIC_LDT.keys())
_PHOT_CACHE: dict[str, Photometry] = {}


def _load_phot(optic: str) -> Photometry:
    if optic not in _PHOT_CACHE:
        _PHOT_CACHE[optic] = load_ldt(_LDT_DIR / _OPTIC_LDT.get(optic, _OPTIC_LDT["F2MD"]))
    return _PHOT_CACHE[optic]


# ── Motor de eficiencia LUXEON 5050 HE Plus — reemplaza el catalogo cerrado
#    S/M/L por un modelo parametrico de 9 variantes Aphex. Ver
#    Instrucciones_motor_eficiencia_Aphex_LuxStudio.docx y modules/tunnel/led_engine.py ──
from modules.tunnel import led_engine as _led

CHAIN_ORDER = list(_led._VARIANT_ORDER)   # 9 variantes, orden de capacidad creciente
_DEFAULT_CRI  = 70     # unico soportado hasta que la interfaz exponga selector de CRI
_DEFAULT_TA_C = 20.0   # temperatura ambiente de diseno — media anual del emplazamiento
                       # (evalua la reduccion media de eficiencia del LED, no un limite de
                       # seguridad; ver Geometria > Entorno en la interfaz). Configurable
                       # por proyecto via set_design_ambient_temperature().


def set_design_ambient_temperature(ta_c: float) -> None:
    """Fija la Ta de diseno para las siguientes llamadas a
    flux_power_at_current/select_model_for_flux en este proceso. Se llama
    una vez por calculo desde design_aphex_tunnel_optimized (modulo
    single-request, sin concurrencia — mismo patron que _QC_CACHE)."""
    global _DEFAULT_TA_C
    _DEFAULT_TA_C = float(ta_c)


def _cct_str_to_k(cct) -> float:
    """'4000K' -> 4000.0"""
    try:
        return float(str(cct).upper().replace("K", "").strip())
    except ValueError:
        return 4000.0


def flux_power_at_current(model: str, cct, mA: float, I_min_pct: float = 0.30):
    """(flux_lm, power_W) para una variante Aphex y corriente dadas —
    delega en el motor fisico led_engine (LUXEON 5050 HE Plus)."""
    variant = _led.VARIANTS_BY_ID[model]
    mA_eff = max(I_min_pct * _led.LED_I_NOMINAL_MA, mA)
    op = _led._operating_point_at_current(mA_eff, variant, _cct_str_to_k(cct), _DEFAULT_CRI, _DEFAULT_TA_C)
    return op.calculated_luminaire_flux_lm, op.input_power_w


def select_model_for_flux(phi_lm: float, cct, I_max_mA: float,
                          I_min_pct: float = 0.30) -> dict:
    """Selecciona, entre las 9 variantes Aphex (orden de capacidad
    creciente), la mas pequena que alcance phi_lm lm — delega en
    led_engine.select_optimal_variant (seccion 17 del documento)."""
    cct_k = _cct_str_to_k(cct)
    op = _led.select_optimal_variant(
        target_flux_lm=phi_lm, cct_k=cct_k, cri=_DEFAULT_CRI, Ta_C=_DEFAULT_TA_C,
        i_max_ma_project=I_max_mA,
    )
    if op is None:
        variant = _led.VARIANTS_BY_ID[_led._VARIANT_ORDER[-1]]
        op = _led._operating_point_at_current(I_max_mA, variant, cct_k, _DEFAULT_CRI, _DEFAULT_TA_C)
    return {
        "model": op.variant_id,
        "mA":    round(op.current_per_led_a * 1000, 1),
        "W":     round(op.input_power_w, 1),
        "lm":    round(op.calculated_luminaire_flux_lm, 0),
    }


# ── Motor CIE 140 directo ─────────────────────────────────────────────────────

_UNIT_FLUX = 10000.0   # lm de referencia para calculos de U0/Ul/L

_QC_CACHE: dict = {}   # clave: (optic, d, h, w, tilt, arrangement, rtable, mf_str)


def _n_rows(arrangement: str) -> int:
    return {"central_single":1,"central_offset":1,"central_double":2,
            "lateral_left":1,"lateral_right":1,"unilateral":1,
            "bilateral_sym":2,"bilateral_stag":2,"bilateral":2,"staggered":2
            }.get(arrangement, 1)


_WALL_Y_DEFAULT = 0.30  # m — valor por defecto

def _y_positions(arrangement: str, w: float, wall_offset: float = _WALL_Y_DEFAULT) -> list[float]:
    """Posiciones transversales [m] de las luminarias. Road: y in [0, w].
    wall_offset: distancia desde la pared lateral (m)."""
    wo = max(0.05, float(wall_offset))
    if arrangement in ("bilateral_sym","bilateral_stag","bilateral","staggered"):
        return [wo, w - wo]
    elif arrangement == "central_double":
        return [w/2 - 0.30, w/2 + 0.30]
    elif arrangement == "central_offset":
        return [w/2 + wo]
    elif arrangement == "lateral_left":
        return [wo]
    elif arrangement in ("lateral_right","unilateral"):
        return [w - wo]
    return [w/2]                                # central


_PAIRED_ARRANGEMENTS = {"bilateral_sym", "bilateral_stag", "bilateral", "staggered", "central_double"}


def _build_lums(optic, d, h, w, tilt, arrangement, n_side=5, flux=_UNIT_FLUX,
               wall_offset=_WALL_Y_DEFAULT):
    """Genera array +/-n_side periodos (2*n_side+1 grupos).
    Convencion identica a photometric_verify para coherencia de estimaciones.

    El tilt (rotacion transversal, CIE 140 Anexo A) se espeja entre ambas filas
    en disposiciones enfrentadas: cada fila se inclina hacia el eje del tunel
    (nunca ambas hacia el mismo lado), igual que la vista previa del frontend."""
    phot      = _load_phot(optic)
    ys        = _y_positions(arrangement, w, wall_offset)
    is_paired = arrangement in _PAIRED_ARRANGEMENTS
    lums      = []
    for i in range(-n_side, n_side + 1):
        x = i * d
        for y in ys:
            y_tilt = tilt if (not is_paired or y < w / 2) else -tilt
            orient = LuminaireOrientation(tilt_deg=y_tilt)
            lums.append(LuminaireInstance(x=x, y=y, H=h,
                                          photometry=phot, flux_lm=flux, orientation=orient))
    return lums


def _calc_grid(d, w, nl=10, nt=5):
    """Grid CIE 140 en la celda central [-d/2, d/2] x [0, w].
    10×5 = 50 puntos — mismo que photometric_verify para consistencia."""
    xs = [(-d/2)+(j+0.5)*d/nl for j in range(nl)]
    ys = [(k+0.5)*w/nt         for k in range(nt)]
    return [(x,y) for x in xs for y in ys], nl, nt


def _L_array(optic, d, h, w, tilt, arrangement, rtable, mf, flux=_UNIT_FLUX,
             wall_offset=_WALL_Y_DEFAULT):
    """Array numpy de luminancias en la celda central [cd/m2]."""
    lums = _build_lums(optic, d, h, w, tilt, arrangement, flux=flux, wall_offset=wall_offset)
    pts, nl, nt = _calc_grid(d, w)
    calc = TunnelCalculator(rtable_name=rtable, maintenance_factor=mf)
    obs  = Observer(lane_y_m=w/2, d_observer_m=60.0)  # CIE 140 sec.6.2.2
    return np.array([calc.luminance_at_point(xP,yP,lums,obs).L for xP,yP in pts]), nl, nt


def _quality_and_mean(optic, d, h, w, tilt, rtable, mf, arrangement, wall_offset):
    """(U0, Ul, L_mean_a_UNIT_FLUX) cacheados juntos bajo una unica clave —
    antes eval_quality() y L_at_unit_flux() construian cada uno su propio
    _L_array() para la misma (optic,d,h,w,tilt,...), duplicando el trabajo
    caro (fotometria LDT + CIE 140 en la rejilla) en cada punto muestreado."""
    key = (optic, round(d,3), round(h,3), round(w,3), round(tilt,1), arrangement, rtable,
           f"{mf:.2f}", round(wall_offset,3))
    if key in _QC_CACHE:
        return _QC_CACHE[key]

    L, nl, nt = _L_array(optic, d, h, w, tilt, arrangement, rtable, mf, wall_offset=wall_offset)
    if L.max() < 1e-9:
        result = (0.0, 0.0, 0.0)
        _QC_CACHE[key] = result
        return result

    U0 = float(L.min() / L.mean())

    # Ul: minimo de (L_min/L_max) por cada fila longitudinal (mismo y)
    ul_rows = []
    for k in range(nt):
        row = L[k::nt]
        if len(row) > 1 and row.max() > 0:
            ul_rows.append(float(row.min()/row.max()))
    Ul = min(ul_rows) if ul_rows else 0.0

    result = (U0, Ul, float(L.mean()))
    _QC_CACHE[key] = result
    return result


def eval_quality(optic, d, h, w, tilt, rtable="R2", mf=0.70, arrangement="central_single",
                wall_offset=_WALL_Y_DEFAULT):
    """(U0, Ul). Independientes del flujo — se usa UNIT_FLUX."""
    U0, Ul, _ = _quality_and_mean(optic, d, h, w, tilt, rtable, mf, arrangement, wall_offset)
    return U0, Ul


def L_at_unit_flux(optic, d, h, w, tilt, arrangement, rtable, mf,
                   wall_offset=_WALL_Y_DEFAULT) -> float:
    """L_avg [cd/m2] con UNIT_FLUX lm por luminaria."""
    _, _, L_mean = _quality_and_mean(optic, d, h, w, tilt, rtable, mf, arrangement, wall_offset)
    return L_mean


def phi_for_luminance(optic, d, h, w, tilt, L_req, arrangement, rtable, mf,
                     wall_offset=_WALL_Y_DEFAULT) -> float:
    """Flujo por luminaria [lm] para producir L_req [cd/m2]."""
    L_unit = L_at_unit_flux(optic, d, h, w, tilt, arrangement, rtable, mf, wall_offset=wall_offset)
    return (L_req / L_unit * _UNIT_FLUX) if L_unit > 0 else 1e9


def L_from_flux(optic, d, h, w, tilt, flux_lm, arrangement, rtable, mf,
                wall_offset=_WALL_Y_DEFAULT) -> float:
    """L_avg estimada [cd/m2] para flux_lm por luminaria."""
    L_unit = L_at_unit_flux(optic, d, h, w, tilt, arrangement, rtable, mf, wall_offset=wall_offset)
    return L_unit * flux_lm / _UNIT_FLUX


def clear_cache():
    _QC_CACHE.clear()


# ── Fase 1: Optimizador interior ──────────────────────────────────────────────

def _find_dmax_adaptive(ok_fn, d_min, d_max_hard, coarse_n=10, fine_n=25):
    """Mayor d en [d_min, d_max_hard] tal que ok_fn(d) es True — busqueda
    adaptativa grueso->fino.

    ok_fn NO es necesariamente monotona en d (U0/Ul pueden empeorar a d muy
    pequeno -modo casi-puntual bajo la luminaria en una celda muy corta- y
    mejorar de nuevo a d intermedio antes de degradarse otra vez a d grande),
    por lo que no se puede resolver con una biseccion global directa ni
    asumir "si d_min no cumple, ningun d cumple".

    Estrategia:
      1. Muestrea `coarse_n` puntos de MAYOR a MENOR d y para en el primero
         que cumple — es candidato al mayor d factible sin necesidad de
         evaluar el resto (ahorra evaluaciones caras de CIE 140 respecto a
         muestrear los 25 puntos siempre, que era el comportamiento previo).
      2. Si NINGUNO de los `coarse_n` cumple, escala a `fine_n` puntos (la
         resolucion completa original) antes de concluir que no hay ningun
         d factible — evita falsos negativos por una region factible
         estrecha que el paso grueso pudiera saltarse.
      3. Afina el candidato encontrado hacia el siguiente punto muestreado
         (mayor, no factible) por biseccion local — igual que antes.

    Retorna (d_encontrado, True) o (None, False) si no hay ningun d factible.
    """
    if d_max_hard <= d_min:
        return (d_min, True) if ok_fn(d_min) else (None, False)

    def _sample_desc(n):
        step = (d_max_hard - d_min) / (n - 1)
        ds = [d_min + i * step for i in range(n)]
        ds[-1] = d_max_hard  # evitar error de redondeo
        for i in range(n - 1, -1, -1):
            if ok_fn(ds[i]):
                return ds, i
        return ds, None

    ds, idx_best = _sample_desc(coarse_n)
    if idx_best is None:
        ds, idx_best = _sample_desc(fine_n)
        if idx_best is None:
            return None, False

    d_best = ds[idx_best]
    upper  = ds[idx_best + 1] if idx_best < len(ds) - 1 else None

    # Segunda pasada: si el candidato no esta en el extremo superior, TODOS los
    # puntos gruesos por encima (ds[idx_best+1:]) dieron "no cumple" — pero con
    # solo `coarse_n` puntos, una banda factible mas ancha podria caer entera
    # en el hueco entre dos de ellos y pasar desapercibida. Se vuelve a
    # muestrear, con el doble de densidad, SOLO esa region superior; si
    # aparece un d mayor que el candidato grueso, se adopta como nuevo mejor
    # (y su cota superior para la biseccion es el siguiente punto conocido
    # como "no cumple" de ese re-muestreo).
    if upper is not None:
        recheck_n = coarse_n
        step = (d_max_hard - d_best) / recheck_n
        recheck_ds = [d_best + (j + 1) * step for j in range(recheck_n)]
        for j in range(len(recheck_ds) - 1, -1, -1):
            if ok_fn(recheck_ds[j]):
                d_best = recheck_ds[j]
                upper  = recheck_ds[j + 1] if j + 1 < len(recheck_ds) else upper
                break

    if upper is None:
        return round(d_best, 2), True

    # Afinar hacia el siguiente punto muestreado (que no cumple) por biseccion
    # local — dentro de este sub-intervalo SI se puede asumir una unica
    # transicion, ya que el muestreo ya localizo la region factible mas alta.
    lo, hi = d_best, upper
    for _ in range(20):
        mid = (lo + hi) / 2.0
        if ok_fn(mid):
            lo = mid
        else:
            hi = mid
        if hi - lo < 0.05:
            break
    return round(lo, 2), True


def find_dmax_for_quality(optic, tilt, h, w, U0_obj, Ul_obj, rtable, mf, arrangement,
                          d_min=2.5, d_max_hard=25.0,
                          wall_offset=_WALL_Y_DEFAULT) -> float:
    """Mayor d tal que U0>=U0_obj Y Ul>=Ul_obj. Retorna 0 si ninguna d en
    [d_min, d_max_hard] cumple. Ver _find_dmax_adaptive para la estrategia
    de muestreo (U0/Ul no son monotonos en d en general)."""
    def ok(d):
        U0, Ul = eval_quality(optic, d, h, w, tilt, rtable, mf, arrangement,
                              wall_offset=wall_offset)
        return U0 >= U0_obj and Ul >= Ul_obj

    d_found, feasible = _find_dmax_adaptive(ok, d_min, d_max_hard)
    return d_found if feasible else 0.0


def optimize_interior(
    h, w, L_int, U0_obj, Ul_obj, I_max_mA, cct,
    rtable="R2", mf=0.70, arrangement="central_single",
    I_min_pct=0.30, tilt_grid=None, d_min=2.5, d_max_hard=25.0,
    wall_offset=_WALL_Y_DEFAULT,
) -> dict:
    """
    Optimizador zona interior.

    1. Maximiza d para U0/Ul sobre (optica × tilt).
    2. Calcula I para L_int. Si L@I_max < L_int: reduce d por biseccion.
    """
    if tilt_grid is None:
        tilt_grid = [0.0, 5.0, 10.0, 15.0, 20.0]

    warnings_out = []
    best = None  # {"d", "optic", "tilt"}

    for optic in OPTICS:
        for tilt in tilt_grid:
            d = find_dmax_for_quality(optic, tilt, h, w, U0_obj, Ul_obj,
                                      rtable, mf, arrangement, d_min, d_max_hard,
                                      wall_offset=wall_offset)
            if d > 0 and (best is None or d > best["d"]):
                best = {"d": d, "optic": optic, "tilt": tilt}

    if best is None:
        warnings_out.append(
            f"Ninguna combinacion optica x tilt cumple U0>={U0_obj}/Ul>={Ul_obj} "
            f"a d_min={d_min} m. Usando F2M2 tilt=0 d={d_min} m."
        )
        best = {"d": d_min, "optic": "F2M2", "tilt": 0.0}

    d_opt, optic, tilt = best["d"], best["optic"], best["tilt"]

    # Verificar alcanzabilidad de L_int con L@I_max; si no alcanza reducir d
    lm_max, _ = flux_power_at_current(CHAIN_ORDER[-1], cct, I_max_mA, I_min_pct)

    # Busqueda binaria de d tal que L@lm_max >= L_int
    L_at_max = L_from_flux(optic, d_opt, h, w, tilt, lm_max, arrangement, rtable, mf,
                           wall_offset=wall_offset)
    if L_at_max < L_int:
        # d_opt es demasiado grande; reducir hasta que L_max cubra L_int o llegar a d_min.
        # IMPORTANTE: al reducir d hay que seguir exigiendo U0/Ul (no son monotonos en
        # d, asi que un d menor NO garantiza seguir cumpliendo calidad) — se usa el
        # mismo buscador adaptativo que el resto del modulo, pidiendo AMBAS
        # condiciones (calidad Y flujo) a la vez, en vez de una biseccion que solo
        # mirase el flujo (ese biseccion tenia ademas el sentido de la comparacion
        # invertido: nunca reducia d de verdad).
        def _ok_shrink(d):
            U0d, Uld = eval_quality(optic, d, h, w, tilt, rtable, mf, arrangement,
                                    wall_offset=wall_offset)
            if U0d < U0_obj or Uld < Ul_obj:
                return False
            L_d = L_from_flux(optic, d, h, w, tilt, lm_max, arrangement, rtable, mf,
                              wall_offset=wall_offset)
            return L_d >= L_int

        d_shrunk, feasible_shrink = _find_dmax_adaptive(_ok_shrink, d_min, d_opt)
        if feasible_shrink:
            d_opt = d_shrunk
            warnings_out.append(
                f"d reducido a {d_opt} m para alcanzar L_int={L_int:.1f} cd/m2 "
                f"manteniendo U0>={U0_obj}/Ul>={Ul_obj}."
            )
        else:
            L_at_dmin = L_from_flux(optic, d_min, h, w, tilt, lm_max, arrangement, rtable, mf,
                                     wall_offset=wall_offset)
            warnings_out.append(
                f"L_int={L_int:.1f} cd/m2 no alcanzable con Aphex L {I_max_mA} mA "
                f"a d_min={d_min} m manteniendo U0>={U0_obj}/Ul>={Ul_obj} "
                f"(L_max={L_at_dmin:.1f} cd/m2 a d_min)."
            )
            d_opt = d_min

    # Seleccion de corriente
    phi = phi_for_luminance(optic, d_opt, h, w, tilt, L_int, arrangement, rtable, mf,
                            wall_offset=wall_offset)
    sel = select_model_for_flux(phi, cct, I_max_mA, I_min_pct)

    U0f, Ulf = eval_quality(optic, d_opt, h, w, tilt, rtable, mf, arrangement,
                            wall_offset=wall_offset)
    L_est    = L_from_flux(optic, d_opt, h, w, tilt, sel["lm"], arrangement, rtable, mf,
                           wall_offset=wall_offset)

    return {
        "d_opt":    round(d_opt, 2),
        "optic":    optic,
        "tilt_deg": tilt,
        "model":    sel["model"],
        "mA":       sel["mA"],
        "W":        sel["W"],
        "lm":       round(sel["lm"], 0),
        "U0":       round(U0f, 3),
        "Ul":       round(Ulf, 3),
        "L_est":    round(L_est, 1),
        "warnings": warnings_out,
    }


# ── Fase 2/3: Optimizador por luminaria ───────────────────────────────────────

def optimize_single_luminaire(
    L_req, d, h, w, U0_obj, I_max_mA, cct,
    rtable="R2", mf=0.70, arrangement="central_single",
    I_min_pct=0.30, tilt_grid=None,
    wall_offset=_WALL_Y_DEFAULT,
) -> dict:
    """
    Para una luminaria en transicion/umbral:
    (optica, tilt, modelo, mA, W) con minima corriente que cumple
    L_req y U0 >= U0_obj.
    """
    if tilt_grid is None:
        tilt_grid = [0.0, 5.0, 10.0, 15.0, 20.0]

    best = None

    for optic in OPTICS:
        for tilt in tilt_grid:
            U0, _ = eval_quality(optic, d, h, w, tilt, rtable, mf, arrangement,
                                 wall_offset=wall_offset)
            if U0 < U0_obj:
                continue
            phi = phi_for_luminance(optic, d, h, w, tilt, L_req, arrangement, rtable, mf,
                                    wall_offset=wall_offset)
            sel = select_model_for_flux(phi, cct, I_max_mA, I_min_pct)
            if best is None or sel["mA"] < best["mA"]:
                L_est = L_from_flux(optic, d, h, w, tilt, sel["lm"], arrangement, rtable, mf,
                                    wall_offset=wall_offset)
                best = {
                    "optic": optic, "tilt_deg": tilt,
                    "model": sel["model"], "mA": sel["mA"],
                    "W": sel["W"], "lm": round(sel["lm"],0),
                    "U0": round(U0,3), "L_est": round(L_est,1),
                    "warning": None,
                }

    if best is None:
        # NOTA: este fallback NUNCA deberia dispararse para llamadas que provienen
        # de find_dmax_for_zone (que pre-valida que d es factible antes de llamar
        # aqui). Se mantiene por compatibilidad con el modo retrofit (d_fixed,
        # donde d es una restriccion externa real y no se puede re-optimizar) y
        # queda marcado explicitamente como no-factible via 'feasible': False para
        # que el llamador SIEMPRE emita un warning visible en vez de aceptar el
        # resultado en silencio.
        optic, tilt = "F2M2", 0.0
        U0, _ = eval_quality(optic, d, h, w, tilt, rtable, mf, arrangement)
        phi   = phi_for_luminance(optic, d, h, w, tilt, L_req, arrangement, rtable, mf)
        sel   = select_model_for_flux(phi, cct, I_max_mA, I_min_pct)
        L_est = L_from_flux(optic, d, h, w, tilt, sel["lm"], arrangement, rtable, mf)
        best  = {
            "optic": optic, "tilt_deg": tilt,
            "model": sel["model"], "mA": sel["mA"],
            "W": sel["W"], "lm": round(sel["lm"],0),
            "U0": round(U0,3), "L_est": round(L_est,1),
            "feasible": False,
            "warning": (f"⚠️ U0_obj={U0_obj} NO ALCANZABLE a d={d:.1f}m con ninguna "
                        f"optica+tilt (U0 resultante={U0:.3f}). Requiere reducir d."),
        }
    else:
        best["feasible"] = True
        best.setdefault("warning", None)
    return best


# ── Fase 2b: busqueda de d factible (quality + flux) por zona ────────────────

def find_dmax_for_zone(
    L_req, h, w, U0_obj, Ul_obj, I_max_mA, cct,
    rtable="R2", mf=0.70, arrangement="central_single",
    I_min_pct=0.30, tilt_grid=None, d_min=2.5, d_max_hard=25.0,
    wall_offset=_WALL_Y_DEFAULT, tandem=False,
) -> dict:
    """
    Busca, sobre la malla (optica x tilt), el mayor d tal que se puedan
    satisfacer SIMULTANEAMENTE:
      - Calidad:  U0 >= U0_obj  Y  Ul >= Ul_obj  (independiente del flujo)
      - Flujo:    la luminancia L_req (o L_req/2 si tandem=True) es alcanzable
                  con el modelo/corriente disponibles hasta I_max_mA.

    Para cada combo (optica, tilt) se muestrea conjuntamente calidad Y flujo
    sobre [d_min, d_max_hard] y se toma el mayor d que cumple AMBAS
    condiciones SIMULTANEAMENTE (ver nota abajo — NO se puede calcular
    d_quality_max y d_flux_max por separado y tomar min(), porque U0/Ul en
    funcion de d no son monotonos en general).

    Se elige el combo que maximiza d_feasible (mismo criterio que optimize_interior).

    Retorna dict con 'feasible': False si NINGUN combo alcanza d_min con
    calidad Y flujo satisfechos simultaneamente (caso de infactibilidad fisica
    real) — el llamador DEBE emitir un warning explicito en ese caso, nunca
    aceptar en silencio un resultado que viole U0_obj/Ul_obj.

    NOTA (bug corregido): antes se calculaba d_quality_max = find_dmax_for_quality(...)
    y d_flux_max (biseccion asumiendo flujo monotono creciente en d, lo cual SI
    es correcto) por separado, y se tomaba d_feasible = min(d_quality_max, d_flux_max).
    Esto es invalido porque U0/Ul NO son monotonos en d: hay combinaciones optica+tilt
    donde la calidad es mala a d pequeno, buena a d intermedio y mala otra vez a d
    grande (para z. ej. tilt alto, la celda muy corta bajo la luminaria produce un
    pico local que baja U0). d_quality_max localiza el mayor d con calidad OK, pero
    eso NO implica que TODO d <= d_quality_max tambien cumpla calidad. Si
    d_flux_max resultaba menor que d_quality_max, el min() podia caer en una zona
    de d donde la calidad real ya NO se cumplia — produciendo un resultado
    'feasible: True' con U0/Ul realmente incumplidos (el bug reportado: L_est
    llegaba al objetivo pero U0 quedaba muy por debajo de U0_obj). La solucion:
    muestrear d directamente pidiendo calidad Y flujo simultaneos en cada punto.
    """
    if tilt_grid is None:
        tilt_grid = [0.0, 5.0, 10.0, 15.0, 20.0]

    L_target = (L_req / 2.0) if tandem else L_req
    lm_max, _ = flux_power_at_current(CHAIN_ORDER[-1], cct, I_max_mA, I_min_pct)

    best = None  # {"d", "optic", "tilt"}

    for optic in OPTICS:
        for tilt in tilt_grid:
            def _combined_ok(d, _optic=optic, _tilt=tilt):
                U0, Ul = eval_quality(_optic, d, h, w, _tilt, rtable, mf, arrangement,
                                      wall_offset=wall_offset)
                if U0 < U0_obj or Ul < Ul_obj:
                    return False
                phi = phi_for_luminance(_optic, d, h, w, _tilt, L_target,
                                        arrangement, rtable, mf, wall_offset=wall_offset)
                return phi <= lm_max

            d_feasible, feasible = _find_dmax_adaptive(_combined_ok, d_min, d_max_hard)
            if not feasible or d_feasible < d_min:
                continue

            if best is None or d_feasible > best["d"]:
                best = {"d": d_feasible, "optic": optic, "tilt": tilt}

    if best is None:
        return {
            "feasible": False, "d": round(d_min, 2), "optic": None, "tilt_deg": None,
            "model": None, "mA": 0.0, "W": 0.0, "lm": 0.0,
            "U0": 0.0, "Ul": 0.0, "L_est": 0.0,
            "warning": (
                f"⚠️ INFACTIBLE: ninguna combinacion optica+tilt alcanza "
                f"U0>={U0_obj}/Ul>={Ul_obj} Y el flujo requerido para "
                f"L_req={L_req:.0f} cd/m2 a d>={d_min} m"
                + (" incluso en tandem" if tandem else "") + ". "
                "Posibles soluciones: aumentar el flujo/corriente (I_max o modelo de "
                "mayor potencia), reducir la interdistancia minima, o replantear la "
                "boca del tunel (orientacion, pantallas o apantallamiento de luz "
                "diurna para bajar el L20/Lth exigido)."
            ),
        }

    d_use, optic, tilt = round(best["d"], 2), best["optic"], best["tilt"]
    phi   = phi_for_luminance(optic, d_use, h, w, tilt, L_target, arrangement, rtable, mf,
                              wall_offset=wall_offset)
    sel   = select_model_for_flux(phi, cct, I_max_mA, I_min_pct)
    U0f, Ulf = eval_quality(optic, d_use, h, w, tilt, rtable, mf, arrangement,
                            wall_offset=wall_offset)
    L_unit = L_from_flux(optic, d_use, h, w, tilt, sel["lm"], arrangement, rtable, mf,
                         wall_offset=wall_offset)
    L_total = 2.0 * L_unit if tandem else L_unit

    return {
        "feasible": True,
        "d":        d_use,
        "optic":    optic,
        "tilt_deg": tilt,
        "model":    sel["model"],
        "mA":       sel["mA"],
        "W":        sel["W"],
        "lm":       round(sel["lm"], 0),
        "U0":       round(U0f, 3),
        "Ul":       round(Ulf, 3),
        "L_est":    round(L_total, 1),
        "warning":  None,
    }


# ── Curva CIE 88 de transicion ────────────────────────────────────────────────

def cie88_L_transition(s, s_start, Lth, Lin, speed_kmh):
    """L(t) = Lth x (1.9 + t)^(-1.4), t=tiempo desde inicio [s]."""
    v_ms = max(speed_kmh / 3.6, 0.1)
    t    = max(0.0, (s - s_start) / v_ms)
    return max(Lth * (1.9 + t)**(-1.4), Lin)
