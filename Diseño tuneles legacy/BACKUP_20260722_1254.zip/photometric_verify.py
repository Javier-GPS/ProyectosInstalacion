"""
modules/tunnel/photometric_verify.py
=====================================
CIE 140:2019 photometric verification for APHEX tunnel zone designs.

After design_aphex_tunnel() selects luminaires for each zone using the
inside-out UF-table algorithm, this module verifies the actual luminance
quality (L_avg, U0, Ul, TI) using the full CIE 140:2019 point-by-point
calculation with real LDT angular distributions and CIE 144:2001 r-tables.

All S/M/L APHEX models share the same photometric distribution (same optics
F2MD/F2M2/F151). The LDT files for APHEX M are used as reference; flux is
scaled to the operating point of each zone's selected luminaire.

Road surface -> r-table mapping (CIE 144:2001):
    dark_asphalt   -> R3
    medium_asphalt -> R2
    light_asphalt  -> R1
    concrete       -> C1
    bright_concrete-> C2
"""
from __future__ import annotations

import sys
import math
from pathlib import Path
from typing import Optional

# ── Resolve project root so photometric_engine is importable ─────────────────
_HERE        = Path(__file__).resolve()
_PROJECT_ROOT = _HERE.parents[2]          # .../CALCULO FOTOMETRICO SALVI/
if str(_PROJECT_ROOT) not in sys.path:
    sys.path.insert(0, str(_PROJECT_ROOT))

_LDT_DIR = _PROJECT_ROOT / "photometric_engine" / "data" / "photometries"

# ── Road surface → CIE 144 r-table ──────────────────────────────────────────
_SURFACE_RTABLE: dict[str, str] = {
    "dark_asphalt":    "R3",
    "medium_asphalt":  "R2",
    "light_asphalt":   "R1",
    "concrete":        "C1",
    "bright_concrete": "C2",
}

# ── Optic → APHEX M LDT filename (all models share the same distribution) ───
_OPTIC_LDT: dict[str, str] = {
    "F2MD": "APHEX_M_H10_40K_F2MD_VDR_SPUW_200W.ldt",
    "F2M2": "APHEX_M_H10_40K_F2M2_VDR_SPUW_200W.ldt",
    "F151": "APHEX_M_H10_40K_F151_VDR_SPUW_200W.ldt",
}

# CIE 140 compliance thresholds
_U0_MIN  = 0.40
_UL_MIN  = 0.60
_TI_MAX  = 15.0

# Diffuse reflectance of road surface (Lambertian component, for radiosity)
_RHO_ROAD: dict[str, float] = {
    "dark_asphalt":    0.07,
    "medium_asphalt":  0.10,
    "light_asphalt":   0.15,
    "concrete":        0.28,
    "bright_concrete": 0.40,
}


def _is_available() -> bool:
    """Check that photometric_engine can be imported."""
    try:
        import photometric_engine.salvi_photometry.ldt_parser  # noqa: F401
        return True
    except ImportError:
        return False


def verify_luminaire_result(lum_result, params: dict, use_radiosity: bool = False) -> dict:
    """
    Run CIE 140:2019 photometric verification for every zone in a
    TunnelLuminaireResult produced by design_aphex_tunnel().

    Parameters
    ----------
    lum_result : TunnelLuminaireResult
        Output of design_aphex_tunnel() / calculate_luminaire_layout().
    params : dict
        Original luminaire params dict (needs mounting_height_m, maintenance_factor).

    Returns
    -------
    dict with structure:
        {
          "available": bool,
          "error": str | None,
          "rtable": "R2",
          "zones": {
            "CIN": {
              "L_avg": 12.94, "L_min": 7.45,
              "U0": 0.576, "Ul": 0.970, "TI": 1.3,
              "E_h_avg": 165.3,
              "compliant": true, "L_req": 10.0,
              "checks": {"L_avg": true, "U0": true, "Ul": true, "TI": true}
            },
            ...
          },
          "overall_compliant": bool
        }
    """
    out: dict = {"available": False, "error": None, "zones": {}, "overall_compliant": False}

    if not _is_available():
        out["error"] = "photometric_engine no disponible (importación fallida)"
        return out

    try:
        from photometric_engine.salvi_photometry.ldt_parser import load_ldt
        from photometric_engine.salvi_photometry.geometry   import Observer
        from photometric_engine.salvi_photometry.calculator import TunnelCalculator, LuminaireInstance, LuminaireOrientation
        from photometric_engine.salvi_photometry.radiosity  import TunnelSection, build_patches, solve_radiosity, indirect_illuminance_on_road
    except ImportError as exc:
        out["error"] = f"Error importando photometric_engine: {exc}"
        return out

    # ── Parámetros generales ─────────────────────────────────────────────────
    optic   = lum_result.optic or "F2MD"
    surface = lum_result.road_surface_type or "medium_asphalt"
    rtable  = _SURFACE_RTABLE.get(surface, "R2")
    W       = float(lum_result.road_width_m)
    H       = float(params.get("mounting_height_m", 5.0))
    mf      = float(params.get("maintenance_factor", 0.70))

    # ── LDT file ─────────────────────────────────────────────────────────────
    ldt_fname = _OPTIC_LDT.get(optic, _OPTIC_LDT["F2MD"])
    ldt_path  = _LDT_DIR / ldt_fname
    if not ldt_path.exists():
        out["error"] = f"LDT no encontrado: {ldt_fname}"
        return out

    try:
        phot = load_ldt(ldt_path)
    except Exception as exc:
        out["error"] = f"Error leyendo LDT: {exc}"
        return out

    calc = TunnelCalculator(rtable, mf)
    # Observer at road centre, 60 m ahead (CIE 140 §6.2.2)
    obs  = Observer(lane_y_m=W / 2, d_observer_m=60.0)

    out["available"] = True
    out["rtable"]    = rtable
    out["optic"]     = optic
    out["H_m"]       = H

    zone_results: dict = {}
    all_compliant = True

    for zd in lum_result.zones:
        if zd.n_luminaires <= 0 or zd.zone_length <= 0:
            continue

        S        = float(zd.d_used)
        flux_lm  = float(zd.flux_lm)
        L_req    = float(zd.L_required)
        zone_key = zd.zone_name

        if S <= 0.1 or flux_lm <= 0:
            continue

        # ── Luminaire array: ±5 spans, positions depend on arrangement ─────────
        n_side  = 5
        WALL_Y  = float(params.get('wall_offset_m', 0.30))  # m from wall to luminaire
        arr     = params.get('arrangement', 'central_single') or 'central_single'

        # ── Tandem support: 2 physical luminaires per position, offset along x ──
        # ZoneLuminaireDesign.n_tandem==2 means each nominal position i*S actually
        # holds a real A/B pair separated by tandem_offset_m (each carrying zd.flux_lm,
        # matching the per-unit flux convention used when the zone was designed).
        is_tandem   = int(getattr(zd, 'n_tandem', 1) or 1) == 2
        tandem_off  = float(getattr(zd, 'tandem_offset_m', 0.0) or 0.0)

        def _x_positions(i: int) -> list:
            """Physical x offsets for nominal position i (single, or A/B tandem pair)."""
            if is_tandem and tandem_off > 0:
                return [i * S - tandem_off / 2.0, i * S + tandem_off / 2.0]
            return [i * S]

        tilt_base = float(getattr(zd, "tilt_deg", 0) or 0)

        # El tilt (rotacion transversal, CIE 140 Anexo A) se espeja segun el
        # lado: cada fila se inclina hacia el eje del tunel, nunca ambas hacia
        # el mismo lado — igual que optimizer._build_lums y la vista previa.
        def _tilt_for_y(y_pos: float) -> float:
            return tilt_base if y_pos < W / 2 else -tilt_base

        if arr == 'bilateral_stag':
            # Alternating sides: even index → left wall, odd → right wall
            lums = [
                LuminaireInstance(
                    x           = x_p,
                    y           = (y_pos := (WALL_Y if abs(i) % 2 == 0 else W - WALL_Y)),
                    H           = H,
                    photometry  = phot,
                    flux_lm     = flux_lm,
                    orientation = LuminaireOrientation(tilt_deg=_tilt_for_y(y_pos)),
                )
                for i in range(-n_side, n_side + 1)
                for x_p in _x_positions(i)
            ]
        else:
            # Determine y positions per arrangement
            if arr == 'lateral_left':
                ys = [WALL_Y]
            elif arr == 'lateral_right':
                ys = [W - WALL_Y]
            elif arr == 'bilateral_sym':
                ys = [WALL_Y, W - WALL_Y]
            elif arr == 'central_double':
                ys = [W / 2 - 0.30, W / 2 + 0.30]
            else:                        # central_single / central_offset / auto
                ys = [W / 2]
            lums = [
                LuminaireInstance(
                    x           = x_p,
                    y           = y,
                    H           = H,
                    photometry  = phot,
                    flux_lm     = flux_lm,
                    orientation = LuminaireOrientation(tilt_deg=_tilt_for_y(y)),
                )
                for i in range(-n_side, n_side + 1)
                for y in ys
                for x_p in _x_positions(i)
            ]

        # ── CIE 140 §6.3 calculation grid over one representative span ───────
        n_long, n_trans = 10, 5
        xs  = [(-S / 2) + (i + 0.5) * S / n_long for i in range(n_long)]
        ys  = [(j + 0.5) * W / n_trans             for j in range(n_trans)]
        pts = [(x, y) for x in xs for y in ys]

        try:
            zr = calc.calculate_zone(
                zone_name   = zd.zone_type,
                zone_type   = zd.zone_type,
                s_start     = -S / 2,
                s_end       =  S / 2,
                L_req       = L_req,
                calc_points = pts,
                luminaires  = lums,
                observer    = obs,
            )
            # ── Optional radiosity pass ───────────────────────────────────
            L_indirect = 0.0
            rad_info = {}
            if use_radiosity:
                try:
                    import math as _math
                    rho_road    = _RHO_ROAD.get(surface, 0.10)
                    rho_wall    = float(params.get('rho_wall',    0.40))
                    rho_ceiling = float(params.get('rho_ceiling', 0.25))
                    H_t         = float(params.get('height_m', H + 1.0))
                    section = TunnelSection(
                        width_m=W, height_m=H_t,
                        rho_road=rho_road, rho_wall=rho_wall,
                        rho_ceiling=rho_ceiling,
                    )
                    patches = build_patches(section)
                    # Compute direct E on each patch from luminaire array
                    n_side_rad = 5
                    for p in patches:
                        e_direct = 0.0
                        for lum in lums:
                            for xi in range(-n_side_rad, n_side_rad+1):
                                x_l = lum.x + xi * S
                                dy = p.y_center - lum.y
                                dz = p.z_center - lum.H
                                dx = 0.0 - x_l
                                r2 = dx*dx + dy*dy + dz*dz
                                if r2 < 0.01: continue
                                r  = _math.sqrt(r2)
                                # cos of angle of incidence on patch
                                cos_inc = -(dy*p.normal[0] + dz*p.normal[1]) / r
                                if cos_inc <= 0: continue
                                # photometric angles (3D generalization)
                                d_plan = _math.sqrt(dx*dx + dy*dy)
                                g_rad  = _math.atan2(d_plan, max(0.001, lum.H - p.z_center))
                                g_deg  = _math.degrees(g_rad)
                                c_deg  = (_math.degrees(_math.atan2(dy, dx)) + 360) % 360
                                I_cd   = lum.photometry.intensity(c_deg, g_deg,
                                            scale_flux_lm=lum.flux_lm)
                                e_direct += I_cd * cos_inc / r2 * mf
                        p.E_direct = e_direct
                    solve_radiosity(patches)
                    # Indirect luminance on road = E_indirect * rho_road / pi
                    y_pts = list(set(yP for _, yP in pts))
                    e_ind_avg = _math.fsum(
                        indirect_illuminance_on_road(patches, yP) for yP in y_pts
                    ) / max(1, len(y_pts))
                    L_indirect = e_ind_avg * rho_road / _math.pi
                    rad_info = {
                        'rho_wall': rho_wall, 'rho_ceiling': rho_ceiling,
                        'L_indirect': round(L_indirect, 3),
                        'pct': round(100*L_indirect/max(zr.L_avg,0.01), 1),
                    }
                except Exception as rad_err:
                    rad_info = {'error': str(rad_err)}

            L_avg_total = zr.L_avg + L_indirect
            L_min_total = zr.L_min + L_indirect
            U0_rad = L_min_total / L_avg_total if L_avg_total > 0 else zr.U0
            Ul_rad = zr.Ul  # Ul shape unchanged by uniform indirect term

            L_ok  = L_avg_total >= L_req  if L_req > 0 else True
            U0_ok = U0_rad >= _U0_MIN
            Ul_ok = Ul_rad >= _UL_MIN
            TI_ok = zr.TI  <= _TI_MAX

            compliant = all([L_ok, U0_ok, Ul_ok, TI_ok])
            if not compliant:
                all_compliant = False

            zone_results[zone_key] = {
                "L_avg":      round(L_avg_total, 2),
                "L_min":      round(L_min_total, 2),
                "L_direct":   round(zr.L_avg, 2),
                "L_indirect": round(L_indirect, 3),
                "U0":         round(U0_rad, 3),
                "Ul":         round(Ul_rad, 3),
                "TI":         round(zr.TI,  1),
                "E_h_avg":    round(zr.E_h_avg, 1),
                "L_req":      round(L_req, 1),
                "compliant":  compliant,
                "radiosity":  rad_info,
                "checks": {
                    "L_avg": L_ok,
                    "U0":    U0_ok,
                    "Ul":    Ul_ok,
                    "TI":    TI_ok,
                },
            }
        except Exception as exc:
            zone_results[zone_key] = {
                "error": str(exc),
                "compliant": False,
            }
            all_compliant = False

    out["zones"]            = zone_results
    out["overall_compliant"] = all_compliant and bool(zone_results)
    return out


def compute_real_luminance_profile(lum_result, params: dict, road_width_m: float,
                                    step_size: float = 1.0) -> dict:
    """
    Perfil L(s) real a resolucion fina (misma interdistancia que la curva
    teorica CIE 88 — ver profile.py build_profile), calculado punto a punto
    con el motor CIE 140 usando el layout FISICO completo del tunel (posicion,
    optica, tilt y flujo reales de cada luminaria — reconstruidos a partir de
    los setpoints de cada zona), no solo una celda representativa por zona
    como verify_luminaire_result. Muestra por tanto el rizado real entre
    luminarias (picos bajo cada una, minimos a mitad de vano), en vez de un
    unico valor por luminaria conectado con una linea recta enganosa en el
    grafico de decaimiento.
    """
    out: dict = {"available": False, "error": None, "points": []}

    if not _is_available():
        out["error"] = "photometric_engine no disponible (importación fallida)"
        return out

    try:
        from photometric_engine.salvi_photometry.ldt_parser import load_ldt
        from photometric_engine.salvi_photometry.geometry   import Observer, LuminaireOrientation
        from photometric_engine.salvi_photometry.calculator import TunnelCalculator, LuminaireInstance
    except ImportError as exc:
        out["error"] = f"Error importando photometric_engine: {exc}"
        return out

    surface = lum_result.road_surface_type or "medium_asphalt"
    rtable  = _SURFACE_RTABLE.get(surface, "R2")
    W       = float(road_width_m)
    H       = float(params.get("mounting_height_m", 5.0))
    mf      = float(params.get("maintenance_factor", 0.70))
    arr     = params.get('arrangement', 'central_single') or 'central_single'
    WALL_Y  = float(params.get('wall_offset_m', 0.30))

    if arr == 'lateral_left':
        ys_default = [WALL_Y]
    elif arr in ('lateral_right', 'unilateral'):
        ys_default = [W - WALL_Y]
    elif arr in ('bilateral_sym', 'bilateral', 'staggered'):
        ys_default = [WALL_Y, W - WALL_Y]
    elif arr == 'central_double':
        ys_default = [W / 2 - 0.30, W / 2 + 0.30]
    else:
        ys_default = [W / 2]

    _phot_cache: dict = {}

    def _phot(optic: str):
        if optic not in _phot_cache:
            fname = _OPTIC_LDT.get(optic, _OPTIC_LDT["F2MD"])
            _phot_cache[optic] = load_ldt(_LDT_DIR / fname)
        return _phot_cache[optic]

    def _tilt_for_y(tilt_base: float, y_pos: float) -> float:
        return tilt_base if y_pos < W / 2 else -tilt_base

    # ── Reconstruir el layout físico completo del túnel a partir de los
    #    setpoints reales de cada zona (posición, óptica, tilt, flujo) ──────
    lums: list = []
    tube_length = 0.0
    try:
        for zd in lum_result.zones:
            if zd.n_luminaires <= 0:
                continue
            tube_length = max(tube_length, float(getattr(zd, 's_end', 0) or 0))
            sps = zd.setpoints or []
            for sp in sps:
                x_pos    = float(sp['s'])
                optic_id = sp.get('optic') or 'F2MD'
                flux     = float(sp.get('flux_lm', 0) or 0)
                tilt0    = float(sp.get('tilt_deg', 0) or 0)
                if flux <= 0:
                    continue
                if arr == 'bilateral_stag':
                    # Lado alternado por índice de posición física (par A/B
                    # incluido, ya expandido en 's' individuales).
                    y_pos = WALL_Y if (sp.get('idx', 1) - 1) % 2 == 0 else (W - WALL_Y)
                    lums.append(LuminaireInstance(
                        x=x_pos, y=y_pos, H=H, photometry=_phot(optic_id), flux_lm=flux,
                        orientation=LuminaireOrientation(tilt_deg=_tilt_for_y(tilt0, y_pos)),
                    ))
                else:
                    for y_pos in ys_default:
                        lums.append(LuminaireInstance(
                            x=x_pos, y=y_pos, H=H, photometry=_phot(optic_id), flux_lm=flux,
                            orientation=LuminaireOrientation(tilt_deg=_tilt_for_y(tilt0, y_pos)),
                        ))
    except Exception as exc:
        out["error"] = f"Error reconstruyendo el layout de luminarias: {exc}"
        return out

    if not lums or tube_length <= 0:
        out["error"] = "Sin luminarias posicionadas para calcular el perfil"
        return out

    calc = TunnelCalculator(rtable, mf)
    obs  = Observer(lane_y_m=W / 2, d_observer_m=60.0)

    points = []
    s = 0.0
    while True:
        s_c = min(s, tube_length)
        pr = calc.luminance_at_point(s_c, W / 2, lums, obs)
        points.append({"s": round(s_c, 2), "L": round(pr.L, 3)})
        if s_c >= tube_length:
            break
        s += step_size

    out["available"]    = True
    out["points"]       = points
    out["n_luminaires"] = len(lums)
    return out
