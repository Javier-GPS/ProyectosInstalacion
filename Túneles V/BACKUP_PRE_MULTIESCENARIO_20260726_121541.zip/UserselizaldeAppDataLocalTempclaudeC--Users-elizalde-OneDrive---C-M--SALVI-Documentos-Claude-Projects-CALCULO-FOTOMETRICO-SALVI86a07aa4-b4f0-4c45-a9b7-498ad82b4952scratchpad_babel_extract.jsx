
const { useState, useCallback, useMemo, useRef } = React;
const {
  LineChart, BarChart, Bar, ComposedChart, Area,
  Line, XAxis, YAxis, CartesianGrid, Tooltip,
  Legend, ReferenceLine, ReferenceArea, ResponsiveContainer, Customized, Brush
} = Recharts;

const LANGS     = window.STE_LANGS    || { es:{ label:'Español', flag:'ES' } };
const TR        = window.STE_TR       || {};
const HELP_DATA = window.STE_HELP_DATA || {};

function t(key, lang) {
  const entry = TR[key];
  if (!entry) return key;
  return entry[lang] || entry['es'] || key;
}

const STEP_IDS = [0, 1, 2, 3, 4, 5, 6, 7];
/** Defensive guard: siempre devuelve array, nunca explota con objeto */
const _asArr = v => Array.isArray(v) ? v : [];

// ── Error Boundary: atrapa crashes de render sin pantalla blanca ──────────
class ErrorBoundary extends React.Component {
  constructor(p){super(p);this.state={err:null};}
  static getDerivedStateFromError(e){return{err:e};}
  componentDidCatch(e,i){console.error('[SALVI] ErrorBoundary:',e,i);}
  render(){
    if(this.state.err){
      const msg=this.state.err?.message||String(this.state.err);
      return React.createElement('div',{style:{padding:20,background:'#fef2f2',border:'1px solid #fca5a5',borderRadius:8,margin:12,fontSize:'.8rem'}},
        React.createElement('b',{style:{color:'#b91c1c'}},'Error de interfaz: '),
        msg,
        React.createElement('br'),
        React.createElement('button',{onClick:()=>this.setState({err:null}),
          style:{marginTop:8,padding:'4px 12px',borderRadius:4,border:'none',background:'#b91c1c',color:'#fff',cursor:'pointer'}},
          'Reintentar')
      );
    }
    return this.props.children;
  }
}

const ZONE_COLORS = {
  ACCESS:     "#e74c3c",
  THRESHOLD:  "#f39c12",
  TRANSITION: "#17a2b8",
  INTERIOR:   "#27ae60",
  EXIT:       "#8e44ad",
  PARTING:    "#e74c3c",
  NIGHT:      "#2c3e50",
};

const ENV_OPTIONS = [
  { value: "open_country_flat",  label: "Campo abierto plano" },
  { value: "open_country_hilly", label: "Campo abierto ondulado" },
  { value: "forest",             label: "Entorno forestal" },
  { value: "urban",              label: "Urbano" },
  { value: "mountain",           label: "Montaña" },
  { value: "coastal",            label: "Costero" },
  { value: "desert",             label: "Desierto" },
];

const ORIENT_OPTIONS = ["N","NE","E","SE","S","SW","W","NW"];
const OPPOSITE_ORI = {N:"S",NE:"SW",E:"W",SE:"NW",S:"N",SW:"NE",W:"E",NW:"SE"};
const ORIENT_LABEL = {N:"Norte",NE:"Noreste",E:"Este",SE:"Sureste",S:"Sur",SW:"Suroeste",W:"Oeste",NW:"Noroeste"};

function LangSwitcher({ lang, onChange }) {
  return (
    <div className="lang-switcher">
      {Object.entries(LANGS).map(([code, { flag }]) => (
        <button key={code}
          className={`lang-btn ${lang === code ? 'active' : ''}`}
          onClick={() => onChange(code)}
          title={LANGS[code].label}>
          {flag}
        </button>
      ))}
    </div>
  );
}

function HelpBlock({ blocks }) {
  if (!blocks || !blocks.length) return null;
  return (
    <div>
      {blocks.map((b, i) => {
        if (b.h1)   return <h1 key={i}>{b.h1}</h1>;
        if (b.h2)   return <h2 key={i}>{b.h2}</h2>;
        if (b.p)    return <p  key={i}>{b.p}</p>;
        if (b.ul)   return <ul key={i}>{b.ul.map((item, j) => <li key={j}>{item}</li>)}</ul>;
        if (b.tip)  return <div key={i} className="help-tip">💡 {b.tip}</div>;
        if (b.warn) return <div key={i} className="help-warn">⚠️ {b.warn}</div>;
        if (b.table) return (
          <table key={i} className="help-table">
            <thead><tr>{b.table.heads.map((h, j) => <th key={j}>{h}</th>)}</tr></thead>
            <tbody>{b.table.rows.map((row, j) => <tr key={j}>{row.map((cell, k) => <td key={k}>{cell}</td>)}</tr>)}</tbody>
          </table>
        );
        if (b.keys) return (
          <table key={i} className="help-keys">
            <tbody>{b.keys.map(({ k, d }, j) => <tr key={j}><td>{k}</td><td>{d}</td></tr>)}</tbody>
          </table>
        );
        return null;
      })}
    </div>
  );
}

function HelpPanel({ lang, onClose }) {
  const [section, setSection] = useState('overview');
  const NAV = [
    { id: 'overview',  icon: '🎯' }, { id: 'guide',     icon: '📋' },
    { id: 'normativa', icon: '📐' }, { id: 'concepts',  icon: '💡' },
    { id: 'limits',    icon: '⚠️' }, { id: 'faq',       icon: '❓' },
    { id: 'ai',        icon: '🤖' }, { id: 'shortcuts', icon: '⌨️' },
  ];
  const blocks = (HELP_DATA[section] || {})[lang] || (HELP_DATA[section] || {})['es'] || [];
  return (
    <div className="help-overlay" onClick={e => e.target === e.currentTarget && onClose()}>
      <div className="help-panel">
        <div className="help-header">
          <div>
            <div style={{fontWeight:700, fontSize:'.90rem'}}>{t('help.title', lang)}</div>
            <div style={{fontSize:'.70rem', opacity:.7}}>{t('help.sub', lang)}</div>
          </div>
          <button className="tb-btn" onClick={onClose}>{t('help.close', lang)}</button>
        </div>
        <div className="help-body">
          <nav className="help-nav">
            {NAV.map(({ id, icon }) => (
              <button key={id} className={`help-nav-btn ${section === id ? 'active' : ''}`} onClick={() => setSection(id)}>
                <span style={{marginRight:4}}>{icon}</span>{t(`help.nav.${id}`, lang)}
              </button>
            ))}
          </nav>
          <div className="help-content"><HelpBlock blocks={blocks} /></div>
        </div>
      </div>
    </div>
  );
}

function InfoTip({ content, side='right' }) {
  const [open, setOpen] = React.useState(false);
  const [pos, setPos] = React.useState(null);
  const iconRef = React.useRef(null);
  const W = 260;

  const toggle = (e) => {
    e.stopPropagation();
    if (!open && iconRef.current) {
      const r = iconRef.current.getBoundingClientRect();
      let left = side === 'left' ? r.right - W : r.left;
      left = Math.min(Math.max(8, left), window.innerWidth - W - 8);
      const top = Math.min(r.bottom + 6, window.innerHeight - 8);
      setPos({ top, left });
    }
    setOpen(o => !o);
  };

  return (
    <span style={{position:'relative',display:'inline-block',marginLeft:4,verticalAlign:'middle'}}>
      <span
        ref={iconRef}
        onClick={toggle}
        style={{display:'inline-flex',alignItems:'center',justifyContent:'center',
          width:14,height:14,borderRadius:'50%',
          background:'#6366f1',color:'#fff',
          fontSize:'9px',fontWeight:700,cursor:'pointer',lineHeight:1,
          userSelect:'none',flexShrink:0}}
      >i</span>
      {open && pos && ReactDOM.createPortal(
        <div style={{
          position:'fixed',top:pos.top,left:pos.left,width:W,zIndex:99999,
          background:'#fff',color:'#111',
          borderRadius:7,padding:'9px 11px',
          fontSize:'.67rem',lineHeight:1.6,fontWeight:400,
          boxShadow:'0 6px 20px rgba(0,0,0,.25)',
          border:'1px solid #d1d5db',
          maxHeight:'60vh',overflowY:'auto'
        }}
          onClick={e=>e.stopPropagation()}
          dangerouslySetInnerHTML={{__html:content}}
        />,
        document.body
      )}
    </span>
  );
}

function Field({ label, hint, info, infoSide, children, osm, onClearOsm }) {
  return (
    <div className={`field${osm ? ' field-osm' : ''}`}>
      <label>
        {label}
        {info && <InfoTip content={info} side={infoSide||'right'}/>}
        {osm && (
          <span className="osm-badge" title="Importado de OSM — clic para validar"
            onClick={e=>{ e.preventDefault(); onClearOsm && onClearOsm(); }}>
            🗺 OSM
          </span>
        )}
      </label>
      {children}
      {hint && <span className="hint">{hint}</span>}
    </div>
  );
}

function KpiCard({ label, value, unit, highlight }) {
  return (
    <div className={`kpi-card ${highlight ? "highlight" : ""}`}>
      <div className="kpi-label">{label}</div>
      <div className="kpi-value">{value}</div>
      <div className="kpi-unit">{unit}</div>
    </div>
  );
}

function ZoneBadge({ zone }) {
  return <span className={`badge-zone z-${zone}`}>{zone.replace("_", " ")}</span>;
}

function Alert({ type, children }) {
  return <div className={`alert alert-${type}`}>{children}</div>;
}

function RegulationCurveChart({ curve }) {
  if (!curve || !curve.points || curve.points.length === 0) return null;
  return (
    <div style={{width:"100%", height:220}}>
      <ResponsiveContainer>
        <LineChart data={curve.points} margin={{top:10, right:30, left:0, bottom:20}}>
          <CartesianGrid strokeDasharray="3 3" stroke="#E8E2D8" />
          <XAxis dataKey="L20" label={{ value:"L₂₀ (cd/m²)", position:"insideBottom", offset:-8, fontSize:11 }} tick={{ fontSize:10 }} />
          <YAxis domain={[0,105]} label={{ value:"Regulación (%)", angle:-90, position:"insideLeft", fontSize:11 }} tick={{ fontSize:10 }} />
          <Tooltip formatter={(val) => [`${val}%`, "Regulación"]} labelFormatter={(l20) => `L₂₀ = ${l20} cd/m²`} />
          <Line type="monotone" dataKey="dimming_pct" stroke="#1E1E1E" strokeWidth={2} dot={{ fill:"#1E1E1E", r:2.5 }} name="Regulación (%)" />
        </LineChart>
      </ResponsiveContainer>
    </div>
  );
}

function StepControl({ result, form, onChange }) {
  if (!result?.success) return <Alert type="info">Completa el cálculo primero.</Alert>;

  const protocol   = form.control_protocol   || 'DALI-continuous';
  const sensorType = form.sensor_type        || 'luminancemeter_L20';
  const interval   = +(form.sample_interval_min || 10);
  const dimMin     = +(form.dim_min_pct      || 20);
  const dimMax     = +(form.dim_max_pct      || 100);
  const rampTime   = +(form.ramp_time_s      || 60);

  const { summary } = result;
  const Lth_d = summary.Lth;
  const L20_d = summary.L20;
  const k     = L20_d > 0 ? Lth_d / L20_d : 0;

  // Dimming curve: L20 from 0 → L20_design; dim% = clamp(L20/L20_design×100, dimMin, dimMax)
  const curveData = useMemo(() => {
    const pts = [];
    for (let i = 0; i <= 25; i++) {
      const L20  = +(( i / 25) * L20_d).toFixed(1);
      const frac = L20_d > 0 ? i / 25 : 0;
      const dim  = +Math.min(dimMax, Math.max(dimMin, frac * 100)).toFixed(1);
      pts.push({ L20, dim });
    }
    return pts;
  }, [L20_d, dimMin, dimMax]);

  // Annual energy estimate
  const SKY_HOURS = {
    clear:        [{ label:'Día soleado',         L20f:1.00, hrs:1600 },
                   { label:'Día parcial',          L20f:0.40, hrs:1200 },
                   { label:'Amanecer/anochecer',   L20f:0.05, hrs:600  },
                   { label:'Noche',                L20f:0.00, hrs:5360 }],
    intermediate: [{ label:'Día soleado',         L20f:1.00, hrs:800  },
                   { label:'Día parcial',          L20f:0.40, hrs:1600 },
                   { label:'Amanecer/anochecer',   L20f:0.05, hrs:600  },
                   { label:'Noche',                L20f:0.00, hrs:5760 }],
    overcast:     [{ label:'Día soleado',         L20f:1.00, hrs:200  },
                   { label:'Día parcial',          L20f:0.40, hrs:2000 },
                   { label:'Amanecer/anochecer',   L20f:0.05, hrs:600  },
                   { label:'Noche',                L20f:0.00, hrs:5960 }],
  };
  const skyDist    = SKY_HOURS[form.sky_condition] || SKY_HOURS.intermediate;
  const installedKw = +(form.installed_power_kw || 0);

  const energyRows = skyDist.map(({ label, L20f, hrs }) => {
    const dim     = +Math.min(dimMax, Math.max(dimMin, L20f * 100)).toFixed(0);
    const kWh     = installedKw > 0 ? +(installedKw * (dim / 100) * hrs).toFixed(0) : null;
    const kWh_fix = installedKw > 0 ? +(installedKw * hrs).toFixed(0)               : null;
    return { label, hrs, dim, kWh, kWh_fix };
  });
  const totalKwh    = installedKw > 0 ? energyRows.reduce((s, r) => s + (r.kWh    || 0), 0) : null;
  const totalKwhFix = installedKw > 0 ? energyRows.reduce((s, r) => s + (r.kWh_fix || 0), 0) : null;
  const savingsPct  = totalKwh && totalKwhFix && totalKwhFix > 0
    ? Math.round((1 - totalKwh / totalKwhFix) * 100) : null;

  const handleExport = () => {
    const data = {
      protocol, sensor_type: sensorType,
      sample_interval_min: interval,
      dim_min_pct: dimMin, dim_max_pct: dimMax, ramp_time_s: rampTime,
      design_L20: L20_d, design_Lth: Lth_d, k_factor: +k.toFixed(4),
      energy_estimate: totalKwh
        ? { total_kwh: Math.round(totalKwh), total_kwh_fixed: Math.round(totalKwhFix), savings_pct: savingsPct }
        : null,
    };
    const blob = new Blob([JSON.stringify(data, null, 2)], { type:'application/json' });
    const a = document.createElement('a'); a.href = URL.createObjectURL(blob);
    a.download = `control_${form.tube_id||'T1'}.json`; a.click();
  };

  return (
    <div>
      {/* ── Sistema de control ── */}
      <div className="card">
        <div className="card-title">🎛️ Sistema de control — CIE 88:2004 §87–111</div>
        <div className="form-grid col-2">
          <Field label="Protocolo">
            <select value={protocol} onChange={e => onChange('control_protocol', e.target.value)}>
              <option value="DALI-continuous">DALI continuo (IEC 62386)</option>
              <option value="SmartEC">SmartEC continuo</option>
              <option value="DALI-scenes">DALI escenas preset</option>
              <option value="0-10V">Analógico 0-10V</option>
            </select>
          </Field>
          <Field label="Sensor de luminancia">
            <select value={sensorType} onChange={e => onChange('sensor_type', e.target.value)}>
              <option value="luminancemeter_L20">Luminancímetro L₂₀ (CIE §5)</option>
              <option value="photocell_Lad">Célula fotoeléctrica Lad</option>
              <option value="schedule">Sin sensor (horario)</option>
            </select>
          </Field>
          <Field label="Intervalo de muestreo">
            <select value={interval} onChange={e => onChange('sample_interval_min', +e.target.value)}>
              <option value={5}>5 minutos</option>
              <option value={10}>10 minutos</option>
              <option value={15}>15 minutos</option>
              <option value={30}>30 minutos</option>
            </select>
          </Field>
          <Field label="Rampa de transición">
            <select value={rampTime} onChange={e => onChange('ramp_time_s', +e.target.value)}>
              <option value={30}>30 s</option>
              <option value={60}>60 s</option>
              <option value={120}>2 min</option>
              <option value={300}>5 min</option>
            </select>
          </Field>
        </div>
        {sensorType === 'schedule' && (
          <div className="alert alert-warning" style={{marginTop:8,fontSize:'.78rem'}}>
            ⚠️ Sin luminancímetro la regulación no sigue el modelo continuo CIE 88. Se recomienda al menos una célula fotoeléctrica Lad.
          </div>
        )}
      </div>

      {/* ── Límites de dimerado ── */}
      <div className="card">
        <div className="card-title">📊 Límites de dimerado</div>
        <div className="form-grid col-2" style={{marginBottom:8}}>
          <Field label="Mínimo (noche / seguridad)" hint={`Nivel nocturno: ${dimMin}%`}>
            <input type="range" min={5} max={40} step={5} value={dimMin}
              onChange={e => onChange('dim_min_pct', +e.target.value)}
              style={{width:'100%',accentColor:'var(--salvi-black)'}}/>
          </Field>
          <Field label="Máximo (pico solar)" hint={`Nivel de diseño: ${dimMax}%`}>
            <input type="range" min={80} max={100} step={5} value={dimMax}
              onChange={e => onChange('dim_max_pct', +e.target.value)}
              style={{width:'100%',accentColor:'var(--salvi-black)'}}/>
          </Field>
        </div>
        <div style={{display:'flex',gap:20,fontSize:'.74rem',color:'var(--salvi-grey)',flexWrap:'wrap'}}>
          <span>L₂₀ diseño: <strong style={{color:'var(--salvi-black)'}}>{L20_d} cd/m²</strong></span>
          <span>Lth diseño: <strong style={{color:'var(--salvi-black)'}}>{Lth_d} cd/m²</strong></span>
          <span>k = Lth/L₂₀: <strong style={{color:'var(--salvi-black)'}}>{+k.toFixed(3)}</strong></span>
        </div>
      </div>

      {/* ── Curva de regulación ── */}
      <div className="chart-card">
        <div className="chart-card-title">Curva de regulación continua — Zona Umbral</div>
        <ResponsiveContainer width="100%" height={200}>
          <ComposedChart data={curveData} margin={{top:8,right:55,left:0,bottom:22}}>
            <CartesianGrid strokeDasharray="3 3" stroke="#E8E2D8"/>
            <XAxis dataKey="L20" tick={{fontSize:10}}
              label={{value:'L₂₀ (cd/m²)',position:'insideBottom',offset:-10,fontSize:10,fill:'#6A6A6A'}}/>
            <YAxis domain={[0,105]} tick={{fontSize:10}} tickFormatter={v=>`${v}%`}/>
            <Tooltip formatter={v=>[`${v}%`,'Dimerado']} labelFormatter={l=>`L₂₀ = ${l} cd/m²`}/>
            <ReferenceLine y={dimMin} stroke="#B7791F" strokeDasharray="4 2"
              label={{value:`min ${dimMin}%`,fontSize:9,fill:'#B7791F',position:'insideRight'}}/>
            <ReferenceLine y={dimMax} stroke="#1F7A4D" strokeDasharray="4 2"
              label={{value:`max ${dimMax}%`,fontSize:9,fill:'#1F7A4D',position:'insideRight'}}/>
            <ReferenceLine x={L20_d} stroke="#1E1E1E" strokeDasharray="3 3"
              label={{value:'diseño',fontSize:9,fill:'#1E1E1E',position:'top'}}/>
            <Line type="monotone" dataKey="dim" stroke="#1E1E1E" strokeWidth={2} dot={false} name="Dimerado (%)"/>
          </ComposedChart>
        </ResponsiveContainer>
      </div>

      {/* ── Estimación energética anual ── */}
      <div className="card">
        <div className="card-title">⚡ Estimación energética anual</div>
        {installedKw === 0 ? (
          <div>
            <div className="alert alert-info" style={{fontSize:'.78rem',marginBottom:10}}>
              💡 Completa el paso de <strong>Luminarias</strong> primero — la potencia instalada se transferirá automáticamente.
            </div>
            <Field label="O introduce la potencia instalada (kW)">
              <input type="number" min={0} step={0.5} value={form.installed_power_kw||''}
                placeholder="ej. 12.5"
                onChange={e=>onChange('installed_power_kw', +e.target.value)}/>
            </Field>
          </div>
        ) : (
          <>
            <div style={{marginBottom:10,fontSize:'.74rem',color:'var(--salvi-grey)'}}>
              Potencia instalada: <strong style={{color:'var(--salvi-black)'}}>{installedKw} kW</strong>
              {' — '}Distribución anual según cielo: <strong style={{color:'var(--salvi-black)'}}>{form.sky_condition||'intermediate'}</strong>
            </div>
            <table className="result-table" style={{marginBottom:10}}>
              <thead>
                <tr>
                  <th>Condición</th>
                  <th style={{textAlign:'right'}}>h/año</th>
                  <th style={{textAlign:'center'}}>Nivel</th>
                  <th style={{textAlign:'right'}}>kWh control</th>
                  <th style={{textAlign:'right',color:'var(--salvi-grey)'}}>kWh 100%</th>
                </tr>
              </thead>
              <tbody>
                {energyRows.map((r,i) => (
                  <tr key={i}>
                    <td style={{fontSize:'.78rem'}}>{r.label}</td>
                    <td style={{textAlign:'right',fontSize:'.80rem'}}>{r.hrs.toLocaleString()}</td>
                    <td style={{textAlign:'center'}}>
                      <div style={{display:'inline-flex',alignItems:'center',gap:5,minWidth:80}}>
                        <div style={{width:44,height:7,borderRadius:4,background:'var(--salvi-line)',overflow:'hidden'}}>
                          <div style={{width:`${r.dim}%`,height:'100%',background:'var(--salvi-black)'}}/>
                        </div>
                        <span style={{fontSize:'.75rem',fontWeight:600}}>{r.dim}%</span>
                      </div>
                    </td>
                    <td style={{textAlign:'right',fontWeight:600,fontSize:'.82rem'}}>{r.kWh?.toLocaleString()}</td>
                    <td style={{textAlign:'right',fontSize:'.78rem',color:'var(--salvi-grey)'}}>{r.kWh_fix?.toLocaleString()}</td>
                  </tr>
                ))}
                <tr style={{fontWeight:700,borderTop:'2px solid var(--salvi-line)'}}>
                  <td>Total</td>
                  <td style={{textAlign:'right'}}>8.760</td>
                  <td/>
                  <td style={{textAlign:'right'}}>{totalKwh?.toLocaleString()} kWh</td>
                  <td style={{textAlign:'right',color:'var(--salvi-grey)'}}>{totalKwhFix?.toLocaleString()} kWh</td>
                </tr>
              </tbody>
            </table>
            {savingsPct !== null && (
              <div className="alert alert-success" style={{fontSize:'.80rem'}}>
                ✅ Ahorro estimado con control continuo: <strong>{savingsPct}%</strong>
                {totalKwhFix && totalKwh
                  ? ` — ${Math.round((totalKwhFix - totalKwh) / 1000)} MWh/año ahorrados`
                  : ''}
              </div>
            )}
          </>
        )}
      </div>

      {/* ── Exportar ── */}
      <div className="card">
        <div className="card-title">💾 Exportar parámetros</div>
        <div style={{display:'flex',gap:8}}>
          <button className="btn btn-outline" onClick={handleExport}>⬇️ JSON</button>
        </div>
      </div>
    </div>
  );
}

function ProfileChart({ chartData, tunnelLength, Lth, Lin, zones, actualPoints, denseActual=false }) {
  if (!chartData || !chartData.data || chartData.data.length === 0) {
    return <div style={{textAlign:"center",color:"#999",padding:"40px"}}>Sin datos de perfil</div>;
  }
  const { data } = chartData;

  // ── Zone metadata ────────────────────────────────────────────────
  const ZONE_LABELS = {
    ACCESS:'Acceso', THRESHOLD:'Umbral A', TRANSITION:'Trans. A',
    INTERIOR:'Interior', TRANSITION_B:'Trans. B', THRESHOLD_B:'Umbral B',
    EXIT:'Salida', PARTING:'Post-salida'
  };
  const ZONE_FILL = {
    ACCESS:'#f3f4f6', THRESHOLD:'#fef3c7', TRANSITION:'#e0f2fe',
    INTERIOR:'#d1fae5', TRANSITION_B:'#bae6fd', THRESHOLD_B:'#fef9c3',
    EXIT:'#ede9fe', PARTING:'#f3f4f6'
  };
  const ZONE_STROKE = {
    ACCESS:'#9ca3af', THRESHOLD:'#d97706', TRANSITION:'#0891b2',
    INTERIOR:'#059669', TRANSITION_B:'#0284c7', THRESHOLD_B:'#ca8a04',
    EXIT:'#7c3aed', PARTING:'#9ca3af'
  };
  const ZONE_ORDER = zones
    ? Object.keys(zones).filter(k=>zones[k]).sort((a,b)=>zones[a].s_start-zones[b].s_start).map(k=>k.toUpperCase())
    : ['ACCESS','THRESHOLD','TRANSITION','INTERIOR','EXIT','PARTING'];

  // ── Interior compression ────────────────────────────────────────
  // If interior zone is wide, compress it to INT_MAX display-units
  const INT_MAX = 250; // max visual width for interior (in s-units)
  let intStart = null, intEnd = null;
  if (zones?.interior) { intStart = zones.interior.s_start; intEnd = zones.interior.s_end; }
  else {
    // derive from data
    const intPts = data.filter(d=>d.zone.toUpperCase()==='INTERIOR');
    if (intPts.length > 1) { intStart = intPts[0].s; intEnd = intPts[intPts.length-1].s; }
  }
  const intLen = (intStart!=null && intEnd!=null) ? intEnd - intStart : 0;
  const doCompress = intLen > INT_MAX + 50;
  const compRatio  = doCompress ? INT_MAX / intLen : 1;

  const cS = (s) => {
    if (!doCompress || intStart == null) return s;
    if (s <= intStart) return s;
    if (s >= intEnd)   return intStart + INT_MAX + (s - intEnd);
    return intStart + (s - intStart) * compRatio;
  };
  const realS = (cs) => {
    if (!doCompress || intStart == null) return cs;
    if (cs <= intStart) return cs;
    const intEndC = intStart + INT_MAX;
    if (cs <= intEndC) return intStart + (cs - intStart) / compRatio;
    return intEnd + (cs - intEndC);
  };

  // ── Build unified dataset (one row per s, one column per zone) ──
  const zonesPresent = [...new Set(data.map(d=>d.zone.toUpperCase()))].filter(z=>ZONE_ORDER.includes(z)).sort((a,b)=>ZONE_ORDER.indexOf(a)-ZONE_ORDER.indexOf(b));
  const unified = data.map((pt,i)=>{
    const zone=pt.zone.toUpperCase(); const row={s:cS(pt.s), sReal:pt.s};
    zonesPresent.forEach(z=>{row[z]=null;}); row[zone]=pt.L;
    if(i>0){const prev=data[i-1].zone.toUpperCase(); if(prev!==zone&&zonesPresent.includes(prev))row[prev]=pt.L;}
    if(i<data.length-1){const next=data[i+1].zone.toUpperCase(); if(next!==zone&&zonesPresent.includes(next))row[next]=pt.L;}
    return row;
  });

  // ── Custom tick: show real s values ────────────────────────────
  const tickFormatter = (val) => {
    const r = Math.round(realS(val));
    return r + ' m';
  };

  // ── L real calculada (por luminaria) — superpuesta sobre la curva
  //    teorica CIE, usando el mismo eje comprimido cS(). Se adjunta al
  //    punto teorico existente MAS CERCANO (en vez de insertar una fila
  //    nueva) para que el tooltip siempre tenga ambos valores en la
  //    misma fila — si no, al pasar el raton exactamente sobre un punto
  //    real (fila propia, sin serie teorica), el tooltip caia de vuelta
  //    al mismo valor real y lo mostraba erroneamente como "teorica".
  const hasActual = actualPoints && actualPoints.length > 0;
  if (hasActual && unified.length > 0) {
    actualPoints
      .filter(p => p && p.s != null && p.L != null)
      .forEach(p => {
        const target = cS(p.s);
        let bestIdx = 0, bestDist = Infinity;
        for (let i = 0; i < unified.length; i++) {
          const dist = Math.abs(unified[i].s - target);
          if (dist < bestDist) { bestDist = dist; bestIdx = i; }
        }
        unified[bestIdx]._ACTUAL      = p.L;
        unified[bestIdx]._ACTUAL_LREQ = p.Lreq ?? null;
        unified[bestIdx]._ACTUAL_U0   = p.U0 ?? null;
        unified[bestIdx]._ACTUAL_UL   = p.Ul ?? null;
        unified[bestIdx].sReal        = p.s;
      });
  }

  // ── Zone bar data — sorted by s_start, includes B-zones ──────────
  const zoneBarItems = zones
    ? Object.keys(zones).filter(k=>zones[k])
        .sort((a,b)=>zones[a].s_start-zones[b].s_start)
        .map(key => {
          const z = zones[key];
          const dispLen = Math.max(1, cS(z.s_end) - cS(z.s_start));
          return { key, z, dispLen,
            label: ZONE_LABELS[key.toUpperCase()] || key,
            lenStr: doCompress && key==='interior' ? `${intLen.toFixed(0)} m ✂` : `${z.length?.toFixed(0)||'?'} m`,
            color: ZONE_STROKE[key.toUpperCase()] || '#9ca3af',
          };
        })
    : [];

  // left margin of recharts chart (YAxis) ≈ 50px; right margin ≈ 95px
  const CHART_LEFT_PX  = 50;
  const CHART_RIGHT_PX = 95;

  return (
    <div style={{width:"100%"}}>
      {hasActual && (
        <div style={{display:'flex',alignItems:'center',gap:6,marginBottom:4,fontSize:'.68rem',color:'#64748b'}}>
          <span style={{display:'inline-block',width:14,height:2,background:'#dc2626'}}/>
          <span>L real calculada (perfil físico CIE 140 punto a punto) superpuesta a la curva teórica CIE 88</span>
        </div>
      )}
      <div style={{height:320}}>
        <ResponsiveContainer>
          <ComposedChart data={unified} margin={{top:10,right:95,left:10,bottom:10}}>
            {/* Zone background bands */}
            {zones && ZONE_ORDER.map(zk => {
              const z = zones[zk.toLowerCase()]; if(!z) return null;
              return <ReferenceArea key={zk} x1={cS(z.s_start)} x2={cS(z.s_end)}
                fill={ZONE_FILL[zk]||'#f9f9f9'} fillOpacity={0.55} stroke="none"/>;
            })}

            {/* Marca del "corte" de compresión de la zona interior */}
            {doCompress && (
              <ReferenceLine x={intStart + INT_MAX} stroke="#94a3b8" strokeWidth={1.5}
                strokeDasharray="2 3"
                label={{value:`✂ ${intLen.toFixed(0)} m comprimidos`, position:"top",
                        fontSize:9, fill:"#64748b", fontWeight:600}}/>
            )}

            <CartesianGrid strokeDasharray="3 3" stroke="#E8E2D8"/>
            <XAxis dataKey="s" type="number" tickFormatter={tickFormatter} tick={{fontSize:9}}
              tickCount={doCompress?10:14}
              domain={[0, cS(tunnelLength || data[data.length-1]?.s || 0)]}/>
            <YAxis label={{value:"L (cd/m²) — escala log",angle:-90,position:"insideLeft",offset:10,fontSize:11}}
              tick={{fontSize:10}} scale="log" domain={[Math.max(0.5, (Lin||1)*0.5), 'auto']}
              allowDataOverflow={true}
              ticks={[1,2,5,10,20,50,100,200,500,1000].filter(t=>t>=Math.max(0.5,(Lin||1)*0.5))}
              tickFormatter={(v)=>Number(v)>=1?Math.round(v):v}/>

            <Tooltip content={({active,payload,label})=>{
              if(!active||!payload)return null;
              const pts=payload.filter(p=>p.value!=null); if(!pts.length)return null;
              const actualRow = payload.find(p=>p.dataKey==='_ACTUAL' && p.value!=null)?.payload;
              const pt = pts.find(p=>p.dataKey!=='_ACTUAL') || pts[0];
              const realM = Math.round(realS(label));
              return (
                <div style={{background:'#fff',border:`2px solid ${pt.color}`,borderRadius:5,padding:'7px 11px',fontSize:12}}>
                  <div style={{fontWeight:700,marginBottom:3}}>s = {realM} m</div>
                  <div style={{color:pt.color}}>{ZONE_LABELS[pt.dataKey]||pt.dataKey}</div>
                  <div style={{color:'#333',marginTop:2}}>L teórica = <strong>{Number(pt.value).toFixed(1)} cd/m²</strong></div>
                  {actualRow && actualRow._ACTUAL!=null && (
                    <div style={{marginTop:5,paddingTop:5,borderTop:'1px dashed #e2e8f0'}}>
                      <div style={{color:'#dc2626',fontWeight:600}}>L real calculada</div>
                      <div style={{color:'#333'}}>L = <strong>{Number(actualRow._ACTUAL).toFixed(1)} cd/m²</strong></div>
                      {actualRow._ACTUAL_LREQ!=null && <div style={{color:'#333'}}>L req. = {Number(actualRow._ACTUAL_LREQ).toFixed(1)} cd/m²</div>}
                      {actualRow._ACTUAL_U0!=null && <div style={{color:'#333'}}>U0 = {Number(actualRow._ACTUAL_U0).toFixed(3)}</div>}
                      {actualRow._ACTUAL_UL!=null && <div style={{color:'#333'}}>Ul = {Number(actualRow._ACTUAL_UL).toFixed(3)}</div>}
                    </div>
                  )}
                </div>
              );
            }}/>

            {zonesPresent.map(zone=>(
              <Area key={zone} type="monotone" dataKey={zone} name={zone}
                fill={ZONE_COLORS[zone]||"#aaa"} stroke={ZONE_COLORS[zone]||"#aaa"}
                fillOpacity={0.5} strokeWidth={2.5} connectNulls={false} dot={false}
                legendType="none" activeDot={{r:4,strokeWidth:0}}/>
            ))}

            {hasActual && (
              <Line type="linear" dataKey="_ACTUAL" name="L real (calculada)"
                stroke="#dc2626" strokeWidth={2} dot={denseActual ? false : {r:2.5,fill:'#dc2626',strokeWidth:0}}
                connectNulls={true} activeDot={{r:5,strokeWidth:0}} isAnimationActive={false}/>
            )}

            <ReferenceLine y={Lth} stroke="#f39c12" strokeDasharray="6 3" strokeWidth={1.5}
              label={{value:`Lth = ${Math.round(Lth)} cd/m²`,position:"right",fontSize:10,fill:"#c87f0a",fontWeight:600}}/>
            <ReferenceLine y={Lin} stroke="#27ae60" strokeDasharray="6 3" strokeWidth={1.5}
              label={{value:`Lin = ${Lin!=null?Lin.toFixed(1):'—'} cd/m²`,position:"right",fontSize:10,fill:"#1e8449",fontWeight:600}}/>

            <Brush dataKey="s" height={22} travellerWidth={8}
              stroke="#94a3b8" fill="#f8fafc"
              tickFormatter={tickFormatter}
              startIndex={0} endIndex={unified.length-1}/>
          </ComposedChart>
        </ResponsiveContainer>
      </div>

      {/* ── Zone label strip (HTML, always visible) ── */}
      {zoneBarItems.length > 0 && (
        <div style={{display:'flex', marginLeft:CHART_LEFT_PX, marginRight:CHART_RIGHT_PX, marginTop:2}}>
          {zoneBarItems.map(({key, dispLen, label, lenStr, color, bg}) => (
            <div key={key} style={{
              flex: dispLen,
              borderTop: `3px solid ${color}`,
              padding: '3px 2px 0',
              textAlign: 'center',
              overflow: 'hidden',
              minWidth: 0,
            }}>
              <div style={{fontSize:'9px', fontWeight:700, color, whiteSpace:'nowrap', overflow:'hidden', textOverflow:'ellipsis'}}>
                {label}
              </div>
              <div style={{fontSize:'8px', color:'#94a3b8', whiteSpace:'nowrap'}}>
                {lenStr}
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}

function estimateSD(v_kmh) {
  const v=v_kmh/3.6; return v*1.5+(v*v)/(2*3.5);
}

/* ══════════════════════════════════════════════════════════════════
   MapSelector — Leaflet map for tunnel geolocation + OSM import
   ══════════════════════════════════════════════════════════════════ */
/* ── TunnelFloatPanel — ventana flotante y arrastrable sobre el mapa ── */
function TunnelFloatPanel({ tunnelList, selTunnel, tunFilter, setTunFilter,
    tunTypeFilter, setTunTypeFilter, selectTunnel, removeTunnelFromList,
    importTunnel, setShowTunTable, tunColor }) {
  const [pos, setPos] = useState({x:8, y:56});
  const dragging = useRef(false);
  const offset   = useRef({dx:0,dy:0});

  React.useEffect(()=>{
    const onMove = (e)=>{
      if(!dragging.current) return;
      setPos({x: e.clientX - offset.current.dx, y: e.clientY - offset.current.dy});
    };
    const onUp = ()=>{ dragging.current=false; };
    document.addEventListener('mousemove', onMove);
    document.addEventListener('mouseup',   onUp);
    return ()=>{ document.removeEventListener('mousemove',onMove); document.removeEventListener('mouseup',onUp); };
  },[]);

  const startDrag = (e)=>{
    if(e.target.closest('button,input,select')) return;
    dragging.current = true;
    offset.current   = {dx: e.clientX - pos.x, dy: e.clientY - pos.y};
    e.preventDefault();
  };

  const thSt={padding:'4px 6px',fontWeight:600,color:'#92400e',fontSize:'.62rem',whiteSpace:'nowrap',borderBottom:'2px solid #fde68a',userSelect:'none'};
  const tdSt={padding:'3px 6px',verticalAlign:'middle',whiteSpace:'nowrap'};
  const aBtn=(bg,cl)=>({padding:'2px 5px',fontSize:'.68rem',cursor:'pointer',lineHeight:1.3,background:bg,border:'1px solid '+cl+'55',borderRadius:4,color:cl});

  const hwTypes=[...new Set(tunnelList.map(t=>t.highway).filter(Boolean))].sort();
  const filtered=tunnelList.filter(t=>{
    const mN=!tunFilter||(t.name||'').toLowerCase().includes(tunFilter.toLowerCase())||(t.ref||'').toLowerCase().includes(tunFilter.toLowerCase());
    const mT=tunTypeFilter==='all'||t.highway===tunTypeFilter;
    return mN&&mT;
  });

  return (
    <div style={{position:'absolute',left:pos.x,top:pos.y,width:580,zIndex:900,
        background:'#fff',border:'1.5px solid #d97706',borderRadius:8,
        boxShadow:'0 6px 28px rgba(0,0,0,.22)',display:'flex',flexDirection:'column',
        maxHeight:'62vh',minHeight:140,overflow:'hidden'}}>

      {/* Header / drag handle */}
      <div onMouseDown={startDrag}
        style={{display:'flex',alignItems:'center',gap:7,padding:'5px 10px',
          background:'#fffbeb',borderBottom:'1px solid #fde68a',flexShrink:0,
          cursor:'grab',userSelect:'none',borderRadius:'6px 6px 0 0'}}>
        <span style={{fontSize:'.75rem',color:'#92400e',marginRight:2}}>⠿</span>
        <span style={{fontWeight:700,fontSize:'.72rem',color:'#92400e'}}>🚇 Túneles</span>
        <span style={{fontSize:'.65rem',color:'#b45309',marginRight:'auto'}}>
          {filtered.length}/{tunnelList.length}{selTunnel?` · "${selTunnel.name}"`:''}</span>
        <input placeholder="Filtrar…" value={tunFilter} onChange={e=>setTunFilter(e.target.value)}
          style={{fontSize:'.65rem',padding:'2px 6px',border:'1px solid #fcd34d',borderRadius:4,
            width:110,outline:'none',background:'#fff'}}/>
        {hwTypes.length>1&&(
          <select value={tunTypeFilter} onChange={e=>setTunTypeFilter(e.target.value)}
            style={{fontSize:'.65rem',padding:'2px 4px',border:'1px solid #fcd34d',borderRadius:4,background:'#fff',cursor:'pointer'}}>
            <option value="all">Todos</option>
            {hwTypes.map(h=><option key={h} value={h}>{h}</option>)}
          </select>
        )}
        <button onClick={()=>setShowTunTable(false)}
          style={{background:'none',border:'none',cursor:'pointer',fontSize:'1rem',color:'#92400e',padding:'0 3px',lineHeight:1}}>✕</button>
      </div>

      {/* Table */}
      <div style={{overflowY:'auto',flex:1}}>
        <table style={{width:'100%',borderCollapse:'collapse',fontSize:'.67rem'}}>
          <thead><tr style={{background:'#fef3c7',position:'sticky',top:0,zIndex:2}}>
            <th style={{...thSt,width:20}}/>
            <th style={{...thSt,textAlign:'left',minWidth:130}}>Nombre</th>
            <th style={{...thSt,width:70,textAlign:'center'}}>Tipo</th>
            <th style={{...thSt,width:52,textAlign:'right'}}>L km</th>
            <th style={{...thSt,width:40,textAlign:'center'}}>v</th>
            <th style={{...thSt,width:34,textAlign:'center'}}>Car.</th>
            <th style={{...thSt,width:38,textAlign:'center'}}>Boca E</th>
            <th style={{...thSt,width:38,textAlign:'center'}}>Boca S</th>
            <th style={{...thSt,width:52,textAlign:'center'}}>Sentido</th>
            <th style={{...thSt,width:74,textAlign:'center'}}>Acc.</th>
          </tr></thead>
          <tbody>
            {filtered.map(tun=>{
              const isSel=selTunnel?.id===tun.id, origIdx=tunnelList.indexOf(tun);
              return (<React.Fragment key={tun.id}>
                <tr onClick={()=>selectTunnel(tun,origIdx)}
                  style={{background:isSel?'#fef9c3':origIdx%2===0?'#fff':'#fafaf9',
                    cursor:'pointer',borderBottom:'1px solid #f3f4f6',
                    boxShadow:isSel?'inset 0 0 0 2px #fbbf24':'none'}}>
                  <td style={{...tdSt,textAlign:'center'}}>
                    <span style={{display:'inline-block',width:9,height:9,borderRadius:'50%',background:tunColor(origIdx)}}/>
                  </td>
                  <td style={{...tdSt,fontWeight:isSel?700:400,maxWidth:160,overflow:'hidden',textOverflow:'ellipsis'}}>
                    {tun.name||tun.id}
                    {tun.ref&&tun.ref!==tun.name&&<span style={{color:'#9ca3af',marginLeft:4}}>({tun.ref})</span>}
                  </td>
                  <td style={{...tdSt,textAlign:'center',color:'#6b7280'}}>{tun.highway||'—'}</td>
                  <td style={{...tdSt,textAlign:'right'}}>{tun.length?(tun.length/1000).toFixed(2):'—'}</td>
                  <td style={{...tdSt,textAlign:'center'}}>{tun.speedKmh||'—'}</td>
                  <td style={{...tdSt,textAlign:'center'}}>{tun.lanes||'—'}</td>
                  <td style={{...tdSt,textAlign:'center',color:'#059669',fontWeight:600}}>{tun.entryOctant}</td>
                  <td style={{...tdSt,textAlign:'center',color:'#dc2626',fontWeight:600}}>{tun.exitOctant}</td>
                  <td style={{...tdSt,textAlign:'center',fontSize:'.61rem',color:tun.oneway?'#0284c7':'#6b7280'}}>{tun.oneway?'↑':'⇅'}</td>
                  <td style={{...tdSt,textAlign:'center'}} onClick={e=>e.stopPropagation()}>
                    <div style={{display:'flex',gap:3,justifyContent:'center'}}>
                      <button onClick={()=>selectTunnel(tun,origIdx)} style={aBtn('#f0f9ff','#0284c7')}>🔍</button>
                      <button onClick={()=>{selectTunnel(tun,origIdx);setTimeout(()=>{importTunnel();setShowTunTable(false);},80);}} style={aBtn('#f0fdf4','#059669')}>⬆</button>
                      <button onClick={()=>removeTunnelFromList(tun.id)} style={aBtn('#fff1f2','#dc2626')}>✕</button>
                    </div>
                  </td>
                </tr>
                {isSel&&(
                  <tr style={{background:'#fffbeb'}}>
                    <td colSpan={10} style={{padding:'5px 12px',borderBottom:'2px solid #fde68a'}}>
                      <div style={{display:'flex',alignItems:'flex-start',gap:10}}>
                        <div style={{flex:1}}>
                          <div style={{fontSize:'.71rem',fontWeight:700,color:'#92400e',marginBottom:3}}>🚇 {tun.name}</div>
                          <div style={{display:'flex',flexWrap:'wrap',gap:'2px 10px',fontSize:'.66rem'}}>
                            <span><b>L</b>={tun.length?tun.length.toLocaleString()+' m':'—'}</span>
                            <span><b>v</b>={tun.speedKmh?tun.speedKmh+' km/h':'—'}</span>
                            <span><b>E</b>={tun.entryOctant} <b>S</b>={tun.exitOctant}</span>
                            <span>{tun.oneway?'↑ Único sentido':'⇅ Bidireccional'}</span>
                            {tun.inclinePct!==null&&<span><b>Pend.</b>={tun.inclinePct}%</span>}
                            {tun.surface&&<span><b>Pav.</b>={tun.surface}</span>}
                          </div>
                        </div>
                        <button onClick={()=>{importTunnel();setShowTunTable(false);}}
                          style={{padding:'5px 14px',fontSize:'.7rem',fontWeight:700,cursor:'pointer',
                            background:'var(--salvi-black)',color:'#fff',border:'none',borderRadius:5,flexShrink:0}}>
                          ⬆ Importar
                        </button>
                      </div>
                    </td>
                  </tr>
                )}
              </React.Fragment>);
            })}
            {filtered.length===0&&(
              <tr><td colSpan={10} style={{textAlign:'center',padding:'14px',color:'var(--salvi-grey)',fontStyle:'italic'}}>Sin resultados</td></tr>
            )}
          </tbody>
        </table>
      </div>
    </div>
  );
}

function MapSelector({ lat, lng, onUpdate, onImport, lumData, portalOrientation, tunnelLength, tunnelWidth }) {
  // ── Refs ──────────────────────────────────────────
  const divRef         = useRef(null);
  const div3dRef       = useRef(null);
  const mapRef         = useRef(null);
  const map3dRef       = useRef(null);
  const markerRef      = useRef(null);
  const tileRef        = useRef(null);
  const tunnelGrpRef   = useRef(null);
  const lumGrpRef      = useRef(null);
  const toolGrpRef     = useRef(null);
  const plinesRef      = useRef({});
  const measurePtsRef  = useRef([]);
  const tunnelListRef  = useRef([]);
  const selTunnelRef   = useRef(null);
  const toolActiveRef  = useRef('none');

  // ── State ─────────────────────────────────────────
  const [mapMode,       setMapMode]       = useState('streets');
  const [activeTool,    setActiveTool]    = useState('none');
  const [measureDist,   setMeasureDist]   = useState(null);
  const [showLum,       setShowLum]       = useState(true);
  const [loadingTun,    setLoadingTun]    = useState(false);
  const [tunnelList,    setTunnelList]    = useState([]);
  const [visibleSet,    setVisibleSet]    = useState(new Set());
  const [selTunnel,     setSelTunnel]     = useState(null);
  const [searchVal,     setSearchVal]     = useState('');
  const [searching,     setSearching]     = useState(false);
  const [searchResults, setSearchResults] = useState([]);
  const [showResults,   setShowResults]   = useState(false);
  const [tunError,      setTunError]      = useState(null);
  const [showTunTable,  setShowTunTable]  = useState(false);
  const [tunFilter,     setTunFilter]     = useState('');
  const [tunTypeFilter, setTunTypeFilter] = useState('all');

  const initLat = parseFloat(lat) || 40.4165;
  const initLng = parseFloat(lng) || -3.7038;
  const TILE_URLS = {
    streets:   'https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png',
    satellite: 'https://server.arcgisonline.com/ArcGIS/rest/services/World_Imagery/MapServer/tile/{z}/{y}/{x}',
  };
  const PALETTE = ['#d97706','#0284c7','#059669','#7c3aed','#db2777','#ea580c'];
  const tunColor = (i) => PALETTE[i % PALETTE.length];

  // ── Mirrors ───────────────────────────────────────
  React.useEffect(() => { toolActiveRef.current = activeTool;  }, [activeTool]);
  React.useEffect(() => { tunnelListRef.current = tunnelList;  }, [tunnelList]);
  React.useEffect(() => { selTunnelRef.current  = selTunnel;   }, [selTunnel]);

  // ── Point-in-polygon ──────────────────────────────
  const pointInPolygon = (point, polygon) => {
    let inside = false;
    for (let i = 0, j = polygon.length - 1; i < polygon.length; j = i++) {
      const xi = polygon[i].lng, yi = polygon[i].lat;
      const xj = polygon[j].lng, yj = polygon[j].lat;
      if (((yi > point.lat) !== (yj > point.lat)) &&
          (point.lng < (xj - xi) * (point.lat - yi) / (yj - yi) + xi))
        inside = !inside;
    }
    return inside;
  };

  // ── Measure helpers ───────────────────────────────
  const haversineDist = (a, b) => {
    const R = 6371000, toRad = d => d * Math.PI / 180;
    const dLat = toRad(b.lat - a.lat), dLng = toRad(b.lng - a.lng);
    const s = Math.sin(dLat/2)**2 + Math.cos(toRad(a.lat))*Math.cos(toRad(b.lat))*Math.sin(dLng/2)**2;
    return R * 2 * Math.atan2(Math.sqrt(s), Math.sqrt(1-s));
  };

  const _drawMeasureOnMapLibre = () => {
    const m = map3dRef.current;
    if (!m) return;
    const pts = measurePtsRef.current;
    const coords = pts.map(p => [p.lng, p.lat]);
    const src = m.getSource('_measure');
    const data = { type:'FeatureCollection', features: [
      ...(coords.length>=2 ? [{type:'Feature',geometry:{type:'LineString',coordinates:coords}}] : []),
      ...coords.map(c=>({type:'Feature',geometry:{type:'Point',coordinates:c}})),
    ]};
    if (src) { src.setData(data); return; }
    m.addSource('_measure', {type:'geojson', data});
    m.addLayer({id:'_measure-line',type:'line',source:'_measure',filter:['==','$type','LineString'],
      paint:{'line-color':'#f59e0b','line-width':2,'line-dasharray':[4,3]}});
    m.addLayer({id:'_measure-dot',type:'circle',source:'_measure',filter:['==','$type','Point'],
      paint:{'circle-radius':5,'circle-color':'#f59e0b','circle-stroke-width':2,'circle-stroke-color':'#fff'}});
  };

  const _clearMeasureOnMapLibre = () => {
    const m = map3dRef.current;
    if (!m) return;
    try { if(m.getLayer('_measure-line')) m.removeLayer('_measure-line'); } catch(_){}
    try { if(m.getLayer('_measure-dot'))  m.removeLayer('_measure-dot');  } catch(_){}
    try { if(m.getSource('_measure'))     m.removeSource('_measure');      } catch(_){}
  };

  const _drawLumOnMapLibre = (entryLat, entryLng, bearing, widthM, arr, lumZones) => {
    const m = map3dRef.current;
    if (!m) return;
    const MODEL_CLR = {S:'#22c55e', M:'#3b82f6', L:'#a855f7'};
    const familyOf = (m) => !m ? 'M' : (/_S_|^S$/.test(m) ? 'S' : /_M_|^M$/.test(m) ? 'M' : /_L_|^L$/.test(m) ? 'L' : 'M');
    const features = [];
    let distAlongAxis = 0;
    const latOff = widthM * 0.35;
    const perpPositions = (axLat, axLng) => {
      if (arr==='bilateral_sym'||arr==='bilateral_stag')
        return [moveAlongBearing(axLat,axLng,latOff,(bearing-90+360)%360),
                moveAlongBearing(axLat,axLng,latOff,(bearing+90)%360)];
      if (arr==='lateral_left')  return [moveAlongBearing(axLat,axLng,latOff,(bearing-90+360)%360)];
      if (arr==='lateral_right') return [moveAlongBearing(axLat,axLng,latOff,(bearing+90)%360)];
      if (arr==='central_double') return [moveAlongBearing(axLat,axLng,latOff*0.4,(bearing+90)%360),
                                          moveAlongBearing(axLat,axLng,latOff*0.4,(bearing-90+360)%360)];
      return [[axLat, axLng]];
    };
    const lastPosBySide = {};   // distancia a la luminaria precedente, por "lado"
    lumZones.forEach(zone => {
      const zLen = parseFloat(zone.zone_length)||0, n = parseInt(zone.n_luminaires)||0;
      const d_used = parseFloat(zone.d_used)||(n>0?zLen/n:0);
      const zStart = parseFloat(zone.s_start)||0;
      const setpoints = _asArr(zone.setpoints);
      const hasSetpoints = setpoints.length===n && n>0;
      for (let i=0; i<n; i++) {
        const sp = setpoints[i];
        const d = hasSetpoints
          ? distAlongAxis + (parseFloat(sp.s) - zStart)
          : distAlongAxis + d_used*(i+0.5);
        const [axLat, axLng] = moveAlongBearing(entryLat, entryLng, d, bearing);
        const model = sp?.model || zone.model || 'M';
        const pw    = sp?.power_w || zone.power_w || 0;
        const mA    = sp?.current_mA || zone.current_mA || '?';
        const Lreq  = sp?.L_req ?? zone.L_required ?? 0;
        const tilt  = zone.tilt_deg ?? 0;
        const clr   = MODEL_CLR[familyOf(model)]||'#94a3b8';
        perpPositions(axLat, axLng).forEach(([pLat, pLng], sideIdx) => {
          const posObj = {lat:pLat, lng:pLng};
          const prev = lastPosBySide[sideIdx];
          const distPrev = prev ? haversineDist(prev, posObj) : null;
          lastPosBySide[sideIdx] = posObj;
          features.push({type:'Feature', geometry:{type:'Point',coordinates:[pLng,pLat]},
            properties:{model, color:clr, pw, mA, Lreq, tilt, distPrev:distPrev??-1,
                        zone_name:zone.zone_name, idx:i+1, n, tandem:sp?.tandem||''}});
        });
      }
      distAlongAxis += zLen;
    });
    const geojson = {type:'FeatureCollection', features};
    const src = m.getSource('_lum');
    if (src) { src.setData(geojson); return; }
    m.addSource('_lum', {type:'geojson', data:geojson});
    m.addLayer({id:'_lum-outer',type:'circle',source:'_lum',paint:{
      'circle-radius':7, 'circle-color':'#ffffff','circle-stroke-width':0}});
    m.addLayer({id:'_lum-dot',type:'circle',source:'_lum',paint:{
      'circle-radius':7, 'circle-color':['get','color'],
      'circle-stroke-width':1.5,'circle-stroke-color':'#fff','circle-opacity':0.92}});
    m.addLayer({id:'_lum-label',type:'symbol',source:'_lum',layout:{
      'text-field':['get','model'], 'text-size':9, 'text-allow-overlap':true,
      'text-ignore-placement':true}, paint:{'text-color':'#fff'}});
    m.on('click', '_lum-dot', (e) => {
      // Con la herramienta de medir activa, un click sobre una luminaria debe
      // registrar el punto de medición, no abrir su popup.
      if (toolActiveRef.current === 'measure') {
        addMeasurePoint({lat: e.lngLat.lat, lng: e.lngLat.lng});
        return;
      }
      const p = e.features?.[0]?.properties; if (!p) return;
      const tandemTag = p.tandem ? ` · Par ${p.tandem}` : '';
      const distTxt = Number(p.distPrev)>=0 ? `${Number(p.distPrev).toFixed(1)} m` : '—';
      const html = [
        `<b>${p.zone_name}</b> — Luminaria ${p.idx}/<b>${p.n}</b>${tandemTag}`,
        `<b>Aphex ${p.model}</b>  ·  <b>${Number(p.pw).toFixed(0)} W</b>  ·  ${p.mA} mA`,
        `d← anterior: <b>${distTxt}</b>  ·  Tilt: ${p.tilt}°`,
        `L<sub>req</sub> = ${Number(p.Lreq).toFixed(1)} cd/m²`,
      ].join('<br>');
      new window.maplibregl.Popup().setLngLat(e.lngLat).setHTML(html).addTo(m);
    });
    m.on('mouseenter', '_lum-dot', () => { m.getCanvas().style.cursor = 'pointer'; });
    m.on('mouseleave', '_lum-dot', () => { m.getCanvas().style.cursor = ''; });
  };

  const _clearLumOnMapLibre = () => {
    const m = map3dRef.current;
    if (!m) return;
    try { if(m.getLayer('_lum-outer')) m.removeLayer('_lum-outer'); } catch(_){}
    try { if(m.getLayer('_lum-dot'))   m.removeLayer('_lum-dot');   } catch(_){}
    try { if(m.getSource('_lum'))      m.removeSource('_lum');       } catch(_){}
  };

  const addMeasurePoint = (latlng) => {
    measurePtsRef.current.push(latlng);
    const pts = measurePtsRef.current;
    // Leaflet overlay
    if (toolGrpRef.current && window.L) {
      const L = window.L;
      toolGrpRef.current.clearLayers();
      pts.forEach(p => L.circleMarker(p, {radius:4,color:'#f59e0b',fillColor:'#f59e0b',fillOpacity:1,weight:2}).addTo(toolGrpRef.current));
      if (pts.length >= 2)
        L.polyline(pts, {color:'#f59e0b',weight:2,dashArray:'6 4'}).addTo(toolGrpRef.current);
    }
    // MapLibre overlay
    if (map3dRef.current) _drawMeasureOnMapLibre();
    // Distance
    if (pts.length >= 2) {
      let dist = 0;
      for (let i = 1; i < pts.length; i++) dist += haversineDist(pts[i-1], pts[i]);
      setMeasureDist(dist < 1000 ? `${Math.round(dist)} m` : `${(dist/1000).toFixed(3)} km`);
    }
  };
  const clearMeasure = () => {
    measurePtsRef.current = [];
    if (toolGrpRef.current) toolGrpRef.current.clearLayers();
    _clearMeasureOnMapLibre();
    setMeasureDist(null);
  };

  // ── Init Leaflet ──────────────────────────────────
  React.useEffect(() => {
    if (!divRef.current || !window.L || mapRef.current) return;
    const L = window.L;
    const map = L.map(divRef.current, {zoomControl:true}).setView([initLat, initLng], 14);
    tileRef.current      = L.tileLayer(TILE_URLS.streets, {attribution:'© OSM', maxZoom:19}).addTo(map);
    tunnelGrpRef.current = L.layerGroup().addTo(map);
    lumGrpRef.current    = L.layerGroup().addTo(map);
    toolGrpRef.current   = L.layerGroup().addTo(map);
    const marker = L.marker([initLat, initLng], {draggable:true})
      .addTo(map).bindPopup('<b>Portal del túnel</b>').openPopup();
    marker.on('dragend', e => {
      const p = e.target.getLatLng();
      onUpdate('lat', parseFloat(p.lat.toFixed(5)));
      onUpdate('lng', parseFloat(p.lng.toFixed(5)));
    });
    map.on('click', e => {
      const tool = toolActiveRef.current;
      if      (tool === 'measure') addMeasurePoint(e.latlng);
      else if (tool === 'none')    { marker.setLatLng(e.latlng); onUpdate('lat', parseFloat(e.latlng.lat.toFixed(5))); onUpdate('lng', parseFloat(e.latlng.lng.toFixed(5))); }
    });
    mapRef.current = map; markerRef.current = marker;
    const raf = requestAnimationFrame(() => requestAnimationFrame(() => { try{map.invalidateSize();}catch(_){} }));
    return () => { cancelAnimationFrame(raf); try{map.remove();}catch(_){} mapRef.current=null; };
  }, []);

  // ── Switch tile layer ─────────────────────────────
  React.useEffect(() => {
    if (!mapRef.current || !window.L || !tileRef.current || mapMode === 'terrain3d') return;
    mapRef.current.removeLayer(tileRef.current);
    const url = TILE_URLS[mapMode] || TILE_URLS.streets;
    tileRef.current = window.L.tileLayer(url, {attribution:'© OSM/Esri', maxZoom:19}).addTo(mapRef.current);
    tileRef.current.bringToBack();
    requestAnimationFrame(() => requestAnimationFrame(() => { try{mapRef.current?.invalidateSize();}catch(_){} }));
  }, [mapMode]);

  // ── MapLibre 3D terrain ───────────────────────────
  React.useEffect(() => {
    if (mapMode !== 'terrain3d') {
      if (map3dRef.current) { try{map3dRef.current.remove();}catch(_){} map3dRef.current=null; }
      return;
    }
    if (!div3dRef.current || !window.maplibregl || map3dRef.current) return;
    const center = mapRef.current ? [mapRef.current.getCenter().lng, mapRef.current.getCenter().lat] : [initLng, initLat];
    const zoom   = mapRef.current ? Math.max(8, mapRef.current.getZoom()-1) : 12;
    const ml = window.maplibregl;
    const m = new ml.Map({
      container: div3dRef.current,
      style: { version:8, sources:{
        sat:{type:'raster',tiles:['https://server.arcgisonline.com/ArcGIS/rest/services/World_Imagery/MapServer/tile/{z}/{y}/{x}'],tileSize:256,attribution:'© Esri'},
        dem:{type:'raster-dem',tiles:['https://s3.amazonaws.com/elevation-tiles-prod/terrarium/{z}/{x}/{y}.png'],tileSize:256,encoding:'terrarium',attribution:'© Mapzen/OSM'}
      }, layers:[{id:'sat',type:'raster',source:'sat'}] },
      center, zoom, pitch:60, bearing:0, antialias:true,
    });
    m.on('load', () => {
      m.setTerrain({source:'dem',exaggeration:1.5});
      m.addLayer({id:'sky',type:'sky',paint:{'sky-type':'atmosphere','sky-atmosphere-sun':[0,90],'sky-atmosphere-sun-intensity':15}});
      const el = document.createElement('div');
      el.style.cssText = 'width:14px;height:14px;border-radius:50%;background:#f59e0b;border:3px solid #fff;box-shadow:0 2px 6px rgba(0,0,0,.5);pointer-events:none';
      new ml.Marker({element:el,anchor:'center'}).setLngLat([parseFloat(lng)||initLng,parseFloat(lat)||initLat]).addTo(m);
    });
    m.dragRotate.enable(); m.touchZoomRotate.enableRotation();
    m.addControl(new ml.NavigationControl({visualizePitch:true}), 'top-left');
    // Click handler para herramienta de medición en 3D
    m.on('click', e => {
      if (toolActiveRef.current === 'measure') {
        addMeasurePoint({lat: e.lngLat.lat, lng: e.lngLat.lng});
      }
    });
    map3dRef.current = m;
    return () => { if(map3dRef.current){try{map3dRef.current.remove();}catch(_){} map3dRef.current=null;} };
  }, [mapMode]);

  // ── Lasso tool ────────────────────────────────────
  React.useEffect(() => {
    if (!mapRef.current || activeTool !== 'lasso') return;
    const map = mapRef.current; const L = window.L;
    map.getContainer().style.cursor = 'crosshair';
    map.dragging.disable(); map.doubleClickZoom.disable();
    let drawing = false; const lpts = [];
    const onDown = (e) => { drawing=true; lpts.length=0; lpts.push(e.latlng); };
    const onMove = (e) => {
      if(!drawing) return; lpts.push(e.latlng);
      if(toolGrpRef.current) toolGrpRef.current.clearLayers();
      if(lpts.length>=2) L.polygon(lpts,{color:'#f59e0b',weight:2,fillColor:'#fef3c7',fillOpacity:0.2,dashArray:'5 3'}).addTo(toolGrpRef.current);
    };
    const onUp = () => {
      if(!drawing) return; drawing=false;
      const poly=lpts.slice(); lpts.length=0;
      if(toolGrpRef.current) toolGrpRef.current.clearLayers();
      setActiveTool('none'); if(poly.length<3) return;
      const tList=tunnelListRef.current;
      const matches=tList.filter(tun=>tun.geometry.some(pt=>pointInPolygon({lat:pt.lat,lng:pt.lon},poly)));
      tList.forEach((t,i)=>{const pl=plinesRef.current[t.id];if(pl)pl.setStyle({color:tunColor(i),weight:5,opacity:0.85});});
      matches.forEach(tun=>{const pl=plinesRef.current[tun.id];if(pl)pl.setStyle({color:'#f59e0b',weight:9,opacity:1});});
      if(matches.length){setSelTunnel(matches[0]);if(matches[0].geometry.length){const mid=matches[0].geometry[Math.floor(matches[0].geometry.length/2)];map.panTo([mid.lat,mid.lon]);}}
    };
    map.on('mousedown',onDown); map.on('mousemove',onMove); map.on('mouseup',onUp);
    return () => {
      map.getContainer().style.cursor=''; map.dragging.enable(); map.doubleClickZoom.enable();
      map.off('mousedown',onDown); map.off('mousemove',onMove); map.off('mouseup',onUp);
      if(toolGrpRef.current) toolGrpRef.current.clearLayers();
    };
  }, [activeTool]);

  // ── Cursor for measure ────────────────────────────
  React.useEffect(() => {
    const c = mapRef.current?.getContainer();
    if(c) c.style.cursor = activeTool==='measure' ? 'crosshair' : '';
  }, [activeTool]);

  // ── Sync marker ───────────────────────────────────
  React.useEffect(() => {
    if(markerRef.current && lat && lng) markerRef.current.setLatLng([parseFloat(lat),parseFloat(lng)]);
  }, [lat,lng]);

  // ── GPS bearing helpers ───────────────────────────
  const OCTANT_BEARINGS = {N:0,NE:45,E:90,SE:135,S:180,SW:225,W:270,NW:315};
  const moveAlongBearing = (latDeg,lngDeg,distM,bearingDeg) => {
    const R=6371000,d=distM/R,θ=bearingDeg*Math.PI/180;
    const φ1=latDeg*Math.PI/180,λ1=lngDeg*Math.PI/180;
    const φ2=Math.asin(Math.sin(φ1)*Math.cos(d)+Math.cos(φ1)*Math.sin(d)*Math.cos(θ));
    const λ2=λ1+Math.atan2(Math.sin(θ)*Math.sin(d)*Math.cos(φ1),Math.cos(d)-Math.sin(φ1)*Math.sin(φ2));
    return [φ2*180/Math.PI,λ2*180/Math.PI];
  };

  // ── Luminaire markers on map ──────────────────────
  React.useEffect(() => {
    // Clear both Leaflet and MapLibre layers
    if(lumGrpRef.current) lumGrpRef.current.clearLayers();
    _clearLumOnMapLibre();
    if(!lumData||!showLum) return;
    const entryLat=parseFloat(lat)||initLat, entryLng=parseFloat(lng)||initLng;
    const L=window.L;
    const bearing=OCTANT_BEARINGS[portalOrientation]??180;
    const widthM=parseFloat(tunnelWidth)||8;
    const arr=lumData.arrangement||'central_single';
    const lumZones=_asArr(lumData.zones);
    const latOffset=widthM*0.35;
    const MODEL_CLR={S:'#22c55e',M:'#3b82f6',L:'#a855f7'};
    const MODEL_R  ={S:7,        M:9,        L:11};
    // El motor LED nuevo devuelve variant_id (p.ej. "APHEX_S_75W") en vez
    // de la letra S/M/L directa — se extrae la familia para colores/tamaños.
    const familyOf = (m) => !m ? 'M' : (/_S_|^S$/.test(m) ? 'S' : /_M_|^M$/.test(m) ? 'M' : /_L_|^L$/.test(m) ? 'L' : 'M');

    if(mapMode==='terrain3d') {
      // Render on MapLibre via GeoJSON
      _drawLumOnMapLibre(entryLat, entryLng, bearing, widthM, arr, lumZones);
    } else if(L && lumGrpRef.current) {
      // Render on Leaflet
      let distAlongAxis=0;
      const lastPosBySide={};   // distancia a la luminaria precedente, por "lado" (bilateral/tandem)
      lumZones.forEach(zone=>{
        const zLen=parseFloat(zone.zone_length)||0,n=parseInt(zone.n_luminaires)||0;
        const d_used=parseFloat(zone.d_used)||(n>0?zLen/n:0);
        const zStart=parseFloat(zone.s_start)||0;
        const setpoints=_asArr(zone.setpoints);
        const hasSetpoints=setpoints.length===n && n>0;
        for(let i=0;i<n;i++){
          const sp = setpoints[i];
          // d = distancia real desde el portal de entrada. Con setpoints (transición
          // y umbral/salida en tándem) se usa la posición física real de cada
          // luminaria; sin ellos (zonas uniformes sin tándem) se reparte por d_used.
          const d = hasSetpoints
            ? distAlongAxis + (parseFloat(sp.s) - zStart)
            : distAlongAxis + d_used*(i+0.5);
          const axisPos=moveAlongBearing(entryLat,entryLng,d,bearing);
          let positions=[];
          if(arr==='central_single'||arr==='central_offset'){const perpOffset=arr==='central_offset'?latOffset*0.5:0;positions=[moveAlongBearing(axisPos[0],axisPos[1],perpOffset,bearing+90)];}
          else if(arr==='central_double'){positions=[moveAlongBearing(axisPos[0],axisPos[1],latOffset*0.4,(bearing+90)%360),moveAlongBearing(axisPos[0],axisPos[1],latOffset*0.4,(bearing-90+360)%360)];}
          else if(arr==='lateral_left'){positions=[moveAlongBearing(axisPos[0],axisPos[1],latOffset,(bearing-90+360)%360)];}
          else if(arr==='lateral_right'){positions=[moveAlongBearing(axisPos[0],axisPos[1],latOffset,(bearing+90)%360)];}
          else if(arr==='bilateral_sym'){positions=[moveAlongBearing(axisPos[0],axisPos[1],latOffset,(bearing-90+360)%360),moveAlongBearing(axisPos[0],axisPos[1],latOffset,(bearing+90)%360)];}
          else if(arr==='bilateral_stag'){const side=i%2===0?(bearing-90+360)%360:(bearing+90)%360;positions=[moveAlongBearing(axisPos[0],axisPos[1],latOffset,side)];}
          else{positions=[axisPos];}
          const model = sp?.model   || zone.model   || 'M';
          const pw    = sp?.power_w || zone.power_w || 0;
          const mA    = sp?.current_mA || zone.current_mA || '?';
          const Lreq  = sp?.L_req ?? zone.L_required ?? '?';
          const tilt  = zone.tilt_deg ?? 0;
          const clr   = MODEL_CLR[familyOf(model)]||'#94a3b8';
          const radius= MODEL_R[familyOf(model)]||5;
          const tandemTag = sp?.tandem ? ` · Par ${sp.tandem}` : '';
          positions.forEach((pos,sideIdx)=>{
            const posObj={lat:pos[0],lng:pos[1]};
            const prev=lastPosBySide[sideIdx];
            const distPrev=prev?haversineDist(prev,posObj):null;
            lastPosBySide[sideIdx]=posObj;
            const distTxt=distPrev!=null?`${distPrev.toFixed(1)} m`:'—';
            const tip=[
              `<b>${zone.zone_name}</b> — Luminaria ${i+1}/<b>${n}</b>${tandemTag}`,
              `<b>Aphex ${model}</b>  ·  <b>${Number(pw).toFixed(0)} W</b>  ·  ${mA} mA`,
              `d← anterior: <b>${distTxt}</b>  ·  Tilt: ${tilt}°`,
              `L<sub>req</sub> = ${typeof Lreq==='number'?Lreq.toFixed(1):Lreq} cd/m²`,
            ].join('<br>');
            const dia = radius*2;
            const icon = L.divIcon({
              className: 'lum-divicon',
              html: `<div style="width:${dia}px;height:${dia}px;border-radius:50%;background:${clr};`+
                    `border:1.5px solid #fff;box-shadow:0 1px 3px rgba(0,0,0,.45);display:flex;`+
                    `align-items:center;justify-content:center;font-size:${Math.max(7,radius-1)}px;`+
                    `font-weight:700;color:#fff;font-family:sans-serif;">${model}</div>`,
              iconSize:[dia,dia], iconAnchor:[radius,radius],
            });
            const marker = L.marker(pos,{icon})
             .bindTooltip(tip,{direction:'top',sticky:true,className:'lum-tip'})
             .addTo(lumGrpRef.current);
            // Con la herramienta de medir activa, un click sobre una luminaria
            // debe registrar el punto de medición, no abrir su popup — si no,
            // con cientos de marcadores casi ningún click llega al mapa.
            marker.on('click', e => {
              if (toolActiveRef.current === 'measure') { addMeasurePoint(e.latlng); return; }
              marker.bindPopup(tip).openPopup(e.latlng);
            });
          });
        }
        distAlongAxis+=zLen;
      });
    }
  }, [lumData,showLum,lat,lng,portalOrientation,tunnelWidth,mapMode]);

  // ── Cycle / toggle tools ──────────────────────────
  const cycleMode = () => {
    const ORDER=['streets','satellite','terrain3d'];
    setMapMode(prev=>ORDER[(ORDER.indexOf(prev)+1)%ORDER.length]);
    clearMeasure(); setActiveTool('none');
  };
  const toggleTool = (tool) => {
    if(activeTool===tool){clearMeasure();setActiveTool('none');}
    else{clearMeasure();setActiveTool(tool);}
  };

  // ── Tunnel management ─────────────────────────────
  const removeTunnelFromList = (id) => {
    const pl=plinesRef.current[id];
    if(pl&&tunnelGrpRef.current) tunnelGrpRef.current.removeLayer(pl);
    delete plinesRef.current[id];
    setTunnelList(prev=>prev.filter(t=>t.id!==id));
    setVisibleSet(prev=>{const n=new Set(prev);n.delete(id);return n;});
    if(selTunnel?.id===id) setSelTunnel(null);
  };
  const selectTunnel = (tun, idx) => {
    tunnelListRef.current.forEach((t,i)=>{const pl=plinesRef.current[t.id];if(pl)pl.setStyle({color:tunColor(i),weight:5,opacity:0.85});});
    const pl=plinesRef.current[tun.id];
    if(pl) pl.setStyle({color:'#f59e0b',weight:9,opacity:1});
    if(mapRef.current&&tun.geometry.length){const mid=tun.geometry[Math.floor(tun.geometry.length/2)];mapRef.current.panTo([mid.lat,mid.lon]);}
    setSelTunnel(tun);
  };
  const importTunnel = () => {
    if(!selTunnel) return;
    try {
    const imp = {};
    // Nombre proyecto = nombre del túnel OSM
    imp.project_name       = selTunnel.name || selTunnel.ref || '';
    // Geometría
    if(selTunnel.length)              imp.length_m         = selTunnel.length;
    if(selTunnel.widthM)              imp.width_m          = selTunnel.widthM;
    if(selTunnel.maxHeightM)          imp.height_m         = selTunnel.maxHeightM;
    if(selTunnel.inclinePct != null)  imp.gradient_pct     = selTunnel.inclinePct;
    // Tráfico
    if(selTunnel.speedKmh)            imp.speed_kmh        = selTunnel.speedKmh;
    if(selTunnel.lanes)               imp.num_lanes        = selTunnel.lanes;
    imp.traffic_direction  = selTunnel.oneway ? 'one_way' : 'two_way';
    // Entorno
    imp.portal_orientation = selTunnel.entryOctant !== '?' ? selTunnel.entryOctant : undefined;
    if(selTunnel.lit)                 imp.illuminated_road = true;
    if(selTunnel.surface)             imp.road_surface     = _osmSurface(selTunnel.surface);
    if(selTunnel.operator)            imp.operator         = selTunnel.operator;
    // Coordenadas del portal de entrada
    if(selTunnel.entryCoord && markerRef.current){
      markerRef.current.setLatLng(selTunnel.entryCoord);
      imp.lat = parseFloat(selTunnel.entryCoord[0].toFixed(5));
      imp.lng = parseFloat(selTunnel.entryCoord[1].toFixed(5));
    }
    // Eliminar claves undefined
    Object.keys(imp).forEach(k => imp[k]===undefined && delete imp[k]);
    if(typeof onImport==='function') onImport(imp);
    } catch(importErr) {
      console.error('[OSM] Error en importTunnel:', importErr);
      alert('Error al importar los datos del túnel. Revisa la consola.');
    }
  };

  /* Mapeo surface OSM → tabla CIE 144 */
  const _osmSurface = (s) => {
    if(!s) return undefined;
    const m = s.toLowerCase();
    if(m.includes('concrete')) return 'concrete';
    if(m.includes('asphalt')){
      if(m.includes('dark')) return 'dark_asphalt';
      if(m.includes('light')||m.includes('clear')) return 'light_asphalt';
      return 'medium_asphalt';
    }
    return 'medium_asphalt'; // default
  };

  // ── Helpers ─────────────────────────────────────────────────────────────────
  const _toRad = d => d * Math.PI / 180;
  const _bearing = (p1, p2) => {
    const dLon = _toRad(p2.lon - p1.lon);
    const y = Math.sin(dLon) * Math.cos(_toRad(p2.lat));
    const x = Math.cos(_toRad(p1.lat)) * Math.sin(_toRad(p2.lat))
             - Math.sin(_toRad(p1.lat)) * Math.cos(_toRad(p2.lat)) * Math.cos(dLon);
    return (Math.atan2(y, x) * 180 / Math.PI + 360) % 360;
  };
  const _octant = deg => ['N','NE','E','SE','S','SO','O','NO'][Math.round(deg/45)%8];
  const _haversine = (p1, p2) => {
    const R=6371000;
    const dLat=_toRad(p2.lat-p1.lat), dLon=_toRad(p2.lon-p1.lon);
    const a=Math.sin(dLat/2)**2+Math.cos(_toRad(p1.lat))*Math.cos(_toRad(p2.lat))*Math.sin(dLon/2)**2;
    return 2*R*Math.asin(Math.sqrt(a));
  };
  const parseTunnelWay = (way) => {
    try {
    const tags = way.tags||{};
    const geom = way.geometry||[];
    // geometry & bearings
    let entryOctant='?', exitOctant='?', lengthM=0;
    if(geom.length>=2){
      entryOctant = _octant(_bearing(geom[0], geom[1]));
      exitOctant  = _octant(_bearing(geom[geom.length-2], geom[geom.length-1]));
      for(let i=1;i<geom.length;i++) lengthM+=_haversine(geom[i-1],geom[i]);
    }
    const entryCoord = geom.length ? [geom[0].lat, geom[0].lon] : [0,0];
    // speed: "80", "80 km/h", "ES:urban" → number or null
    const rawSpeed = tags.maxspeed||tags['maxspeed:forward']||'';
    const speedKmh = parseInt(rawSpeed)||null;
    // incline: "2%", "-3%" → number or null
    const rawInc = tags.incline||'';
    const inclinePct = rawInc ? parseFloat(rawInc.replace('%','').trim())||null : null;
    return {
      id:          way.id,
      name:        tags.name || tags['name:es'] || tags['name:ca'] || tags.ref || `Túnel ${way.id}`,
      ref:         tags.ref || null,
      highway:     tags.highway || null,
      geometry:    geom,
      entryOctant, exitOctant,
      length:      Math.round(lengthM),     // metres — tabla usa tun.length
      lengthM:     Math.round(lengthM),     // alias
      entryCoord,
      speedKmh,
      lanes:       parseInt(tags.lanes)||null,
      oneway:      tags.oneway==='yes',
      inclinePct,
      surface:     tags.surface||null,
      widthM:      parseFloat(tags.width)||null,
      maxHeightM:  parseFloat(tags.maxheight)||null,
      operator:    tags.operator||null,
      opening_date:tags.opening_date||null,
    };
    } catch(parseErr) {
      console.warn('[OSM] Error parseando way', way?.id, parseErr);
      return null;
    }
  };

  // ── Identify via Overpass (direct browser call — no proxy) ──────────────────
  const identifyTunnels = async () => {
    if(!mapRef.current) return;
    const zoom=mapRef.current.getZoom();
    if(zoom<11){setTunError('Acerca más el mapa (zoom ≥ 11) para reducir el área de búsqueda');return;}
    setLoadingTun(true); setTunError(null);
    if(tunnelGrpRef.current) tunnelGrpRef.current.clearLayers();
    plinesRef.current={};
    setTunnelList([]); setVisibleSet(new Set()); setSelTunnel(null);
    const b=mapRef.current.getBounds();
    const bbox=`${b.getSouth().toFixed(5)},${b.getWest().toFixed(5)},${b.getNorth().toFixed(5)},${b.getEast().toFixed(5)}`;
    const q=`[out:json][timeout:25][maxsize:2000000];\nway["tunnel"="yes"](${bbox});\nout tags geom;`;
    const ENDPOINTS=[
      'https://overpass-api.de/api/interpreter',
      'https://overpass.kumi.systems/api/interpreter',
    ];
    try {
      let data=null, lastErr='';
      const mkSig=()=>typeof AbortSignal.timeout==='function'?AbortSignal.timeout(28000):undefined;
      for(const ep of ENDPOINTS){
        try{
          const r=await fetch(ep,{
            method:'POST',
            headers:{'Content-Type':'application/x-www-form-urlencoded'},
            body:`data=${encodeURIComponent(q)}`,
            signal:mkSig(),
          });
          if(r.ok){data=await r.json();break;}
          lastErr=`HTTP ${r.status} en ${ep.split('/')[2]}`;
        }catch(err){lastErr=err.message||String(err);}
      }
      if(!data) throw new Error(`Overpass no disponible — ${lastErr||'revisa tu conexión'}`);
      const parsed=(data.elements||[]).map(way=>{
        const t=parseTunnelWay(way); if(!t) return null; const tags=way.tags||{};
        t.widthM=parseFloat(tags.width)||null; t.maxHeightM=parseFloat(tags.maxheight)||null;
        t.surface=tags.surface||null; t.ref=tags.ref||null; t.operator=tags.operator||null;
        t.opening_date=tags.opening_date||null;
        return t;
      });
      const L=window.L;
      const validParsed=parsed.filter(Boolean);
      setTunnelList(validParsed);
      setVisibleSet(new Set(validParsed.map(t=>t.id)));
      if(validParsed.length>0) setShowTunTable(true);
      validParsed.forEach((tun,idx)=>{
        if(!tun.geometry.length) return;
        const coords=tun.geometry.map(pt=>[pt.lat,pt.lon]);
        const color=tunColor(idx);
        const pl=L.polyline(coords,{color,weight:5,opacity:0.85}).addTo(tunnelGrpRef.current);
        pl.on('mouseover',()=>pl.setStyle({weight:8}));
        pl.on('mouseout',()=>{if(selTunnelRef.current?.id!==tun.id)pl.setStyle({weight:5});});
        pl.on('click',e=>{selectTunnel(tun,idx);L.DomEvent.stopPropagation(e);});
        if(coords.length){
          L.circleMarker(coords[0],{radius:6,color,fillColor:color,fillOpacity:0.85,weight:2})
           .bindTooltip(`${tun.name} — E: ${tun.entryOctant}`,{direction:'top'}).addTo(tunnelGrpRef.current);
          L.circleMarker(coords[coords.length-1],{radius:6,color,fillColor:'#fff',fillOpacity:0.9,weight:2})
           .bindTooltip(`S: ${tun.exitOctant}`,{direction:'top'}).addTo(tunnelGrpRef.current);
        }
        plinesRef.current[tun.id]=pl;
      });
      if(validParsed.length===0) setTunError('No se encontraron túneles en la vista');
    }catch(e){setTunError(e.message);}
    finally{setLoadingTun(false);}
  };

  // ── Search / StreetView ───────────────────────────
  const doSearch = async () => {
    if(!searchVal.trim()) return;
    setSearching(true); setSearchResults([]); setShowResults(false);
    try{
      const res=await fetch(`https://nominatim.openstreetmap.org/search?q=${encodeURIComponent(searchVal)}&format=json&limit=6`,{headers:{'Accept-Language':'es,en'}});
      setSearchResults(await res.json()); setShowResults(true);
    }catch(_){}
    finally{setSearching(false);}
  };
  const goToResult = (r) => {
    const lt=parseFloat(r.lat),ln=parseFloat(r.lon);
    mapRef.current?.setView([lt,ln],15);
    markerRef.current?.setLatLng([lt,ln]);
    onUpdate('lat',parseFloat(lt.toFixed(5)));
    onUpdate('lng',parseFloat(ln.toFixed(5)));
    setShowResults(false); setSearchVal(r.display_name.split(',')[0]);
  };
  const openStreetView = () => {
    const lt=parseFloat(lat)||initLat,ln=parseFloat(lng)||initLng;
    window.open(`https://www.google.com/maps?q=&layer=c&cbll=${lt},${ln}`,'_blank');
  };

  // ── UI helpers ────────────────────────────────────
  const tbBtn = (active,extra={}) => ({
    padding:'4px 9px',fontSize:'.67rem',fontWeight:600,cursor:'pointer',
    border:'1px solid var(--salvi-line)',
    background:active?'var(--salvi-black)':'#fff',
    color:active?'#fff':'var(--salvi-grey)',
    ...extra,
  });
  const ICONS = {
    streets:  <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><rect x="3" y="3" width="7" height="7" rx="1"/><rect x="14" y="3" width="7" height="7" rx="1"/><rect x="3" y="14" width="7" height="7" rx="1"/><rect x="14" y="14" width="7" height="7" rx="1"/></svg>,
    satellite:<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><circle cx="12" cy="12" r="9"/><path d="M3 12h18M12 3c-3 3-4 6-4 9s1 6 4 9M12 3c3 3 4 6 4 9s-1 6-4 9"/></svg>,
    terrain3d:<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><path d="M3 20 L9 8 L14 15 L17 10 L21 20Z"/><path d="M1 20h22" strokeLinecap="round"/></svg>,
    ruler:    <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><path d="M2 16 L16 2" strokeLinecap="round"/><path d="M6 20 L20 6" strokeLinecap="round"/><path d="M2 16 L6 20" strokeLinecap="round"/><path d="M5 13 L8 16M9 9 L12 12M13 5 L16 8" strokeLinecap="round"/></svg>,
    lasso:    <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><path d="M12 3c-5 0-9 3.6-9 8s4 8 9 8c1.7 0 3.3-.4 4.6-1.2" strokeLinecap="round"/><path d="M17 14l2 2 4-4" strokeLinecap="round" strokeLinejoin="round"/><path d="M12 11v6l3-3" strokeLinecap="round" strokeLinejoin="round"/></svg>,
  };
  const MODE_LABELS={streets:'Calles',satellite:'Satélite',terrain3d:'Terreno 3D'};

  return (
    <div style={{flex:1,minHeight:0,display:'flex',flexDirection:'column'}}>

      {/* ── Toolbar ── */}
      <div style={{display:'flex',gap:6,padding:'5px 8px',flexShrink:0,
                   background:'var(--salvi-cream)',borderBottom:'1px solid var(--salvi-line)',
                   flexWrap:'wrap',alignItems:'center'}}>
        <div style={{position:'relative',display:'flex',flex:'1 1 170px',minWidth:130}}>
          <input value={searchVal}
            onChange={e=>{setSearchVal(e.target.value);if(!e.target.value)setShowResults(false);}}
            onKeyDown={e=>{if(e.key==='Enter')doSearch();if(e.key==='Escape')setShowResults(false);}}
            placeholder="🔎 Buscar lugar, túnel…"
            style={{flex:1,padding:'4px 8px',fontSize:'.67rem',border:'1px solid var(--salvi-line)',
                    borderRadius:'5px 0 0 5px',outline:'none',background:'#fff'}}/>
          <button onClick={doSearch} disabled={searching}
            style={{...tbBtn(false),borderRadius:'0 5px 5px 0',borderLeft:'none',padding:'4px 8px'}}>
            {searching?'⏳':'→'}
          </button>
          {showResults&&searchResults.length>0&&(
            <div style={{position:'absolute',top:'100%',left:0,right:0,zIndex:9999,
                         background:'#fff',border:'1px solid var(--salvi-line)',borderRadius:5,
                         boxShadow:'0 4px 12px rgba(0,0,0,.15)',marginTop:2,maxHeight:180,overflowY:'auto'}}>
              {searchResults.map((r,i)=>(
                <div key={i} onClick={()=>goToResult(r)}
                  style={{padding:'5px 10px',cursor:'pointer',fontSize:'.67rem',
                          borderBottom:'1px solid var(--salvi-line)'}}
                  onMouseEnter={e=>e.currentTarget.style.background='var(--salvi-surface)'}
                  onMouseLeave={e=>e.currentTarget.style.background='#fff'}>
                  <div style={{fontWeight:600}}>{r.display_name.split(',')[0]}</div>
                  <div style={{color:'var(--salvi-grey)',fontSize:'.61rem'}}>{r.display_name.split(',').slice(1,3).join(',')}</div>
                </div>
              ))}
            </div>
          )}
        </div>
        <button onClick={identifyTunnels} disabled={loadingTun}
          title={tunError||undefined}
          style={{...tbBtn(tunnelList.length>0,{flexShrink:0,
                  background:tunnelList.length>0?'#fef3c7':'#fff',
                  color:tunError?'#b42318':tunnelList.length>0?'#92400e':'var(--salvi-black)'})}}>
          {loadingTun?'⏳':'🔍'}{' '}
          {loadingTun?'Consultando…':tunError?'Error Overpass':tunnelList.length>0?`↺ ${tunnelList.length} túneles OSM`:'Identificar túneles OSM'}
        </button>
        {tunnelList.length>0&&(
          <button onClick={()=>setShowTunTable(v=>!v)}
            style={{...tbBtn(showTunTable,{flexShrink:0,background:showTunTable?'#fffbeb':'#fff',
                    color:showTunTable?'#92400e':'var(--salvi-black)',
                    border:showTunTable?'1.5px solid #d97706':undefined})}}>
            📋 {tunnelList.length}
          </button>
        )}
        <button onClick={openStreetView}
          style={{...tbBtn(false,{display:'flex',alignItems:'center',gap:4,flexShrink:0})}}>
          <svg width="11" height="11" viewBox="0 0 24 24" fill="none"><circle cx="12" cy="8" r="4" stroke="currentColor" strokeWidth="2"/><path d="M6 20c0-3.31 2.69-6 6-6s6 2.69 6 6" stroke="currentColor" strokeWidth="2" strokeLinecap="round"/></svg>
          Street View
        </button>
      </div>

      {/* ── Map ── */}
      <div style={{position:'relative',flex:1,minHeight:0}}>
        <div ref={divRef} className="map-container"
             style={{position:'absolute',inset:0,display:mapMode==='terrain3d'?'none':'block'}}/>
        <div ref={div3dRef}
             style={{position:'absolute',inset:0,display:mapMode==='terrain3d'?'block':'none'}}/>

        <div style={{position:'absolute',top:10,right:10,zIndex:600,display:'flex',flexDirection:'column',gap:5}}>
          <button onClick={cycleMode} title={`${MODE_LABELS[mapMode]} → siguiente`}
            style={{width:34,height:34,borderRadius:8,border:'1px solid rgba(0,0,0,.2)',background:'#fff',cursor:'pointer',display:'flex',alignItems:'center',justifyContent:'center',boxShadow:'0 1px 5px rgba(0,0,0,.25)',color:'var(--salvi-black)'}}>
            {ICONS[mapMode]}
          </button>
          <button onClick={()=>toggleTool('measure')} title="Medir distancia"
            style={{width:34,height:34,borderRadius:8,border:'1px solid rgba(0,0,0,.2)',background:activeTool==='measure'?'var(--salvi-black)':'#fff',cursor:'pointer',display:'flex',alignItems:'center',justifyContent:'center',boxShadow:'0 1px 5px rgba(0,0,0,.25)',color:activeTool==='measure'?'#fff':'var(--salvi-black)'}}>
            {ICONS.ruler}
          </button>
          <button onClick={()=>mapMode!=='terrain3d'&&toggleTool('lasso')}
            title={mapMode==='terrain3d'?'Lazo no disponible en 3D':'Seleccionar con lazo'}
            style={{width:34,height:34,borderRadius:8,border:'1px solid rgba(0,0,0,.2)',background:activeTool==='lasso'?'var(--salvi-black)':'#fff',cursor:mapMode==='terrain3d'?'not-allowed':'pointer',display:'flex',alignItems:'center',justifyContent:'center',boxShadow:'0 1px 5px rgba(0,0,0,.25)',opacity:mapMode==='terrain3d'?0.4:1,color:activeTool==='lasso'?'#fff':'var(--salvi-black)'}}>
            {ICONS.lasso}
          </button>
          {lumData&&(
            <button onClick={()=>setShowLum(v=>!v)} title={showLum?'Ocultar luminarias':'Mostrar luminarias'}
              style={{width:34,height:34,borderRadius:8,border:'1px solid rgba(0,0,0,.2)',background:showLum?'#f59e0b':'#fff',cursor:'pointer',display:'flex',alignItems:'center',justifyContent:'center',boxShadow:'0 1px 5px rgba(0,0,0,.25)',color:showLum?'#fff':'var(--salvi-black)',fontSize:'17px'}}>
              💡
            </button>
          )}
        </div>

        <div style={{position:'absolute',bottom:6,right:10,zIndex:600,background:'rgba(30,30,30,.72)',color:'#fff',borderRadius:4,padding:'2px 7px',fontSize:'.6rem',letterSpacing:'.05em',fontWeight:600,pointerEvents:'none'}}>
          {MODE_LABELS[mapMode]}{mapMode==='terrain3d'?'  · arrastra para inclinar':''}
        </div>

        {activeTool==='measure'&&(
          <div style={{position:'absolute',bottom:28,left:10,zIndex:600,background:'rgba(30,30,30,.85)',color:'#fff',borderRadius:5,padding:'4px 10px',fontSize:'.68rem',display:'flex',alignItems:'center',gap:8}}>
            📏 {measureDist||'Haz clic para medir'}
            {measureDist&&<span onClick={clearMeasure} style={{cursor:'pointer',fontWeight:700,opacity:.8}}>✕</span>}
          </div>
        )}
        {lumData&&showLum&&!lat&&(
          <div style={{position:'absolute',bottom:28,left:10,zIndex:600,background:'rgba(245,158,11,.9)',color:'#fff',borderRadius:5,padding:'4px 10px',fontSize:'.68rem'}}>
            💡 Luminarias mostradas en ubicación de referencia — haz clic en el mapa para ubicar el portal real
          </div>
        )}
        {activeTool==='lasso'&&(
          <div style={{position:'absolute',bottom:28,left:10,zIndex:600,background:'rgba(245,158,11,.9)',color:'#fff',borderRadius:5,padding:'4px 10px',fontSize:'.68rem'}}>
            ✏️ Mantén pulsado y arrastra para seleccionar túneles
          </div>
        )}
        {mapMode==='terrain3d'&&(
          <div style={{position:'absolute',top:10,left:10,zIndex:600,background:'rgba(30,30,30,.78)',color:'#fff',borderRadius:5,padding:'4px 10px',fontSize:'.65rem'}}>
            🖱 Arrastrar: mover · Ctrl+arrastrar: inclinar · Rueda: zoom
            {activeTool==='measure' ? ' · 📏 Clic para medir' : ''}
          </div>
        )}

        {/* ── Tunnel table (floating bottom) ── */}
        {showTunTable&&tunnelList.length>0&&(
          <TunnelFloatPanel
            tunnelList={tunnelList} selTunnel={selTunnel}
            tunFilter={tunFilter} setTunFilter={setTunFilter}
            tunTypeFilter={tunTypeFilter} setTunTypeFilter={setTunTypeFilter}
            selectTunnel={selectTunnel} removeTunnelFromList={removeTunnelFromList}
            importTunnel={importTunnel} setShowTunTable={setShowTunTable}
            tunColor={tunColor}
          />
        )}
      </div>
    </div>
  );
}
// ── Componente: preview de sección transversal del túnel ──────────────────
function TunnelSectionPreview({ form, lumConfig=null }) {
  const W     = parseFloat(form.width_m)   || 10.5;
  const H     = parseFloat(form.height_m)  || 5.5;
  const shape = form.tunnel_shape || 'horseshoe';
  const Hp    = Math.min(parseFloat(form.H_pared_m) ?? 3.0, H);

  // Wall offset + mount height from lum config (optional)
  const wo    = lumConfig ? Math.max(0.05, parseFloat(lumConfig.wall_offset_m)  || 0.30) : null;
  const hm    = lumConfig ? Math.min(H,   parseFloat(lumConfig.mounting_height_m) || 4.5) : null;
  const arr   = lumConfig ? (lumConfig.arrangement || 'central_single') : null;

  // Carriles pintados: carril/arcén son campos de Geometría, independientes de lumConfig.
  const numLanes = Math.max(1, parseInt(form.num_lanes) || 2);
  const laneW    = parseFloat(form.lane_width_m)     || 3.5;
  const shLeft   = Math.max(0, parseFloat(form.shoulder_left_m)  || 0);
  const carriagewayStart_m = shLeft;
  const carriagewayEnd_m   = Math.min(W, shLeft + numLanes * laneW);
  const laneDividers_m = Array.from({length: Math.max(0, numLanes - 1)},
    (_, i) => shLeft + (i + 1) * laneW).filter(y => y > 0 && y < W);

  const SVG_W = 420, SVG_H = 180;
  const mg = { l:44, r:16, t:14, b:20 };
  const tW = SVG_W - mg.l - mg.r;
  const tH = SVG_H - mg.t - mg.b;
  const sc = Math.min(tW / (W + 2), tH / (H + 1));
  const tw = W * sc, th = H * sc;
  const ox = mg.l + (tW - tw) / 2;
  const oy = mg.t + (tH - th);
  const roadH = 5;
  const roadY = oy + th - roadH;

  // Arch geometry
  const wallH_px = (Hp / H) * th;
  const archH_px = th - wallH_px;
  let tunnelPath;
  if (shape === 'rectangular') {
    tunnelPath = `M ${ox} ${oy} L ${ox} ${oy+th} L ${ox+tw} ${oy+th} L ${ox+tw} ${oy} Z`;
  } else if (shape === 'circular') {
    // Sección circular: galería perforada. R calculado de W y H.
    const R_m = ((W/2)**2 + H**2) / (2*H);
    const R_px = R_m * sc;
    const z_ctr = H - R_m;   // positivo si centro por encima de calzada
    const largeArc = z_ctr >= -0.001 ? 1 : 0;
    // Arco desde pared izq a pared der pasando por la clave, cerrado por la calzada
    tunnelPath = `M ${ox} ${oy+th} A ${R_px} ${R_px} 0 ${largeArc} 1 ${ox+tw} ${oy+th} Z`;
  } else {
    // Horseshoe: straight walls + semi-elliptical arch
    const ax = ox + tw / 2, ay = oy + archH_px;
    const rx = tw / 2, ry = archH_px;
    tunnelPath = `M ${ox} ${oy+th} L ${ox} ${ay} A ${rx} ${ry} 0 0 1 ${ox+tw} ${ay} L ${ox+tw} ${oy+th} Z`;
  }

  // Luminaire positions in pixels (only if lumConfig provided). El tilt real
  // varía por posición a lo largo del túnel (curva CIE 88) — mostrar aquí un
  // único ángulo representativo puede despistar, así que la luminaria se
  // dibuja siempre horizontal (sin rotación).
  const lumPts = [];
  let outsideWarning = false;
  let transverseDist_m = null;   // distancia entre las 2 luminarias de esta sección (si aplica)
  if (arr && wo !== null && hm !== null) {
    const pts = [];
    if (['bilateral_sym','bilateral_stag','bilateral','staggered'].includes(arr)) {
      pts.push([wo, hm], [W - wo, hm]);
    } else if (arr === 'lateral_left') { pts.push([wo, hm]); }
    else if (['lateral_right','unilateral'].includes(arr)) { pts.push([W - wo, hm]); }
    else if (arr === 'central_double') { pts.push([W/2 - 0.3, hm], [W/2 + 0.3, hm]); }
    else { pts.push([W/2, hm]); }  // central_single / central_offset

    if (pts.length === 2) transverseDist_m = Math.abs(pts[1][0] - pts[0][0]);

    pts.forEach(([yM, zM]) => {
      const px = ox + (yM / W) * tw;
      const py = roadY - (zM / H) * th;
      // Inside check
      let inside = (zM >= 0 && zM <= H && yM >= 0 && yM <= W);
      if (inside && shape === 'horseshoe' && zM > Hp) {
        const a = W / 2, b = H - Hp;
        if (b > 0) inside = ((yM - W/2)**2 / a**2 + (zM - Hp)**2 / b**2) <= 1.02;
      }
      if (!inside) outsideWarning = true;
      lumPts.push({ px, py, inside });
    });
  }

  // Dimension lines helpers
  const dimLine = (x1,y1,x2,y2,label,lx,ly,rot=0) => (
    React.createElement(React.Fragment, null,
      React.createElement('line', {x1,y1,x2,y2,stroke:'#64748b',strokeWidth:0.8,strokeDasharray:'3 2'}),
      React.createElement('text', {x:lx,y:ly,fill:'#94a3b8',fontSize:8,textAnchor:'middle',
        transform:rot?`rotate(${rot},${lx},${ly})`:undefined}, label)
    )
  );

  return (
    <div style={{marginTop:10,background:'#0f172a',borderRadius:8,padding:'8px 10px',border:'1px solid #1e293b'}}>
      <div style={{fontSize:'.66rem',fontWeight:700,color:'#64748b',marginBottom:6,letterSpacing:'.07em',textTransform:'uppercase'}}>
        Vista de sección transversal
      </div>
      <svg viewBox={`0 0 ${SVG_W} ${SVG_H}`} style={{width:'100%',height:'auto',display:'block'}}>
        {/* Ground */}
        <rect x={0} y={roadY+roadH} width={SVG_W} height={SVG_H-(roadY+roadH)+1} fill="#1e293b"/>
        {/* Tunnel body */}
        <path d={tunnelPath} fill="#1e293b" stroke="#334155" strokeWidth="1.5"/>
        {/* Road */}
        <rect x={ox} y={roadY} width={tw} height={roadH} fill="#374151"/>
        {/* Carriles pintados — borde de calzada (continuo) + separadores de carril (discontinuos) */}
        {carriagewayStart_m > 0.01 && (
          <line x1={ox+(carriagewayStart_m/W)*tw} y1={roadY} x2={ox+(carriagewayStart_m/W)*tw} y2={roadY+roadH}
            stroke="#f8fafc" strokeWidth="1"/>
        )}
        {carriagewayEnd_m < W - 0.01 && (
          <line x1={ox+(carriagewayEnd_m/W)*tw} y1={roadY} x2={ox+(carriagewayEnd_m/W)*tw} y2={roadY+roadH}
            stroke="#f8fafc" strokeWidth="1"/>
        )}
        {laneDividers_m.map((yM,i)=>(
          <line key={i} x1={ox+(yM/W)*tw} y1={roadY} x2={ox+(yM/W)*tw} y2={roadY+roadH}
            stroke="#f8fafc" strokeWidth="0.8" strokeDasharray="2 1.5" opacity="0.85"/>
        ))}
        {/* Arch / wall division (horseshoe only) */}
        {shape==='horseshoe' && Hp > 0 && Hp < H && (
          <line x1={ox} y1={oy+archH_px} x2={ox+tw} y2={oy+archH_px}
            stroke="#334155" strokeWidth="0.6" strokeDasharray="4 3" opacity="0.6"/>
        )}
        {shape==='circular' && (
          <React.Fragment>
            {/* Radio label */}
            {(()=>{const R_m=((W/2)**2+H**2)/(2*H);const R_px=R_m*sc;
              return <text x={ox+tw/2} y={oy+th/2+4} textAnchor="middle" fill="#475569" fontSize="8" opacity="0.8">
                R = {R_m.toFixed(2)} m
              </text>;})()}
          </React.Fragment>
        )}
        {/* Width dimension */}
        <line x1={ox} y1={roadY+roadH+8} x2={ox+tw} y2={roadY+roadH+8} stroke="#64748b" strokeWidth="0.8"/>
        <line x1={ox} y1={roadY+roadH+4} x2={ox} y2={roadY+roadH+12} stroke="#64748b" strokeWidth="0.8"/>
        <line x1={ox+tw} y1={roadY+roadH+4} x2={ox+tw} y2={roadY+roadH+12} stroke="#64748b" strokeWidth="0.8"/>
        <text x={ox+tw/2} y={roadY+roadH+18} textAnchor="middle" fill="#94a3b8" fontSize="9">W = {W.toFixed(1)} m</text>
        {/* Height dimension */}
        <line x1={ox-8} y1={oy} x2={ox-8} y2={roadY} stroke="#64748b" strokeWidth="0.8"/>
        <line x1={ox-12} y1={oy} x2={ox-4} y2={oy} stroke="#64748b" strokeWidth="0.8"/>
        <line x1={ox-12} y1={roadY} x2={ox-4} y2={roadY} stroke="#64748b" strokeWidth="0.8"/>
        <text x={ox-22} y={oy+(roadY-oy)/2+3} textAnchor="middle" fill="#94a3b8" fontSize="9"
          transform={`rotate(-90,${ox-22},${oy+(roadY-oy)/2+3})`}>H = {H.toFixed(1)} m</text>
        {/* H_pared dimension (horseshoe only) */}
        {shape==='horseshoe' && Hp>0 && Hp<H && (
          <React.Fragment>
            <line x1={ox+tw+6} y1={oy+archH_px} x2={ox+tw+6} y2={roadY} stroke="#475569" strokeWidth="0.7"/>
            <line x1={ox+tw+3} y1={oy+archH_px} x2={ox+tw+9} y2={oy+archH_px} stroke="#475569" strokeWidth="0.7"/>
            <line x1={ox+tw+3} y1={roadY} x2={ox+tw+9} y2={roadY} stroke="#475569" strokeWidth="0.7"/>
            <text x={ox+tw+22} y={oy+archH_px+(roadY-oy-archH_px)/2+3} textAnchor="middle" fill="#64748b" fontSize="8"
              transform={`rotate(90,${ox+tw+22},${oy+archH_px+(roadY-oy-archH_px)/2+3})`}>Hp={Hp.toFixed(1)}m</text>
          </React.Fragment>
        )}
        {/* Distancia entre luminarias (transversal, si hay 2 en esta sección) */}
        {lumPts.length === 2 && transverseDist_m !== null && (()=>{
          const y = Math.min(lumPts[0].py, lumPts[1].py) - 10;
          const x1 = lumPts[0].px, x2 = lumPts[1].px;
          return (
            <React.Fragment>
              <line x1={x1} y1={y} x2={x2} y2={y} stroke="#64748b" strokeWidth="0.7"/>
              <line x1={x1} y1={y-3} x2={x1} y2={y+3} stroke="#64748b" strokeWidth="0.7"/>
              <line x1={x2} y1={y-3} x2={x2} y2={y+3} stroke="#64748b" strokeWidth="0.7"/>
              <text x={(x1+x2)/2} y={y-4} textAnchor="middle" fill="#94a3b8" fontSize="8">
                {transverseDist_m.toFixed(2)} m
              </text>
            </React.Fragment>
          );
        })()}
        {/* Luminaire markers — rectángulo horizontal (cuerpo de la luminaria).
            El tilt real varía por posición a lo largo del túnel (curva CIE 88),
            así que aquí se dibuja siempre horizontal para no sugerir un único
            ángulo fijo que no se corresponde con ninguna luminaria en concreto. */}
        {lumPts.map(({px,py,inside},i)=>{
          const rectW = 16, rectH = rectW * 0.25;   // altura = 25% de la anchura transversal
          return (
            <g key={i}>
              <line x1={px} y1={py+rectH/2} x2={px} y2={roadY} stroke={inside?"#fbbf24":"#f87171"} strokeWidth="0.7" strokeDasharray="3 2" opacity="0.5"/>
              <rect x={px-rectW/2} y={py-rectH/2} width={rectW} height={rectH} rx={1}
                fill={inside?"#fbbf24":"#f87171"} stroke="#fff" strokeWidth="1.2" opacity="0.9"/>
              {/* Distancia al suelo de la luminaria (altura de montaje) */}
              <text x={px+9} y={(py+roadY)/2+3} textAnchor="start" fill="#94a3b8" fontSize="7.5">
                h={hm.toFixed(1)}m
              </text>
              {!inside && (
                <text x={px} y={py-10} textAnchor="middle" fill="#f87171" fontSize="9" fontWeight="700">⚠</text>
              )}
            </g>
          );
        })}
        {/* Outside warning banner */}
        {outsideWarning && (
          <React.Fragment>
            <rect x={ox} y={oy} width={tw} height={20} fill="#7f1d1d" opacity="0.6" rx="3"/>
            <text x={ox+tw/2} y={oy+14} textAnchor="middle" fill="#fca5a5" fontSize="9" fontWeight="600">
              ⚠ Luminaria fuera del contorno del túnel
            </text>
          </React.Fragment>
        )}
        {/* Shape label */}
        <text x={ox+tw/2} y={oy+8} textAnchor="middle" fill="#475569" fontSize="8" opacity="0.7">
          {shape==='horseshoe'?'Sección en herradura':shape==='circular'?'Sección circular (galería)':'Sección rectangular'}
        </text>
      </svg>
    </div>
  );
}

// ── Vista 3D en primera persona: recorrido del conductor por el túnel ────────
// Construye la sección transversal real (rectangular/circular/herradura, misma
// geometría que TunnelSectionPreview) extruida a lo largo del eje, coloca las
// luminarias reales (posición/óptica→color) y anima una cámara a la altura del
// ojo del conductor recorriendo el túnel de punta a punta.
const _MODEL_COLOR_3D = { S: 0x22c55e, M: 0x3b82f6, L: 0xa855f7 };
const _ROAD_SURFACE_COLOR_3D = {
  dark_asphalt: 0x1a1a1c, medium_asphalt: 0x28282b, light_asphalt: 0x3c3c3e,
  concrete: 0x716f66, bright_concrete: 0xa8a69b,
};
const _CCT_LIGHT_COLOR_3D = { '3000K': 0xffc38a, '4000K': 0xfff2e0 };
// Distancia (m) antes del portal donde empieza el recorrido -- coincide
// con el punto de toma de la foto de boca subida por el usuario.
const _APPROACH_M_3D = 25;

function _familyOf3D(model) {
  if (!model) return 'M';
  if (/_S_|^S$/.test(model)) return 'S';
  if (/_L_|^L$/.test(model)) return 'L';
  return 'M';
}

function _tunnelCrossSectionPoints3D(W, H, shape, Hp) {
  // Devuelve puntos [y, z] desde la pared izq (y=0,z=0) hasta la pared der
  // (y=W,z=0), pasando por la clave — misma geometría que TunnelSectionPreview.
  const segs = 24;
  const pts = [[0, 0]];
  if (shape === 'rectangular') {
    pts.push([0, H], [W, H]);
  } else if (shape === 'circular') {
    const R  = ((W / 2) ** 2 + H ** 2) / (2 * H);
    const zc = H - R;
    const aMax = Math.acos(Math.max(-1, Math.min(1, -zc / R)));
    for (let i = 0; i <= segs; i++) {
      const a = -aMax + (i / segs) * 2 * aMax;
      pts.push([W / 2 + R * Math.sin(a), zc + R * Math.cos(a)]);
    }
  } else { // horseshoe
    pts.push([0, Hp]);
    for (let i = 0; i <= segs; i++) {
      const a = Math.PI - (i / segs) * Math.PI;
      pts.push([W / 2 + (W / 2) * Math.cos(a), Hp + (H - Hp) * Math.sin(a)]);
    }
    pts.push([W, Hp]);
  }
  pts.push([W, 0]);
  return pts;
}

function Tunnel3DDrive({ lumList, W_m, H_m, shape, H_pared_m, tubeLength, mountH, speedKmh = 80,
                          roadSurface = 'dark_asphalt', numLanes = 2, laneWidthM = 3.5,
                          shoulderLeftM = 0, shoulderRightM = 0, cct = '4000K',
                          rhoWall = 0.40, rhoCeiling = 0.25 }) {
  const mountRef = React.useRef(null);
  const engineRef = React.useRef(null);
  const fileInputRef = React.useRef(null);
  const [playing, setPlaying] = React.useState(false);
  const [speed, setSpeed] = React.useState(speedKmh || 80);
  const [posM, setPosM] = React.useState(-_APPROACH_M_3D);
  const [laneIdx, setLaneIdx] = React.useState(null);
  const [portalImg, setPortalImg] = React.useState(null);
  const [lightIntensity, setLightIntensity] = React.useState(1.0);
  const [imgOffX, setImgOffX] = React.useState(0);
  const [imgOffY, setImgOffY] = React.useState(0);
  const [imgZoom, setImgZoom] = React.useState(1);
  const [showGuide, setShowGuide] = React.useState(true);
  const speedRef = React.useRef(speed);
  const laneIdxRef = React.useRef(null);
  // "lightIntensity" ahora controla la EXPOSICION del tone mapping (ACES
  // Filmic) del renderer, no la intensidad bruta de cada luz -- ver
  // comentario junto a renderer.toneMapping mas abajo.
  const lightIntensityRef = React.useRef(lightIntensity);
  React.useEffect(() => { speedRef.current = speed; }, [speed]);
  React.useEffect(() => { laneIdxRef.current = laneIdx; }, [laneIdx]);
  React.useEffect(() => { lightIntensityRef.current = lightIntensity; }, [lightIntensity]);

  const nLanesEff = Math.max(1, parseInt(numLanes) || 2);

  React.useEffect(() => {
    if (!mountRef.current || typeof THREE === 'undefined' || !(tubeLength > 0)) return;
    const mount = mountRef.current;
    const width  = mount.clientWidth || 640;
    const height = 380;
    const eyeH   = 1.5;

    const scene = new THREE.Scene();
    scene.background = new THREE.Color(0x03040a);
    // Horizonte llevado hasta el limite de vision (antes se cortaba en
    // niebla a 240 m, dando la sensacion de que los focos se "encendian"
    // segun se acercaba la camara). El propio tunel recto ya actua de
    // "vanishing point" natural mucho antes de este limite.
    scene.fog = new THREE.Fog(0x03040a, 25, 500);

    const camera = new THREE.PerspectiveCamera(72, width / height, 0.1, 1000);
    const renderer = new THREE.WebGLRenderer({ antialias: true, preserveDrawingBuffer: true });
    renderer.setSize(width, height);
    renderer.setPixelRatio(Math.min(window.devicePixelRatio || 1, 2));
    // Tone mapping ACES Filmic: el rango real de flujo de las luminarias
    // (miles a >100.000 lm) es demasiado amplio para acumular linealmente y
    // recortar en 1.0 (NoToneMapping por defecto) sin que las zonas oscuras
    // del tunel se vean planas/negras junto a las brillantes -- ACES Filmic
    // comprime ese rango de forma perceptual (la misma curva que usan la
    // mayoria de motores graficos para HDR), evitando el recorte brusco a
    // blanco y conservando detalle en el interior oscuro. El slider de
    // "Intensidad" controla la EXPOSICION de este tone mapping (equivalente
    // a un control de exposicion fotografico), no la intensidad bruta de
    // cada luz -- asi compensa pantallas de distinto brillo sin alterar el
    // contraste relativo real entre luminarias.
    renderer.outputEncoding = THREE.sRGBEncoding;
    renderer.toneMapping = THREE.ACESFilmicToneMapping;
    renderer.toneMappingExposure = lightIntensityRef.current ?? 1.0;
    mount.innerHTML = '';
    mount.appendChild(renderer.domElement);

    const toWorldZ = (y) => W_m / 2 - y;

    // ── Túnel extruido (dos anillos: x=0 y x=tubeLength) — recubrimiento
    //    pared/techo por color de vertice, interpolado segun altura real
    //    entre el tono de ρ pared (por debajo de Hp) y ρ techo (arco/clave),
    //    para reflejar visualmente las reflectancias configuradas. ─────────
    const Hp_eff = Math.min(H_pared_m, H_m);
    const crossPts = _tunnelCrossSectionPoints3D(W_m, H_m, shape, Hp_eff);
    const _rhoToRgb3D = (rho, tint) => {
      const g = Math.max(0.10, Math.min(0.92, 0.14 + (rho || 0.3) * 1.05));
      const r = Math.min(1, g * tint[0]);
      const gg = Math.min(1, g * tint[1]);
      const b = Math.min(1, g * tint[2]);
      return [r, gg, b];
    };
    const wallRGB = _rhoToRgb3D(rhoWall, [1.06, 1.0, 0.94]);      // ligero tono calido
    const ceilRGB = _rhoToRgb3D(rhoCeiling, [0.96, 0.99, 1.06]);  // ligero tono frio
    {
      const positions = [];
      const colors = [];
      const denom = Math.max(0.01, H_m - Hp_eff);
      for (const x of [0, tubeLength]) {
        for (const [y, z] of crossPts) {
          positions.push(x, z, toWorldZ(y));
          const t = Math.max(0, Math.min(1, (z - Hp_eff) / denom));
          colors.push(
            wallRGB[0] + (ceilRGB[0] - wallRGB[0]) * t,
            wallRGB[1] + (ceilRGB[1] - wallRGB[1]) * t,
            wallRGB[2] + (ceilRGB[2] - wallRGB[2]) * t,
          );
        }
      }
      const n = crossPts.length;
      const indices = [];
      for (let i = 0; i < n - 1; i++) {
        const a = i, b = i + 1, c = n + i, d = n + i + 1;
        indices.push(a, c, b, b, c, d);
      }
      const wallGeo = new THREE.BufferGeometry();
      wallGeo.setAttribute('position', new THREE.Float32BufferAttribute(positions, 3));
      wallGeo.setAttribute('color', new THREE.Float32BufferAttribute(colors, 3));
      wallGeo.setIndex(indices);
      wallGeo.computeVertexNormals();
      const wallMat = new THREE.MeshStandardMaterial({
        vertexColors: true, roughness: 0.95, metalness: 0.0, side: THREE.DoubleSide,
      });
      scene.add(new THREE.Mesh(wallGeo, wallMat));
    }

    // ── Calzada: color segun el tipo de firme seleccionado ────────────────
    const roadColor = _ROAD_SURFACE_COLOR_3D[roadSurface] || _ROAD_SURFACE_COLOR_3D.dark_asphalt;
    {
      const half = W_m / 2;
      const roadGeo = new THREE.BufferGeometry();
      const positions = [
        0, 0, half,           tubeLength, 0, half,        0, 0, -half,
        tubeLength, 0, half,  tubeLength, 0, -half,       0, 0, -half,
      ];
      roadGeo.setAttribute('position', new THREE.Float32BufferAttribute(positions, 3));
      roadGeo.computeVertexNormals();
      const roadMat = new THREE.MeshStandardMaterial({ color: roadColor, roughness: 1.0 });
      scene.add(new THREE.Mesh(roadGeo, roadMat));
    }

    // ── Carriles y arcenes: borde de calzada continuo + separadores
    //    discontinuos, mismo criterio que TunnelSectionPreview ─────────────
    const shL = Math.max(0, parseFloat(shoulderLeftM) || 0);
    const shR = Math.max(0, parseFloat(shoulderRightM) || 0);
    const laneW = parseFloat(laneWidthM) || 3.5;
    const carriagewayStart = shL;
    const carriagewayEnd   = Math.min(W_m, shL + nLanesEff * laneW);
    const laneDividerYs = Array.from({ length: Math.max(0, nLanesEff - 1) }, (_, i) => shL + (i + 1) * laneW)
      .filter(y => y > 0.05 && y < W_m - 0.05);

    const _dashTex3D = (() => {
      const c = document.createElement('canvas');
      c.width = 64; c.height = 8;
      const ctx = c.getContext('2d');
      ctx.clearRect(0, 0, 64, 8);
      ctx.fillStyle = '#f2f2f0';
      ctx.fillRect(0, 2, 30, 4);
      const tex = new THREE.CanvasTexture(c);
      tex.wrapS = THREE.RepeatWrapping;
      return tex;
    })();

    const _buildLineStrip3D = (yPos, widthM, dashed) => {
      const geo = new THREE.PlaneGeometry(tubeLength, widthM);
      geo.rotateX(-Math.PI / 2);
      geo.translate(tubeLength / 2, 0.012, toWorldZ(yPos));
      let mat;
      if (dashed) {
        const tex = _dashTex3D.clone();
        tex.repeat.set(tubeLength / 6, 1);
        tex.needsUpdate = true;
        mat = new THREE.MeshBasicMaterial({ map: tex, transparent: true, depthWrite: false });
      } else {
        mat = new THREE.MeshBasicMaterial({ color: 0xf2f2f0 });
      }
      return new THREE.Mesh(geo, mat);
    };
    if (carriagewayStart > 0.05) scene.add(_buildLineStrip3D(carriagewayStart, 0.12, false));
    if (carriagewayEnd < W_m - 0.05) scene.add(_buildLineStrip3D(carriagewayEnd, 0.12, false));
    laneDividerYs.forEach(y => scene.add(_buildLineStrip3D(y, 0.10, true)));

    // ── Iluminacion: color segun la temperatura de color seleccionada ────
    const lightColor = _CCT_LIGHT_COLOR_3D[cct] || _CCT_LIGHT_COLOR_3D['4000K'];

    // Luz de portal (simula luz de dia entrando por ambas bocas)
    const _PORTAL_BASE_I_3D = 2.2;
    const portalA = new THREE.PointLight(0xdbe9ff, _PORTAL_BASE_I_3D, 60, 1.2);
    portalA.position.set(-2, eyeH + 1, 0);
    scene.add(portalA);
    const portalB = new THREE.PointLight(0xdbe9ff, _PORTAL_BASE_I_3D, 60, 1.2);
    portalB.position.set(tubeLength + 2, eyeH + 1, 0);
    scene.add(portalB);
    // Luz de relleno general -- WebGL no puede simular con luces dinamicas
    // reales cada una de (potencialmente) miles de luminarias a la vez, asi
    // que el resto del tunel se ilumina con una base ambiental uniforme
    // (mas el pool de abajo para las mas cercanas). Ambas escalan con el
    // slider de intensidad, para que el usuario controle el nivel general.
    const ambientLight = new THREE.AmbientLight(0x3a3f4a, 1.0);
    scene.add(ambientLight);

    // ── Luminarias: esfera emisiva por unidad (color por familia S/M/L) —
    //    posicion, modelo y tilt tal cual los calculo el motor de diseno ──
    const lumPts = (lumList || []).filter(lm => lm && isFinite(lm.x) && isFinite(lm.y));
    const sphereGeo = new THREE.SphereGeometry(0.14, 10, 8);
    lumPts.forEach((lm) => {
      const color = _MODEL_COLOR_3D[_familyOf3D(lm.model || lm.pcb)] || 0x93c5fd;
      const mat = new THREE.MeshBasicMaterial({ color });
      const mesh = new THREE.Mesh(sphereGeo, mat);
      mesh.position.set(lm.x, mountH, toWorldZ(lm.y));
      if (lm.tilt) mesh.rotation.x = THREE.MathUtils.degToRad(lm.tilt);
      scene.add(mesh);
    });

    // ── Intensidad de cada luz a partir de su flujo real (lm) calculado por
    //    el motor -- antes todas las luminarias brillaban igual (constante
    //    3.2) sin relacion con el diseno real. El flujo real de un proyecto
    //    abarca ~5.000-120.000 lm (>20x): mapearlo LINEALMENTE a intensidad
    //    haria que las luminarias mas pequenas se vean casi apagadas junto a
    //    las mayores. Se usa una escala logaritmica (percepcion visual del
    //    brillo, igual que decibelios/luminancia CIE) normalizada al rango
    //    de flujo REAL presente en este proyecto -- adaptativa, no rangos
    //    fijos -- y comprimida al rango visual [I_LO, I_HI]. El resultado
    //    entra en la escena de forma fija (no depende del slider): el brillo
    //    percibido en pantalla se ajusta despues via la EXPOSICION del tone
    //    mapping (ver renderer.toneMappingExposure), no reescalando cada luz.
    const fluxVals = lumPts.map(lm => Number(lm.flux_lm) || 0).filter(v => v > 0);
    const fluxMin = fluxVals.length ? Math.min(...fluxVals) : 5000;
    const fluxMax = fluxVals.length ? Math.max(...fluxVals) : 100000;
    const logMin = Math.log10(1 + fluxMin);
    const logRange = Math.max(1e-6, Math.log10(1 + fluxMax) - logMin);
    const I_LO = 1.6, I_HI = 6.0;
    const fluxToIntensity3D = (flux) => {
      const f = Math.max(fluxMin, Number(flux) || fluxMin);
      const t = (Math.log10(1 + f) - logMin) / logRange;
      return I_LO + t * (I_HI - I_LO);
    };

    // ── Pool de luces dinamicas: las N luminarias mas cercanas a la camara
    //    reciben una luz real con caida fisica (WebGL no soporta miles de
    //    luces simultaneas) -- se amplia la ventana y el alcance de cada
    //    una para que se solapen y no se note el limite del pool. ─────────
    const N_LIGHTS = 60;
    const lightPool = [];
    for (let i = 0; i < N_LIGHTS; i++) {
      const pl = new THREE.PointLight(lightColor, 0, 45, 1.3);
      scene.add(pl);
      lightPool.push(pl);
    }
    const sortedLums = [...lumPts].sort((a, b) => a.x - b.x);

    const updateLights = (xCam) => {
      let lo = 0, hi = sortedLums.length - 1, mid;
      while (lo < hi) { mid = (lo + hi) >> 1; sortedLums[mid].x < xCam ? lo = mid + 1 : hi = mid; }
      const startIdx = Math.max(0, lo - Math.ceil(N_LIGHTS / 2));
      for (let i = 0; i < N_LIGHTS; i++) {
        const lm = sortedLums[startIdx + i];
        const pl = lightPool[i];
        if (!lm) { pl.intensity = 0; continue; }
        pl.position.set(lm.x, mountH, toWorldZ(lm.y));
        pl.intensity = fluxToIntensity3D(lm.flux_lm);
      }
    };

    // ── Carriles disponibles para el cambio de carril ─────────────────────
    const laneCenters = Array.from({ length: nLanesEff }, (_, i) => toWorldZ(shL + (i + 0.5) * laneW));
    let defaultLaneIdx = 0;
    let bestDist = Infinity;
    laneCenters.forEach((z, i) => { const dd = Math.abs(z); if (dd < bestDist) { bestDist = dd; defaultLaneIdx = i; } });
    if (laneIdxRef.current == null) { laneIdxRef.current = defaultLaneIdx; setLaneIdx(defaultLaneIdx); }

    // ── Camara: altura de ojo del conductor, recorre el eje del tunel;
    //    la posicion lateral (carril) se suaviza con una interpolacion
    //    exponencial en vez de saltar de golpe (cambio de carril fluido) ───
    // El recorrido empieza _APPROACH_M_3D metros ANTES del portal -- el
    // mismo punto (aprox.) desde el que se tomo la foto real de la boca,
    // si el usuario ha subido una (ver overlay de imagen mas abajo).
    let s = -_APPROACH_M_3D;
    let laneZCurrent = laneCenters[laneIdxRef.current] ?? 0;
    const setCam = (sVal, dt) => {
      s = Math.max(-_APPROACH_M_3D, Math.min(tubeLength, sVal));
      const targetZ = laneCenters[laneIdxRef.current] ?? 0;
      const k = dt != null ? 1 - Math.exp(-dt * 5) : 1;
      laneZCurrent += (targetZ - laneZCurrent) * k;
      camera.position.set(s, eyeH, laneZCurrent);
      camera.lookAt(s + 12, eyeH - 0.15, laneZCurrent);
      updateLights(s);
    };
    setCam(-_APPROACH_M_3D, null);

    let raf = null, lastT = null;
    const animate = (t) => {
      raf = requestAnimationFrame(animate);
      if (lastT == null) lastT = t;
      const dt = Math.min(0.1, (t - lastT) / 1000);
      lastT = t;
      const eng = engineRef.current;
      if (eng && eng.playing) {
        const v_ms = (speedRef.current || 80) / 3.6;
        setCam(s + v_ms * dt, dt);
        eng.onProgress(s);
        if (s >= tubeLength) eng.stop();
      } else {
        setCam(s, dt);
      }
      renderer.toneMappingExposure = lightIntensityRef.current ?? 1.0;
      renderer.render(scene, camera);
    };
    raf = requestAnimationFrame(animate);

    const onResize = () => {
      const w = mount.clientWidth || width;
      camera.aspect = w / height;
      camera.updateProjectionMatrix();
      renderer.setSize(w, height);
    };
    window.addEventListener('resize', onResize);

    engineRef.current = {
      playing: false,
      onProgress: (sVal) => setPosM(sVal),
      stop: () => { engineRef.current.playing = false; setPlaying(false); },
      seek: (sVal) => setCam(sVal, null),
    };

    return () => {
      cancelAnimationFrame(raf);
      window.removeEventListener('resize', onResize);
      renderer.dispose();
      scene.traverse(obj => { if (obj.geometry) obj.geometry.dispose(); if (obj.material) obj.material.dispose(); });
      mount.innerHTML = '';
      engineRef.current = null;
    };
  }, [lumList, W_m, H_m, shape, H_pared_m, tubeLength, mountH, roadSurface, numLanes, laneWidthM,
      shoulderLeftM, shoulderRightM, cct, rhoWall, rhoCeiling]);

  React.useEffect(() => {
    if (engineRef.current) engineRef.current.playing = playing;
  }, [playing]);

  const onSeek = (v) => {
    const sVal = parseFloat(v);
    setPosM(sVal);
    engineRef.current?.seek(sVal);
  };
  const changeLane = (delta) => {
    setLaneIdx(prev => {
      const cur = prev ?? 0;
      return Math.max(0, Math.min(nLanesEff - 1, cur + delta));
    });
  };

  const onUploadPortalImg = (e) => {
    const f = e.target.files && e.target.files[0];
    if (!f) return;
    const reader = new FileReader();
    reader.onload = ev => { setPortalImg(ev.target.result); setImgOffX(0); setImgOffY(0); setImgZoom(1); };
    reader.readAsDataURL(f);
    e.target.value = '';
  };
  const fadeOpacity = portalImg ? Math.max(0, Math.min(1, -posM / _APPROACH_M_3D)) : 0;

  // ── Guia de encuadre: silueta real del tunel (misma geometria que el 3D
  //    y que la vista de seccion transversal) para que el usuario pueda
  //    alinear la boca de SU foto con la forma/proporciones reales, ya que
  //    no hay forma fiable de detectar automaticamente la boca en una foto
  //    arbitraria. ────────────────────────────────────────────────────────
  const Hp_eff_guide = Math.min(H_pared_m, H_m);
  const guidePts = _tunnelCrossSectionPoints3D(W_m, H_m, shape, Hp_eff_guide);
  const guideMarginX = W_m * 0.15;
  const guideTopMargin = H_m * 0.15;
  const guideVbW = W_m + guideMarginX * 2;
  const guideVbH = H_m + guideTopMargin;
  const guidePathD = 'M ' + guidePts.map(([y, z]) => `${y + guideMarginX},${guideVbH - z}`).join(' L ')
    + ` L ${guideMarginX},${guideVbH} Z`;

  return (
    <div style={{background:'#03040a',border:'1px solid var(--salvi-line)',borderRadius:8,padding:'10px 12px'}}>
      <div style={{display:'flex',alignItems:'center',gap:8,marginBottom:6}}>
        <div style={{fontSize:'.68rem',fontWeight:700,color:'var(--salvi-grey)',
            textTransform:'uppercase',letterSpacing:'.07em'}}>
          Vista 3D — recorrido del conductor (primera persona)
        </div>
        <input ref={fileInputRef} type="file" accept="image/*" style={{display:'none'}} onChange={onUploadPortalImg}/>
        <button onClick={()=>fileInputRef.current?.click()}
          style={{marginLeft:'auto',padding:'3px 10px',fontSize:'.68rem',fontWeight:600,cursor:'pointer',
                  borderRadius:4,border:'1px solid var(--salvi-line)',background:'#fff',color:'var(--salvi-black)'}}>
          📷 {portalImg ? 'Cambiar foto del portal' : 'Cargar foto del portal'}
        </button>
        {portalImg && (
          <button onClick={()=>setPortalImg(null)}
            style={{padding:'3px 10px',fontSize:'.68rem',fontWeight:600,cursor:'pointer',
                    borderRadius:4,border:'1px solid var(--salvi-line)',background:'#fff',color:'#b91c1c'}}>
            ✕ Quitar
          </button>
        )}
      </div>
      <div style={{position:'relative',width:'100%',height:380,borderRadius:6,overflow:'hidden'}}>
        <div ref={mountRef} style={{width:'100%',height:'100%'}}/>
        {portalImg && fadeOpacity > 0.01 && (
          <div style={{position:'absolute',inset:0,opacity:fadeOpacity,pointerEvents:'none',
                       transition:'opacity .08s linear',overflow:'hidden'}}>
            <img src={portalImg} alt="Boca del túnel"
              style={{width:'100%',height:'100%',objectFit:'cover',
                      transform:`translate(${imgOffX}%, ${imgOffY}%) scale(${imgZoom})`,
                      transformOrigin:'center center'}}/>
            {showGuide && (
              <svg viewBox={`0 0 ${guideVbW} ${guideVbH}`} preserveAspectRatio="xMidYMid meet"
                style={{position:'absolute',inset:0,width:'100%',height:'100%'}}>
                <path d={guidePathD} fill="none" stroke="#22c55e" strokeOpacity="0.85"
                  strokeWidth={guideVbW * 0.008} strokeDasharray={`${guideVbW*0.018} ${guideVbW*0.012}`}/>
              </svg>
            )}
            <div style={{position:'absolute',bottom:6,left:8,fontSize:'.62rem',color:'#fff',
                         background:'rgba(0,0,0,.55)',padding:'2px 8px',borderRadius:4}}>
              📍 Punto real de la foto — el recorrido empieza aquí
            </div>
          </div>
        )}
      </div>
      {portalImg && (
        <div style={{display:'flex',alignItems:'center',gap:10,marginTop:6,flexWrap:'wrap',
                     background:'#0b0d12',border:'1px solid #1e293b',borderRadius:6,padding:'6px 10px'}}>
          <span style={{fontSize:'.64rem',color:'var(--salvi-grey)',fontWeight:600,whiteSpace:'nowrap'}}>
            🎯 Encuadre: alinea la boca de tu foto con la guía verde
          </span>
          <label style={{display:'flex',alignItems:'center',gap:5,fontSize:'.62rem',color:'var(--salvi-grey)'}}>
            H
            <input type="range" min={-50} max={50} step={1} value={imgOffX}
              onChange={e=>setImgOffX(parseFloat(e.target.value)||0)} style={{width:70}}/>
          </label>
          <label style={{display:'flex',alignItems:'center',gap:5,fontSize:'.62rem',color:'var(--salvi-grey)'}}>
            V
            <input type="range" min={-50} max={50} step={1} value={imgOffY}
              onChange={e=>setImgOffY(parseFloat(e.target.value)||0)} style={{width:70}}/>
          </label>
          <label style={{display:'flex',alignItems:'center',gap:5,fontSize:'.62rem',color:'var(--salvi-grey)'}}>
            Zoom
            <input type="range" min={0.5} max={2.5} step={0.05} value={imgZoom}
              onChange={e=>setImgZoom(parseFloat(e.target.value)||1)} style={{width:70}}/>
          </label>
          <button onClick={()=>{setImgOffX(0); setImgOffY(0); setImgZoom(1);}}
            style={{padding:'2px 8px',fontSize:'.62rem',cursor:'pointer',borderRadius:4,
                    border:'1px solid var(--salvi-line)',background:'#fff',color:'var(--salvi-black)'}}>
            ⟲ Reset
          </button>
          <label style={{display:'flex',alignItems:'center',gap:4,fontSize:'.62rem',color:'var(--salvi-grey)',marginLeft:'auto'}}>
            <input type="checkbox" checked={showGuide} onChange={e=>setShowGuide(e.target.checked)}/>
            Mostrar guía
          </label>
        </div>
      )}
      <div style={{display:'flex',alignItems:'center',gap:10,marginTop:8,flexWrap:'wrap'}}>
        <button onClick={()=>setPlaying(p=>!p)}
          style={{padding:'5px 14px',fontSize:'.72rem',fontWeight:700,cursor:'pointer',
                  borderRadius:999,border:'1.5px solid var(--salvi-line)',
                  background:playing?'#1d4ed8':'#fff',color:playing?'#fff':'var(--salvi-black)'}}>
          {playing ? '⏸ Pausa' : '▶ Recorrer túnel'}
        </button>
        <button onClick={()=>{setPlaying(false); onSeek(-_APPROACH_M_3D);}}
          style={{padding:'5px 12px',fontSize:'.72rem',cursor:'pointer',borderRadius:999,
                  border:'1.5px solid var(--salvi-line)',background:'#fff',color:'var(--salvi-black)'}}>
          ⟲ Inicio
        </button>
        {nLanesEff > 1 && (
          <div style={{display:'flex',alignItems:'center',gap:3}}>
            <button onClick={()=>changeLane(-1)} title="Cambiar al carril izquierdo"
              style={{padding:'5px 10px',fontSize:'.72rem',cursor:'pointer',borderRadius:6,
                      border:'1.5px solid var(--salvi-line)',background:'#fff',color:'var(--salvi-black)'}}>
              ◀ Carril
            </button>
            <span style={{fontSize:'.62rem',color:'var(--salvi-grey)',fontFamily:'monospace',minWidth:34,textAlign:'center'}}>
              {(laneIdx??0)+1}/{nLanesEff}
            </span>
            <button onClick={()=>changeLane(1)} title="Cambiar al carril derecho"
              style={{padding:'5px 10px',fontSize:'.72rem',cursor:'pointer',borderRadius:6,
                      border:'1.5px solid var(--salvi-line)',background:'#fff',color:'var(--salvi-black)'}}>
              Carril ▶
            </button>
          </div>
        )}
        <input type="range" min={-_APPROACH_M_3D} max={tubeLength} step={1} value={posM}
          onChange={e=>onSeek(e.target.value)}
          style={{flex:'1 1 160px',minWidth:120}}/>
        <span style={{fontSize:'.68rem',color:'var(--salvi-grey)',fontFamily:'monospace',whiteSpace:'nowrap'}}>
          {posM.toFixed(0)} / {tubeLength.toFixed(0)} m
        </span>
        <label style={{display:'flex',alignItems:'center',gap:6,fontSize:'.68rem',color:'var(--salvi-grey)'}}>
          Velocidad
          <input type="range" min={10} max={130} step={5} value={speed}
            onChange={e=>setSpeed(parseFloat(e.target.value)||80)}
            style={{width:90}}/>
          <span style={{fontFamily:'monospace',minWidth:32,textAlign:'right'}}>{speed}</span> km/h
        </label>
        <label style={{display:'flex',alignItems:'center',gap:6,fontSize:'.68rem',color:'var(--salvi-grey)'}}
          title="Exposición del renderizado (compensa pantallas de distinto brillo) — el brillo relativo entre luminarias viene de su flujo real calculado">
          ☀️ Exposición
          <input type="range" min={0.2} max={3} step={0.05} value={lightIntensity}
            onChange={e=>setLightIntensity(parseFloat(e.target.value)||1)}
            style={{width:90}}/>
          <span style={{fontFamily:'monospace',minWidth:28,textAlign:'right'}}>{lightIntensity.toFixed(2)}×</span>
        </label>
      </div>
    </div>
  );
}

function StepGeometry({ form, onChange, osmFields, onClearOsm }) {
  const osm = (k) => !!osmFields?.has(k);
  const clr = (k) => () => onClearOsm && onClearOsm(k);
  const v=parseFloat(form.speed_kmh)||80; const L=parseFloat(form.length_m)||0;
  const SD=estimateSD(v); const Lmin=Math.ceil(2*SD+30);
  const lengthStatus=L<=0?null:L<SD?"critical":L<Lmin?"warning":L<Lmin*1.5?"ok":"good";
  // Anchura interior = n_carriles x ancho_carril + arcen_izq + arcen_der (CIE 140:
  // donde exista arcen y se requiera informacion de luminancia, se trata con la
  // misma malla de calculo que un carril de circulacion — no se excluye del ancho).
  const setGeomPart = (key, val) => {
    onChange(key, val);
    const parts = { num_lanes: form.num_lanes, lane_width_m: form.lane_width_m,
                     shoulder_left_m: form.shoulder_left_m, shoulder_right_m: form.shoulder_right_m,
                     [key]: val };
    const w = (parseInt(parts.num_lanes)||2) * (parseFloat(parts.lane_width_m)||3.5)
              + (parseFloat(parts.shoulder_left_m)||0) + (parseFloat(parts.shoulder_right_m)||0);
    onChange('width_m', Math.round(w*100)/100);
  };
  return (
    <>
    <PortalGeometryPanel form={form} onChange={onChange} setGeomPart={setGeomPart}/>
    <div className="card">
      <div className="card-title">📐 Geometría del Túnel</div>
      <div className="form-grid">
        <Field label="Nombre del proyecto" osm={osm('project_name')} onClearOsm={clr('project_name')}><input type="text" value={form.project_name} onChange={e=>onChange("project_name",e.target.value)}/></Field>
        <Field label="ID del tubo" hint="Ej: T1, T2"><input type="text" value={form.tube_id} onChange={e=>onChange("tube_id",e.target.value)}/></Field>
        <Field label="Velocidad (km/h)" osm={osm('speed_kmh')} onClearOsm={clr('speed_kmh')}>
          <select value={form.speed_kmh} onChange={e=>onChange("speed_kmh",e.target.value)}>
            {[40,50,60,70,80,90,100,110,120].map(v=><option key={v} value={v}>{v} km/h</option>)}
          </select>
        </Field>
        <Field label="Longitud (m)" osm={osm('length_m')} onClearOsm={clr('length_m')}>
          <input type="number" min="10" max="10000" step="5" value={form.length_m} onChange={e=>onChange("length_m",e.target.value)}/>
          {lengthStatus&&(()=>{
            const cfg={
              critical:{bg:"#fff5f5",border:"#fca5a5",color:"#b91c1c",icon:"⛔",text:`Crítico: ${L.toFixed(0)} m < SD (${SD.toFixed(0)} m)`},
              warning: {bg:"#fffbeb",border:"#fcd34d",color:"#92400e",icon:"⚠️",text:`Corto: min. recomendado ${Lmin} m`},
              ok:      {bg:"#f0fdf4",border:"#86efac",color:"#166534",icon:"✓", text:`Suficiente (mín. ${Lmin} m)`},
              good:    {bg:"#f0fdf4",border:"#86efac",color:"#166534",icon:"✓✓",text:`Holgado. SD=${SD.toFixed(0)} m`},
            }[lengthStatus];
            return <div style={{marginTop:3,padding:"4px 7px",borderRadius:4,fontSize:".68rem",background:cfg.bg,border:`1px solid ${cfg.border}`,color:cfg.color}}>{cfg.icon} {cfg.text}</div>;
          })()}
        </Field>
        <Field label="Pendiente (%)" hint="Positivo = bajada" osm={osm('gradient_pct')} onClearOsm={clr('gradient_pct')}><input type="number" min="-8" max="8" step="0.5" value={form.gradient_pct} onChange={e=>onChange("gradient_pct",e.target.value)}/></Field>
        <Field label="Radio curvatura (m)" hint="Vacío si recto"><input type="number" min="100" max="99999" step="50" value={form.curvature_radius_m||""} onChange={e=>onChange("curvature_radius_m",e.target.value||null)} placeholder="—"/></Field>
        <Field label="Circulación" osm={osm('traffic_direction')} onClearOsm={clr('traffic_direction')}>
          <select value={form.traffic_direction} onChange={e=>onChange("traffic_direction",e.target.value)}>
            <option value="one_way">Un sentido</option><option value="two_way">Bidireccional</option>
          </select>
        </Field>
        <Field label="Nº de carriles" osm={osm('num_lanes')} onClearOsm={clr('num_lanes')}>
          <select value={form.num_lanes} onChange={e=>setGeomPart("num_lanes",e.target.value)}>
            {[1,2,3,4].map(n=><option key={n} value={n}>{n}</option>)}
          </select>
        </Field>
        <Field label="Ancho carril (m)"><input type="number" min="2.5" max="4.5" step="0.05" value={form.lane_width_m??3.5} onChange={e=>setGeomPart("lane_width_m",e.target.value)}/></Field>
        <Field label="Arcén izquierdo (m)" hint="0 = sin arcén"><input type="number" min="0" max="4" step="0.1" value={form.shoulder_left_m??0} onChange={e=>setGeomPart("shoulder_left_m",e.target.value)}/></Field>
        <Field label="Arcén derecho (m)" hint="0 = sin arcén"><input type="number" min="0" max="4" step="0.1" value={form.shoulder_right_m??0} onChange={e=>setGeomPart("shoulder_right_m",e.target.value)}/></Field>
        <Field label="Anchura interior (m)" hint="calzada + arcenes — CIE 140: mismo criterio que un carril" osm={osm('width_m')} onClearOsm={clr('width_m')}><input type="number" min="3" max="30" step="0.5" value={form.width_m} onChange={e=>onChange("width_m",e.target.value)}/></Field>
        <Field label="Altura libre en clave (m)" hint="Altura máxima libre de obstáculos en el centro del túnel" osm={osm('height_m')} onClearOsm={clr('height_m')}><input type="number" min="2.5" max="12" step="0.1" value={form.height_m} onChange={e=>onChange("height_m",e.target.value)}/></Field>
        <Field label="Forma de la sección">
          <select value={form.tunnel_shape||'horseshoe'} onChange={e=>onChange('tunnel_shape',e.target.value)} style={{width:'100%'}}>
            <option value="horseshoe">Herradura / Bóveda</option>
            <option value="circular">Circular (galería perforada)</option>
            <option value="rectangular">Rectangular (corte y cubierta)</option>
          </select>
        </Field>
        {(form.tunnel_shape||'horseshoe')==='horseshoe'&&(
          <Field label="Altura tramo recto (m)" hint="Desde la calzada hasta el arranque de la bóveda">
            <input type="number" min="0" max={parseFloat(form.height_m)||5} step="0.1"
              value={form.H_pared_m??3.0}
              onChange={e=>onChange('H_pared_m', parseFloat(e.target.value)||0)}/>
          </Field>
        )}
        {(form.tunnel_shape||'horseshoe')==='circular'&&(
          <Field label="Radio calculado (m)" hint="R = (W²/4 + H²) / (2H) — automático">
            <div style={{padding:'4px 6px',fontSize:'.75rem',color:'#64748b',fontStyle:'italic'}}>
              {(()=>{const W=parseFloat(form.width_m)||10,H=parseFloat(form.height_m)||5.5;
                const R=((W/2)**2+H**2)/(2*H);return `R = ${R.toFixed(2)} m`;})()}
            </div>
          </Field>
        )}
        <Field label="Pavimento (tabla CIE 144)">
          <select value={form.road_surface||'dark_asphalt'} onChange={e=>onChange("road_surface",e.target.value)}>
            <option value="dark_asphalt">Asfalto oscuro — R3</option>
            <option value="medium_asphalt">Asfalto medio — R2</option>
            <option value="light_asphalt">Asfalto claro — R1</option>
            <option value="concrete">Hormigón — C1</option>
            <option value="bright_concrete">Hormigón claro — C2</option>
          </select>
        </Field>
        {/* ── Reflectancias para radiosidad ── */}
        <div style={{gridColumn:'1/-1',borderTop:'1px solid var(--salvi-line)',paddingTop:6,marginTop:2}}>
          <div style={{fontSize:'.65rem',fontWeight:600,color:'var(--salvi-grey)',textTransform:'uppercase',letterSpacing:'.04em',marginBottom:6}}>Reflectancias (interreflexión)</div>
          <div style={{display:'grid',gridTemplateColumns:'1fr 1fr',gap:6}}>
            <Field label="ρ Paredes" hint="0.20–0.60"
              info="ρ = reflectancia, no absorción (0 = negro · 1 = espejo perfecto).<br><br>valores típicos (hormigón):<br>pintado blanco, limpio: 0.50–0.65<br>en bruto nuevo: 0.35–0.50<br>túnel en explotación: 0.20–0.40<br>muy sucio / grafiti: 0.10–0.20<br><br>recomendado: 0.40 (nuevo) · 0.25 (explotación)">
              <input type="number" min="0.05" max="0.90" step="0.05"
                value={form.rho_wall??0.40}
                onChange={e=>onChange('rho_wall',parseFloat(e.target.value)||0.40)}/>
            </Field>
            <Field label="ρ Techo" hint="0.05–0.50"
              info="ρ = reflectancia techo (0 = negro · 1 = espejo perfecto). el techo acumula hollín y polvo rápidamente.<br><br>valores típicos:<br>pintado blanco, nuevo: 0.50–0.65<br>hormigón sin pintar: 0.25–0.45<br>en explotación: 0.05–0.20<br>muy sucio / ennegrecido: 0.03–0.10<br><br>recomendado: 0.25 (nuevo) · 0.10 (explotación)">
              <input type="number" min="0.05" max="0.90" step="0.05"
                value={form.rho_ceiling??0.25}
                onChange={e=>onChange('rho_ceiling',parseFloat(e.target.value)||0.25)}/>
            </Field>
          </div>
        </div>
      </div>
    </div>
    </>
  );
}

function StepEnvironment({ form, onChange, osmFields, onClearOsm }) {
  const osm = (k) => !!osmFields?.has(k);
  const clr = (k) => () => onClearOsm && onClearOsm(k);
  const [taLoading, setTaLoading] = useState(false);
  const [taInfo, setTaInfo] = useState(null);   // {years:[y0,y1]} tras autocompletar
  const hasCoords = !!(parseFloat(form.lat) && parseFloat(form.lng));
  const autoFillTa = async () => {
    if(!hasCoords) return;
    setTaLoading(true); setTaInfo(null);
    try {
      const res = await fetch('/api/tunnel/climate-ta', {
        method:'POST', headers:{'Content-Type':'application/json'},
        body: JSON.stringify({ lat: parseFloat(form.lat), lng: parseFloat(form.lng) }),
      });
      const j = await res.json();
      if(j.success){
        onChange('ta_design_c', j.ta_mean_c);
        setTaInfo({ years: j.years });
      } else {
        alert('No se pudo obtener el clima: ' + (j.error||'error desconocido'));
      }
    } catch(err) {
      alert('Error de red al consultar el clima: ' + err.message);
    } finally {
      setTaLoading(false);
    }
  };
  return (
    <div className="card">
      <div className="card-title">🌄 Entorno</div>
      <div className="form-grid">
        <Field label="Orientación boca A (entrada)" osm={osm('portal_orientation')} onClearOsm={clr('portal_orientation')}>
          <select value={form.portal_orientation} onChange={e=>onChange("portal_orientation",e.target.value)}>
            {ORIENT_OPTIONS.map(o=><option key={o} value={o}>{o}</option>)}
          </select>
        </Field>
        {form.traffic_direction === 'two_way' && (
          <Field label="Orientación boca B (entrada opuesta)">
            <div style={{display:'flex',alignItems:'center',gap:8,padding:'5px 8px',
                         background:'var(--salvi-surface)',border:'1px solid var(--salvi-line)',
                         borderRadius:5,fontSize:'.78rem',color:'var(--salvi-grey)'}}>
              <span style={{fontSize:'1.1em'}}>
                {form.portal_orientation==='N'?'↓':form.portal_orientation==='S'?'↑':
                 form.portal_orientation==='E'?'←':form.portal_orientation==='W'?'→':
                 form.portal_orientation==='NE'?'↙':form.portal_orientation==='SW'?'↗':
                 form.portal_orientation==='SE'?'↖':form.portal_orientation==='NW'?'↘':'↔'}
              </span>
              <span>
                <strong>{OPPOSITE_ORI[form.portal_orientation]||'—'}</strong>
                {' · '}{ORIENT_LABEL[OPPOSITE_ORI[form.portal_orientation]]||''}
              </span>
              <span style={{marginLeft:'auto',fontSize:'.68rem',fontStyle:'italic'}}>calculado</span>
            </div>
          </Field>
        )}
        <Field label="Cielo de diseño">
          <select value={form.sky_condition} onChange={e=>onChange("sky_condition",e.target.value)}>
            <option value="clear">Despejado</option><option value="intermediate">Parcial</option><option value="overcast">Cubierto</option>
          </select>
        </Field>
        <Field label="Penetración luz diurna">
          <select value={form.daylight_penetration} onChange={e=>onChange("daylight_penetration",e.target.value)}>
            <option value="poor">Pobre</option><option value="good">Buena</option>
          </select>
        </Field>
        <Field label="Reflectancia paredes" hint="0.25–0.50"><input type="number" min="0.05" max="0.90" step="0.05" value={form.wall_reflectance} onChange={e=>onChange("wall_reflectance",e.target.value)}/></Field>
        <Field label="Método cálculo L20">
          <select value={form.l20_method} onChange={e=>onChange("l20_method",e.target.value)}>
            <option value="model">Modelo CIE 88</option><option value="table">Tabla CIE 88</option>
          </select>
        </Field>
        <Field label="Temperatura ambiente diseño (°C)" hint="Media anual — eficiencia LED, no seguridad"
          info="temperatura ambiente usada por el motor led para estimar la reducción media de eficiencia del led (flujo/vf dependen de ts = ta + δt térmico).<br><br>se usa la media anual del emplazamiento, no un máximo histórico: el interior del túnel está mucho más atemperado y estable que el exterior, y el objetivo aquí es la eficiencia media esperada, no un límite de seguridad térmica.<br><br>con coordenadas (lat/lng) cargadas puede autocompletarse desde datos climáticos históricos (open-meteo, media de los últimos 5 años).">
          <div style={{display:'flex',gap:6,alignItems:'center'}}>
            <input type="number" min="-10" max="45" step="0.5" style={{flex:1}}
              value={form.ta_design_c??20}
              onChange={e=>onChange("ta_design_c",parseFloat(e.target.value)||20)}/>
            <button type="button" className="btn-xs" disabled={!hasCoords||taLoading}
              title={hasCoords?'Autocompletar desde clima histórico del emplazamiento':'Necesita lat/lng (importar túnel desde el mapa OSM)'}
              onClick={autoFillTa}>
              {taLoading?'…':'🌡 Auto'}
            </button>
          </div>
          {taInfo && <div style={{fontSize:'.68rem',color:'var(--salvi-grey)',marginTop:3}}>
            Media {taInfo.years[0]}–{taInfo.years[1]} en ({parseFloat(form.lat).toFixed(3)}, {parseFloat(form.lng).toFixed(3)})
          </div>}
        </Field>
      </div>
      <div style={{marginTop:10}}>
        <div className="toggle-row">
          <label className="toggle"><input type="checkbox" checked={form.exit_visible} onChange={e=>onChange("exit_visible",e.target.checked)}/><span className="toggle-slider"></span></label>
          <span className="toggle-label">Salida visible desde SD</span>
        </div>
        <div className="toggle-row">
          <label className="toggle"><input type="checkbox" checked={form.illuminated_road} onChange={e=>onChange("illuminated_road",e.target.checked)}/><span className="toggle-slider"></span></label>
          <span className="toggle-label">
            Carretera exterior iluminada
            {osm('illuminated_road') && <span className="osm-badge" onClick={clr('illuminated_road')} title="Importado de OSM — clic para validar">🗺 OSM</span>}
          </span>
        </div>
      </div>
    </div>
  );
}

function StepTraffic({ form, onChange, osmFields, onClearOsm }) {
  const osm = (k) => !!osmFields?.has(k);
  const clr = (k) => () => onClearOsm && onClearOsm(k);
  // Anchura interior = n_carriles x ancho_carril + arcen_izq + arcen_der
  // (duplicado del mismo helper en StepGeometry — ver comentario allí).
  const setGeomPart = (key, val) => {
    onChange(key, val);
    const parts = { num_lanes: form.num_lanes, lane_width_m: form.lane_width_m,
                     shoulder_left_m: form.shoulder_left_m, shoulder_right_m: form.shoulder_right_m,
                     [key]: val };
    const w = (parseInt(parts.num_lanes)||2) * (parseFloat(parts.lane_width_m)||3.5)
              + (parseFloat(parts.shoulder_left_m)||0) + (parseFloat(parts.shoulder_right_m)||0);
    onChange('width_m', Math.round(w*100)/100);
  };

  /* ── Conversión IMD → veh/h ── */
  const imd   = parseFloat(form.imd)   || 0;
  const kPeak = parseFloat(form.k_peak || 0.10);
  const isTwoWay = form.traffic_direction === 'two_way';
  /* CIE 88: diseño para la hora 30ª. IMD total ambos sentidos.
     Tubo único bidireccional → todos los vehículos pasan por el tubo.
     Tubo sentido único → la mitad. */
  const vehHCalc = imd > 0 ? Math.round(imd * kPeak * (isTwoWay ? 1.0 : 0.5)) : 0;

  const applyIMD = () => {
    if (vehHCalc > 0) onChange("traffic_veh_h", vehHCalc);
  };

  return (
    <div>
      {/* ── IMD + enlace DGT ── */}
      <div className="card" style={{marginBottom:8}}>
        <div className="card-title" style={{display:"flex",alignItems:"center",justifyContent:"space-between"}}>
          <span>📊 IMD — Intensidad Media Diaria</span>
          <a href="https://aforos.dgt.es" target="_blank" rel="noopener noreferrer"
            style={{fontSize:".70rem",fontWeight:600,color:"var(--salvi-blue)",
              textDecoration:"none",padding:"2px 8px",border:"1px solid var(--salvi-blue)",
              borderRadius:4,whiteSpace:"nowrap"}}>
            🔗 Aforos DGT
          </a>
        </div>

        <div className="form-grid col-2" style={{marginBottom:8}}>
          <Field label="IMD (veh/día, ambos sentidos)">
            <input type="number" min="0" max="200000" step="500"
              value={form.imd||""} placeholder="ej. 15000"
              onChange={e=>onChange("imd", e.target.value)}/>
          </Field>
          <Field label="Factor k hora punta">
            <select value={form.k_peak||0.10} onChange={e=>onChange("k_peak",parseFloat(e.target.value))}>
              <option value={0.08}>0.08 — Carretera rural tranquila</option>
              <option value={0.10}>0.10 — Estándar CIE 88 (hora 30ª)</option>
              <option value={0.11}>0.11 — Carretera principal</option>
              <option value={0.12}>0.12 — Tráfico urbano intenso</option>
              <option value={0.14}>0.14 — Acceso urbano congestionado</option>
            </select>
          </Field>
        </div>

        {imd > 0 && (
          <div style={{display:"flex",alignItems:"center",gap:10,padding:"7px 10px",
            background:"var(--salvi-surface)",borderRadius:6,fontSize:".76rem"}}>
            <span style={{color:"var(--salvi-grey)"}}>
              {imd.toLocaleString('es')} × {kPeak}{isTwoWay ? "" : " ÷ 2"} =
            </span>
            <strong style={{fontSize:".88rem",color:"var(--salvi-blue)"}}>
              {vehHCalc.toLocaleString('es')} veh/h
            </strong>
            <span style={{color:"var(--salvi-grey)",fontSize:".68rem"}}>
              ({isTwoWay ? "tubo bidireccional" : "sentido único"})
            </span>
            <button
              onClick={applyIMD}
              style={{marginLeft:"auto",padding:"3px 12px",fontSize:".72rem",fontWeight:700,
                cursor:"pointer",borderRadius:4,background:"var(--salvi-blue)",
                color:"#fff",border:"none",whiteSpace:"nowrap"}}>
              ← Aplicar
            </button>
          </div>
        )}
        <p style={{fontSize:".67rem",color:"var(--salvi-grey)",marginTop:6,lineHeight:1.5}}>
          Consulta el aforo en <em>aforos.dgt.es</em> por código de carretera (N-xxx, A-xxx…).
          La IMD que publica DGT es el total ambos sentidos. El factor k convierte a hora punta (hora 30ª según CIE 88).
        </p>
      </div>

      {/* ── Parámetros de diseño ── */}
      <div className="card">
        <div className="card-title">🚗 Parámetros de diseño</div>
        <div className="form-grid col-3">
          <Field label="Tráfico diseño (veh/h)">
            <input type="number" min="50" max="5000" step="50"
              value={form.traffic_veh_h}
              onChange={e=>onChange("traffic_veh_h",e.target.value)}/>
          </Field>
          <Field label="Carriles" osm={osm('num_lanes')} onClearOsm={clr('num_lanes')}>
            <select value={form.num_lanes} onChange={e=>setGeomPart("num_lanes",e.target.value)}>
              {[1,2,3,4].map(n=><option key={n} value={n}>{n}</option>)}
            </select>
          </Field>
          <Field label="Método Lth">
            <select value={form.lth_method} onChange={e=>onChange("lth_method",e.target.value)}>
              <option value="k_factor">Factor k</option><option value="lseq">Lseq</option>
            </select>
          </Field>
        </div>
        <div style={{marginTop:10}}>
          <div className="toggle-row">
            <label className="toggle"><input type="checkbox" checked={form.has_pedestrians} onChange={e=>onChange("has_pedestrians",e.target.checked)}/><span className="toggle-slider"></span></label>
            <span className="toggle-label">Peatones o ciclistas</span>
          </div>
          <div className="toggle-row">
            <label className="toggle"><input type="checkbox" checked={form.profile_stepped} onChange={e=>onChange("profile_stepped",e.target.checked)}/><span className="toggle-slider"></span></label>
            <span className="toggle-label">Perfil escalonado en transición</span>
          </div>
          {form.profile_stepped&&(
            <div className="form-grid col-2" style={{marginTop:8}}>
              <Field label="Escalones en transición"><input type="number" min="2" max="8" step="1" value={form.n_steps} onChange={e=>onChange("n_steps",e.target.value)}/></Field>
            </div>
          )}
        </div>
      </div>

      {/* ── Distancia y tiempo de parada ─────────────────────────── */}
      <div className="card">
        <div className="card-title">🛑 Distancia y tiempo de parada <span style={{fontSize:'.65rem',fontWeight:400,color:'var(--salvi-grey)'}}>CIE 88:2004 §4.1</span></div>
        {(()=>{
          const v_kmh = parseFloat(form.speed_kmh)||80;
          const v_ms  = v_kmh/3.6;
          const g     = 9.81;
          const slope = parseFloat(form.gradient_pct)||0;   // >0 bajada (peor caso)
          /* μ automático según velocidad si el usuario no lo ha tocado */
          const mu_auto = v_kmh<=50?0.50:v_kmh<=70?0.45:v_kmh<=90?0.40:v_kmh<=110?0.35:0.30;
          const mu      = parseFloat(form.mu_friction)||mu_auto;
          const t_r     = parseFloat(form.t_reaction)||2.5;
          /* Denominador: pendiente positiva = bajada = resta capacidad de frenado */
          const denom   = Math.max(0.05, mu - slope/100);
          const d_stop  = v_ms*t_r + (v_ms*v_ms)/(2*g*denom);
          const t_stop  = t_r + v_ms/(g*denom);
          const fmt1 = n => n.toFixed(1);

          return(
            <div>
              <div className="form-grid col-2" style={{marginBottom:8}}>
                <div>
                  <label style={{fontSize:'.68rem',fontWeight:600,color:'var(--salvi-grey)',display:'block',marginBottom:3}}>
                    Coeficiente de rozamiento μ
                    <InfoTip content="μ — coeficiente de rozamiento rueda-pavimento. fricción longitudinal disponible para frenar (pavimento mojado, caso de diseño habitual).<br><br>valores orientativos según velocidad (cie 88 / normativa de trazado):<br>≤50 km/h: 0.50<br>60–70 km/h: 0.45<br>80–90 km/h: 0.40<br>100–110 km/h: 0.35<br>≥120 km/h: 0.30<br><br>el valor auto ya aplica esta tabla según la velocidad de diseño. redúcelo si el pavimento es especialmente deslizante o la pendiente es muy exigente; no hace falta tocarlo en el caso general."/>
                    <span style={{fontWeight:400,marginLeft:4,fontSize:'.62rem'}}>
                      (auto: {mu_auto} para {v_kmh} km/h)
                    </span>
                  </label>
                  <input type="number" min="0.15" max="0.65" step="0.01"
                    value={form.mu_friction||mu_auto}
                    onChange={e=>onChange("mu_friction", parseFloat(e.target.value)||mu_auto)}
                    style={{width:"100%"}}/>
                </div>
                <div>
                  <label style={{fontSize:'.68rem',fontWeight:600,color:'var(--salvi-grey)',display:'block',marginBottom:3}}>
                    Tiempo de reacción t_r (s)
                    <InfoTip content="t_r — tiempo de reacción del conductor. tiempo entre percibir un obstáculo y empezar a frenar (percepción + decisión + accionamiento del freno).<br><br>valores orientativos:<br>2.0 s: conductor atento, condiciones favorables (mínimo normativo habitual)<br>2.5 s: valor estándar de diseño (cie 88 / trazado de carreteras) — recomendado si no hay motivo para desviarse<br>3.0–4.0 s: condiciones adversas (baja visibilidad, tráfico denso, fatiga esperable)<br><br>un t_r mayor alarga la distancia de parada exigida (sd) y por tanto la longitud mínima de la zona de umbral."/>
                  </label>
                  <input type="number" min="1.0" max="4.0" step="0.5"
                    value={form.t_reaction||2.5}
                    onChange={e=>onChange("t_reaction", parseFloat(e.target.value)||2.5)}
                    style={{width:"100%"}}/>
                </div>
              </div>

              {/* Resultados */}
              <div style={{display:"grid",gridTemplateColumns:"1fr 1fr 1fr",gap:8,marginBottom:8}}>
                <div style={{background:"var(--salvi-surface)",borderRadius:6,padding:"8px 10px",
                    border:"1px solid var(--salvi-line)",textAlign:"center"}}>
                  <div style={{fontSize:".6rem",color:"var(--salvi-grey)",fontWeight:600,
                      textTransform:"uppercase",letterSpacing:".06em",marginBottom:2}}>Distancia de parada</div>
                  <div style={{fontSize:"1.1rem",fontWeight:700,color:"#1e40af"}}>{fmt1(d_stop)} m</div>
                  <div style={{fontSize:".6rem",color:"#94a3b8",marginTop:1}}>
                    {fmt1(v_ms*t_r)} m reacción + {fmt1((v_ms*v_ms)/(2*g*denom))} m frenado
                  </div>
                </div>
                <div style={{background:"var(--salvi-surface)",borderRadius:6,padding:"8px 10px",
                    border:"1px solid var(--salvi-line)",textAlign:"center"}}>
                  <div style={{fontSize:".6rem",color:"var(--salvi-grey)",fontWeight:600,
                      textTransform:"uppercase",letterSpacing:".06em",marginBottom:2}}>Tiempo de parada</div>
                  <div style={{fontSize:"1.1rem",fontWeight:700,color:"#1e40af"}}>{fmt1(t_stop)} s</div>
                  <div style={{fontSize:".6rem",color:"#94a3b8",marginTop:1}}>
                    {fmt1(t_r)} s reacción + {fmt1(t_stop-t_r)} s frenado
                  </div>
                </div>
                <div style={{background:"var(--salvi-surface)",borderRadius:6,padding:"8px 10px",
                    border:"1px solid var(--salvi-line)",textAlign:"center"}}>
                  <div style={{fontSize:".6rem",color:"var(--salvi-grey)",fontWeight:600,
                      textTransform:"uppercase",letterSpacing:".06em",marginBottom:2}}>Long. mín. zona umbral</div>
                  <div style={{fontSize:"1.1rem",fontWeight:700,color:"#059669"}}>{fmt1(d_stop)} m</div>
                  <div style={{fontSize:".6rem",color:"#94a3b8",marginTop:1}}>CIE 88 §4.1 — mín. = d_parada</div>
                </div>
              </div>

              <div style={{fontSize:".62rem",color:"var(--salvi-grey)",lineHeight:1.5}}>
                Peor caso: {slope>0?`bajada ${slope}%`:slope<0?`subida ${Math.abs(slope)}%`:"sin pendiente"}
                {" "}· μ={mu} (pavimento {mu>=0.45?"seco":"húmedo"})
                {" "}· fórmula: d = v·t_r + v²/(2g·(μ{slope>0?" − i":" + |i|"}))
              </div>
            </div>
          );
        })()}
      </div>
    </div>
  );
}

// ══════════════════════════════════════════════════════════════════
// PortalGeometryPanel — geometria de boca por imagen (vision de Claude)
// Ver Especificacion_implementacion_geometria_tuneles_desde_imagenes.docx
// ══════════════════════════════════════════════════════════════════
const PORTAL_FIELD_LABELS = {
  num_lanes:         { label: "Nº de carriles",        unit: "" },
  lane_width_m:      { label: "Ancho de carril",        unit: "m" },
  shoulder_left_m:   { label: "Arcén izquierdo",        unit: "m" },
  shoulder_right_m:  { label: "Arcén derecho",          unit: "m" },
  width_m:           { label: "Anchura interior (suelo)", unit: "m" },
  tunnel_shape:      { label: "Tipo de sección",        unit: "" },
  height_m:          { label: "Altura máxima interior", unit: "m" },
  H_pared_m:         { label: "Altura de hastiales",    unit: "m" },
  mounting_height_m: { label: "Altura montaje luminarias", unit: "m" },
  num_luminaire_rows:{ label: "Nº filas de luminarias", unit: "" },
  wall_offset_m:     { label: "Distancia luminaria-hastial", unit: "m" },
  axis_offset_m:     { label: "Desplazamiento eje calzada/túnel", unit: "m" },
  sidewalk_present:  { label: "Acera / paso técnico",   unit: "" },
  sidewalk_width_m:  { label: "Ancho acera",            unit: "m" },
};
const PORTAL_CRITICAL_FIELDS = ["num_lanes","lane_width_m","shoulder_left_m","shoulder_right_m",
  "width_m","tunnel_shape","height_m","H_pared_m","mounting_height_m","num_luminaire_rows","wall_offset_m"];

function PortalGeometryPanel({ form, onChange, setGeomPart }) {
  const [mode, setMode]           = useState(form.portal_mode || "manual");
  const [images, setImages]       = useState([]); // [{file, previewUrl}]
  const [laneRef, setLaneRef]     = useState(form.portal_lane_ref_m || 3.5);
  const [analyzing, setAnalyzing] = useState(false);
  const [error, setError]         = useState(null);
  const [warnings, setWarnings]   = useState([]);
  const geo = form.portal_geometry || {};

  const setMode2 = (m) => { setMode(m); onChange("portal_mode", m); };

  const onFilesChosen = (e) => {
    const files = Array.from(e.target.files || []).slice(0, 2);
    const withPreviews = files.map(f => ({ file: f, previewUrl: URL.createObjectURL(f) }));
    setImages(withPreviews);
  };

  const analyze = async () => {
    if (!images.length) return;
    setAnalyzing(true); setError(null); setWarnings([]);
    onChange("portal_lane_ref_m", laneRef);
    try {
      const fd = new FormData();
      images.forEach(im => fd.append("images", im.file));
      fd.append("lane_width_ref_m", String(laneRef));
      const res = await fetch("/api/tunnel/portal-analyze", { method: "POST", body: fd });
      const data = await res.json();
      if (!data.success) { setError(data.error || "Error desconocido en el análisis."); return; }
      const nextGeo = {};
      Object.entries(data.fields).forEach(([key, f]) => {
        nextGeo[key] = { ...f, status: "proposed", originalValue: f.value };
      });
      onChange("portal_geometry", nextGeo);
      setWarnings(data.warnings || []);
    } catch (err) {
      setError("Fallo de red al llamar al análisis: " + err.message);
    } finally {
      setAnalyzing(false);
    }
  };

  const updateField = (key, patch) => {
    const next = { ...geo, [key]: { ...geo[key], ...patch } };
    onChange("portal_geometry", next);
  };
  const editValue = (key, val) => updateField(key, { value: val, status: "proposed" });
  const validateField = (key) => updateField(key, { status: "validated" });
  const restoreField = (key) => updateField(key, { value: geo[key]?.originalValue, status: "proposed" });

  const applyToForm = () => {
    const g = key => geo[key]?.value;
    if (g("num_lanes") != null)        setGeomPart("num_lanes", g("num_lanes"));
    if (g("lane_width_m") != null)     setGeomPart("lane_width_m", g("lane_width_m"));
    if (g("shoulder_left_m") != null)  setGeomPart("shoulder_left_m", g("shoulder_left_m"));
    if (g("shoulder_right_m") != null) setGeomPart("shoulder_right_m", g("shoulder_right_m"));
    if (g("height_m") != null)         onChange("height_m", g("height_m"));
    if (g("H_pared_m") != null)        onChange("H_pared_m", g("H_pared_m"));
    if (["horseshoe","circular","rectangular"].includes(g("tunnel_shape")))
      onChange("tunnel_shape", g("tunnel_shape"));
    const lumPatch = {};
    if (g("mounting_height_m") != null) lumPatch.mounting_height_m = g("mounting_height_m");
    if (g("wall_offset_m") != null)     lumPatch.wall_offset_m     = g("wall_offset_m");
    if (Object.keys(lumPatch).length)
      onChange("lum_config", { ...(form.lum_config||{}), ...lumPatch });
  };

  const validateAll = () => {
    const next = {};
    Object.entries(geo).forEach(([k, f]) => { next[k] = { ...f, status: "validated" }; });
    onChange("portal_geometry", next);
    applyToForm();
  };

  const hasProposal = Object.keys(geo).length > 0;
  const criticalPending = PORTAL_CRITICAL_FIELDS.filter(k => geo[k] && geo[k].value != null && geo[k].status !== "validated");
  const confColor = c => c === "alta" ? "#166534" : c === "media" ? "#92400e" : "#b91c1c";

  return (
    <div className="card">
      <div className="card-title">📷 Geometría de boca por imagen</div>
      <div style={{display:'flex',gap:8,marginBottom:10}}>
        {[["manual","Manual (formulario)"],["image","Desde imagen"]].map(([v,l])=>(
          <button key={v} onClick={()=>setMode2(v)}
            style={{padding:'5px 12px',fontSize:'.7rem',fontWeight:600,cursor:'pointer',borderRadius:6,
                    border:'1px solid var(--salvi-line)',
                    background:mode===v?'var(--salvi-black)':'#fff',
                    color:mode===v?'#fff':'var(--salvi-black)'}}>
            {l}
          </button>
        ))}
      </div>

      {mode==='image' && (
        <div>
          <div style={{fontSize:'.68rem',color:'var(--salvi-grey)',marginBottom:8,lineHeight:1.5}}>
            Sube 1-2 fotos de la misma boca (frontal, sin zoom digital). El sistema analiza la imagen
            con IA de visión y propone la geometría — todos los valores quedan como <strong>Propuestos</strong> hasta
            que los revises y valides. La captura automática desde Street View se añadirá en una fase posterior.
          </div>
          <div className="form-grid col-2" style={{marginBottom:10}}>
            <Field label="Imágenes de la boca (máx. 2)">
              <input type="file" accept="image/*" multiple onChange={onFilesChosen}/>
            </Field>
            <Field label="Ancho carril de referencia (m)" hint="Confirma el ancho real del carril visible en la imagen">
              <input type="number" min="2.5" max="4.5" step="0.05" value={laneRef}
                onChange={e=>setLaneRef(parseFloat(e.target.value)||3.5)}/>
            </Field>
          </div>
          {images.length>0 && (
            <div style={{display:'flex',gap:8,marginBottom:10,flexWrap:'wrap'}}>
              {images.map((im,i)=>(
                <img key={i} src={im.previewUrl} alt={`boca ${i+1}`}
                  style={{width:160,height:110,objectFit:'cover',borderRadius:6,border:'1px solid var(--salvi-line)'}}/>
              ))}
            </div>
          )}
          <button onClick={analyze} disabled={!images.length||analyzing}
            style={{padding:'7px 16px',fontSize:'.72rem',fontWeight:600,cursor:images.length?'pointer':'not-allowed',
                    borderRadius:6,border:'1px solid var(--salvi-line)',
                    background:analyzing?'#f1f5f9':'var(--salvi-black)',
                    color:analyzing?'var(--salvi-grey)':'#fff'}}>
            {analyzing?'⏳ Analizando…':'🔍 Analizar geometría'}
          </button>
          {error && (
            <div style={{marginTop:10,padding:'8px 10px',background:'#fef2f2',border:'1px solid #fecaca',
                         borderRadius:6,fontSize:'.68rem',color:'#b91c1c',whiteSpace:'pre-wrap'}}>
              ⚠️ {error}
            </div>
          )}
          {warnings.length>0 && (
            <div style={{marginTop:10,padding:'8px 10px',background:'#fffbeb',border:'1px solid #fde68a',
                         borderRadius:6,fontSize:'.68rem',color:'#92400e'}}>
              {warnings.map((w,i)=><div key={i}>⚠️ {w}</div>)}
            </div>
          )}

          {hasProposal && (
            <div style={{marginTop:14}}>
              <div style={{display:'flex',justifyContent:'space-between',alignItems:'center',marginBottom:6}}>
                <div style={{fontSize:'.68rem',fontWeight:700,color:'var(--salvi-grey)',
                    textTransform:'uppercase',letterSpacing:'.06em'}}>Propuesta de geometría</div>
                <button onClick={validateAll}
                  style={{padding:'5px 12px',fontSize:'.68rem',fontWeight:600,cursor:'pointer',borderRadius:6,
                          border:'1px solid #166534',background:'#f0fdf4',color:'#166534'}}>
                  ✓ Validar toda la geometría
                </button>
              </div>
              <div style={{overflowX:'auto',border:'1px solid var(--salvi-line)',borderRadius:6}}>
                <table style={{width:'100%',borderCollapse:'collapse',fontSize:'.68rem'}}>
                  <thead style={{background:'#f8fafc'}}>
                    <tr>
                      {['Campo','Valor','Confianza','Estado','Acciones'].map(h=>(
                        <th key={h} style={{padding:'5px 8px',textAlign:'left',borderBottom:'2px solid var(--salvi-line)',
                            color:'var(--salvi-grey)',fontWeight:700}}>{h}</th>
                      ))}
                    </tr>
                  </thead>
                  <tbody>
                    {Object.entries(PORTAL_FIELD_LABELS).map(([key,meta])=>{
                      const f = geo[key]; if(!f) return null;
                      const validated = f.status==='validated';
                      return (
                        <tr key={key} style={{borderBottom:'1px solid #f1f5f9'}}>
                          <td style={{padding:'4px 8px',fontWeight:600}} title={f.reasoning||''}>{meta.label}</td>
                          <td style={{padding:'4px 8px'}}>
                            {f.value==null ? <span style={{color:'#94a3b8'}}>— sin dato —</span> :
                              typeof f.value==='boolean' ? (f.value?'Sí':'No') :
                              key==='tunnel_shape' ?
                                <select value={f.value} onChange={e=>editValue(key,e.target.value)}>
                                  <option value="horseshoe">Herradura</option>
                                  <option value="circular">Circular</option>
                                  <option value="rectangular">Rectangular</option>
                                </select> :
                              <input type="number" step="0.05" value={f.value}
                                onChange={e=>editValue(key,parseFloat(e.target.value))}
                                style={{width:80}}/>
                            }
                            {meta.unit && f.value!=null && typeof f.value!=='boolean' && <span style={{marginLeft:4,color:'#94a3b8'}}>{meta.unit}</span>}
                          </td>
                          <td style={{padding:'4px 8px',color:confColor(f.confidence),fontWeight:600,textTransform:'capitalize'}}>
                            {f.confidence||'—'}
                          </td>
                          <td style={{padding:'4px 8px'}}>
                            <span style={{padding:'1px 7px',borderRadius:10,fontSize:'.62rem',fontWeight:700,
                                background:validated?'#f0fdf4':'#fffbeb',color:validated?'#166534':'#92400e'}}>
                              {validated?'Validado':'Propuesto'}
                            </span>
                          </td>
                          <td style={{padding:'4px 8px',whiteSpace:'nowrap'}}>
                            {!validated && f.value!=null && (
                              <button onClick={()=>validateField(key)}
                                style={{fontSize:'.62rem',padding:'2px 6px',marginRight:4,cursor:'pointer',
                                        border:'1px solid #166534',borderRadius:4,background:'#fff',color:'#166534'}}>Validar</button>
                            )}
                            <button onClick={()=>restoreField(key)}
                              style={{fontSize:'.62rem',padding:'2px 6px',cursor:'pointer',
                                      border:'1px solid var(--salvi-line)',borderRadius:4,background:'#fff',color:'var(--salvi-grey)'}}>Restaurar</button>
                          </td>
                        </tr>
                      );
                    })}
                  </tbody>
                </table>
              </div>
              {criticalPending.length>0 && (
                <div style={{marginTop:8,fontSize:'.65rem',color:'#92400e'}}>
                  ⚠️ {criticalPending.length} campo(s) crítico(s) aún sin validar — revísalos antes de continuar al cálculo.
                </div>
              )}
            </div>
          )}
        </div>
      )}
    </div>
  );
}

function ZoneLayoutBar({ zones, tunnelLength }) {
  if (!zones || !tunnelLength) return null;
  const ZONE_META = {
    access:      {label:"Acceso",     bg:"#f0f0f0",border:"#aaa",   txt:"#555"},
    threshold:   {label:"Umbral A",   bg:"#fff3cd",border:"#e8a000",txt:"#7a4800"},
    transition:  {label:"Trans. A",   bg:"#cff4fc",border:"#0891b2",txt:"#0c4a6e"},
    interior:    {label:"Interior",   bg:"#d1fae5",border:"#059669",txt:"#065f46"},
    transition_b:{label:"Trans. B",   bg:"#bae6fd",border:"#0284c7",txt:"#0c4a6e"},
    threshold_b: {label:"Umbral B",   bg:"#fef9c3",border:"#ca8a04",txt:"#7a4800"},
    exit:        {label:"Salida",     bg:"#ede9fe",border:"#7c3aed",txt:"#4c1d95"},
    parting:     {label:"Parting",    bg:"#f0f0f0",border:"#aaa",   txt:"#555"},
  };
  const SD=zones.threshold?zones.threshold.s_end:0;
  const totalSpan=tunnelLength+SD*2; const spanStart=-SD;
  const pct=(s)=>((s-spanStart)/totalSpan*100).toFixed(3)+"%";
  const pctW=(len)=>(len/totalSpan*100).toFixed(3)+"%";
  /* Ordenar por s_start — funciona tanto para sentido único como bidireccional */
  const visibleZones=Object.keys(zones).filter(k=>zones[k]).sort((a,b)=>zones[a].s_start-zones[b].s_start);
  const isTruncated=(z)=>z.description&&z.description.includes('TRUNCADA');
  return (
    <div style={{marginBottom:12}}>
      <div style={{position:"relative",height:48,borderRadius:6,overflow:"hidden",border:"1px solid var(--salvi-line)",background:"var(--salvi-surface)"}}>
        {visibleZones.map(key=>{
          const z=zones[key]; const meta=ZONE_META[key]||ZONE_META.access; const trunc=isTruncated(z);
          return (
            <div key={key} title={`${meta.label}: ${z.s_start.toFixed(0)}–${z.s_end.toFixed(0)} m`}
              style={{position:"absolute",left:pct(z.s_start),width:pctW(z.length),top:0,bottom:0,
                      background:trunc?"#fef2f2":meta.bg,borderRight:`2px solid ${trunc?"#ef4444":meta.border}`,
                      borderLeft:key===visibleZones[0]?`2px solid ${meta.border}`:"none",
                      display:"flex",alignItems:"center",justifyContent:"center",overflow:"hidden",
                      backgroundImage:trunc?"repeating-linear-gradient(45deg,transparent,transparent 4px,rgba(239,68,68,.12) 4px,rgba(239,68,68,.12) 8px)":"none"}}>
              <div style={{textAlign:"center",lineHeight:1.2,padding:"0 3px"}}>
                <div style={{fontSize:".60rem",fontWeight:700,color:trunc?"#b91c1c":meta.txt,whiteSpace:"nowrap",overflow:"hidden",textOverflow:"ellipsis",maxWidth:"100%"}}>{trunc?"⚠️ ":""}{meta.label}</div>
                <div style={{fontSize:".56rem",color:trunc?"#b91c1c":meta.txt,opacity:.85}}>{z.length.toFixed(0)} m</div>
              </div>
            </div>
          );
        })}
        {SD>0&&<div style={{position:"absolute",left:pct(0),top:0,bottom:0,width:2,background:"var(--salvi-black)",zIndex:2}}/>}
        <div style={{position:"absolute",left:pct(tunnelLength),top:0,bottom:0,width:2,background:"var(--salvi-black)",zIndex:2}}/>
      </div>
      <div style={{position:"relative",height:14,marginTop:2}}>
        {[0,tunnelLength*0.25,tunnelLength*0.5,tunnelLength*0.75,tunnelLength].map(s=>(
          <span key={s} style={{position:"absolute",left:pct(s),transform:"translateX(-50%)",fontSize:".58rem",color:"var(--salvi-grey)"}}>{s.toFixed(0)}m</span>
        ))}
      </div>
    </div>
  );
}

function StepResults({ result, showChart = true }) {
  if (!result) return <Alert type="info">Ejecuta el cálculo primero.</Alert>;
  if (!result.success) {
    return <div>{_asArr(result.errors).map((e,i)=><Alert key={i} type="danger"><strong>Error:</strong> {e}</Alert>)}</div>;
  }
  const { summary, classification, zones, validation, chart } = result;
  return (
    <div>
      {result.warnings&&result.warnings.length>0&&result.warnings.map((w,i)=><Alert key={i} type="warning">⚠️ {w}</Alert>)}
      {validation&&!validation.valid&&validation.errors.map((e,i)=><Alert key={i} type="danger">❌ {e}</Alert>)}
      {validation&&validation.valid&&<Alert type="success">✅ Perfil longitudinal válido según CIE 88:2004</Alert>}

      {(() => {
        const isBidi = result.lth?.Lth_b != null && result.lth?.Lth_b !== summary.Lth;
        if (!isBidi) {
          return (
            <div className="kpi-grid">
              <KpiCard label="Velocidad" value={summary.speed_kmh} unit="km/h"/>
              <KpiCard label="SD" value={summary.SD_m} unit="m"/>
              <KpiCard label="L₂₀" value={summary.L20} unit="cd/m²"/>
              <KpiCard label="Lth" value={summary.Lth} unit="cd/m²" highlight/>
              <KpiCard label="Lin" value={summary.Lin} unit="cd/m²"/>
              <KpiCard label="L noche" value={summary.L_night} unit="cd/m²"/>
              <KpiCard label="Factor k" value={summary.k_factor} unit="Lth/L20"/>
              <KpiCard label="qc" value={summary.qc} unit="m²·sr/lm"/>
            </div>
          );
        }
        return (
          <React.Fragment>
            <div className="kpi-grid">
              <KpiCard label="Velocidad" value={summary.speed_kmh} unit="km/h"/>
              <KpiCard label="Lin" value={summary.Lin} unit="cd/m²"/>
              <KpiCard label="L noche" value={summary.L_night} unit="cd/m²"/>
              <KpiCard label="Factor k" value={summary.k_factor} unit="Lth/L20"/>
              <KpiCard label="qc" value={summary.qc} unit="m²·sr/lm"/>
            </div>
            <div style={{display:"flex", gap:12, marginTop:8, flexWrap:"wrap"}}>
              <div style={{flex:"1 1 260px"}}>
                <div style={{fontSize:".72rem", fontWeight:700, marginBottom:4, opacity:.65}}>
                  ← PORTAL A
                </div>
                <div className="kpi-grid">
                  <KpiCard label="SD" value={summary.SD_m} unit="m"/>
                  <KpiCard label="L₂₀" value={summary.L20} unit="cd/m²"/>
                  <KpiCard label="Lth" value={summary.Lth} unit="cd/m²" highlight/>
                </div>
              </div>
              <div style={{flex:"1 1 260px"}}>
                <div style={{fontSize:".72rem", fontWeight:700, marginBottom:4, opacity:.65, textAlign:"right"}}>
                  PORTAL B →
                </div>
                <div className="kpi-grid">
                  <KpiCard label="SD" value={result.lth?.SD_b_m ?? summary.SD_m} unit="m"/>
                  <KpiCard label="L₂₀" value={result.lth?.L20_b ?? summary.L20} unit="cd/m²"/>
                  <KpiCard label="Lth" value={result.lth?.Lth_b ?? summary.Lth} unit="cd/m²" highlight/>
                </div>
              </div>
            </div>
          </React.Fragment>
        );
      })()}

      {showChart&&(
        <div className="card">
          <div className="card-title">📈 Perfil Longitudinal de Luminancia</div>
          <ProfileChart chartData={chart} tunnelLength={summary.length_m} Lth={summary.Lth} Lin={summary.Lin} zones={zones}/>
        </div>
      )}

      <div className="card">
        <div className="card-title">🏷️ Clasificación CIE 88:2004</div>
        <div style={{display:"flex",gap:8,flexWrap:"wrap",marginBottom:10}}>
          <span className={`cls-badge cls-${classification.optical==='optically_long'?'long':'short'}`}>
            {classification.optical==='optically_long'?'🔴 Largo':'🟢 Corto'}
          </span>
          <span className={`cls-badge cls-${classification.daylighting==='normal'?'long':classification.daylighting==='none'?'short':'normal'}`}>
            Ilum: {classification.daylighting}
          </span>
          <span style={{fontSize:".75rem",color:"var(--salvi-grey)",alignSelf:"center"}}>{classification.geometric}</span>
        </div>
        <p style={{fontSize:".80rem",color:"var(--salvi-grey)",lineHeight:1.5}}>{classification.justification}</p>
      </div>

      {(() => {
        /* Etiquetas legibles por clave de zona (distingue Portal A / B) */
        const ZONE_KEY_LABELS = {
          access:       'Acceso',
          threshold:    'Umbral',
          transition:   'Transición',
          interior:     'Interior',
          transition_b: 'Transición B',
          threshold_b:  'Umbral B',
          exit:         'Salida',
          parting:      'Post-salida',
        };
        /* Colores de fondo por clave */
        const ZONE_KEY_BG = {
          access:'#fdecea', threshold:'#fff8e1', transition:'#e0f7fa',
          interior:'#e8f5e9', transition_b:'#cce5ff', threshold_b:'#fff3cd',
          exit:'#f3e5f5', parting:'#fdecea',
        };
        /* Ordenar por posición s_start para mostrar orden geográfico */
        const sortedZones = Object.entries(zones)
          .sort(([,a],[,b]) => a.s_start - b.s_start);

        /* Detectar si hay zonas B (bidireccional) */
        const hasBPortal = zones.threshold_b || zones.transition_b;

        return (
          <div className="card">
            <div className="card-title">📏 Zonas Normativas CIE 88</div>
            <div style={{overflowX:"auto"}}>
              <table className="result-table">
                <thead>
                  <tr>
                    <th>Zona</th><th>Inicio (m)</th><th>Fin (m)</th>
                    <th>Longitud (m)</th><th>L inicio</th><th>L fin</th><th>L mín. req.</th>
                  </tr>
                </thead>
                <tbody>
                  {sortedZones.map(([key, z], i) => {
                    const bg  = ZONE_KEY_BG[key] || '#fff';
                    const lbl = ZONE_KEY_LABELS[key] || key;
                    /* Separador visual antes de las zonas del Portal B */
                    const isFirstB = hasBPortal && (key === 'transition_b');
                    return (
                      <React.Fragment key={key}>
                        {isFirstB && (
                          <tr>
                            <td colSpan={7} style={{background:'#f0f0f0',textAlign:'center',
                              fontSize:'.72rem',color:'#666',padding:'4px',fontWeight:600,
                              borderTop:'2px dashed #bbb'}}>
                              ← Portal B (espejo CIE 88)
                            </td>
                          </tr>
                        )}
                        <tr style={{background:bg}}>
                          <td>
                            <span style={{display:'inline-block',padding:'2px 8px',borderRadius:4,
                              background:bg,border:'1px solid rgba(0,0,0,.12)',
                              fontWeight:700,fontSize:'.75rem',color:'#333'}}>
                              {lbl}
                            </span>
                          </td>
                          <td>{z.s_start.toFixed(1)}</td>
                          <td>{z.s_end.toFixed(1)}</td>
                          <td><strong>{z.length.toFixed(1)}</strong></td>
                          <td>{z.L_start.toFixed(2)}</td>
                          <td>{z.L_end.toFixed(2)}</td>
                          <td style={{fontWeight:600}}>{z.L_min_required.toFixed(2)}</td>
                        </tr>
                      </React.Fragment>
                    );
                  })}
                </tbody>
              </table>
            </div>
          </div>
        );
      })()}

      <div className="card">
        <div className="card-title">✅ Criterios de Calidad CIE 88</div>
        <Alert type="info">Uo, Ul, TI y ratio paredes requieren cálculo fotométrico completo con LDT.</Alert>
        <table className="result-table" style={{marginTop:8}}>
          <thead><tr><th>Criterio</th><th>Norma</th><th>Estado</th></tr></thead>
          <tbody>
            <tr><td>Uniformidad Uo</td><td>≥ 0.40</td><td><span style={{color:"var(--salvi-grey)"}}>Requiere LDT</span></td></tr>
            <tr><td>Uniformidad Ul</td><td>≥ 0.60</td><td><span style={{color:"var(--salvi-grey)"}}>Requiere LDT</span></td></tr>
            <tr><td>Deslumbramiento TI</td><td>≤ 15 %</td><td><span style={{color:"var(--salvi-grey)"}}>Requiere LDT</span></td></tr>
            <tr><td>Ratio pared/calzada</td><td>≥ 0.60</td><td><span style={{color:"var(--salvi-grey)"}}>Requiere LDT</span></td></tr>
            <tr><td>Perfil longitudinal</td><td>CIE 88:2004</td>
              <td>{validation&&validation.valid?<span style={{color:"var(--success)"}}>✅ Cumple</span>:<span style={{color:"var(--danger)"}}>❌ Revisar</span>}</td>
            </tr>
          </tbody>
        </table>
      </div>
    </div>
  );
}

const ROAD_SURFACES = {
  dark_asphalt:   {label:"Asfalto oscuro (R3)",rho:0.065},
  medium_asphalt: {label:"Asfalto medio (R2)",rho:0.085},
  light_asphalt:  {label:"Asfalto claro (R1)",rho:0.105},
  concrete:       {label:"Hormigón (C1/C2)",rho:0.140},
  bright_concrete:{label:"Hormigón claro",rho:0.165},
};
const ARRANGEMENTS = {
  central_single:   "Fila central única (eje del túnel)",
  central_offset:   "Fila central desplazada del eje",
  central_double:   "Doble fila central",
  lateral_left:     "Lateral izquierda (sentido circulación)",
  lateral_right:    "Lateral derecha (sentido circulación)",
  bilateral_sym:    "Bilateral simétrico (frente a frente)",
  bilateral_stag:   "Bilateral en tresbolillo",
};
const ZONE_BG_LUM = { threshold:"#fff8e1", transition:"#e0f7fa", interior:"#e8f5e9", exit:"#f3e5f5", threshold_b:"#fff3cd", transition_b:"#cce5ff" };

const DEFAULT_LUM_CONFIG = {
  I_max_mA: 500,
  cct: "4000K",
  optic: "auto",
  mounting_height_m: 4.5,
  wall_offset_m: 0.30,
  axis_offset_m: 0.30,
  arrangement: "central_single",
  maintenance_factor: 0.70,
  road_surface: "dark_asphalt",
  // Parámetros optimizador
  U0_obj:    0.40,
  Ul_obj:    0.60,
  I_min_pct: 30,       // % (30 → 30 % de 350 mA = 105 mA)
  tilt_max:  20,       // grados
  d_fixed:   "",       // vacío = auto; número = modo retrofit
  d_min:     0.8,      // m — espaciado mínimo entre luminarias (def 0.8 m)
  n_transition_subzones: 1,  // 1–10 — nº de sub-tipologías (d/óptica propias) en la zona de transición
};



/* ══════════════════════════════════════════════════════════════════
   TunnelLuminanceLayout
   Perfil CIE 88 (curva requerida) + curva instalada + layout luminarias
   ══════════════════════════════════════════════════════════════════ */
function TunnelLuminanceLayout({ result, lumResult, photoResult }) {
  const [tip, setTip] = React.useState(null);
  if (!result?.chart?.L_required || !Array.isArray(result.chart.L_required)) return null;
  if (!lumResult?.zones?.length) return null;

  const chart = result.chart;
  const L_m   = result.summary.length_m;
  const zones = lumResult.zones || [];

  // ── SVG layout ────────────────────────────────────────────────────────────
  const W=900, ML=54, MR=18, MT=14, MB=34;
  const CW = W - ML - MR;
  const HP = 200;   // luminance profile height
  const HS = 62;    // luminaire strip height
  const GAP = 22;
  const HT = MT + HP + GAP + HS + MB;

  const xS = s => ML + (s / L_m) * CW;

  // Y scale: max L from CIE 88 profile (inside tunnel)
  const validLs = chart.L_required.filter((_,i) =>
    chart.s[i] >= 0 && chart.s[i] <= L_m && chart.L_required[i] > 0);
  const maxL = (validLs.length ? Math.max(...validLs) : 100) * 1.15;
  const yL = L => MT + HP - Math.max(0, Math.min(1, L / maxL)) * HP;

  // ── CIE 88 required curve ─────────────────────────────────────────────────
  let reqD = '';
  chart.s.forEach((s, i) => {
    if (s < 0 || s > L_m) return;
    const L = chart.L_required[i];
    if (L <= 0) return;
    reqD += `${reqD ? 'L' : 'M'}${xS(s).toFixed(1)},${yL(L).toFixed(1)} `;
  });

  // ── Achieved L curve ──────────────────────────────────────────────────────
  // For uniform zones  → flat step at L_estimated (s_start … s_end)
  // For transition zones → polyline through each setpoint's (s, L_req)
  // This shows that the installed curve follows CIE 88 exactly in transition.
  const achPts = [];  // {s, L, isSP}  (isSP = comes from a DALI setpoint)
  const sortedZones = [...zones].sort((a,b) => parseFloat(a.s_start)-parseFloat(b.s_start));

  sortedZones.forEach(z => {
    const s0 = parseFloat(z.s_start);
    const s1 = parseFloat(z.s_end);
    const Le = parseFloat(z.L_estimated);
    if (z.setpoints?.length > 0) {
      // Transition: individual DALI setpoints — curve matches CIE 88
      z.setpoints.forEach(sp => {
        achPts.push({ s: parseFloat(sp.s), L: parseFloat(sp.L_req), isSP: true,
                      model: sp.model, mA: sp.current_mA, W: sp.power_w });
      });
    } else if (!isNaN(Le) && Le > 0 && z.n_luminaires > 0) {
      // Uniform zone: horizontal step
      achPts.push({ s: s0, L: Le, isSP: false });
      achPts.push({ s: s1, L: Le, isSP: false });
    }
  });
  achPts.sort((a,b) => a.s - b.s);

  let achD = '';
  achPts.forEach(pt => {
    achD += `${achD ? 'L' : 'M'}${xS(pt.s).toFixed(1)},${yL(pt.L).toFixed(1)} `;
  });

  // ── CIE 140 measured L_avg per zone (stepped) ─────────────────────────────
  const measPts = [];
  if (photoResult?.zones) {
    sortedZones.forEach(z => {
      const pz = photoResult.zones[z.zone_name];
      if (!pz || !pz.L_avg) return;
      const s0 = parseFloat(z.s_start), s1 = parseFloat(z.s_end);
      if (isNaN(s0)||isNaN(s1)) return;
      measPts.push({ s: s0, L: pz.L_avg });
      measPts.push({ s: s1, L: pz.L_avg });
    });
  }
  let measD = '';
  measPts.forEach(pt => {
    measD += `${measD ? 'L' : 'M'}${xS(pt.s).toFixed(1)},${yL(pt.L).toFixed(1)} `;
  });

  // ── Luminaire positions ───────────────────────────────────────────────────
  // Transition zones: exact positions from setpoints[], with per-luminaire current
  // Uniform zones:    evenly spaced at d_used
  const lumPos = [];
  sortedZones.forEach(z => {
    if (!z.n_luminaires || z.n_luminaires <= 0 || !z.d_used) return;
    const s0  = parseFloat(z.s_start);
    const d   = parseFloat(z.d_used);
    if (z.setpoints?.length > 0) {
      z.setpoints.forEach(sp => {
        lumPos.push({
          s: parseFloat(sp.s), model: sp.model,
          mA: sp.current_mA, W: sp.power_w,
          L_req: sp.L_req, zone_name: z.zone_name,
          d: d.toFixed(1), isSP: true,
        });
      });
    } else {
      const avgW = z.power_w || (z.n_luminaires > 0 ? Math.round((z.power_zone_w||0)/z.n_luminaires) : 0);
      for (let i = 0; i < z.n_luminaires; i++) {
        const s = s0 + d / 2 + i * d;
        if (s > L_m + d) break;
        lumPos.push({
          s, model: z.model, mA: z.current_mA, W: avgW,
          L_req: z.L_required, zone_name: z.zone_name,
          d: d.toFixed(1), isSP: false,
        });
      }
    }
  });

  // ── Zone colours & labels ─────────────────────────────────────────────────
  const ZBG = {
    access:'#fdecea', threshold:'#fff8e1', transition:'#e0f7fa',
    interior:'#e8f5e9', transition_b:'#cce5ff', threshold_b:'#fff3cd',
    exit:'#f3e5f5', parting:'#fdecea',
  };

  // Y / X ticks
  const yTicks = Array.from({length:6}, (_,i) => (i/5)*maxL);
  const xStep  = L_m<=300?50:L_m<=1000?100:L_m<=3000?500:1000;
  const xTicks = [];
  for (let s=0; s<=L_m; s+=xStep) xTicks.push(s);
  if (xTicks[xTicks.length-1] !== L_m) xTicks.push(L_m);

  const LY0 = MT + HP + GAP;
  const MFC = { S:'#43a047', M:'#1e88e5', L:'#e53935' };

  return (
    <div style={{position:'relative'}}>
      {/* Title */}
      <div style={{fontSize:'.72rem',fontWeight:700,color:'var(--salvi-grey)',
                   textTransform:'uppercase',letterSpacing:'.07em',marginBottom:4}}>
        Curva de luminancia instalada vs. CIE 88:2004 · Posición de luminarias
      </div>

      <svg viewBox={`0 0 ${W} ${HT}`}
           style={{width:'100%',height:'auto',overflow:'visible',display:'block'}}>

        {/* ── Zone background bands ── */}
        {sortedZones.map((z, zi) => {
          const x1 = xS(Math.max(0, parseFloat(z.s_start)));
          const x2 = xS(Math.min(L_m, parseFloat(z.s_end)));
          if (x2 <= x1) return null;
          const bg = ZBG[z.zone_type] || '#f5f5f5';
          return (
            <g key={zi}>
              <rect x={x1} y={MT} width={x2-x1} height={HP+GAP+HS}
                fill={bg} opacity={0.38}/>
              {/* zone divider */}
              {zi > 0 && (
                <line x1={x1} y1={MT} x2={x1} y2={LY0+HS}
                  stroke="#ccc" strokeWidth="0.8" strokeDasharray="3,3"/>
              )}
              <text x={(x1+x2)/2} y={LY0+HS-5}
                textAnchor="middle" fontSize="8" fill="#aaa" fontWeight="700">
                {z.zone_name}
              </text>
            </g>
          );
        })}

        {/* ── Grid lines ── */}
        {yTicks.map((L,i) => (
          <line key={i} x1={ML} y1={yL(L)} x2={ML+CW} y2={yL(L)}
            stroke="#ebebeb" strokeWidth="0.8"/>
        ))}

        {/* ── Area fill CIE 88 ── */}
        {reqD && (
          <path d={`${reqD}L${xS(L_m)},${MT+HP} L${ML},${MT+HP} Z`}
            fill="rgba(30,136,229,0.06)" stroke="none"/>
        )}

        {/* ── CIE 88 required curve (blue) ── */}
        {reqD && (
          <path d={reqD} fill="none" stroke="#1e88e5"
            strokeWidth="2.5" strokeLinejoin="round"/>
        )}

        {/* ── Installed L curve (orange-red) ── */}
        {/* Uniform zones: dashed; transition zones: solid — both on same path */}
        {achD && (
          <path d={achD} fill="none" stroke="#f57c00"
            strokeWidth="2" strokeLinejoin="round" strokeDasharray="9,5" opacity={0.92}/>
        )}

        {/* ── CIE 140 measured L_avg steps (verde esmeralda) ── */}
        {measD && (
          <path d={measD} fill="none" stroke="#059669"
            strokeWidth="2.2" strokeLinejoin="round" strokeLinecap="round" opacity={0.9}/>
        )}
        {/* CIE 140 zone-start dots */}
        {measPts.filter((_,i)=>i%2===0).map((pt,i)=>(
          <circle key={i} cx={xS(pt.s)} cy={yL(pt.L)} r={3.5}
            fill="#059669" stroke="#fff" strokeWidth="1.2" opacity={0.95}/>
        ))}

        {/* ── Setpoint dots (transition zones only) ── */}
        {achPts.filter(p => p.isSP).map((pt, i) => (
          <circle key={i} cx={xS(pt.s)} cy={yL(pt.L)} r={3}
            fill={MFC[pt.model]||'#f57c00'} stroke="#fff" strokeWidth="1" opacity={0.9}/>
        ))}

        {/* ── Profile frame ── */}
        <rect x={ML} y={MT} width={CW} height={HP}
          fill="none" stroke="#ccc" strokeWidth="0.6"/>

        {/* ── Y axis ── */}
        <line x1={ML} y1={MT} x2={ML} y2={MT+HP} stroke="#aaa" strokeWidth="1"/>
        {yTicks.map((L,i) => (
          <g key={i}>
            <line x1={ML-4} y1={yL(L)} x2={ML} y2={yL(L)} stroke="#aaa" strokeWidth="1"/>
            <text x={ML-6} y={yL(L)+3.5} textAnchor="end" fontSize="8.5" fill="#666">
              {L < 1 ? L.toFixed(1) : Math.round(L)}
            </text>
          </g>
        ))}
        <text x={11} y={MT+HP/2} textAnchor="middle" fontSize="8" fill="#888"
          transform={`rotate(-90,11,${MT+HP/2})`}>cd/m²</text>

        {/* ── X axis ── */}
        {xTicks.map(s => (
          <g key={s}>
            <line x1={xS(s)} y1={MT+HP} x2={xS(s)} y2={MT+HP+4}
              stroke="#aaa" strokeWidth="1"/>
            <text x={xS(s)} y={MT+HP+13} textAnchor="middle" fontSize="8" fill="#666">
              {s}
            </text>
          </g>
        ))}
        <text x={ML+CW/2} y={HT-4} textAnchor="middle" fontSize="8" fill="#888">
          posición (m)
        </text>

        {/* ── Strip separator ── */}
        <line x1={ML} y1={LY0} x2={ML+CW} y2={LY0} stroke="#ddd" strokeWidth="1.2"/>

        {/* ── Spacing dimension (first zone, illustrative) ── */}
        {(() => {
          const z = sortedZones.find(z => z.n_luminaires > 0 && parseFloat(z.d_used) > 0);
          if (!z) return null;
          const s0 = parseFloat(z.s_start), d = parseFloat(z.d_used);
          const xa = xS(s0+d/2), xb = xS(s0+d/2+d), yd = LY0+5;
          if (xb - xa < 18) return null;
          return (
            <g>
              <line x1={xa} y1={yd} x2={xb} y2={yd} stroke="#94a3b8" strokeWidth="0.9"/>
              <line x1={xa} y1={yd-3} x2={xa} y2={yd+3} stroke="#94a3b8" strokeWidth="0.9"/>
              <line x1={xb} y1={yd-3} x2={xb} y2={yd+3} stroke="#94a3b8" strokeWidth="0.9"/>
              <text x={(xa+xb)/2} y={yd-5} textAnchor="middle" fontSize="7" fill="#94a3b8">
                d={d.toFixed(1)} m
              </text>
            </g>
          );
        })()}

        {/* ── Luminaire markers ── */}
        {lumPos.map((lp, i) => {
          const x = xS(lp.s);
          const fill = MFC[lp.model] || '#999';
          return (
            <rect key={i}
              x={x-2.5} y={LY0+10} width={5} height={HS-22}
              fill={fill} rx={1.5}
              opacity={lp.isSP ? 0.72 : 0.88}
              style={{cursor:'pointer'}}
              onMouseEnter={e => setTip({x:e.clientX, y:e.clientY, d:lp})}
              onMouseLeave={() => setTip(null)}/>
          );
        })}

        {/* ── Legend ── */}
        <g transform={`translate(${ML},${HT-MB+12})`}>
          {[['S','Aphex S','#43a047'],['M','Aphex M','#1e88e5'],['L','Aphex L','#e53935']].map(([m,l,c],i)=>(
            <g key={m} transform={`translate(${i*85},0)`}>
              <rect x={0} y={-7} width={10} height={10} fill={c} rx={1.5}/>
              <text x={14} y={2} fontSize="8" fill="#555">{l}</text>
            </g>
          ))}
          <g transform="translate(268,0)">
            <line x1={0} y1={-2} x2={18} y2={-2} stroke="#1e88e5" strokeWidth="2.5"/>
            <circle cx={9} cy={-2} r={0} fill="#1e88e5"/>
            <text x={22} y={2} fontSize="8" fill="#555">L req. CIE 88:2004</text>
          </g>
          <g transform="translate(400,0)">
            <line x1={0} y1={-2} x2={18} y2={-2} stroke="#f57c00"
              strokeWidth="2.5" strokeDasharray="9,4"/>
            <circle cx={9} cy={-2} r={3} fill="#1e88e5" stroke="#fff" strokeWidth="1"/>
            <text x={22} y={2} fontSize="8" fill="#555">L instalada · setpoints DALI</text>
          </g>
          {measD&&(
            <g transform="translate(570,0)">
              <line x1={0} y1={-2} x2={18} y2={-2} stroke="#059669" strokeWidth="2.2"/>
              <circle cx={9} cy={-2} r={3.5} fill="#059669" stroke="#fff" strokeWidth="1.2"/>
              <text x={22} y={2} fontSize="8" fill="#555">L med. CIE 140</text>
            </g>
          )}
        </g>
      </svg>

      {/* ── Tooltip ── */}
      {tip && (
        <div style={{
          position:'fixed', left:tip.x+14, top:tip.y-58,
          background:'rgba(18,18,18,0.93)', color:'#fff',
          borderRadius:6, padding:'8px 13px', fontSize:'.72rem',
          pointerEvents:'none', zIndex:9999,
          boxShadow:'0 3px 14px rgba(0,0,0,.4)',
          lineHeight:1.85, minWidth:168,
        }}>
          <div style={{fontWeight:700,color:MFC[tip.d.model]||'#fff',
                       fontSize:'.78rem',marginBottom:2}}>
            Aphex {tip.d.model} — {tip.d.zone_name}
          </div>
          s = {typeof tip.d.s==='number'?tip.d.s.toFixed(1):tip.d.s} m<br/>
          L objetivo = <strong>{tip.d.L_req} cd/m²</strong><br/>
          I = <strong>{tip.d.mA} mA</strong> · P = {tip.d.W} W<br/>
          <span style={{color:'#aaa',fontSize:'.68rem'}}>
            Espaciado constante: {tip.d.d} m
            {tip.d.isSP ? ' · DALI individual' : ''}
          </span>
        </div>
      )}
    </div>
  );
}

function StepLuminaires({ result, form, onChange, onGoToMap }) {
  const [lumResult,setLumResult]=useState(null);
  const [photoResult,setPhotoResult]=useState(null);
  const [loading,setLoading]=useState(false);
  const [error,setError]=useState(null);

  if(!result||!result.success) return <Alert type="info">Completa el cálculo CIE 88 antes de dimensionar las luminarias.</Alert>;

  /* Config lives in form.lum_config (left panel), with fallback to defaults */
  const lum = {...DEFAULT_LUM_CONFIG, ...(form.lum_config||{})};

  const handleCalculate=async()=>{
    setLoading(true); setError(null);
    try {
      const resp=await fetch('/api/tunnel/luminaires',{
        method:'POST',
        headers:{'Content-Type':'application/json'},
        body:JSON.stringify({...form, luminaire: lum}),
      });
      const data=await resp.json();
      if(!data.success){ setError(data.error||'Error de cálculo'); }
      else {
        setLumResult(data.luminaires);
        setPhotoResult(data.photometric || null);
        if(data.luminaires?.totals?.power_kw) onChange('installed_power_kw', data.luminaires.totals.power_kw);
        onChange('luminaires_result', { ...data.luminaires, arrangement: lum.arrangement });
      }
    } catch(e){ setError(`Error: ${e.message}`); }
    finally{ setLoading(false); }
  };

  /* ── Colores por modelo Aphex ── */
  const MODEL_COLOR  = { S:"#e8f5e9", M:"#e3f2fd", L:"#fce4ec" };
  const MODEL_BORDER = { S:"#43a047", M:"#1e88e5", L:"#e53935" };

  return (
    <div>
      <div className="card">
        <div className="btn-row">
          <button className="btn btn-primary btn-lg" onClick={handleCalculate} disabled={loading}>
            {loading ? "⏳ Calculando…" : "⚡ Calcular Luminarias Aphex"}
          </button>
          {form.luminaires_result && onGoToMap && (
            <button onClick={onGoToMap}
              style={{padding:"8px 18px", fontSize:".8rem", fontWeight:700,
                      cursor:"pointer", borderRadius:6,
                      background:"#fffbeb", color:"#92400e",
                      border:"2px solid #d97706", whiteSpace:"nowrap"}}>
              🗺 Ver posición en mapa
            </button>
          )}
        </div>
        {error && <Alert type="danger" style={{marginTop:8}}>{error}</Alert>}
      </div>

            {lumResult && (
        <>
          {/* ══ Fila 1: Zonas CIE (izquierda) + KPIs / chips (derecha) ══ */}
          {(() => {
            const ZK_LBL = { access:'Acceso', threshold:'Umbral', transition:'Transición',
              interior:'Interior', transition_b:'Trans. B', threshold_b:'Umbral B',
              exit:'Salida', parting:'Post-sal.' };
            const ZK_BG = { access:'#fdecea', threshold:'#fff8e1', transition:'#e0f7fa',
              interior:'#e8f5e9', transition_b:'#cce5ff', threshold_b:'#fff3cd',
              exit:'#f3e5f5', parting:'#fdecea' };
            const sortedZ = Object.entries(result.zones||{}).sort(([,a],[,b])=>a.s_start-b.s_start);
            return (
              <div style={{display:"flex",gap:10,alignItems:"flex-start",marginBottom:10}}>
                <div style={{flex:"0 0 38%",minWidth:0}}>
                  <div className="card" style={{marginBottom:0}}>
                    <div className="card-title" style={{fontSize:".76rem",marginBottom:6}}>📏 Zonas Normativas CIE 88</div>
                    <table className="result-table" style={{fontSize:".73rem"}}>
                      <thead><tr>
                        <th>Zona</th>
                        <th style={{textAlign:"right"}}>m</th>
                        <th style={{textAlign:"right"}}>L req. (cd/m²)</th>
                      </tr></thead>
                      <tbody>
                        {sortedZ.map(([key,z])=>(
                          <tr key={key} style={{background:ZK_BG[key]||'#fff'}}>
                            <td style={{fontWeight:700,fontSize:".71rem"}}>{ZK_LBL[key]||key}</td>
                            <td style={{textAlign:"right"}}>{z.length.toFixed(0)}</td>
                            <td style={{textAlign:"right",fontWeight:700}}>{z.L_min_required.toFixed(2)}</td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                </div>
                <div style={{flex:"1 1 auto",minWidth:0}}>
                  <div className="kpi-grid" style={{gridTemplateColumns:"repeat(2,1fr)",marginBottom:8}}>
                    <div className="kpi-card">
                      <div className="kpi-value">{lumResult.totals.n_luminaires}<span className="kpi-unit"> ud</span></div>
                      <div className="kpi-label">Total luminarias</div>
                    </div>
                    <div className="kpi-card">
                      <div className="kpi-value">{lumResult.totals.power_kw}<span className="kpi-unit"> kW</span></div>
                      <div className="kpi-label">Potencia instalada</div>
                    </div>
                    <div className="kpi-card">
                      <div className="kpi-value">{lumResult.totals.power_density_wm2}<span className="kpi-unit"> W/m²</span></div>
                      <div className="kpi-label">Densidad media</div>
                    </div>
                    <div className="kpi-card">
                      <div className="kpi-value">{(lumResult.totals.flux_lm/1e6).toFixed(2)}<span className="kpi-unit"> Mlm</span></div>
                      <div className="kpi-label">Flujo total instalado</div>
                    </div>
                  </div>
                  <div style={{display:"flex",gap:6,flexWrap:"wrap",alignItems:"center"}}>
                    {[
                      {label:"Óptica", val:lumResult.optic},
                      {label:"CCT", val:lumResult.cct},
                      {label:"I_max", val:`${lumResult.I_max_mA} mA`},
                      {label:"UF", val:lumResult.zones?.[0]?.UF||"—"},
                    ].map(({label,val})=>(
                      <div key={label} style={{background:"#f5f5f5",borderRadius:4,padding:"3px 10px",fontSize:".73rem"}}>
                        <span style={{fontWeight:700}}>{label}:</span> {val}
                      </div>
                    ))}
                    {onGoToMap && (
                      <button onClick={onGoToMap}
                        style={{marginLeft:"auto",padding:"4px 14px",fontSize:".73rem",
                          fontWeight:700,cursor:"pointer",borderRadius:5,
                          background:"#fffbeb",color:"#92400e",
                          border:"1.5px solid #d97706",whiteSpace:"nowrap"}}>
                        🗺 Ver posición en mapa
                      </button>
                    )}
                  </div>
                </div>
              </div>
            );
          })()}

          {/* ══ Fila 2: Criterios CIE (izquierda) + Resumen modelos (derecha) ══ */}
          {(() => {
            const MODELS = ['S','M','L'];
            const MC = MODEL_COLOR;
            const MB = MODEL_BORDER;
            const zoneKeys  = _asArr(lumResult.zones).map(z=>z.zone_type).filter((v,i,a)=>a.indexOf(v)===i);
            const zoneNames = _asArr(lumResult.zones).map(z=>z.zone_name).filter((v,i,a)=>a.indexOf(v)===i);
            const agg = {};
            MODELS.forEach(m=>{ agg[m]={n:{},pw:0,totalN:0}; zoneKeys.forEach(k=>{agg[m].n[k]=0;}); });
            _asArr(lumResult.zones).forEach(z=>{
              if(z.model && MODELS.includes(z.model)){
                agg[z.model].n[z.zone_type]=(agg[z.model].n[z.zone_type]||0)+z.n_luminaires;
                agg[z.model].totalN+=z.n_luminaires;
                agg[z.model].pw+=(z.power_zone_w||0);
              }
            });
            const grandN  = MODELS.reduce((s,m)=>s+agg[m].totalN,0);
            const grandPw = MODELS.reduce((s,m)=>s+agg[m].pw,0);
            return (
              <div style={{display:"flex",gap:10,alignItems:"flex-start",marginBottom:10}}>
                <div style={{flex:"0 0 42%",minWidth:0}}>
                  <div className="card" style={{marginBottom:0}}>
                    <div className="card-title" style={{fontSize:".76rem",marginBottom:6}}>
                      📐 Verificación CIE 140:2019
                      {photoResult?.available && (
                        <span style={{marginLeft:6,padding:"1px 6px",borderRadius:4,fontSize:".68rem",
                          background:photoResult.overall_compliant?"#d1fae5":"#fee2e2",
                          color:photoResult.overall_compliant?"#065f46":"#991b1b",fontWeight:700}}>
                          {photoResult.overall_compliant?"✅ CUMPLE":"❌ REVISAR"}
                        </span>
                      )}
                    </div>
                    {photoResult?.available ? (
                      <>
                        <div style={{fontSize:".68rem",color:"var(--salvi-grey)",marginBottom:5}}>
                          Tabla {photoResult.rtable} · {photoResult.optic} · H={photoResult.H_m}m · CIE 140:2019
                        </div>
                        <table className="result-table" style={{fontSize:".70rem"}}>
                          <thead>
                            <tr>
                              <th>Zona</th>
                              <th style={{textAlign:"right"}} title="L media ≥ L_req">L_avg</th>
                              <th style={{textAlign:"right"}} title="Uniformidad global ≥ 0.40">U0</th>
                              <th style={{textAlign:"right"}} title="Uniformidad long. ≥ 0.60">Ul</th>
                              <th style={{textAlign:"right"}} title="Deslumbramiento ≤ 15%">TI%</th>
                              <th style={{textAlign:"center"}}>OK</th>
                            </tr>
                          </thead>
                          <tbody>
                            {Object.entries(photoResult.zones||{}).map(([zk,zv])=>{
                              if(zv.error) return (
                                <tr key={zk}>
                                  <td style={{fontWeight:700}}>{zk}</td>
                                  <td colSpan={5} style={{color:"var(--danger)",fontSize:".68rem"}}>{zv.error}</td>
                                </tr>
                              );
                              const chk = zv.checks||{};
                              const cv = (ok) => ({color: ok?"var(--success)":"var(--danger)", fontWeight:ok?400:700});
                              return (
                                <tr key={zk} style={{background:zv.compliant?"#f0fff4":"#fff5f5"}}>
                                  <td style={{fontWeight:700}}>{zk}</td>
                                  <td style={{textAlign:"right",...cv(chk.L_avg)}}>
                                    {zv.L_avg}
                                    <span style={{color:"#aaa",fontWeight:400}}> /{zv.L_req}</span>
                                  </td>
                                  <td style={{textAlign:"right",...cv(chk.U0)}}>{zv.U0}</td>
                                  <td style={{textAlign:"right",...cv(chk.Ul)}}>{zv.Ul}</td>
                                  <td style={{textAlign:"right",...cv(chk.TI)}}>{zv.TI}</td>
                                  <td style={{textAlign:"center",fontSize:".85rem"}}>{zv.compliant?"✅":"❌"}</td>
                                </tr>
                              );
                            })}
                          </tbody>
                        </table>
                        <div style={{marginTop:5,borderTop:"1px solid var(--salvi-line)",paddingTop:5}}>
                          <table className="result-table" style={{fontSize:".70rem"}}>
                            <tbody>
                              <tr><td>Perfil long.</td><td>CIE 88</td>
                                <td>{result.validation?.valid
                                  ?<span style={{color:"var(--success)",fontWeight:700}}>✅ Cumple</span>
                                  :<span style={{color:"var(--danger)",fontWeight:700}}>❌ Revisar</span>}
                                </td>
                              </tr>
                              <tr><td>Ratio pared</td><td>≥ 0.60</td><td style={{color:"var(--salvi-grey)"}}>—</td></tr>
                            </tbody>
                          </table>
                        </div>
                      </>
                    ) : (
                      <>
                        {photoResult?.error && (
                          <Alert type="warning" style={{fontSize:".68rem",padding:"3px 7px",marginBottom:5}}>
                            ⚠️ {photoResult.error}
                          </Alert>
                        )}
                        <table className="result-table" style={{fontSize:".73rem"}}>
                          <thead><tr><th>Criterio</th><th>Norma</th><th>Estado</th></tr></thead>
                          <tbody>
                            <tr><td>Unif. Uo</td><td>≥ 0.40</td><td style={{color:"var(--salvi-grey)",fontSize:".70rem"}}>Req. LDT</td></tr>
                            <tr><td>Unif. Ul</td><td>≥ 0.60</td><td style={{color:"var(--salvi-grey)",fontSize:".70rem"}}>Req. LDT</td></tr>
                            <tr><td>Deslustr. TI</td><td>≤ 15 %</td><td style={{color:"var(--salvi-grey)",fontSize:".70rem"}}>Req. LDT</td></tr>
                            <tr><td>Ratio pared</td><td>≥ 0.60</td><td style={{color:"var(--salvi-grey)",fontSize:".70rem"}}>Req. LDT</td></tr>
                            <tr><td>Perfil long.</td><td>CIE 88</td>
                              <td>{result.validation?.valid
                                ?<span style={{color:"var(--success)",fontWeight:700}}>✅ Cumple</span>
                                :<span style={{color:"var(--danger)",fontWeight:700}}>❌ Revisar</span>}
                              </td>
                            </tr>
                          </tbody>
                        </table>
                      </>
                    )}
                  </div>
                </div>
                <div style={{flex:"1 1 auto",minWidth:0}}>
                  <div className="card" style={{marginBottom:0}}>
                    <div className="card-title" style={{fontSize:".76rem",marginBottom:6}}>📊 Resumen por Modelo Aphex</div>
                    <div style={{overflowX:"auto"}}>
                      <table className="result-table" style={{fontSize:".73rem"}}>
                        <thead>
                          <tr>
                            <th>Modelo</th>
                            {zoneNames.map((zn,i)=><th key={i} style={{textAlign:"center"}}>{zn}</th>)}
                            <th style={{textAlign:"center",borderLeft:"2px solid var(--salvi-line)"}}>Uds</th>
                            <th style={{textAlign:"right"}}>kW</th>
                          </tr>
                        </thead>
                        <tbody>
                          {MODELS.filter(m=>agg[m].totalN>0).map(m=>(
                            <tr key={m} style={{background:MC[m]||"#fff"}}>
                              <td>
                                <span style={{background:MC[m],border:`1.5px solid ${MB[m]}`,
                                  borderRadius:4,padding:"1px 7px",fontWeight:700,
                                  color:MB[m],fontSize:".71rem"}}>
                                  Aphex {m}
                                </span>
                              </td>
                              {zoneKeys.map((zk,i)=>(
                                <td key={i} style={{textAlign:"center",color:agg[m].n[zk]?MB[m]:"#ccc"}}>
                                  {agg[m].n[zk]||"—"}
                                </td>
                              ))}
                              <td style={{textAlign:"center",fontWeight:700,borderLeft:"2px solid var(--salvi-line)"}}>{agg[m].totalN}</td>
                              <td style={{textAlign:"right",fontWeight:700}}>{(agg[m].pw/1000).toFixed(1)}</td>
                            </tr>
                          ))}
                          <tr style={{background:"var(--salvi-surface)",fontWeight:700,borderTop:"2px solid var(--salvi-line)"}}>
                            <td>TOTAL</td>
                            {zoneKeys.map((zk,i)=>{
                              const colN=MODELS.reduce((s,m)=>s+(agg[m].n[zk]||0),0);
                              return <td key={i} style={{textAlign:"center"}}>{colN||"—"}</td>;
                            })}
                            <td style={{textAlign:"center",borderLeft:"2px solid var(--salvi-line)"}}>{grandN}</td>
                            <td style={{textAlign:"right"}}>{(grandPw/1000).toFixed(1)}</td>
                          </tr>
                        </tbody>
                      </table>
                    </div>
                  </div>
                </div>
              </div>
            );
          })()}

          {/* ══ Perfil CIE 88 + layout luminarias ══ */}
          <div className="card">
            <div className="card-title">📈 Perfil de Luminancia + Layout Aphex</div>
            <TunnelLuminanceLayout result={result} lumResult={lumResult} photoResult={photoResult}/>
          </div>

          {/* Avisos */}
          {lumResult.warnings?.length > 0 && (
            <div className="card">
              {_asArr(lumResult.warnings).map((w,i)=><Alert key={i} type="warning">⚠️ {w}</Alert>)}
            </div>
          )}
        </>
      )}
    </div>
  );
}


// ─── PASO 7: INFORME ───────────────────────────────────────────

function StepReport({ result, form, tubes }) {
  const [generating, setGenerating]       = useState(false);
  const [generatingXls, setGeneratingXls] = useState(false);
  const [generatingAll, setGeneratingAll] = useState(false);
  const [status, setStatus]               = useState(null);

  if (!result || !result.success) {
    return <Alert type="info">Completa el cálculo antes de generar el informe.</Alert>;
  }

  const { summary, classification, zones, control } = result;

  // Tubos con resultado calculado
  const calculatedTubes = tubes
    ? Object.entries(tubes).filter(([,t]) => t.result?.success)
    : [];
  const isMultiTube = calculatedTubes.length > 1;

  const handleGenerate = async () => {
    setGenerating(true);
    setStatus({type:"info", msg:"Generando informe Word (CIE 88:2004)…"});
    try {
      const resp = await fetch('/api/tunnel/report', {
        method: 'POST',
        headers: {'Content-Type': 'application/json'},
        body: JSON.stringify(form)
      });
      if (!resp.ok) {
        const err = await resp.json().catch(() => ({error: resp.statusText}));
        setStatus({type:"error", msg:`Error ${resp.status}: ${err.error || resp.statusText}`});
        return;
      }
      // Descargar el blob
      const blob = await resp.blob();
      const url  = URL.createObjectURL(blob);
      const a    = document.createElement('a');
      a.href     = url;
      a.download = `informe_tunel_${form.tube_id || 'T1'}.docx`;
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
      URL.revokeObjectURL(url);
      setStatus({type:"success", msg:"✅ Informe descargado correctamente."});
    } catch(e) {
      setStatus({type:"error", msg:`Error de conexión: ${e.message}`});
    } finally {
      setGenerating(false);
    }
  };

  // Zonas: adaptar tanto formato array como objeto
  const zonesArr = Array.isArray(zones)
    ? zones
    : Object.values(zones || {});

  // Handler informe combinado (multi-tubo)
  const handleCombined = async () => {
    setGeneratingAll(true);
    setStatus({type:"info", msg:`Generando informe combinado (${calculatedTubes.length} tubos)…`});
    try {
      // Construir payload con solo los forms de los tubos calculados
      const tubesPayload = {};
      calculatedTubes.forEach(([id, t]) => { tubesPayload[id] = { form: t.form }; });
      const resp = await fetch('/api/tunnel/report-combined', {
        method: 'POST',
        headers: {'Content-Type': 'application/json'},
        body: JSON.stringify({
          tubes: tubesPayload,
          project_name: form.project_name || ''
        })
      });
      if (!resp.ok) {
        const err = await resp.json().catch(() => ({error: resp.statusText}));
        setStatus({type:"error", msg:`Error ${resp.status}: ${err.error || resp.statusText}`});
        return;
      }
      const blob = await resp.blob();
      const url  = URL.createObjectURL(blob);
      const a    = document.createElement('a');
      a.href     = url;
      a.download = `informe_${(form.project_name||'tunel').replace(/\s+/g,'_')}_completo.docx`;
      document.body.appendChild(a); a.click();
      document.body.removeChild(a);
      URL.revokeObjectURL(url);
      setStatus({type:"success", msg:`✅ Informe combinado descargado (${calculatedTubes.length} tubos).`});
    } catch(e) {
      setStatus({type:"error", msg:`Error: ${e.message}`});
    } finally {
      setGeneratingAll(false);
    }
  };

  const anyBusy = generating || generatingXls || generatingAll;

  return (
    <div>
      {/* Botón principal */}
      <div className="card">
        <div className="card-title"><span className="section-icon">📄</span>Informe Técnico CIE 88:2004</div>

        <p style={{fontSize:".90rem",color:"var(--gray-600)",marginBottom:16,lineHeight:1.6}}>
          Genera el informe técnico en <strong>Word</strong> (portada, clasificación, luminancias,
          zonas, plan de control y criterios de calidad) o en <strong>Excel</strong> (6 hojas:
          Portada, Zonas, Resultados, Control, Luminarias y Perfil longitudinal con gráfica).
        </p>

        <div className="btn-row" style={{flexWrap:"wrap"}}>
          <button className="btn btn-primary" onClick={handleGenerate} disabled={anyBusy}
                  style={{minWidth:220}}>
            {generating ? "⏳ Generando Word…" : `⬇️ Word — Tubo ${form.tube_id || 'T1'}`}
          </button>
          <button className="btn btn-outline" disabled={anyBusy}
                  style={{minWidth:220}}
                  onClick={async () => {
                    setGeneratingXls(true);
                    setStatus({type:"info", msg:"Generando Excel…"});
                    try {
                      const resp = await fetch('/api/tunnel/export-excel', {
                        method: 'POST',
                        headers: {'Content-Type': 'application/json'},
                        body: JSON.stringify(form)
                      });
                      if (!resp.ok) {
                        const err = await resp.json().catch(() => ({error: resp.statusText}));
                        setStatus({type:"error", msg:`Error ${resp.status}: ${err.error}`});
                        return;
                      }
                      const blob = await resp.blob();
                      const url  = URL.createObjectURL(blob);
                      const a    = document.createElement('a');
                      a.href     = url;
                      a.download = `calculo_tunel_${form.tube_id || 'T1'}.xlsx`;
                      document.body.appendChild(a); a.click();
                      document.body.removeChild(a);
                      URL.revokeObjectURL(url);
                      setStatus({type:"success", msg:"✅ Excel descargado correctamente."});
                    } catch(e) {
                      setStatus({type:"error", msg:`Error: ${e.message}`});
                    } finally {
                      setGeneratingXls(false);
                    }
                  }}>
            {generatingXls ? "⏳ Generando Excel…" : `📊 Excel — Tubo ${form.tube_id || 'T1'}`}
          </button>

          {/* Informes combinados — solo aparecen si hay ≥2 tubos calculados */}
          {isMultiTube && (<>
            <button className="btn btn-success" onClick={handleCombined} disabled={anyBusy}
                    style={{minWidth:220}}>
              {generatingAll
                ? `⏳ Generando…`
                : `📑 Word (${calculatedTubes.map(([id])=>id).join('+')})`}
            </button>
            <button className="btn btn-outline" onClick={async () => {
                setGeneratingAll(true);
                setStatus({type:"info", msg:`Generando Excel combinado…`});
                try {
                  const tubesPayload = {};
                  calculatedTubes.forEach(([id, t]) => { tubesPayload[id] = { form: t.form }; });
                  const resp = await fetch('/api/tunnel/export-excel-combined', {
                    method:'POST', headers:{'Content-Type':'application/json'},
                    body: JSON.stringify({ tubes: tubesPayload, project_name: form.project_name||'' })
                  });
                  if (!resp.ok) {
                    const err = await resp.json().catch(() => ({error: resp.statusText}));
                    setStatus({type:"error", msg:`Error: ${err.error}`}); return;
                  }
                  const blob = await resp.blob();
                  const url = URL.createObjectURL(blob);
                  const a = document.createElement('a');
                  a.href = url;
                  a.download = `calculo_${(form.project_name||'tunel').replace(/\s+/g,'_')}_completo.xlsx`;
                  document.body.appendChild(a); a.click();
                  document.body.removeChild(a); URL.revokeObjectURL(url);
                  setStatus({type:"success", msg:"✅ Excel combinado descargado."});
                } catch(e) {
                  setStatus({type:"error", msg:`Error: ${e.message}`});
                } finally { setGeneratingAll(false); }
              }} disabled={anyBusy} style={{minWidth:220}}>
              {generatingAll ? "⏳…" : `📊 Excel (${calculatedTubes.map(([id])=>id).join('+')})`}
            </button>
          </>)}
        </div>

        {status && (
          <Alert type={status.type} style={{marginTop:12}}>{status.msg}</Alert>
        )}
      </div>

      {/* Resumen de lo que contiene */}
      <div className="card">
        <div className="card-title"><span className="section-icon">📋</span>Contenido del Informe</div>

        <div style={{display:"grid",gridTemplateColumns:"1fr 1fr",gap:12}}>
          {[
            {icon:"🏷️", title:"Portada", desc:`${form.project_name} · Tubo ${form.tube_id} · ${summary.length_m} m`},
            {icon:"📐", title:"Clasificación CIE 88", desc:`${classification.geometric} · ${classification.optical}`},
            {icon:"💡", title:"Luminancias", desc:`L₂₀=${summary.L20} · Lth=${summary.Lth} · Lin=${summary.Lin} cd/m²`},
            {icon:"🗺️", title:"Zonas normativas", desc:`${zonesArr.length} zonas calculadas`},
            {icon:"🎛️", title:"Plan de control", desc:control
              ? `${control.protocol} · ${control.n_groups} grupos · ${control.n_scenes} escenas`
              : "No disponible"},
            {icon:"✅", title:"Criterios de calidad", desc:"Uo, Ul, TI, ratio paredes (CIE 88:2004)"},
          ].map(({icon,title,desc}) => (
            <div key={title} style={{display:"flex",gap:10,alignItems:"flex-start",
                                     background:"var(--gray-50)",borderRadius:6,padding:"10px 12px",
                                     border:"1px solid var(--gray-200)"}}>
              <span style={{fontSize:"1.1rem"}}>{icon}</span>
              <div>
                <div style={{fontWeight:600,fontSize:".85rem",color:"var(--gray-800)"}}>{title}</div>
                <div style={{fontSize:".80rem",color:"var(--gray-500)",marginTop:2}}>{desc}</div>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Vista previa texto */}
      <div className="card">
        <div className="card-title"><span className="section-icon">👁️</span>Vista Previa</div>
        <div style={{fontFamily:"monospace",fontSize:".80rem",lineHeight:1.9,
                     background:"var(--gray-50)",padding:16,borderRadius:6,
                     borderLeft:"3px solid var(--brand)",whiteSpace:"pre-wrap"}}>
{`SALVI TUNNEL ENGINE — Informe Técnico
Norma: CIE 88:2004 — Guide for the Lighting of Road Tunnels and Underpasses
${"─".repeat(58)}

PROYECTO:  ${form.project_name}
Tubo:      ${summary.tube_id || form.tube_id}   Longitud: ${summary.length_m} m
Fecha:     ${new Date().toLocaleDateString('es-ES')}

1. CLASIFICACIÓN
   Geométrica:        ${classification.geometric}
   Óptica:            ${classification.optical}
   Ilum. diurna:      ${classification.daylighting}

2. DISTANCIA DE PARADA
   v diseño = ${summary.speed_kmh} km/h   SD = ${summary.SD_m} m

3. LUMINANCIAS DE DISEÑO
   L₂₀ = ${summary.L20} cd/m²   Lth = ${summary.Lth} cd/m²
   Lin = ${summary.Lin} cd/m²    L_noche = ${summary.L_night} cd/m²
   k = ${summary.k_factor}   qc = ${summary.qc} m²·sr/lm

4. ZONAS CIE 88
${zonesArr.map(z => `   ${(z.type||z.zone_type||"").padEnd(12)} ${String(z.s_start?.toFixed(0)||0).padStart(4)}–${String(z.s_end?.toFixed(0)||0).padStart(4)} m   L_min = ${z.L_min_required?.toFixed(1)||"—"} cd/m²`).join('\n')}

${control ? `5. PLAN DE CONTROL
   Protocolo: ${control.protocol}   Grupos: ${control.n_groups}   Escenas: ${control.n_scenes}` : ""}
`}
        </div>
      </div>
    </div>
  );
}

// ─── COMPARATIVA MULTI-TUBO ────────────────────────────────────

const OPPOSITE_ORIENT = {
  "N":"S","S":"N","E":"W","W":"E",
  "NE":"SW","SW":"NE","NW":"SE","SE":"NW",
};

function TubeComparison({ tubes }) {
  const tubeIds    = Object.keys(tubes).filter(id => tubes[id].result?.success);
  if (tubeIds.length < 2) return null;

  const metrics = [
    {key:"L20",     label:"L₂₀ (cd/m²)",   path: r => r.summary.L20},
    {key:"Lth",     label:"Lth (cd/m²)",    path: r => r.summary.Lth},
    {key:"Lin",     label:"Lin (cd/m²)",    path: r => r.summary.Lin},
    {key:"L_night", label:"L_noche (cd/m²)",path: r => r.summary.L_night},
    {key:"SD",      label:"SD (m)",          path: r => r.summary.SD_m},
    {key:"kfactor", label:"Factor k",        path: r => r.summary.k_factor},
    {key:"optical", label:"Clase óptica",    path: r => r.classification.optical.replace(/_/g," ")},
    {key:"daylighting",label:"Ilum. diurna", path: r => r.classification.daylighting},
  ];

  return (
    <div className="card" style={{marginTop:16}}>
      <div className="card-title">
        <span className="section-icon">🔀</span>Comparativa de Tubos
      </div>
      <div style={{overflowX:"auto"}}>
        <table className="result-table" style={{fontSize:".85rem"}}>
          <thead>
            <tr>
              <th style={{textAlign:"left"}}>Parámetro</th>
              {tubeIds.map(id => (
                <th key={id} style={{background:"var(--brand-lt)",color:"var(--brand-dk)"}}>
                  Tubo {id}
                </th>
              ))}
            </tr>
          </thead>
          <tbody>
            {metrics.map(({key, label, path}) => {
              const vals = tubeIds.map(id => {
                try { return path(tubes[id].result); } catch { return "—"; }
              });
              const allSame = vals.every(v => v === vals[0]);
              return (
                <tr key={key}>
                  <td style={{fontWeight:600,color:"var(--gray-700)"}}>{label}</td>
                  {vals.map((v, i) => (
                    <td key={i} style={{
                      textAlign:"center",
                      fontWeight: !allSame && typeof v === "number" ? 700 : 400,
                      color: !allSame && typeof v === "number" && i === 0 ? "var(--brand)" : "inherit"
                    }}>
                      {v}
                    </td>
                  ))}
                </tr>
              );
            })}
          </tbody>
        </table>
      </div>
      <p style={{fontSize:".78rem",color:"var(--gray-400)",marginTop:8}}>
        Diferencias resaltadas en azul (T1). Los dos tubos se calculan independientemente.
      </p>
    </div>
  );
}

// ─── APP PRINCIPAL ─────────────────────────────────────────────

const DEFAULT_FORM = {
  project_name:"Proyecto Túnel", tube_id:"T1", length_m:300, speed_kmh:80,
  gradient_pct:0, curvature_radius_m:null, traffic_direction:"one_way",
  mu_friction:null, t_reaction:2.5,
  width_m:10.5, height_m:5.5, num_lanes:2, lane_width_m:3.5,
  shoulder_left_m:0, shoulder_right_m:0, portal_orientation:"S",
  tunnel_shape:"horseshoe", H_pared_m:3.0, road_surface:"dark_asphalt",
  environment_type:"open_country_flat", sky_condition:"clear",
  daylight_penetration:"poor", wall_reflectance:0.4,
  exit_visible:false, illuminated_road:false,
  traffic_veh_h:500, has_pedestrians:false,
  l20_method:"model", lth_method:"k_factor",
  profile_stepped:false, n_steps:4, n_transition_groups:2,
  control_protocol:"DALI",
  lat:"", lng:"",
  imd:"", k_peak:0.10,
  ta_design_c:20,
};

const STE_VERSION = "1.2";
const _mkTube = (id, baseForm=DEFAULT_FORM) => ({ form:{...baseForm, tube_id:id}, result:null });

const MAIN_TABS = [
  {id:'perfil',     label:'Perfil'},
  {id:'zonas',      label:'Zonas'},
  {id:'control',    label:'Control'},
  {id:'luminarias', label:'Luminarias'},
  {id:'informe',    label:'Informe'},
];


// ══════════════════════════════════════════════════════════════════
// TunnelPerspective — sección transversal + datos clave del túnel
// ══════════════════════════════════════════════════════════════════
function TunnelPerspective({ form, result, onEdit }) {
  const W  = parseFloat(form.width_m)  || 8;
  const H  = parseFloat(form.height_m) || 5;
  const L  = parseFloat(form.length_m) || 500;
  const lanes = parseInt(form.num_lanes) || 2;
  const dir   = form.traffic_direction === 'two_way' ? '⇅' : '↑';
  const slope = parseFloat(form.gradient_pct) || 0;

  // SVG viewport
  const SVG_W = 420, SVG_H = 220;
  const margin = { top: 20, right: 20, bottom: 40, left: 20 };
  const tW = SVG_W - margin.left - margin.right;   // tunnel drawing width
  const tH = SVG_H - margin.top  - margin.bottom;  // tunnel drawing height

  // Scale: fit tunnel cross-section into drawing area
  const scaleX = tW / (W + 4);
  const scaleY = tH / (H + 2);
  const sc = Math.min(scaleX, scaleY);
  const tw = W * sc;   // scaled tunnel width
  const th = H * sc;   // scaled tunnel height

  // Center in drawing area
  const ox = margin.left + (tW - tw) / 2;
  const oy = margin.top  + (tH - th);

  // Arch path — usa forma real del túnel
  const _shape = form.tunnel_shape || 'horseshoe';
  const _Hp    = parseFloat(form.H_pared_m) ?? 3.0;
  const wallH_px = Math.min(_Hp, H) / H * th;
  const archH_px = th - wallH_px;
  const archH  = archH_px;  // alias para labels de Lth/Lin
  let archPath;
  if (_shape === 'rectangular') {
    archPath = `M ${ox} ${oy} L ${ox} ${oy+th} L ${ox+tw} ${oy+th} L ${ox+tw} ${oy} Z`;
  } else if (_shape === 'circular') {
    const R_m = ((W/2)**2 + H**2) / (2*H);
    const R_px = R_m * sc;
    const z_ctr = H - R_m;
    const largeArc = z_ctr >= -0.001 ? 1 : 0;
    archPath = `M ${ox} ${oy+th} A ${R_px} ${R_px} 0 ${largeArc} 1 ${ox+tw} ${oy+th} Z`;
  } else {
    const _ax = ox + tw/2, _ay = oy + archH_px;
    archPath = `M ${ox} ${oy+th} L ${ox} ${_ay} A ${tw/2} ${archH_px} 0 0 1 ${ox+tw} ${_ay} L ${ox+tw} ${oy+th} Z`;
  }

  // Road surface
  const roadY  = oy + th;
  const roadH  = 6;
  const laneW  = tw / lanes;

  // Pavement markings
  const markings = [];
  for (let i = 1; i < lanes; i++) {
    markings.push(ox + laneW * i);
  }

  // Result-based info
  const Lth = result?.summary?.Lth;
  const Lin = result?.summary?.Lin;
  const kpi = result?.success;

  const ORIENT_ARROW = {
    N:'↑',NE:'↗',E:'→',SE:'↘',S:'↓',SW:'↙',W:'←',NW:'↖'
  };

  return (
    <div style={{display:'flex',gap:12,padding:'10px 12px',flexWrap:'wrap'}}>
      {/* SVG section */}
      <div style={{flex:'1 1 300px',minWidth:260,background:'var(--salvi-surface)',border:'1px solid var(--salvi-line)',borderRadius:8,padding:8}}>
        <div style={{fontSize:'.68rem',fontWeight:700,color:'var(--salvi-grey)',marginBottom:4,textAlign:'center',letterSpacing:'.08em',textTransform:'uppercase'}}>
          Sección transversal
        </div>
        <svg viewBox={`0 0 ${SVG_W} ${SVG_H}`} style={{width:'100%',height:'auto',display:'block'}}>
          {/* Ground */}
          <rect x={0} y={roadY} width={SVG_W} height={SVG_H - roadY + 1} fill="#d1d5db"/>
          {/* Tunnel interior */}
          <path d={archPath} fill="#1e293b" stroke="#334155" strokeWidth="2"/>
          {/* Road surface */}
          <rect x={ox} y={roadY - roadH} width={tw} height={roadH} fill="#374151"/>
          {/* Lane markings */}
          {markings.map((x, i) => (
            <line key={i} x1={x} y1={roadY - roadH + 1} x2={x} y2={roadY - 1}
              stroke="#fbbf24" strokeWidth="1.5" strokeDasharray="8 5"/>
          ))}
          {/* Kerb lines */}
          <rect x={ox} y={roadY - roadH} width={3} height={roadH} fill="#6b7280"/>
          <rect x={ox + tw - 3} y={roadY - roadH} width={3} height={roadH} fill="#6b7280"/>

          {/* Width annotation */}
          <line x1={ox} y1={roadY + 14} x2={ox + tw} y2={roadY + 14} stroke="#94a3b8" strokeWidth="1"/>
          <line x1={ox} y1={roadY + 10} x2={ox} y2={roadY + 18} stroke="#94a3b8" strokeWidth="1"/>
          <line x1={ox + tw} y1={roadY + 10} x2={ox + tw} y2={roadY + 18} stroke="#94a3b8" strokeWidth="1"/>
          <text x={ox + tw/2} y={roadY + 26} textAnchor="middle" fill="#94a3b8" fontSize="10">
            {W} m
          </text>

          {/* Height annotation */}
          <line x1={ox - 14} y1={oy} x2={ox - 14} y2={roadY - roadH} stroke="#94a3b8" strokeWidth="1"/>
          <line x1={ox - 18} y1={oy} x2={ox - 10} y2={oy} stroke="#94a3b8" strokeWidth="1"/>
          <line x1={ox - 18} y1={roadY - roadH} x2={ox - 10} y2={roadY - roadH} stroke="#94a3b8" strokeWidth="1"/>
          <text x={ox - 22} y={oy + (roadY - roadH - oy)/2 + 4} textAnchor="middle" fill="#94a3b8" fontSize="10"
            transform={`rotate(-90,${ox - 22},${oy + (roadY - roadH - oy)/2 + 4})`}>
            {H} m
          </text>

          {/* Traffic arrow */}
          {Array.from({length: lanes}, (_,i) => (
            <text key={i} x={ox + laneW*(i+0.5)} y={roadY - 2} textAnchor="middle"
              fill="#fbbf24" fontSize="11" fontWeight="bold">
              {dir}
            </text>
          ))}

          {/* Portal orientation label */}
          <text x={SVG_W - 8} y={14} textAnchor="end" fill="#64748b" fontSize="10">
            Portal {ORIENT_ARROW[form.portal_orientation]||''} {form.portal_orientation}
          </text>

          {/* Slope */}
          {slope !== 0 && (
            <text x={8} y={14} textAnchor="start" fill="#64748b" fontSize="10">
              Pend. {slope > 0 ? '+' : ''}{slope}%
            </text>
          )}

          {/* Luminance levels if calculated */}
          {kpi && (
            <g>
              <text x={SVG_W/2} y={oy + archH*0.45} textAnchor="middle" fill="#fbbf24" fontSize="9.5" fontWeight="600">
                Lth = {Lth} cd/m²
              </text>
              <text x={SVG_W/2} y={oy + archH*0.45 + 13} textAnchor="middle" fill="#86efac" fontSize="9">
                Lin = {Lin} cd/m²
              </text>
            </g>
          )}
        </svg>
      </div>

      {/* Data table */}
      <div style={{flex:'1 1 180px',minWidth:160,display:'flex',flexDirection:'column',gap:6}}>
        <div style={{background:'var(--salvi-surface)',border:'1px solid var(--salvi-line)',borderRadius:8,padding:'8px 10px',fontSize:'.72rem'}}>
          <div style={{fontWeight:700,color:'var(--salvi-black)',marginBottom:6,fontSize:'.68rem',textTransform:'uppercase',letterSpacing:'.07em'}}>Geometría</div>
          {[
            ['Longitud', `${L.toLocaleString()} m`],
            ['Anchura', `${W} m`],
            ['Altura libre', `${H} m`],
            ['Carriles', lanes],
            ['Circulación', form.traffic_direction==='one_way'?'Un sentido':'Bidireccional'],
            ['Pendiente', `${slope > 0 ? '+' : ''}${slope} %`],
            ['Portal', form.portal_orientation],
          ].map(([k,v])=>(
            <div key={k} style={{display:'flex',justifyContent:'space-between',padding:'2px 0',borderBottom:'1px solid var(--salvi-line)'}}>
              <span style={{color:'var(--salvi-grey)'}}>{k}</span>
              <span style={{fontWeight:600,color:'var(--salvi-black)'}}>{v}</span>
            </div>
          ))}
        </div>
        {kpi && (
          <div style={{background:'#f0fdf4',border:'1px solid #86efac',borderRadius:8,padding:'8px 10px',fontSize:'.72rem'}}>
            <div style={{fontWeight:700,color:'#166534',marginBottom:6,fontSize:'.68rem',textTransform:'uppercase',letterSpacing:'.07em'}}>Fotometría CIE 88</div>
            {[
              ['L₂₀', `${result.summary.L20} cd/m²`],
              ['Lth',  `${Lth} cd/m²`],
              ['Lin',  `${Lin} cd/m²`],
              ['SD',   `${result.summary.SD_m} m`],
              ['k',    result.summary.k_factor],
            ].map(([k,v])=>(
              <div key={k} style={{display:'flex',justifyContent:'space-between',padding:'2px 0',borderBottom:'1px solid #bbf7d0'}}>
                <span style={{color:'#166534'}}>{k}</span>
                <span style={{fontWeight:600,color:'#14532d'}}>{v}</span>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}

// ══════════════════════════════════════════════════════════════════
// LumConfigPanel — configuración de luminarias en panel izquierdo
// ══════════════════════════════════════════════════════════════════
function LumConfigPanel({ lum, onChange, roadWidthM, heightM, hParedM, tunnelShape }) {
  const round2 = v => Math.round(v*100)/100;
  const half   = Math.max(0.6, (roadWidthM || 10.5) / 2);
  const wallVal = lum.wall_offset_m ?? DEFAULT_LUM_CONFIG.wall_offset_m;
  const axisVal = lum.axis_offset_m ?? round2(half - wallVal);

  // En sección herradura, el arranque de bóveda (H_pared_m) hace que el
  // contorno se curve hacia dentro por encima de esa altura — una luminaria
  // montada ahí no puede pegarse tanto a la pared como una montada en el
  // tramo recto. Si la disposición es de pared (bilateral/lateral) y la
  // altura de montaje cae en la zona curva, se calcula la distancia mínima
  // a la pared que mantiene la luminaria dentro del contorno real (misma
  // elipse que usa TunnelSectionPreview) y se sube el offset automáticamente
  // en vez de dejar que se muestre "fuera del contorno".
  React.useEffect(() => {
    const wallAdjacent = ['bilateral_sym','bilateral_stag','lateral_left','lateral_right'].includes(lum.arrangement);
    if (!wallAdjacent || (tunnelShape||'horseshoe') !== 'horseshoe') return;
    const H  = heightM ?? 5.5;
    const Hp = Math.min(hParedM ?? 3.0, H);
    const zM = lum.mounting_height_m ?? DEFAULT_LUM_CONFIG.mounting_height_m;
    if (zM <= Hp) return;   // tramo recto: cualquier offset razonable es válido
    const a = half, b = H - Hp;
    if (b <= 0) return;
    const ratio = (zM - Hp) / b;
    if (ratio >= 1) return;  // altura por encima de la clave: no hay posición segura
    const safeOffset = round2(Math.min(round2(half - 0.05), a * (1 - Math.sqrt(1 - ratio*ratio)) + 0.05));
    const current = lum.wall_offset_m ?? DEFAULT_LUM_CONFIG.wall_offset_m;
    if (current < safeOffset) {
      onChange({ wall_offset_m: safeOffset, axis_offset_m: round2(half - safeOffset) });
    }
  }, [lum.arrangement, lum.mounting_height_m, roadWidthM, heightM, hParedM, tunnelShape]);
  // "Distancia a pared" y "Distancia al eje" describen la misma fila de
  // luminarias desde referencias opuestas (pared vs eje): wall + axis = W/2.
  const pairedOffsetInput = (val, onSet) => (
    <div style={{display:'flex',alignItems:'center',gap:4}}>
      <input type="number" min={0.05} max={round2(half-0.05)} step={0.05}
        value={val}
        onChange={e=>{
          const v = parseFloat(e.target.value);
          if(!isNaN(v)) onSet(Math.max(0.05, Math.min(round2(half-0.05), v)));
        }}
        style={{width:0,flex:1,padding:'4px 6px',fontSize:'.7rem',border:'1px solid var(--salvi-line)',borderRadius:4}}/>
      <span style={{fontSize:'.66rem',color:'var(--salvi-grey)'}}>m</span>
    </div>
  );
  const label = text => (
    <div style={{fontSize:'.64rem',fontWeight:600,color:'var(--salvi-grey)',marginBottom:3,
                 textTransform:'uppercase',letterSpacing:'.05em',whiteSpace:'nowrap',
                 overflow:'hidden',textOverflow:'ellipsis'}} title={text}>{text}</div>
  );
  const cell = (text, children) => (
    <div style={{minWidth:0}}>
      {label(text)}
      {children}
    </div>
  );
  // Fila de 2 columnas: [labelA, childA, labelB, childB]
  const row2 = (labelA, childA, labelB, childB) => (
    <div style={{display:'grid',gridTemplateColumns:'1fr 1fr',gap:8,marginBottom:8}}>
      {cell(labelA, childA)}
      {cell(labelB, childB)}
    </div>
  );

  const sel = (key, opts) => (
    <select value={lum[key]} onChange={e=>onChange({[key]:e.target.value})}
      style={{width:'100%',padding:'4px 6px',fontSize:'.7rem',border:'1px solid var(--salvi-line)',borderRadius:4,background:'#fff',cursor:'pointer'}}>
      {opts.map(([v,l])=><option key={v} value={v}>{l}</option>)}
    </select>
  );

  const numInput = (key, min, max, step, unit='') => (
    <div style={{display:'flex',alignItems:'center',gap:4}}>
      <input type="number" min={min} max={max} step={step}
        value={lum[key] ?? DEFAULT_LUM_CONFIG[key]}
        onChange={e=>{const v=parseFloat(e.target.value); if(!isNaN(v)) onChange({[key]:v});}}
        style={{width:0,flex:1,padding:'4px 6px',fontSize:'.7rem',border:'1px solid var(--salvi-line)',borderRadius:4}}/>
      {unit && <span style={{fontSize:'.66rem',color:'var(--salvi-grey)',whiteSpace:'nowrap'}}>{unit}</span>}
    </div>
  );

  const slider = (key, min, max, step, fmt, onSet) => (
    <div>
      <input type="range" className="lum-slider" min={min} max={max} step={step}
        value={lum[key] ?? DEFAULT_LUM_CONFIG[key]}
        onChange={e=>onSet(e.target.value)}
        style={{width:'100%'}}/>
      <div style={{fontSize:'.68rem',fontWeight:700,color:'var(--salvi-black)',marginTop:2}}>
        {fmt(lum[key] ?? DEFAULT_LUM_CONFIG[key])}
      </div>
    </div>
  );

  const sep = text => (
    <div style={{fontSize:'.63rem',fontWeight:700,color:'var(--salvi-blue)',textTransform:'uppercase',
                 letterSpacing:'.08em',margin:'12px 0 6px',borderBottom:'1px solid var(--salvi-line)',paddingBottom:3}}>
      {text}
    </div>
  );

  return (
    <div style={{padding:'10px 10px 6px'}}>
      {/* Banner info */}
      <div style={{background:'#f0fdf4',border:'1px solid #86efac',borderRadius:6,padding:'7px 9px',marginBottom:10}}>
        <div style={{fontSize:'.67rem',fontWeight:700,color:'#166534',marginBottom:2}}>💡 Modelo Aphex — selección automática</div>
        <div style={{fontSize:'.65rem',color:'#15803d',lineHeight:1.5}}>
          Optimizador <b>CIE 140</b>: maximiza interdistancia respetando U0 y Ul mínimos,
          luego selecciona <b>S → M → L</b> a la corriente mínima necesaria.
        </div>
      </div>

      {sep('Geometría')}

      {row2(
        'Disposición', (
          <select value={lum.arrangement} onChange={e=>onChange({arrangement:e.target.value})}
            style={{width:'100%',padding:'4px 6px',fontSize:'.7rem',border:'1px solid var(--salvi-line)',borderRadius:4,background:'#fff',cursor:'pointer'}}>
            <option value="central_single">Central simple</option>
            <option value="central_double">Central doble</option>
            <option value="central_offset">Central desplazado</option>
            <option value="lateral_left">Lateral izquierda</option>
            <option value="lateral_right">Lateral derecha</option>
            <option value="bilateral_sym">Bilateral simétrico</option>
            <option value="bilateral_stag">Bilateral alternado</option>
          </select>
        ),
        'Altura montaje (m)', numInput('mounting_height_m', 1.5, 12, 0.1, 'm')
      )}

      {row2(
        'Interdist. mínima (m)', (
          <div style={{display:'flex',alignItems:'center',gap:4}}>
            <input type="number" min="0.3" max="10" step="0.1"
              value={lum.d_min ?? 0.8}
              onChange={e=>{
                const v = parseFloat(e.target.value);
                onChange({d_min: isNaN(v)?0.8:Math.max(0.3,Math.min(10,v))});
              }}
              style={{width:0,flex:1,padding:'4px 6px',fontSize:'.7rem',border:'1px solid var(--salvi-line)',borderRadius:4}}/>
            <span style={{fontSize:'.66rem',color:'var(--salvi-grey)'}}>m</span>
          </div>
        ),
        'Interdist. fija (m)', (
          <div style={{display:'flex',alignItems:'center',gap:4}}>
            <input type="number" min="1" max="50" step="0.5"
              placeholder="Auto"
              value={lum.d_fixed ?? ""}
              onChange={e=>{
                const v = e.target.value;
                onChange({d_fixed: v===''?'':parseFloat(v)||''});
              }}
              style={{width:0,flex:1,padding:'4px 6px',fontSize:'.7rem',border:'1px solid var(--salvi-line)',borderRadius:4}}/>
            <span style={{fontSize:'.66rem',color:'var(--salvi-grey)'}}>m</span>
          </div>
        )
      )}

      {row2(
        'Distancia a pared (m)', pairedOffsetInput(wallVal, v=>onChange({wall_offset_m:v, axis_offset_m:round2(half-v)})),
        'Distancia al eje (m)',  pairedOffsetInput(axisVal, v=>onChange({axis_offset_m:v, wall_offset_m:round2(half-v)}))
      )}
      <div style={{fontSize:'.62rem',color:'var(--salvi-grey)',marginTop:-2,marginBottom:8,lineHeight:1.4}}>
        <b>Interdist. mínima</b>: límite inferior del espaciado (umbral, mucha luminancia). <b>Interdist. fija</b>: activa modo retrofit con posiciones predefinidas.
        <b> Distancia al eje</b>: sólo aplica con disposición "Central desplazado" — ambas miden la misma fila desde referencias opuestas (pared/eje) y suman W/2, así que cambiar una ajusta la otra.
      </div>

      {sep('Luminaria')}

      {row2(
        'Óptica inicial', sel('optic',[['auto','Auto (optimizador)'],['F2M2','F2M2'],['F2MD','F2MD'],['F151','F151']]),
        'Temp. color', sel('cct',[['4000K','4000 K neutro'],['3000K','3000 K cálido']])
      )}

      {row2(
        'Corriente mínima', slider('I_min_pct', 20, 50, 5,
          v => `${v}% = ${Math.round(v/100*350)} mA`,
          v => onChange({I_min_pct:parseInt(v)})),
        'Corriente máxima', (
          <div style={{display:'flex',alignItems:'center',gap:4}}>
            <input type="number" min="105" max="1050" step="5"
              value={lum.I_max_mA}
              onChange={e=>{const v=parseInt(e.target.value); if(!isNaN(v)&&v>=105) onChange({I_max_mA:v});}}
              style={{width:0,flex:1,padding:'4px 6px',fontSize:'.7rem',border:'1px solid var(--salvi-line)',borderRadius:4}}/>
            <span style={{fontSize:'.66rem',color:'var(--salvi-grey)'}}>mA</span>
          </div>
        )
      )}

      {row2(
        'Tilt máximo', slider('tilt_max', 0, 35, 1, v => `${v}°`, v => onChange({tilt_max:parseInt(v)})),
        'Factor mant.', sel('maintenance_factor',[['0.80','0.80 — Frecuente'],['0.75','0.75 — Normal'],['0.70','0.70 — Sucio']])
      )}

      {sep('Objetivos de calidad')}

      {row2(
        'U0 mínimo', slider('U0_obj', 0.30, 0.80, 0.01, v => (+v).toFixed(2), v => onChange({U0_obj:parseFloat(v)})),
        'Ul mínimo', slider('Ul_obj', 0.40, 0.90, 0.01, v => (+v).toFixed(2), v => onChange({Ul_obj:parseFloat(v)}))
      )}

      {row2(
        'Sub-tipologías transición',
        slider('n_transition_subzones', 1, 10, 1, v => `${v}`, v => onChange({n_transition_subzones:parseInt(v)})),
        null, null
      )}
    </div>
  );
}

// ══════════════════════════════════════════════════════════════════
// LumModelsSummary — tabla compacta: modelos usados x cantidad + total
// ══════════════════════════════════════════════════════════════════
function LumModelsSummary({ luminairesResult }) {
  const zones = luminairesResult?.zones || [];
  if (!zones.length) return null;

  const counts = {};
  let total = 0;
  zones.forEach(z => {
    const sps = z.setpoints;
    if (sps && sps.length) {
      sps.forEach(sp => {
        const m = sp.model || '—';
        counts[m] = (counts[m] || 0) + 1;
        total += 1;
      });
    } else if ((z.n_luminaires || 0) > 0) {
      const m = z.model || '—';
      counts[m] = (counts[m] || 0) + z.n_luminaires;
      total += z.n_luminaires;
    }
  });
  const rows = Object.entries(counts).sort((a, b) => b[1] - a[1]);
  if (!rows.length) return null;

  return (
    <div style={{padding:'0 10px 10px'}}>
      <div style={{fontSize:'.63rem',fontWeight:700,color:'var(--salvi-blue)',textTransform:'uppercase',
                   letterSpacing:'.08em',margin:'12px 0 6px',borderBottom:'1px solid var(--salvi-line)',paddingBottom:3}}>
        Modelos utilizados
      </div>
      <table style={{width:'100%',fontSize:'.72rem',borderCollapse:'collapse'}}>
        <tbody>
          {rows.map(([model, n]) => (
            <tr key={model}>
              <td style={{padding:'2px 0',color:'var(--salvi-black)'}}>{model}</td>
              <td style={{padding:'2px 0',textAlign:'right',fontWeight:600,color:'var(--salvi-black)'}}>{n}</td>
            </tr>
          ))}
          <tr>
            <td style={{padding:'4px 0 0',fontWeight:700,borderTop:'1px solid var(--salvi-line)',color:'var(--salvi-black)'}}>Total luminarias</td>
            <td style={{padding:'4px 0 0',textAlign:'right',fontWeight:700,borderTop:'1px solid var(--salvi-line)',color:'var(--salvi-black)'}}>{total}</td>
          </tr>
        </tbody>
      </table>
    </div>
  );
}

// ══════════════════════════════════════════════════════════════════
// LuminaireSectionEditor — sección interactiva + cálculo + resultados
// ══════════════════════════════════════════════════════════════════
function LuminaireSectionEditor({ result, form, onChange, onGoToMap, toolbarSlot }) {
  // Persist lumResult across wizard navigation by seeding from form.luminaires_result
  const [lumResult,    setLumResult]   = useState(form.luminaires_result || null);
  const [photoResult,  setPhotoResult] = useState(null);
  const [loading,      setLoading]     = useState(false);
  const [error,        setError]       = useState(null);
  const [tiltOverrides,   setTiltOverrides]   = useState({});
  const [tandemOverrides, setTandemOverrides] = useState({});
  const [lumFilters,     setLumFilters]       = useState({});
  const [calcMode,      setCalcMode]      = useState('direct'); // 'direct' | 'radiosity'
  const [roi,           setRoi]           = useState({kwhCost:0.15, hoursYear:8760, treatCostM2:15, open:true});
  const [mousePos,      setMousePos]      = useState({x:0,y:0});

  // Sync lumResult if form.luminaires_result changes externally (e.g. tube switch)
  React.useEffect(() => {
    if (form.luminaires_result && !lumResult) {
      setLumResult(form.luminaires_result);
    }
  }, [form.luminaires_result]);

  // Sigue el cursor mientras dura el cálculo (feedback visual: puede tardar 1-2 min)
  React.useEffect(() => {
    if (!loading) return;
    const onMove = e => setMousePos({x:e.clientX, y:e.clientY});
    window.addEventListener('mousemove', onMove);
    return () => window.removeEventListener('mousemove', onMove);
  }, [loading]);

  if (!result?.success) return (
    <div style={{padding:24,textAlign:'center',color:'var(--salvi-grey)',fontSize:'.82rem'}}>
      Completa el cálculo CIE 88:2004 antes de dimensionar las luminarias.
    </div>
  );

  const lum = {...DEFAULT_LUM_CONFIG, ...(form.lum_config||{})};
  const W   = parseFloat(form.width_m)  || 8;
  const H   = parseFloat(form.height_m) || 5;

  const handleCalculate = async () => {
    setLoading(true); setError(null);
    try {
      const resp = await fetch('/api/tunnel/luminaires', {
        method:'POST', headers:{'Content-Type':'application/json'},
        body: JSON.stringify({...form, luminaire: lum, tilt_overrides: tiltOverrides, tandem_overrides: tandemOverrides, calc_mode: calcMode}),
      });
      const data = await resp.json();
      if (!data.success) { setError(data.error||'Error de cálculo'); return; }
      setLumResult(data.luminaires);
      setPhotoResult(data.photometric || null);
      onChange('luminaires_result', {...data.luminaires, arrangement: lum.arrangement});
      if (data.luminaires?.totals?.power_kw) onChange('installed_power_kw', data.luminaires.totals.power_kw);
    } catch(e) { setError(`Error: ${e.message}`); }
    finally { setLoading(false); }
  };

  // ── Arrangement buttons ────────────────────────────────────────
  const ARRANGEMENTS = [
    {id:'central_single',  label:'Central simple'},
    {id:'central_double',  label:'Central doble'},
    {id:'central_offset',  label:'Central desplazado'},
    {id:'lateral_left',    label:'Lateral izq.'},
    {id:'lateral_right',   label:'Lateral der.'},
    {id:'bilateral_sym',   label:'Bilateral sim.'},
    {id:'bilateral_stag',  label:'Bilateral alt.'},
  ];

  // ── Results tables ─────────────────────────────────────────────
  const MODEL_COLOR  = {S:'#f0fdf4',M:'#eff6ff',L:'#fdf2f8'};
  const MODEL_BORDER = {S:'#22c55e',M:'#3b82f6',L:'#a855f7'};

  return (
    <div style={{padding:'12px',display:'flex',flexDirection:'column',gap:12,flex:1,minHeight:0}}>

      {/* Indicador "Calculando…" que sigue al cursor (el cálculo puede tardar 1-2 min) */}
      {loading && ReactDOM.createPortal(
        <div style={{position:'fixed',left:mousePos.x+16,top:mousePos.y+16,zIndex:99999,pointerEvents:'none',
                     background:'var(--salvi-black)',color:'#fff',padding:'5px 10px',borderRadius:6,
                     fontSize:'.72rem',fontWeight:600,display:'flex',alignItems:'center',gap:6,
                     boxShadow:'0 2px 10px rgba(0,0,0,.35)',whiteSpace:'nowrap'}}>
          <svg width="12" height="12" viewBox="0 0 12 12" style={{animation:'spin 1s linear infinite',flexShrink:0}}>
            <circle cx="6" cy="6" r="5" fill="none" stroke="currentColor" strokeWidth="2" strokeDasharray="16 8"/>
          </svg>
          Calculando luminarias… (puede tardar 1-2 min)
        </div>,
        document.body
      )}

      {/* ── Cross-section + arrangement selector ── */}
      <div style={{background:'var(--salvi-surface)',border:'1px solid var(--salvi-line)',borderRadius:8,padding:'10px 12px'}}>
        <div style={{fontSize:'.68rem',fontWeight:700,color:'var(--salvi-grey)',marginBottom:6,textTransform:'uppercase',letterSpacing:'.07em'}}>
          Sección transversal — disposición de luminarias
        </div>
        <TunnelSectionPreview form={form} lumConfig={lum}/>
        <div style={{display:'flex',flexWrap:'wrap',gap:5,marginTop:8}}>
          {ARRANGEMENTS.map(({id,label})=>{
            const active = lum.arrangement===id;
            return (
              <button key={id}
                onClick={()=>onChange('lum_config',{...DEFAULT_LUM_CONFIG,...form.lum_config,arrangement:id})}
                style={{padding:'4px 9px',fontSize:'.66rem',fontWeight:active?700:400,cursor:'pointer',
                        border:`1.5px solid ${active?'var(--salvi-black)':'var(--salvi-line)'}`,borderRadius:5,
                        background:active?'var(--salvi-black)':'#fff',color:active?'#fff':'var(--salvi-grey)',
                        transition:'all .12s'}}>
                {label}
              </button>
            );
          })}
        </div>
      </div>

      {/* ── Modo + Calcular — trasladado al panel izquierdo vía portal ── */}
      {(() => {
        const toolbarContent = (
          <div>
            {error && <div style={{fontSize:'.7rem',color:'#b91c1c',background:'#fef2f2',border:'1px solid #fecaca',
                                   borderRadius:5,padding:'4px 8px',marginBottom:6}}>❌ {error}</div>}
            <div style={{display:'flex',alignItems:'center',gap:6,marginBottom:6}}>
              {/* Pill: Directo */}
              <button onClick={()=>setCalcMode('direct')}
                style={{flex:1,padding:'5px 8px',fontSize:'.71rem',fontWeight:calcMode==='direct'?700:500,
                        border:'1.5px solid var(--salvi-black)',borderRadius:999,cursor:'pointer',
                        background:'#fff',color:'var(--salvi-black)',whiteSpace:'nowrap',
                        transition:'all .12s',
                        boxShadow:calcMode==='direct'?'inset 0 0 0 2px var(--salvi-black)':'none'}}>
                Directo
              </button>

              {/* Toggle switch iOS-style */}
              <div onClick={()=>setCalcMode(calcMode==='direct'?'radiosity':'direct')}
                style={{position:'relative',width:36,height:20,borderRadius:10,cursor:'pointer',
                        background:'var(--salvi-black)',flexShrink:0,transition:'background .2s'}}>
                <div style={{position:'absolute',top:3,
                             left:calcMode==='direct'?3:17,
                             width:14,height:14,borderRadius:'50%',
                             background:'#fff',transition:'left .2s',boxShadow:'0 1px 3px rgba(0,0,0,.3)'}}/>
              </div>

              {/* Pill: con reflexiones */}
              <button onClick={()=>setCalcMode('radiosity')}
                style={{flex:1,padding:'5px 8px',fontSize:'.71rem',fontWeight:calcMode==='radiosity'?700:500,
                        border:'1.5px solid var(--salvi-black)',borderRadius:999,cursor:'pointer',
                        background:'#fff',color:'var(--salvi-black)',whiteSpace:'nowrap',
                        transition:'all .12s',
                        boxShadow:calcMode==='radiosity'?'inset 0 0 0 2px var(--salvi-black)':'none'}}>
                reflexiones
              </button>
            </div>

            {/* ▶ Calcular */}
            <button onClick={handleCalculate} disabled={loading} className="calc-btn"
              style={{display:'flex',alignItems:'center',justifyContent:'center',gap:7}}>
              {loading
                ? <svg width="12" height="12" viewBox="0 0 12 12" style={{animation:'spin 1s linear infinite'}}>
                    <circle cx="6" cy="6" r="5" fill="none" stroke="currentColor" strokeWidth="2" strokeDasharray="16 8"/>
                  </svg>
                : <svg width="10" height="12" viewBox="0 0 10 12" fill="currentColor">
                    <path d="M0 0L10 6L0 12V0Z"/>
                  </svg>
              }
              {loading ? 'Calculando…' : 'Calcular'}
            </button>
          </div>
        );
        return toolbarSlot ? ReactDOM.createPortal(toolbarContent, toolbarSlot) : toolbarContent;
      })()}

      {/* Mapa (solo si hay resultado) */}
      {lumResult && onGoToMap && (
        <div style={{display:'flex',marginBottom:6}}>
          <button onClick={onGoToMap} title="Ver en mapa"
            style={{padding:'5px 13px',fontSize:'.73rem',fontWeight:500,cursor:'pointer',
                    border:'1.5px solid var(--salvi-line)',borderRadius:999,
                    background:'#fff',color:'var(--salvi-black)',whiteSpace:'nowrap',
                    display:'flex',alignItems:'center',gap:5}}>
            🗺️ Mapa
          </button>
        </div>
      )}
      {calcMode==='radiosity' && (
        <div style={{fontSize:'.66rem',color:'#92400e',background:'#fffbeb',border:'1px solid #fde68a',
                     borderRadius:4,padding:'3px 8px',marginBottom:2}}>
          ρ paredes {form.rho_wall??0.40} · ρ techo {form.rho_ceiling??0.25}
        </div>
      )}

      {/* ── Results ── */}
      {lumResult && (() => {
        const MODELS = ['S','M','L'];
        const zoneList = [..._asArr(lumResult.zones)].sort((a,b)=>parseFloat(a.s_start)-parseFloat(b.s_start));
        const zoneKeys  = [...new Set(zoneList.map(z=>z.zone_type))];
        const zoneNames = [...new Set(zoneList.map(z=>z.zone_name))];
        const agg = {};
        MODELS.forEach(m=>{ agg[m]={totalN:0,pw:0,n:{}}; zoneKeys.forEach(k=>{agg[m].n[k]=0;}); });
        zoneList.forEach(z=>{
          if(z.model&&MODELS.includes(z.model)){
            agg[z.model].n[z.zone_type]=(agg[z.model].n[z.zone_type]||0)+z.n_luminaires;
            agg[z.model].totalN+=z.n_luminaires;
            agg[z.model].pw+=(z.power_zone_w||0);
          }
        });
        return (
          <>
            {/* KPI strip */}
            <div style={{display:'flex',gap:8,flexWrap:'wrap'}}>
              {[
                {label:'Potencia instalada', val:lumResult.totals.power_kw?.toFixed(2), unit:'kW'},
                {label:'W / luminaria',      val:((lumResult.totals.power_kw||0)*1000/(lumResult.totals.n_luminaires||1)).toFixed(0), unit:'W/ud'},
              ].map(({label,val,unit})=>(
                <div key={label} style={{flex:'1 1 130px',background:'var(--salvi-surface)',
                    border:'1px solid var(--salvi-line)',borderRadius:7,padding:'8px 12px'}}>
                  <div style={{fontSize:'.65rem',color:'var(--salvi-grey)',marginBottom:2}}>{label}</div>
                  <div style={{fontSize:'1.1rem',fontWeight:700}}>{val} <span style={{fontSize:'.68rem',fontWeight:400,color:'var(--salvi-grey)'}}>{unit}</span></div>
                </div>
              ))}
            </div>

            {/* Zone detail table */}
            <div style={{overflowX:'auto',background:'var(--salvi-surface)',border:'1px solid var(--salvi-line)',borderRadius:8}}>
              <table style={{width:'100%',borderCollapse:'collapse',fontSize:'.7rem'}}>
                <thead>
                  <tr style={{background:'#f8fafc'}}>
                    {['Zona','s ini (m)','s fin (m)','Modelo','Óptica','Inclin.','Tándem','N','d (m)','L_req','L_est','Margen','P zona (W)'].map(h=>(
                      <th key={h} style={{padding:'6px 8px',textAlign:h==='Zona'?'left':'right',
                        borderBottom:'1px solid var(--salvi-line)',whiteSpace:'nowrap',
                        fontWeight:700,color:'var(--salvi-grey)',fontSize:'.65rem'}}>{h}</th>
                    ))}
                  </tr>
                </thead>
                <tbody>
                  {zoneList.map((z,i)=>{
                    const bg  = MODEL_COLOR[z.model]  || '#fff';
                    const bd  = MODEL_BORDER[z.model] || '#e2e8f0';
                    const warn = z.warnings?.length > 0;
                    return (
                      <tr key={i} style={{background:bg,borderLeft:`3px solid ${bd}`}}>
                        <td style={{padding:'5px 8px',fontWeight:600}}>{z.zone_name}</td>
                        <td style={{padding:'5px 8px',textAlign:'right'}}>{parseFloat(z.s_start).toFixed(0)}</td>
                        <td style={{padding:'5px 8px',textAlign:'right'}}>{parseFloat(z.s_end).toFixed(0)}</td>
                        <td style={{padding:'5px 8px',textAlign:'right',fontWeight:700}}>Aphex {z.model}</td>
                        <td style={{padding:'5px 8px',textAlign:'right',fontFamily:'monospace',fontSize:'.68rem'}}>{z.optic||'—'}</td>
                        <td style={{padding:'3px 6px',textAlign:'right'}}>
                          <div style={{display:'flex',alignItems:'center',justifyContent:'flex-end',gap:2}}>
                            <input type='number' min='0' max='30' step='1'
                              value={tiltOverrides[z.zone_name] ?? z.tilt_deg ?? 0}
                              onChange={e=>setTiltOverrides(prev=>({...prev,[z.zone_name]:parseFloat(e.target.value)||0}))}
                              style={{width:42,textAlign:'right',border:'1px solid var(--salvi-line)',
                                borderRadius:3,padding:'1px 3px',fontSize:'.68rem',
                                fontWeight:(tiltOverrides[z.zone_name]??z.tilt_deg)>0?700:400,
                                color:(tiltOverrides[z.zone_name]??z.tilt_deg)>0?'#1d4ed8':'inherit'}}/>
                            <span style={{fontSize:'.65rem',color:'var(--salvi-grey)'}}>°</span>
                          </div>
                        </td>
                        {/* Tándem toggle */}
                        {(()=>{
                          const auto2x = z.n_tandem===2;
                          const ovr    = tandemOverrides[z.zone_name];
                          const eff    = ovr!==undefined ? ovr : auto2x;
                          const isAuto = ovr===undefined;
                          return(
                            <td style={{padding:'3px 6px',textAlign:'center'}}>
                              <button
                                title={eff?'Tándem activo — click para forzar individual':'Individual — click para forzar tándem'}
                                onClick={()=>{
                                  const next=!eff;
                                  if(next===auto2x){
                                    setTandemOverrides(p=>{const n={...p};delete n[z.zone_name];return n;});
                                  } else {
                                    setTandemOverrides(p=>({...p,[z.zone_name]:next}));
                                  }
                                }}
                                style={{fontSize:'.62rem',fontWeight:700,padding:'2px 6px',borderRadius:4,
                                  cursor:'pointer',border:'none',lineHeight:1.3,
                                  background:eff?(isAuto?'#dbeafe':'#ede9fe'):'#f3f4f6',
                                  color:eff?(isAuto?'#1d4ed8':'#7c3aed'):'#94a3b8'}}>
                                {eff?'⊕ 2×':'1×'}{isAuto&&eff?' ●':ovr!==undefined?' ✎':''}
                              </button>
                            </td>
                          );
                        })()}
                        <td style={{padding:'5px 8px',textAlign:'right'}}>{z.n_luminaires}</td>
                        <td style={{padding:'5px 8px',textAlign:'right'}}>{parseFloat(z.d_used||0).toFixed(1)}</td>
                        <td style={{padding:'5px 8px',textAlign:'right',fontWeight:600}}>{(z.L_required??z.L_min_required)?.toFixed(1)}</td>
                        <td style={{padding:'5px 8px',textAlign:'right',
                            color:(z.L_estimated!=null&&z.L_required>0&&(z.L_estimated/z.L_required)<0.95)?'#b91c1c':'#16a34a',
                            fontWeight:600}}>
                          {z.L_estimated?.toFixed(1)||'—'}
                        </td>
                        <td style={{padding:'5px 8px',textAlign:'right',fontSize:'.65rem',
                            color:(z.margin_pct!=null&&z.margin_pct<-5)?'#b91c1c':z.margin_pct>5?'#16a34a':'#64748b',
                            fontWeight:600}}>
                          {z.n_luminaires>0&&z.margin_pct!=null?(z.margin_pct>0?'+':'')+z.margin_pct.toFixed(0)+'%':'—'}
                        </td>
                        <td style={{padding:'5px 8px',textAlign:'right'}}>{(z.power_zone_w||0).toFixed(0)}</td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>

            {/* Model colour legend */}
            <div style={{display:'flex',gap:12,padding:'4px 0',fontSize:'.65rem',color:'var(--salvi-grey)'}}>
              {[['S','#22c55e'],['M','#3b82f6'],['L','#a855f7']].map(([m,c])=>(
                <span key={m} style={{display:'flex',alignItems:'center',gap:4}}>
                  <span style={{display:'inline-block',width:10,height:10,borderRadius:'50%',background:c}}/>
                  Aphex {m}
                </span>
              ))}
              <span style={{marginLeft:'auto',opacity:.6}}>🗺️ colores reproducidos en el mapa</span>
            </div>
            {/* Warnings: undersupplied zones — usa CIE 140 real si disponible */}
            {(() => {
              const unmet = zoneList.filter(z=>{
                if(!z.n_luminaires||z.n_luminaires<=0) return false;
                if(photoResult?.zones?.[z.zone_name]){
                  const pz=photoResult.zones[z.zone_name];
                  return z.L_required>0&&(pz.L_avg||0)<z.L_required*0.95;
                }
                return z.margin_pct!=null&&z.margin_pct<-5;
              });
              if(!unmet.length) return null;
              return (
                <div style={{background:'#fff1f2',border:'1px solid #fca5a5',borderRadius:6,padding:'8px 12px',fontSize:'.7rem'}}>
                  <div style={{fontWeight:700,color:'#b91c1c',marginBottom:4}}>
                    ⚠️ {unmet.length} zona{unmet.length>1?'s':''} no alcanzan la luminancia requerida con los parámetros actuales
                  </div>
                  {unmet.map((z,i)=>{
                    const pz=photoResult?.zones?.[z.zone_name];
                    const L_real=pz?pz.L_avg:null;
                    const L_show=L_real!=null?L_real:z.L_estimated;
                    const pct=z.L_required>0?Math.round((L_show/z.L_required-1)*100):null;
                    return (
                      <div key={i} style={{color:'#7f1d1d',marginBottom:6}}>
                        <div>
                          <b>{z.zone_name}</b>: L_req={z.L_required?.toFixed(0)} cd/m² → alcanzado {L_show?.toFixed(1)} cd/m²
                          {pct!=null?<span style={{color:'#b91c1c',fontWeight:700}}> ({pct}%)</span>:null}
                          <span style={{opacity:.7}}> · {L_real!=null?'CIE 140':'estimación opt.'}</span>
                        </div>
                        <div style={{opacity:.85,marginTop:1}}>
                          Posibles soluciones: <b>aumentar el flujo/corriente</b> (I_max o modelo de mayor potencia),{' '}
                          <b>reducir la interdistancia mínima</b>, o <b>replantear la boca del túnel</b> (orientación,
                          pantallas antideslumbrantes o apantallamiento de luz diurna para bajar el L20/Lth exigido).
                        </div>
                      </div>
                    );
                  })}
                </div>
              );
            })()}

            {/* Luminance layout */}
            {result?.chart?.L_required && (
              <div style={{background:'var(--salvi-surface)',border:'1px solid var(--salvi-line)',borderRadius:8,padding:'10px 12px'}}>
                <div style={{fontSize:'.68rem',fontWeight:700,color:'var(--salvi-grey)',marginBottom:8,
                    textTransform:'uppercase',letterSpacing:'.07em'}}>
                  Perfil longitudinal de luminancia
                </div>
                <TunnelLuminanceLayout result={result} lumResult={lumResult} photoResult={photoResult}/>
              </div>
            )}

            {/* CIE 140 verification */}
            {photoResult && (() => {
              if(!photoResult.available){
                return <div style={{fontSize:'.72rem',color:'#b91c1c',padding:'6px 0'}}>
                  ⚠️ {photoResult.error||'Motor fotométrico no disponible'}
                </div>;
              }
              /* Orden geográfico: CTH → CTR → CIN → CTR·B → CTH·B */
              const _ZP = (n) => n.startsWith('CTH·B')||n.startsWith('CTH2') ? 4
                               : n.startsWith('CTR2')||n.startsWith('CTR·B') ? 3
                               : n.startsWith('CIN')                         ? 2
                               : n.startsWith('CTR')                         ? 1
                               : n.startsWith('CTH')                         ? 0 : 5;
              const entries = Object.entries(photoResult.zones||{}).sort(([a],[b])=>_ZP(a)-_ZP(b));
              if(!entries.length) return null;
              return (
                <div style={{background:'var(--salvi-surface)',border:'1px solid var(--salvi-line)',borderRadius:8,padding:'10px 12px'}}>
                  <div style={{fontSize:'.68rem',fontWeight:700,color:'var(--salvi-grey)',marginBottom:4,
                      textTransform:'uppercase',letterSpacing:'.07em'}}>
                    Verificación CIE 140:2019
                  </div>
                  <div style={{fontSize:'.64rem',color:'var(--salvi-grey)',marginBottom:4}}>
                    Tabla {photoResult.rtable} · {photoResult.optic} · H={photoResult.H_m}m
                  </div>
                  {photoResult.calc_mode==='radiosity'&&(
                    <div style={{fontSize:'.66rem',color:'#6366f1',background:'#eef2ff',
                        borderRadius:4,padding:'3px 8px',marginBottom:6}}>
                      ✦ Con interreflexión — ρ par.={form.rho_wall??0.40} · ρ techo={form.rho_ceiling??0.25}
                    </div>
                  )}
                  <table style={{width:'100%',borderCollapse:'collapse',fontSize:'.7rem'}}>
                    <thead>
                      <tr style={{background:'#f8fafc'}}>
                        <th style={{padding:'5px 8px',textAlign:'left',borderBottom:'1px solid var(--salvi-line)',fontWeight:700,color:'var(--salvi-grey)',fontSize:'.65rem'}}>Zona</th>
                        <th style={{padding:'5px 8px',textAlign:'right',borderBottom:'1px solid var(--salvi-line)',fontWeight:700,color:'var(--salvi-grey)',fontSize:'.65rem'}}>L̄ (cd/m²)</th>
                        <th style={{padding:'5px 8px',textAlign:'right',borderBottom:'1px solid var(--salvi-line)',fontWeight:700,color:'#94a3b8',fontSize:'.65rem'}} title='Luminancia requerida CIE 88'>L_req</th>
                        {photoResult.calc_mode==='radiosity'&&(
                          <th style={{padding:'5px 8px',textAlign:'right',borderBottom:'1px solid var(--salvi-line)',fontWeight:700,color:'#6366f1',fontSize:'.65rem'}} title='Aporte indirecto paredes+techo'>L ind. (%)</th>
                        )}
                        <th style={{padding:'5px 8px',textAlign:'right',borderBottom:'1px solid var(--salvi-line)',fontWeight:700,color:'var(--salvi-grey)',fontSize:'.65rem'}}>U₀</th>
                        <th style={{padding:'5px 8px',textAlign:'right',borderBottom:'1px solid var(--salvi-line)',fontWeight:700,color:'var(--salvi-grey)',fontSize:'.65rem'}}>Uₗ</th>
                        <th style={{padding:'5px 8px',textAlign:'right',borderBottom:'1px solid var(--salvi-line)',fontWeight:700,color:'var(--salvi-grey)',fontSize:'.65rem'}}>TI (%)</th>
                        <th style={{padding:'5px 8px',textAlign:'center',borderBottom:'1px solid var(--salvi-line)',fontWeight:700,color:'var(--salvi-grey)',fontSize:'.65rem'}}>Estado</th>
                      </tr>
                    </thead>
                    <tbody>
                      {entries.map(([zname,zd])=>{
                        const zdes=zoneList.find(z=>z.zone_name===zname);
                        const Lreq=zdes?.L_required||0;
                        const lok=Lreq<=0||(zd.L_avg||0)>=Lreq*0.95;
                        const u0ok=(zd.U0||0)>=0.4, ulok=(zd.Ul||0)>=0.6, tiok=(zd.TI||99)<=15;
                        const ok=lok&&u0ok&&ulok&&tiok;
                        const rad=zd.radiosity||{};
                        return (
                          <tr key={zname} style={{borderBottom:'1px solid var(--salvi-line)',background:ok?'':'#fff5f5'}}>
                            <td style={{padding:'4px 8px',fontWeight:600}}>{zname}</td>
                            <td style={{padding:'4px 8px',textAlign:'right',color:lok?'inherit':'#b91c1c',fontWeight:lok?400:700}}>{(zd.L_avg||0).toFixed(1)}</td>
                            <td style={{padding:'4px 8px',textAlign:'right',color:'#94a3b8',fontSize:'.64rem'}}>{Lreq>0?Lreq.toFixed(0):'—'}</td>
                            {photoResult.calc_mode==='radiosity'&&(
                              <td style={{padding:'4px 8px',textAlign:'right',color:'#6366f1',fontSize:'.64rem'}}>
                                {rad.L_indirect!=null?`+${rad.L_indirect} (${rad.pct}%)`:'—'}
                              </td>
                            )}
                            <td style={{padding:'4px 8px',textAlign:'right',color:u0ok?'#166534':'#b91c1c',fontWeight:700}}>{(zd.U0||0).toFixed(3)}</td>
                            <td style={{padding:'4px 8px',textAlign:'right',color:ulok?'#166534':'#b91c1c',fontWeight:700}}>{(zd.Ul||0).toFixed(3)}</td>
                            <td style={{padding:'4px 8px',textAlign:'right',color:tiok?'#166534':'#b91c1c',fontWeight:700}}>{(zd.TI||0).toFixed(1)}</td>
                            <td style={{padding:'4px 8px',textAlign:'center',fontSize:'.65rem'}}>{ok?'✅ Cumple':'⚠️ REVISAR'}</td>
                          </tr>
                        );
                      })}
                    </tbody>
                  </table>
                </div>
              );
            })()}

            {/* ── Curva de decaimiento L(s) real vs. teórica CIE 88 ──────
                 Perfil real a resolución fina (misma interdistancia que la
                 curva teórica), calculado punto a punto con el layout físico
                 completo del túnel — muestra el rizado real entre luminarias
                 en vez de un punto por luminaria conectado con una línea
                 recta (que en escala log se hunde por debajo del valor real
                 entre posiciones muy separadas). Si el motor fino no está
                 disponible, se cae al método anterior (un punto por
                 luminaria) como respaldo. */}
            {result.chart && zoneList.length>0 && (() => {
              const fineProfile = photoResult?.real_profile;
              let actualPoints;
              if (fineProfile?.available && fineProfile.points?.length) {
                actualPoints = fineProfile.points.map(p => ({
                  s: parseFloat(p.s), L: parseFloat(p.L),
                  Lreq: null, U0: null, Ul: null,
                }));
              } else {
                actualPoints = [];
                zoneList.forEach(z => {
                  (z.setpoints||[]).forEach(sp => {
                    if (sp && sp.s != null && sp.L_est != null) {
                      actualPoints.push({
                        s: parseFloat(sp.s), L: parseFloat(sp.L_est),
                        Lreq: sp.L_req!=null ? parseFloat(sp.L_req) : null,
                        U0: sp.U0!=null ? parseFloat(sp.U0) : null,
                        Ul: sp.Ul!=null ? parseFloat(sp.Ul) : (z.Ul!=null ? parseFloat(z.Ul) : null),
                      });
                    }
                  });
                });
              }
              if (!actualPoints.length) return null;
              return (
                <div style={{background:'var(--salvi-surface)',border:'1px solid var(--salvi-line)',
                             borderRadius:8,padding:'10px 12px'}}>
                  <div style={{fontSize:'.68rem',fontWeight:700,color:'var(--salvi-grey)',
                      textTransform:'uppercase',letterSpacing:'.07em',marginBottom:6}}>
                    Curva de decaimiento L(s) — calculada vs. CIE 88
                    {!fineProfile?.available && (
                      <span style={{fontWeight:400,textTransform:'none',color:'#b45309',marginLeft:6}}>
                        (perfil fino no disponible — mostrando un punto por luminaria)
                      </span>
                    )}
                  </div>
                  <ProfileChart chartData={result.chart} tunnelLength={result.summary.length_m}
                    Lth={result.summary.Lth} Lin={result.summary.Lin} zones={result.zones}
                    actualPoints={actualPoints} denseActual={!!fineProfile?.available}/>
                </div>
              );
            })()}

            {/* ── Lista de luminarias ──────────────────────────────────── */}
            {zoneList.filter(z=>z.n_luminaires>0).length>0&&(()=>{
              /* Parámetros geométricos */
              const W_m        = parseFloat(form.width_m)||11.5;
              const wo         = parseFloat(lum?.wall_offset_m||0.30);
              const arr        = lumResult.arrangement||'bilateral_sym';

              /* GPS — disponible si el usuario ha fijado el portal en el mapa */
              const hasGPS = !!(parseFloat(form.lat) && parseFloat(form.lng));
              const _entryLat = parseFloat(form.lat)||0;
              const _entryLng = parseFloat(form.lng)||0;
              const _OCTANT   = {N:0,NE:45,E:90,SE:135,S:180,SW:225,W:270,NW:315};
              const _bearing  = _OCTANT[form.portal_orientation]??180;
              const _moveAlong = (latD,lngD,distM,brg) => {
                const R=6371000,d=distM/R,th=brg*Math.PI/180;
                const p1=latD*Math.PI/180,l1=lngD*Math.PI/180;
                const p2=Math.asin(Math.sin(p1)*Math.cos(d)+Math.cos(p1)*Math.sin(d)*Math.cos(th));
                const l2=l1+Math.atan2(Math.sin(th)*Math.sin(d)*Math.cos(p1),Math.cos(d)-Math.sin(p1)*Math.sin(p2));
                return [p2*180/Math.PI,(l2*180/Math.PI+540)%360-180];
              };
              const _lumGPS = (xM, yM) => {
                /* eje del túnel a distancia xM desde portal A */
                const [axLat,axLng] = _moveAlong(_entryLat,_entryLng,xM,_bearing);
                /* desplazamiento transversal: y=0 → pared izq, y=W_m → pared der */
                const perpBrg = (_bearing+90)%360;
                const [lat,lng] = _moveAlong(axLat,axLng,yM-W_m/2,perpBrg);
                return [lat.toFixed(6),lng.toFixed(6)];
              };
              const ys = arr==='bilateral_sym'||arr==='bilateral_stag'||arr==='bilateral'||arr==='staggered'
                            ? [wo, W_m-wo]
                            : arr==='central_double'
                              ? [W_m/2-0.30, W_m/2+0.30]
                              : arr==='lateral_left' ? [wo]
                              : arr==='lateral_right'||arr==='unilateral' ? [W_m-wo]
                              : [W_m/2];

              /* Construir lista individual de luminarias */
              let lumList=[], gid=1;
              for(const z of zoneList.filter(z=>z.n_luminaires>0)){
                const hasSP  = z.setpoints && z.setpoints.length===z.n_luminaires;
                const dAct   = parseFloat(z.d_used)||1;
                const sStart = parseFloat(z.s_start)||0;
                const n      = z.n_luminaires;
                for(let i=0;i<n;i++){
                  const sp  = hasSP ? z.setpoints[i] : null;
                  const xPos = sp ? parseFloat(sp.s) : sStart+(i+0.5)*dAct;
                  for(const yPos of ys){
                    lumList.push({
                      id:     gid++,
                      zone:   z.zone_name,
                      x:      xPos,
                      y:      yPos,
                      model:  sp?sp.model:z.model,
                      pcb:    z.pcb,
                      optic:  sp?sp.optic:z.optic,
                      tilt:   sp!=null?sp.tilt_deg:z.tilt_deg,
                      mA:     sp?sp.current_mA:z.current_mA,
                      W:      sp?sp.power_w:z.power_w,
                      L_req:  sp?sp.L_req:z.L_required,
                      L_est:  sp?.L_est ?? z.L_estimated,
                      U0:     sp?.U0 ?? z.UF,
                      Ul:     z.Ul,
                      tandem: sp?.tandem||null,
                      pair:   sp?.pair??null,
                    });
                  }
                }
              }
              /* Distancia al siguiente de la MISMA fila (y) — con varias filas
                 (bilateral/central doble/tándem) el siguiente en la lista suele
                 ser el de la otra fila, así que hay que buscar hacia delante. */
              for(let i=0;i<lumList.length;i++){
                const cur=lumList[i];
                let nxt=null;
                for(let j=i+1;j<lumList.length;j++){
                  if(lumList[j].zone!==cur.zone) break;
                  if(Math.abs(lumList[j].y-cur.y)<0.01){ nxt=lumList[j]; break; }
                }
                cur.d_nxt = nxt ? (nxt.x-cur.x).toFixed(1) : '—';
              }

              const familyOfM=m=>!m?'M':(/_S_|^S$/.test(m)?'S':/_M_|^M$/.test(m)?'M':/_L_|^L$/.test(m)?'L':'M');
              const clrM=m=>{const f=familyOfM(m); return f==='S'?'#22c55e':f==='M'?'#3b82f6':'#a855f7';};

              /* ── Filtros por columna ──────────────────────────────────────
                 Un input de texto libre por columna. Numéricas aceptan
                 operador + valor (">0.4", "<=20", "!=0") o rango ("10-50");
                 sin operador reconocido cae a comparación exacta o texto. */
              const LUM_COL_DEFS = [
                { type:'num',  get: lm => lm.id },
                { type:'text', get: lm => lm.zone },
                { type:'text', get: lm => lm.tandem || '' },
                { type:'num',  get: lm => lm.x },
                { type:'num',  get: lm => lm.y },
                { type:'num',  get: lm => (lm.d_nxt==='—' ? null : parseFloat(lm.d_nxt)) },
                { type:'text', get: lm => lm.pcb || lm.model || '' },
                { type:'text', get: lm => lm.optic || '' },
                { type:'num',  get: lm => lm.tilt!=null ? parseFloat(lm.tilt) : null },
                { type:'num',  get: lm => lm.mA!=null ? parseFloat(lm.mA) : null },
                { type:'num',  get: lm => lm.W!=null ? parseFloat(lm.W) : null },
                { type:'num',  get: lm => lm.L_req },
                { type:'num',  get: lm => lm.L_est },
                { type:'num',  get: lm => lm.U0 },
                { type:'num',  get: lm => lm.Ul },
                ...(hasGPS ? [
                  { type:'num', get: lm => parseFloat(_lumGPS(lm.x, lm.y)[0]) },
                  { type:'num', get: lm => parseFloat(_lumGPS(lm.x, lm.y)[1]) },
                ] : []),
              ];
              const _matchNum = (value, filterStr) => {
                if (!filterStr) return true;
                if (value == null || isNaN(value)) return false;
                const s = filterStr.trim();
                const m = s.match(/^(>=|<=|!=|>|<|=)?\s*(-?\d+\.?\d*)$/);
                if (m) {
                  const op = m[1] || '=';
                  const num = parseFloat(m[2]);
                  if (op==='>')  return value >  num;
                  if (op==='>=') return value >= num;
                  if (op==='<')  return value <  num;
                  if (op==='<=') return value <= num;
                  if (op==='!=') return Math.abs(value-num) > 1e-9;
                  return Math.abs(value-num) < 1e-9;
                }
                const r = s.match(/^(-?\d+\.?\d*)\s*-\s*(-?\d+\.?\d*)$/);
                if (r) {
                  const a = parseFloat(r[1]), b = parseFloat(r[2]);
                  return value >= Math.min(a,b) && value <= Math.max(a,b);
                }
                return String(value).includes(s);
              };
              const _matchText = (value, filterStr) =>
                !filterStr || String(value||'').toLowerCase().includes(filterStr.trim().toLowerCase());
              const filteredLumList = lumList.filter(lm =>
                LUM_COL_DEFS.every((col, i) => {
                  const f = lumFilters[i];
                  if (!f) return true;
                  return col.type==='num' ? _matchNum(col.get(lm), f) : _matchText(col.get(lm), f);
                })
              );
              const lumFiltersActive = Object.values(lumFilters).some(v => v);

              /* Exportar la tabla a .xls real (SpreadsheetML/HTML, MIME ms-excel) —
                 sin depender de ninguna libreria externa; Excel lo abre nativamente. */
              const exportLumListXls = () => {
                const headers = [...['ID','Zona','Par','x (m)','y (m)','d→ (m)','Modelo Aphex','Óptica',
                  'Tilt (°)','mA','W','L_req (cd/m²)','L_est (cd/m²)','U0','Ul'], ...(hasGPS?['Lat','Lon']:[])];
                const rows = filteredLumList.map(lm => {
                  const row = [
                    lm.id, lm.zone, lm.tandem||'', lm.x.toFixed(1), lm.y.toFixed(2), lm.d_nxt,
                    lm.pcb||lm.model||'', lm.optic||'', lm.tilt!=null?parseFloat(lm.tilt).toFixed(0):'0',
                    lm.mA?Math.round(parseFloat(lm.mA)):'', lm.W?Math.round(parseFloat(lm.W)):'',
                    lm.L_req>0?parseFloat(lm.L_req).toFixed(0):'', lm.L_est!=null?parseFloat(lm.L_est).toFixed(1):'',
                    lm.U0!=null?parseFloat(lm.U0).toFixed(3):'', lm.Ul!=null?parseFloat(lm.Ul).toFixed(3):'',
                  ];
                  if (hasGPS) { const [lt,ln]=_lumGPS(lm.x,lm.y); row.push(lt,ln); }
                  return row;
                });
                const esc = s => String(s).replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;');
                const thead = `<tr>${headers.map(h=>`<th>${esc(h)}</th>`).join('')}</tr>`;
                const tbody = rows.map(r=>`<tr>${r.map(c=>`<td>${esc(c)}</td>`).join('')}</tr>`).join('');
                const html = `<html xmlns:o="urn:schemas-microsoft-com:office:office" xmlns:x="urn:schemas-microsoft-com:office:excel" xmlns="http://www.w3.org/TR/REC-html40">
<head><meta charset="UTF-8"><!--[if gte mso 9]><xml><x:ExcelWorkbook><x:ExcelWorksheets><x:ExcelWorksheet><x:Name>Luminarias</x:Name><x:WorksheetOptions><x:DisplayGridlines/></x:WorksheetOptions></x:ExcelWorksheet></x:ExcelWorksheets></x:ExcelWorkbook></xml><![endif]--></head>
<body><table border="1">${thead}${tbody}</table></body></html>`;
                const blob = new Blob(['﻿'+html], {type:'application/vnd.ms-excel'});
                const url = URL.createObjectURL(blob);
                const a = document.createElement('a');
                a.href = url; a.download = `lista_luminarias_${form.tube_id||'T1'}.xls`;
                document.body.appendChild(a); a.click(); document.body.removeChild(a);
                URL.revokeObjectURL(url);
              };

              return (
                <div style={{background:'var(--salvi-surface)',border:'1px solid var(--salvi-line)',borderRadius:8,padding:'10px 12px'}}>
                  <div style={{display:'flex',alignItems:'center',gap:8,marginBottom:6}}>
                    <div style={{fontSize:'.68rem',fontWeight:700,color:'var(--salvi-grey)',
                        textTransform:'uppercase',letterSpacing:'.07em'}}>
                      Lista de luminarias ({filteredLumList.length}{lumFiltersActive?` / ${lumList.length}`:''} unidades)
                    </div>
                    {lumFiltersActive && (
                      <button onClick={()=>setLumFilters({})}
                        style={{padding:'3px 10px',fontSize:'.68rem',fontWeight:600,cursor:'pointer',
                          borderRadius:4,border:'1px solid var(--salvi-line)',
                          background:'#fff',color:'#b91c1c'}}>
                        ✕ Limpiar filtros
                      </button>
                    )}
                    <button onClick={exportLumListXls}
                      style={{marginLeft:lumFiltersActive?0:'auto',padding:'3px 10px',fontSize:'.68rem',fontWeight:600,
                        cursor:'pointer',borderRadius:4,border:'1px solid var(--salvi-line)',
                        background:'#fff',color:'var(--salvi-black)',display:'flex',alignItems:'center',gap:5}}>
                      📊 Exportar a Excel
                    </button>
                  </div>
                  <div style={{overflowY:'auto',maxHeight:320,border:'1px solid var(--salvi-line)',borderRadius:4}}>
                    <table style={{width:'100%',borderCollapse:'collapse',fontSize:'.63rem'}}>
                      <thead style={{position:'sticky',top:0,background:'#f8fafc',zIndex:1}}>
                        <tr>
                          {[...['ID','Zona','Par','x (m)','y (m)','d→ (m)','Modelo Aphex','Lente','Tilt','mA','W','L_req','L_est','U0','Ul'],...(hasGPS?['Lat','Lon']:[])].map((h,i)=>(
                            <th key={i} style={{padding:'3px 6px',textAlign:i>=2?'right':'left',
                                borderBottom:'1px solid var(--salvi-line)',
                                fontWeight:700,color:'var(--salvi-grey)',whiteSpace:'nowrap',fontSize:'.61rem'}}>
                              {h}
                            </th>
                          ))}
                        </tr>
                        <tr>
                          {LUM_COL_DEFS.map((col,i)=>(
                            <th key={i} style={{padding:'2px 4px',borderBottom:'2px solid var(--salvi-line)',background:'#fff'}}>
                              <input value={lumFilters[i]||''}
                                onChange={e=>setLumFilters(prev=>({...prev,[i]:e.target.value}))}
                                placeholder={col.type==='num'?'>0.4':'texto'}
                                style={{width:'100%',boxSizing:'border-box',fontSize:'.6rem',padding:'2px 4px',
                                  border:'1px solid var(--salvi-line)',borderRadius:3,fontWeight:400}}/>
                            </th>
                          ))}
                        </tr>
                      </thead>
                      <tbody>
                        {filteredLumList.map((lm,i)=>{
                          const clr=clrM(lm.model);
                          const isNewZone=i===0||filteredLumList[i-1].zone!==lm.zone;
                          const insufficient = lm.L_req>0 && lm.L_est!=null && (lm.L_est/lm.L_req)<0.95;
                          return (
                            <tr key={i} style={{
                              borderBottom:'1px solid #f1f5f9',
                              borderLeft:insufficient?'3px solid #dc2626':'3px solid transparent',
                              background:insufficient?'#fef2f2':lm.tandem?'#f5f0ff':isNewZone&&i>0?'#f0f4ff':''}}>
                              <td style={{padding:'2px 6px',color:'#94a3b8',fontFamily:'monospace'}}>
                                {lm.tandem?<span style={{color:'#7c3aed',fontSize:'.6rem'}}>⊕ </span>:null}{lm.id}
                              </td>
                              <td style={{padding:'2px 6px',fontWeight:600,whiteSpace:'nowrap'}}>{lm.zone}</td>
                              <td style={{padding:'2px 6px',textAlign:'center',fontWeight:700,fontSize:'.62rem',
                                  color:lm.tandem?'#7c3aed':'#d1d5db'}}>
                                {lm.tandem||'—'}
                              </td>
                              <td style={{padding:'2px 6px',textAlign:'right',fontFamily:'monospace'}}>{lm.x.toFixed(1)}</td>
                              <td style={{padding:'2px 6px',textAlign:'right',fontFamily:'monospace'}}>{lm.y.toFixed(2)}</td>
                              <td style={{padding:'2px 6px',textAlign:'right',color:'#64748b'}}>{lm.d_nxt}</td>
                              <td style={{padding:'2px 6px',textAlign:'right',whiteSpace:'nowrap'}}>
                                <span style={{background:clr,color:'#fff',borderRadius:3,padding:'1px 5px',fontWeight:700}}>
                                  {lm.pcb||lm.model||'—'}
                                </span>
                              </td>
                              <td style={{padding:'2px 6px',textAlign:'right',fontFamily:'monospace',fontWeight:600}}>{lm.optic||'—'}</td>
                              <td style={{padding:'2px 6px',textAlign:'right'}}>{lm.tilt!=null?parseFloat(lm.tilt).toFixed(0)+'°':'0°'}</td>
                              <td style={{padding:'2px 6px',textAlign:'right',fontWeight:600}}>{lm.mA?Math.round(parseFloat(lm.mA)):'-'}</td>
                              <td style={{padding:'2px 6px',textAlign:'right'}}>{lm.W?Math.round(parseFloat(lm.W)):'-'}</td>
                              <td style={{padding:'2px 6px',textAlign:'right',fontWeight:insufficient?700:400,
                                  color:insufficient?'#b91c1c':'#94a3b8'}}
                                  title={insufficient?`Insuficiente: alcanzado ≈${lm.L_est.toFixed(0)} cd/m² de ${parseFloat(lm.L_req).toFixed(0)} requeridos`:undefined}>
                                {lm.L_req>0?parseFloat(lm.L_req).toFixed(0):'—'}{insufficient?' ⚠':''}
                              </td>
                              <td style={{padding:'2px 6px',textAlign:'right',fontWeight:insufficient?700:400,
                                  color:insufficient?'#b91c1c':'#16a34a'}}>
                                {lm.L_est!=null?parseFloat(lm.L_est).toFixed(1):'—'}
                              </td>
                              <td style={{padding:'2px 6px',textAlign:'right',color:lm.U0!=null&&lm.U0<0.40?'#b91c1c':'#64748b'}}>
                                {lm.U0!=null?parseFloat(lm.U0).toFixed(3):'—'}
                              </td>
                              <td style={{padding:'2px 6px',textAlign:'right',color:lm.Ul!=null&&lm.Ul<0.60?'#b91c1c':'#64748b'}}>
                                {lm.Ul!=null?parseFloat(lm.Ul).toFixed(3):'—'}
                              </td>
                              {hasGPS&&(()=>{const [lt,ln]=_lumGPS(lm.x,lm.y);return(<>
                                <td style={{padding:'2px 6px',textAlign:'right',fontFamily:'monospace',fontSize:'.59rem',color:'#0ea5e9'}}>{lt}</td>
                                <td style={{padding:'2px 6px',textAlign:'right',fontFamily:'monospace',fontSize:'.59rem',color:'#0ea5e9'}}>{ln}</td>
                              </>);})()}
                            </tr>
                          );
                        })}
                      </tbody>
                    </table>
                  </div>
                  <div style={{fontSize:'.6rem',color:'var(--salvi-grey)',marginTop:4,opacity:.7}}>
                    x = posición eje túnel (m desde portal A) · y = transversal desde pared izq. · d→ = distancia al siguiente mismo lado · Par A/B = luminarias en tándem (⊕)
                    {hasGPS?' · Lat/Lon (WGS84) calculadas desde portal A':'  · Configure posición del portal en el mapa para obtener Lat/Lon'}
                  </div>
                </div>
              );
            })()}

            {/* ── Vista 3D — recorrido del conductor ──────────────────────── */}
            {zoneList.filter(z=>z.n_luminaires>0).length>0 && (()=>{
              const W_m3    = parseFloat(form.width_m)||11.5;
              const H_m3    = parseFloat(form.height_m)||5.5;
              const Hp_m3   = parseFloat(form.H_pared_m) ?? 3.0;
              const shape3  = form.tunnel_shape||'horseshoe';
              const mountH3 = parseFloat(lum?.mounting_height_m)||4.5;
              const arr3    = lumResult.arrangement||'bilateral_sym';
              const wo3     = Math.max(0.05, parseFloat(lum?.wall_offset_m)||0.30);
              const tubeLen3 = parseFloat(result?.summary?.length_m)
                || zoneList.reduce((m,z)=>Math.max(m,parseFloat(z.s_end)||0),0);

              const ys3 = ['bilateral_sym','bilateral_stag','bilateral','staggered'].includes(arr3)
                            ? [wo3, W_m3-wo3]
                            : arr3==='central_double' ? [W_m3/2-0.30, W_m3/2+0.30]
                            : arr3==='lateral_left' ? [wo3]
                            : ['lateral_right','unilateral'].includes(arr3) ? [W_m3-wo3]
                            : [W_m3/2];

              const lumList3 = [];
              zoneList.filter(z=>z.n_luminaires>0).forEach(z=>{
                const hasSP  = z.setpoints && z.setpoints.length===z.n_luminaires;
                const dAct   = parseFloat(z.d_used)||1;
                const sStart = parseFloat(z.s_start)||0;
                for(let i=0;i<z.n_luminaires;i++){
                  const sp      = hasSP ? z.setpoints[i] : null;
                  const xPos    = sp ? parseFloat(sp.s) : sStart+(i+0.5)*dAct;
                  const model   = sp ? sp.model : z.model;
                  const tilt    = sp?.tilt_deg ?? z.tilt_deg ?? 0;
                  const fluxLm  = parseFloat(sp?.flux_lm ?? z.flux_lm) || 0;
                  for(const yPos of ys3){ lumList3.push({ x:xPos, y:yPos, model, tilt, flux_lm:fluxLm }); }
                }
              });

              if (!lumList3.length || !(tubeLen3>0)) return null;
              return (
                <Tunnel3DDrive lumList={lumList3} W_m={W_m3} H_m={H_m3} shape={shape3}
                  H_pared_m={Hp_m3} tubeLength={tubeLen3} mountH={mountH3}
                  speedKmh={parseFloat(form.speed_kmh)||80}
                  roadSurface={form.road_surface||'dark_asphalt'}
                  numLanes={parseInt(form.num_lanes)||2}
                  laneWidthM={parseFloat(form.lane_width_m)||3.5}
                  shoulderLeftM={parseFloat(form.shoulder_left_m)||0}
                  shoulderRightM={parseFloat(form.shoulder_right_m)||0}
                  cct={lumResult.cct||lum?.cct||'4000K'}
                  rhoWall={parseFloat(form.rho_wall)||0.40}
                  rhoCeiling={parseFloat(form.rho_ceiling)||0.25}/>
              );
            })()}

            {/* ── Panel ahorro energético y ROI paredes reflectantes ─────── */}
            {photoResult?.calc_mode==='radiosity'&&(()=>{
              /* Geometría del túnel */
              const W_roi = parseFloat(form.width_m)||10.5;
              const H_roi = parseFloat(form.height_m)||5.5;
              const L_roi = parseFloat(form.length_m)||500;
              const shp   = form.tunnel_shape||'horseshoe';
              /* Superficie a tratar: paredes + techo (sin pavimento) */
              const surfM2 = shp==='circular'
                ? Math.PI*(W_roi/2)*L_roi
                : (2*H_roi + W_roi)*L_roi;

              /* Cálculo de ahorro potencial por zona */
              const sortedZ = [..._asArr(lumResult.zones)].sort((a,b)=>parseFloat(a.s_start)-parseFloat(b.s_start));
              let totalLen=0, weightedSaving=0, hasInd=false;
              for(const z of sortedZ.filter(z=>z.n_luminaires>0)){
                const pz = photoResult.zones?.[z.zone_name];
                if(!pz) continue;
                const zLen = parseFloat(z.zone_length)||0;
                const Lreq = parseFloat(z.L_required)||0;
                const Lavg = pz.L_avg||0;
                const Lind = pz.L_indirect||0;
                totalLen += zLen;
                if(Lind>0) hasInd=true;
                /* Si la zona está sobreiluminada gracias al aporte indirecto, se puede reducir potencia */
                if(Lavg>Lreq*1.02&&Lreq>0&&Lavg>0){
                  weightedSaving += zLen*(Lavg-Lreq)/Lavg;
                }
              }
              if(!hasInd||totalLen===0) return null;

              const savFrac  = weightedSaving/totalLen;
              const totalW   = (lumResult.totals?.power_kw||0)*1000;
              const savW     = Math.round(totalW*savFrac);
              const savKwhY  = Math.round(savW*(roi.hoursYear/1000));
              const savEurY  = savKwhY*roi.kwhCost;
              const invest   = surfM2*roi.treatCostM2;
              const payback  = savEurY>0 ? invest/savEurY : null;

              const numFmt = n => Math.round(n).toLocaleString('es-ES');
              const monFmt = n => n.toLocaleString('es-ES',{style:'currency',currency:'EUR',maximumFractionDigits:0});

              return(
                <div style={{background:'var(--salvi-surface)',border:'1px solid #6366f1',
                    borderRadius:8,padding:'10px 12px',borderLeft:'4px solid #6366f1'}}>

                  {/* Cabecera colapsable */}
                  <div style={{display:'flex',alignItems:'center',gap:6,cursor:'pointer'}}
                       onClick={()=>setRoi(r=>({...r,open:!r.open}))}>
                    <span style={{fontSize:'1rem',color:'#6366f1'}}>✦</span>
                    <div style={{fontSize:'.68rem',fontWeight:700,color:'#6366f1',
                        textTransform:'uppercase',letterSpacing:'.07em',flex:1}}>
                      Ahorro energético · Retorno inversión paredes reflectantes
                    </div>
                    <span style={{fontSize:'.65rem',color:'#6366f1'}}>{roi.open?'▲':'▼'}</span>
                  </div>

                  {roi.open&&(
                    <div style={{marginTop:8}}>
                      <div style={{fontSize:'.64rem',color:'#4b5563',marginBottom:8,lineHeight:1.5}}>
                        El aporte indirecto de paredes y techo permite dimmear las luminarias
                        un <strong>{Math.round(savFrac*100)}%</strong> en promedio ponderado por zona,
                        manteniendo los niveles CIE 88. Ajusta los parámetros económicos:
                      </div>

                      {/* Inputs */}
                      <div style={{display:'grid',gridTemplateColumns:'1fr 1fr 1fr',gap:8,marginBottom:10}}>
                        {[
                          {label:'Coste energía (€/kWh)',   key:'kwhCost',      min:0.05,max:0.60, step:0.01},
                          {label:'Horas de operación/año',  key:'hoursYear',    min:1000,max:8760, step:100},
                          {label:'Coste tratamiento (€/m²)',key:'treatCostM2',  min:1,   max:150,  step:1},
                        ].map(({label,key,min,max,step})=>(
                          <div key={key} style={{display:'flex',flexDirection:'column',gap:3}}>
                            <label style={{fontSize:'.6rem',color:'var(--salvi-grey)',fontWeight:600}}>{label}</label>
                            <input type="number" min={min} max={max} step={step}
                              value={roi[key]}
                              onChange={e=>setRoi(r=>({...r,[key]:parseFloat(e.target.value)||r[key]}))}
                              style={{width:'100%',padding:'3px 6px',border:'1px solid var(--salvi-line)',
                                borderRadius:4,fontSize:'.68rem',textAlign:'right',
                                background:'var(--salvi-bg)'}}/>
                          </div>
                        ))}
                      </div>

                      {/* KPIs */}
                      <div style={{display:'grid',gridTemplateColumns:'repeat(4,1fr)',gap:8,marginBottom:8}}>
                        {[
                          {label:'Reducción de potencia',
                           val:`${numFmt(savW)} W`,
                           sub:`${Math.round(savFrac*100)}% de ${numFmt(totalW)} W inst.`,
                           clr:'#059669'},
                          {label:'Ahorro energético anual',
                           val:monFmt(savEurY),
                           sub:`${numFmt(savKwhY)} kWh/año`,
                           clr:'#059669'},
                          {label:'Inversión tratamiento',
                           val:monFmt(invest),
                           sub:`${numFmt(Math.round(surfM2))} m² · ${roi.treatCostM2} €/m²`,
                           clr:'#6366f1'},
                          {label:'Retorno simple',
                           val:payback?`${payback.toFixed(1)} años`:'—',
                           sub:payback?(payback<8?'✅ Rentable':payback<15?'⚠️ Analizar':'❌ Largo plazo'):'Sin excedente',
                           clr:payback?(payback<8?'#059669':payback<15?'#d97706':'#b91c1c'):'#94a3b8'},
                        ].map(({label,val,sub,clr})=>(
                          <div key={label} style={{background:'#f8fafc',borderRadius:6,
                              padding:'8px 10px',border:'1px solid var(--salvi-line)'}}>
                            <div style={{fontSize:'.58rem',color:'var(--salvi-grey)',fontWeight:600,
                                marginBottom:2,textTransform:'uppercase',letterSpacing:'.06em'}}>{label}</div>
                            <div style={{fontSize:'.82rem',fontWeight:700,color:clr}}>{val}</div>
                            <div style={{fontSize:'.58rem',color:'#94a3b8',marginTop:1}}>{sub}</div>
                          </div>
                        ))}
                      </div>

                      <div style={{fontSize:'.58rem',color:'#94a3b8',fontStyle:'italic',lineHeight:1.4}}>
                        * Ahorro teórico asumiendo dimming DALI proporcional por zona. Sólo válido cuando el cálculo
                        en modo Radiosidad (✦) muestra zonas con L_avg &gt; L_req. Superficie estimada:
                        {' '}{numFmt(Math.round(surfM2))} m² (paredes + techo, sin pavimento).
                        ρ activos: paredes={form.rho_wall??0.40} · techo={form.rho_ceiling??0.25}.
                      </div>
                    </div>
                  )}
                </div>
              );
            })()}
          </>
        );
      })()}
    </div>
  );
}

/* ══════════════════════════════════════════════════════════════════
   App — componente raíz
   ══════════════════════════════════════════════════════════════════ */
function App() {
  const [lang,        setLang]        = useState('es');
  const [showHelp,    setShowHelp]    = useState(false);
  const [lpSection,   setLpSection]   = useState('entorno');
  const [lpWidth,     setLpWidth]     = useState(460);
  const [osmFields,   setOsmFields]   = useState(new Set());
  const [calculating, setCalculating] = useState(false);
  const [calcError,   setCalcError]   = useState(null);
  const [lumToolbarSlot, setLumToolbarSlot] = useState(null);
  const lpDragging = useRef(false);

  // ── Multi-tube ─────────────────────────────────────────────────
  const [activeTubeId, setActiveTubeId] = useState('T1');
  const [tubes, setTubes] = useState({ T1: _mkTube('T1') });
  const tube   = tubes[activeTubeId] || _mkTube(activeTubeId);
  const form   = tube.form;
  const result = tube.result;

  const patchTube = (id, patch) =>
    setTubes(prev => ({ ...prev, [id]: { ...prev[id], ...patch } }));
  // Fusiona siempre contra el estado más reciente (no contra el `form` cerrado
  // en el render) — evita que llamadas onChange consecutivas en el mismo
  // bloque síncrono (p.ej. tras un cálculo) se pisen entre sí y pierdan datos.
  const onChange = (key, val) =>
    setTubes(prev => ({
      ...prev,
      [activeTubeId]: { ...prev[activeTubeId], form: { ...prev[activeTubeId].form, [key]: val } },
    }));
  const onClearOsm = (key) =>
    setOsmFields(prev => { const s = new Set(prev); s.delete(key); return s; });

  // ── Calculate CIE 88 ──────────────────────────────────────────
  const handleCalculate = async () => {
    setCalculating(true); setCalcError(null);
    try {
      const resp = await fetch('/api/tunnel/calculate', {
        method:'POST', headers:{'Content-Type':'application/json'},
        body: JSON.stringify(form),
      });
      const data = await resp.json();
      patchTube(activeTubeId, { result: data });
      if (data.success) setLpSection('zonas');
      else setCalcError(data.error || 'Error de cálculo');
    } catch(e) { setCalcError(e.message); }
    finally { setCalculating(false); }
  };

  // ── Left panel resize ─────────────────────────────────────────
  const startLpResize = useCallback((e) => {
    e.preventDefault();
    const startX = e.clientX, startW = lpWidth;
    lpDragging.current = true;
    document.body.classList.add('dragging');
    const onMove = (ev) => setLpWidth(Math.min(520, Math.max(220, startW + ev.clientX - startX)));
    const onUp = () => {
      lpDragging.current = false;
      document.body.classList.remove('dragging');
      document.removeEventListener('mousemove', onMove);
      document.removeEventListener('mouseup', onUp);
    };
    document.addEventListener('mousemove', onMove);
    document.addEventListener('mouseup', onUp);
  }, [lpWidth]);

  // ── All 6 phases in order ────────────────────────────────────
  const LP_SECTIONS = [
    { id:'entorno',    icon:'🌄', label:'Entorno',    done: !!(form.portal_orientation) },
    { id:'geometria',  icon:'📐', label:'Geometría',  done: !!(form.length_m && form.width_m && form.traffic_veh_h) },
    { id:'zonas',      icon:'📊', label:'Zonas',      done: !!(result?.success) },
    { id:'luminarias', icon:'💡', label:'Luminarias', done: !!(form.luminaires_result) },
    { id:'control',    icon:'🎛️', label:'Control',    done: false },
    { id:'informe',    icon:'📄', label:'Informe',    done: false },
  ];

  // La curva CIE 88 (result.success) es prerequisito de Zonas/Luminarias/
  // Control/Informe — no tiene sentido entrar ahi sin haber calculado.
  const cieReady = !!result?.success;
  const FORWARD_GATED = ['zonas','luminarias','control','informe'];

  const setSection = (id) => {
    if (FORWARD_GATED.includes(id) && !cieReady) {
      setCalcError('Calcula primero la curva CIE 88:2004 para continuar.');
      return;
    }
    setLpSection(prev => prev === id ? prev : id);
  };

  // ── Main canvas content driven by lpSection ───────────────────
  const renderCanvas = () => {
    switch(lpSection) {
      case 'entorno':
        return (
          <div className="mc-content mc-map-mode">
            <MapSelector
              lat={form.lat} lng={form.lng}
              onUpdate={(k,v)=>onChange(k,v)}
              onImport={imp=>{
                patchTube(activeTubeId,{form:{...form,...imp}});
                setOsmFields(new Set(Object.keys(imp)));
              }}
              lumData={result?.success?{tube_length_m:form.length_m,...(form.luminaires_result||{})}:null}
              portalOrientation={form.portal_orientation}
              tunnelLength={parseFloat(form.length_m)||300}
              tunnelWidth={parseFloat(form.width_m)||10.5}
            />
          </div>
        );
      case 'geometria':
        return (
          <div className="mc-content" style={{padding:0,overflow:'hidden'}}>
            <TunnelPerspective form={form} result={result} onEdit={()=>setLpSection('geometria')}/>
          </div>
        );
      case 'zonas':
        return (
          <div className="mc-content">
            {result?.success
              ? <StepResults result={result}/>
              : <div style={{textAlign:'center',color:'var(--salvi-grey)',padding:60}}>
                  <div style={{fontSize:'2rem',marginBottom:12}}>📊</div>
                  Completa los datos de <b>Entorno</b> y <b>Geometría</b> y pulsa<br/>
                  <b>Calcular CIE 88:2004</b> para ver las zonas.
                </div>
            }
          </div>
        );
      case 'luminarias':
        return (
          <div className="mc-content" style={{padding:0,flex:1,display:'flex',flexDirection:'column',minHeight:0}}>
            <LuminaireSectionEditor result={result} form={form} onChange={onChange}
              onGoToMap={()=>setLpSection('entorno')} toolbarSlot={lumToolbarSlot}/>
          </div>
        );
      case 'control':
        return (
          <div className="mc-content">
            {result?.success
              ? <StepResults result={result}/>
              : <div style={{textAlign:'center',color:'var(--salvi-grey)',padding:60}}>
                  <div style={{fontSize:'2rem',marginBottom:12}}>🎛️</div>
                  Completa el cálculo CIE 88 para configurar el control.
                </div>
            }
          </div>
        );
      case 'informe':
        return (
          <div className="mc-content">
            {result?.success
              ? <StepResults result={result}/>
              : <div style={{textAlign:'center',color:'var(--salvi-grey)',padding:60}}>
                  <div style={{fontSize:'2rem',marginBottom:12}}>📄</div>
                  Completa el cálculo CIE 88 para generar el informe.
                </div>
            }
          </div>
        );
      default:
        return null;
    }
  };

  const canvas = renderCanvas();
  return (
    <div className="app-shell" style={{gridTemplateColumns:`${lpWidth}px 5px 1fr 272px`}}>

      {/* ── TopBar ── */}
      <div className="topbar">
        <span className="tb-brand">SALVI Studio</span>
        <span className="tb-badge">Túnel · CIE 88:2004</span>
        <div className="tb-sep"/>
        <span className="tb-proj">{form.project_name || 'Sin nombre'}</span>
        <span className="tb-spacer"/>
        <LangSwitcher lang={lang} onChange={setLang}/>
        <button className="tb-btn" onClick={()=>setShowHelp(h=>!h)}>❓ Ayuda</button>
      </div>

      {/* ── Left Panel ── */}
      <div className="left-panel">

        {/* Tube tabs */}
        <div className="tube-tabs">
          {Object.keys(tubes).map(tid=>(
            <button key={tid} className={`tube-tab ${activeTubeId===tid?'active':''}`}
              onClick={()=>setActiveTubeId(tid)}>{tid}</button>
          ))}
          <button className="tube-tab add"
            onClick={()=>{
              const next=`T${Object.keys(tubes).length+1}`;
              setTubes(prev=>({...prev,[next]:_mkTube(next,form)}));
              setActiveTubeId(next);
            }}>+ Tubo</button>
          {Object.keys(tubes).length>1 && (
            <button className="tube-tab remove"
              onClick={()=>{
                const ids=Object.keys(tubes).filter(t=>t!==activeTubeId);
                setTubes(prev=>{const n={...prev};delete n[activeTubeId];return n;});
                setActiveTubeId(ids[ids.length-1]);
              }}>✕</button>
          )}
        </div>

        {/* Phase rail — quick-jump icons */}
        <div className="phase-rail">
          {LP_SECTIONS.map(sec=>(
            <button key={sec.id}
              className={`phase-rail-item ${lpSection===sec.id?'active':''}`}
              onClick={()=>setSection(sec.id)}>
              {sec.icon}
              <span className={`pr-dot ${sec.done?'ok':''}`}/>
              <span className="pr-tip">{sec.label}</span>
            </button>
          ))}
        </div>

        {/* Contenido contextual del panel lateral */}
        <div style={{flex:1, overflowY:'auto', borderTop:'1px solid var(--salvi-line)', display: lpSection === 'zonas' ? 'none' : 'block'}}>
          {lpSection === 'entorno' && (
            <StepEnvironment form={form} onChange={onChange} osmFields={osmFields} onClearOsm={onClearOsm}/>
          )}
          {lpSection === 'geometria' && (<>
            <StepGeometry form={form} onChange={onChange} osmFields={osmFields} onClearOsm={onClearOsm}/>
            <StepTraffic  form={form} onChange={onChange} osmFields={osmFields} onClearOsm={onClearOsm}/>
          </>)}
          {lpSection === 'luminarias' && (
            <LumConfigPanel
              lum={{...DEFAULT_LUM_CONFIG,...(form.lum_config||{})}}
              onChange={lum=>onChange('lum_config',{...(form.lum_config||{}),...lum})}
              roadWidthM={parseFloat(form.width_m)||10.5}
              heightM={parseFloat(form.height_m)||5.5}
              hParedM={parseFloat(form.H_pared_m)||3.0}
              tunnelShape={form.tunnel_shape||'horseshoe'}
            />
          )}
          {lpSection === 'control' && (
            <StepControl result={result} form={form} onChange={onChange}/>
          )}
          {lpSection === 'informe' && (
            <StepReport result={result} form={form} tubes={tubes}/>
          )}
        </div>

        {/* Slot: barra Directo/reflexiones/Calcular de la fase Luminarias (portal) */}
        {lpSection === 'luminarias' && (
          <div ref={setLumToolbarSlot} style={{padding:'0 10px 8px',flexShrink:0}}/>
        )}

        {/* Footer: error + calculate */}
        <div className="lp-footer">
          {calcError && (
            <div style={{marginBottom:7,padding:'5px 8px',background:'#fef2f2',
                color:'#b91c1c',fontSize:'.7rem',borderRadius:4,border:'1px solid #fecaca'}}>
              {calcError}
            </div>
          )}
          <button className="calc-btn" onClick={handleCalculate} disabled={calculating}>
            {calculating?'⏳ Calculando CIE 88…':'🔍 Calcular CIE 88:2004'}
          </button>
        </div>

        {/* Anterior / Siguiente */}
        <div className="lp-nav-btns">
          {/* ◀| Anterior */}
          <button
            className="lp-nav-btn"
            title="Anterior"
            disabled={LP_SECTIONS.findIndex(s=>s.id===lpSection)===0}
            onClick={()=>{
              const idx=LP_SECTIONS.findIndex(s=>s.id===lpSection);
              if(idx>0) setSection(LP_SECTIONS[idx-1].id);
            }}>
            <svg width="22" height="22" viewBox="0 0 22 22" fill="currentColor" xmlns="http://www.w3.org/2000/svg">
              {/* barra vertical izquierda */}
              <rect x="3" y="4" width="2.5" height="14" rx="0.8"/>
              {/* triángulo apuntando izquierda */}
              <path d="M17 4.5L7.5 11L17 17.5V4.5Z"/>
            </svg>
          </button>
          {/* ▶| Siguiente */}
          <button
            className={`lp-nav-btn${LP_SECTIONS.findIndex(s=>s.id===lpSection)<LP_SECTIONS.length-1?' next-active':''}`}
            title={FORWARD_GATED.includes(LP_SECTIONS[LP_SECTIONS.findIndex(s=>s.id===lpSection)+1]?.id) && !cieReady
              ? 'Calcula primero la curva CIE 88:2004' : 'Siguiente'}
            disabled={LP_SECTIONS.findIndex(s=>s.id===lpSection)===LP_SECTIONS.length-1 ||
              (FORWARD_GATED.includes(LP_SECTIONS[LP_SECTIONS.findIndex(s=>s.id===lpSection)+1]?.id) && !cieReady)}
            onClick={()=>{
              const idx=LP_SECTIONS.findIndex(s=>s.id===lpSection);
              if(idx<LP_SECTIONS.length-1) setSection(LP_SECTIONS[idx+1].id);
            }}>
            <svg width="22" height="22" viewBox="0 0 22 22" fill="currentColor" xmlns="http://www.w3.org/2000/svg">
              {/* triángulo apuntando derecha */}
              <path d="M5 4.5L14.5 11L5 17.5V4.5Z"/>
              {/* barra vertical derecha */}
              <rect x="16.5" y="4" width="2.5" height="14" rx="0.8"/>
            </svg>
          </button>
        </div>
      </div>

      {/* ── Resize handle ── */}
      <div className="lp-resizer" style={{gridRow:2}} onMouseDown={startLpResize}/>

      {/* ── Main Canvas — content driven by lpSection ── */}
      <div className="main-canvas">
        <div style={{flex:1,minHeight:0,display:'flex',flexDirection:'column',overflow:'hidden'}}>
          <ErrorBoundary key={lpSection}>{canvas}</ErrorBoundary>
        </div>
      </div>

      {/* ── Right Decision Panel ── */}
      <div className="right-panel">
        <div style={{fontSize:'.68rem',fontWeight:700,color:'var(--salvi-grey)',
            textTransform:'uppercase',letterSpacing:'.08em',marginBottom:8}}>
          Decisión
        </div>
        {result?.success ? (
          <>
            {/* Lth Portal A */}
            <KpiCard
              label={`Lth · Portal ${form.portal_orientation||'A'}`}
              value={result.summary?.Lth?.toFixed(1)}
              unit="cd/m²" highlight/>
            {/* Lth Portal B — solo bidireccional cuando Lth_b difiere */}
            {form.traffic_direction === 'two_way' &&
             result.lth?.Lth_b != null &&
             result.lth?.Lth_b !== result.summary?.Lth && (
              <KpiCard
                label={`Lth · Portal ${result.lth?.orientation_b||'B'}`}
                value={Number(result.lth?.Lth_b).toFixed(1)}
                unit="cd/m²" highlight/>
            )}
            <KpiCard label="Lin (interior)" value={result.summary?.Lin?.toFixed(1)}  unit="cd/m²"/>
            <KpiCard label="SD (distancia)" value={result.summary?.SD_m?.toFixed(0)} unit="m"/>
            {form.installed_power_kw && (
              <KpiCard label="P. instalada" value={parseFloat(form.installed_power_kw).toFixed(1)} unit="kW"/>
            )}
            <div style={{marginTop:8,marginBottom:4}}>
              {Object.values(result.zones||{}).map(z=>(
                <div key={z.zone_type} style={{display:'flex',justifyContent:'space-between',
                    alignItems:'center',padding:'4px 0',
                    borderBottom:'1px solid var(--salvi-line)',fontSize:'.7rem'}}>
                  <span style={{fontWeight:600}}>{z.zone_name}</span>
                  <span style={{color:'var(--salvi-grey)'}}>{z.L_zone?.toFixed(1)} cd/m²</span>
                </div>
              ))}
            </div>
            <LumModelsSummary luminairesResult={form.luminaires_result}/>
            <div style={{marginTop:'auto',paddingTop:10,display:'flex',flexDirection:'column',gap:6}}>
              <button onClick={()=>setSection('luminarias')}
                style={{width:'100%',padding:'7px',fontSize:'.72rem',fontWeight:600,
                  border:'1px solid var(--salvi-black)',borderRadius:5,
                  background:'transparent',cursor:'pointer',color:'var(--salvi-black)'}}>
                💡 Calcular luminarias
              </button>
              <button onClick={()=>setSection('informe')}
                style={{width:'100%',padding:'7px',fontSize:'.72rem',fontWeight:600,
                  border:'1px solid var(--salvi-line)',borderRadius:5,
                  background:'transparent',cursor:'pointer',color:'var(--salvi-grey)'}}>
                📄 Generar informe
              </button>
            </div>
          </>
        ) : (
          <div style={{fontSize:'.74rem',color:'var(--salvi-grey)',textAlign:'center',
              marginTop:40,lineHeight:1.7}}>
            Introduce los parámetros<br/>y pulsa<br/>
            <b>Calcular CIE 88:2004</b><br/>
            para ver los resultados.
          </div>
        )}
      </div>

      {showHelp && <HelpPanel lang={lang} onClose={()=>setShowHelp(false)}/>}
    </div>
  );
}

ReactDOM.createRoot(document.getElementById('root')).render(<App/>);
