@echo off
cd /d "%~dp0"

REM Activar entorno virtual si existe
if exist "venv\Scripts\activate.bat" call venv\Scripts\activate.bat

cls
echo.
echo ============================================================
echo  SALVI Tunnel Engine - CIE 88:2004
echo ============================================================
echo.
echo  Iniciando servidor Flask...
echo.

REM Arrancar Flask en segundo plano (ventana separada minimizada)
start "SALVI Tunnel Engine" /min python app.py

REM Esperar a que Flask este listo (3 segundos)
echo  Esperando a que el servidor este listo...
timeout /t 3 /nobreak > nul

REM Abrir el navegador
start "" "http://localhost:5000/tunnel"

echo.
echo ============================================================
echo  Servidor activo en:
echo.
echo    Modulo tuneles  ->  http://localhost:5000/tunnel
echo    App principal   ->  http://localhost:5000
echo.
echo  El servidor corre en segundo plano (barra de tareas).
echo  Para detenerlo: cierra la ventana "SALVI Tunnel Engine".
echo ============================================================
echo.

REM Cerrar esta ventana de lanzamiento automaticamente
exit
