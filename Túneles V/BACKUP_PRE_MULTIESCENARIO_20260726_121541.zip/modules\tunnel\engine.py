"""
SALVI Tunnel Engine - Motor principal
Orquesta todos los modulos de calculo CIE 88:2004.
Punto de entrada unico para el calculo de un tunel.
"""

from .models import (
    TunnelDesignResult, TunnelTube, Portal,
    PortalOrientation, SkyCondition, TrafficDirection,
    DataSource, DataConfidence
)
from .classification import classify_tunnel
from .design_speed import calculate_design_speed
from .l20_lseq_lth import (
    calculate_L20_model, calculate_L20_table,
    calculate_Lseq, calculate_Lth,
    calculate_interior_luminance, calculate_night_luminance
)
from .zones import build_zones, zones_to_dict
from .profile import build_profile, validate_profile, profile_to_chart_data
from .control import build_control_plan, export_dali, export_smartec


def run_tunnel_calculation(params: dict) -> dict:
    """
    Funcion principal del SALVI Tunnel Engine.
    Recibe los parametros del formulario y devuelve el resultado completo.
    """
    errors = []
    warnings = []

    try:
        # 1. EXTRAER PARAMETROS
        project_name    = params.get("project_name", "Proyecto Tunel")
        tube_id         = params.get("tube_id", "T1")
        length_m        = float(params.get("length_m", 300))
        speed_kmh       = float(params.get("speed_kmh", 80))
        traffic_veh_h   = int(params.get("traffic_veh_h", 500))
        gradient_pct    = float(params.get("gradient_pct", 0.0))
        traffic_dir_str = params.get("traffic_direction", "one_way")
        exit_visible    = bool(params.get("exit_visible", False))
        daylight_pen    = params.get("daylight_penetration", "poor")
        orient_str      = params.get("portal_orientation", "S")
        env_type        = params.get("environment_type", "open_country_flat")
        sky_str         = params.get("sky_condition", "clear")
        wall_refl       = float(params.get("wall_reflectance", 0.4))
        has_pedestrians = bool(params.get("has_pedestrians", False))
        illuminated_road= bool(params.get("illuminated_road", False))
        curv_radius     = params.get("curvature_radius_m", None)
        if curv_radius is not None:
            curv_radius = float(curv_radius)
        speed_source_str= params.get("speed_source", "user")
        l20_method      = params.get("l20_method", "model")
        lth_method      = params.get("lth_method", "k_factor")
        profile_stepped = bool(params.get("profile_stepped", False))
        n_steps         = int(params.get("n_steps", 4))

        # Parsear enums
        traffic_dir = TrafficDirection(traffic_dir_str)
        orientation = PortalOrientation(orient_str)
        sky_cond    = SkyCondition(sky_str)
        speed_src   = DataSource.USER

        # 2. CLASIFICACION
        classification = classify_tunnel(
            length_m=length_m,
            stopping_distance_m=0,
            exit_visible=exit_visible,
            daylight_penetration=daylight_pen,
            traffic_veh_h=traffic_veh_h,
            has_pedestrians=has_pedestrians,
            speed_kmh=speed_kmh,
            wall_reflectance=wall_refl,
            curvature_radius_m=curv_radius,
            gradient_pct=gradient_pct
        )

        # 3. VELOCIDAD Y DISTANCIA DE PARADA
        speed_result = calculate_design_speed(
            speed_kmh=speed_kmh,
            gradient_pct=gradient_pct,
            source=speed_src,
            confidence=DataConfidence.MEDIUM
        )
        SD = speed_result.stopping_distance_m

        # SD portal B (bidireccional): pendiente efectiva invertida
        # Si el túnel sube de A→B, el conductor que entra por B baja (más SD)
        if traffic_dir == TrafficDirection.TWO_WAY and gradient_pct != 0.0:
            speed_result_b = calculate_design_speed(
                speed_kmh=speed_kmh,
                gradient_pct=-gradient_pct,   # pendiente opuesta
                source=speed_src,
                confidence=DataConfidence.MEDIUM
            )
            SD_b = speed_result_b.stopping_distance_m
        else:
            SD_b = SD

        # Reclasificar con SD real
        classification = classify_tunnel(
            length_m=length_m,
            stopping_distance_m=SD,
            exit_visible=exit_visible,
            daylight_penetration=daylight_pen,
            traffic_veh_h=traffic_veh_h,
            has_pedestrians=has_pedestrians,
            speed_kmh=speed_kmh,
            wall_reflectance=wall_refl,
            curvature_radius_m=curv_radius,
            gradient_pct=gradient_pct
        )

        # 4. L20
        if l20_method == "table":
            l20_result = calculate_L20_table(env_type, orientation)
        else:
            l20_result = calculate_L20_model(
                environment_type=env_type,
                orientation=orientation,
                sky_condition=sky_cond
            )

        # 5. LSEQ (estimacion)
        lseq_result = calculate_Lseq(l20_result.L20, method="estimated")

        # 6. LTH
        lth_result = calculate_Lth(
            L20_result=l20_result,
            speed_kmh=speed_kmh,
            traffic_veh_h=traffic_veh_h,
            method=lth_method,
            Lseq_result=lseq_result if lth_method == "lseq" else None
        )
        Lth = lth_result.Lth

        # 6b. LTH PORTAL B (bidireccional — orientación opuesta)
        _OPPOSITE_ORI = {
            "N":"S","NE":"SW","E":"W","SE":"NW",
            "S":"N","SW":"NE","W":"E","NW":"SE",
        }
        if traffic_dir == TrafficDirection.TWO_WAY:
            orient_b_str = _OPPOSITE_ORI.get(orient_str, orient_str)
            orientation_b = PortalOrientation(orient_b_str)
            if l20_method == "table":
                l20_b = calculate_L20_table(env_type, orientation_b)
            else:
                l20_b = calculate_L20_model(
                    environment_type=env_type,
                    orientation=orientation_b,
                    sky_condition=sky_cond
                )
            lseq_b = calculate_Lseq(l20_b.L20, method="estimated")
            lth_b_res = calculate_Lth(
                L20_result=l20_b,
                speed_kmh=speed_kmh,
                traffic_veh_h=traffic_veh_h,
                method=lth_method,
                Lseq_result=lseq_b if lth_method == "lseq" else None
            )
            Lth_b = lth_b_res.Lth
        else:
            orient_b_str = orient_str
            l20_b        = l20_result
            Lth_b        = Lth

        # 7. LUMINANCIA INTERIOR Y NOCTURNA
        Lin = calculate_interior_luminance(speed_kmh, traffic_veh_h, length_m)
        L_night = calculate_night_luminance(Lin, illuminated_road)

        # Verificacion: Lth debe ser > Lin
        if Lth < Lin:
            warnings.append(
                "Lth={:.1f} < Lin={:.2f} — Se usara Lin como umbral minimo".format(Lth, Lin)
            )
            Lth = max(Lth, Lin * 2)
            lth_result.Lth = Lth

        # 8. ZONAS
        zones = build_zones(
            tube_length=length_m,
            stopping_distance_m=SD,
            speed_kmh=speed_kmh,
            Lth=Lth,
            Lin=Lin,
            classification=classification,
            traffic_direction=traffic_dir,
            L_night=L_night,
            Lth_b=Lth_b,
            stopping_distance_b_m=SD_b,
        )
        zones.tube_id = tube_id
        # Propagar advertencias de zonas (ej. tunel corto)
        warnings.extend(zones.warnings)

        # 9. PERFIL LONGITUDINAL
        # Resolucion: 1m para tuneles <= 500m, 2m para mayores
        step_size = 1.0 if length_m <= 500 else 2.0

        profile = build_profile(
            tube_length=length_m,
            stopping_distance=SD,
            speed_kmh=speed_kmh,
            Lth=Lth,
            Lin=Lin,
            L_night=L_night,
            zones=zones,
            step_size=step_size,
            use_stepped=profile_stepped,
            n_steps_transition=n_steps,
            Lth_b=Lth_b,
        )

        # 10. VALIDACION
        validation = validate_profile(profile)
        errors.extend(validation.get("errors", []))
        warnings.extend(validation.get("warnings", []))

        # 11. DATOS PARA GRAFICA
        chart_data = profile_to_chart_data(profile)

        # 12. PLAN DE CONTROL
        n_tr_groups = int(params.get("n_transition_groups", 2))
        ctrl_protocol = params.get("control_protocol", "DALI")
        control_plan = build_control_plan(
            tube_id=tube_id,
            L20_design=l20_result.L20,
            Lth_design=Lth,
            Lin=Lin,
            L_night=L_night,
            k_factor=lth_result.k_factor,
            speed_kmh=speed_kmh,
            zones=zones,
            n_transition_groups=n_tr_groups,
            protocol=ctrl_protocol
        )
        warnings.extend(control_plan.warnings)

        # 13. RESUMEN DE RESULTADOS
        return {
            "success": True,
            "errors": errors,
            "warnings": warnings,
            "summary": {
                "project": project_name,
                "tube_id": tube_id,
                "length_m": length_m,
                "speed_kmh": speed_kmh,
                "SD_m": SD,
                "L20": round(l20_result.L20, 0),
                "Lth": round(Lth, 1),
                "Lin": round(Lin, 2),
                "L_night": round(L_night, 2),
                "Lseq": round(lseq_result.Lseq, 0),
                "k_factor": round(lth_result.k_factor, 4),
                "qc": round(lth_result.qc, 3),
            },
            "classification": {
                "geometric": classification.geometric_category.value,
                "optical": classification.optical_category.value,
                "daylighting": classification.daylighting_need.value,
                "justification": classification.justification
            },
            "speed": {
                "v_kmh": speed_kmh,
                "SD_m": SD,
                "d_reaction_m": speed_result.reaction_distance_m,
                "d_braking_m": speed_result.braking_distance_m,
                "reference_point_s": speed_result.reference_point_s
            },
            "l20": {
                "L20": round(l20_result.L20, 0),
                "method": l20_result.method,
                "confidence": l20_result.confidence.value,
                "note": l20_result.note
            },
            "lth": {
                "Lth": round(Lth, 1),
                "Lth_b": round(Lth_b, 1),
                "L20": round(l20_result.L20, 0),
                "L20_b": round(l20_b.L20, 0),
                "SD_b_m": round(SD_b, 1),
                "orientation_b": orient_b_str,
                "k_factor": round(lth_result.k_factor, 4),
                "qc": round(lth_result.qc, 3),
                "method": lth_result.method,
                "converged": lth_result.converged
            },
            "interior": {
                "Lin": round(Lin, 2),
                "L_night": round(L_night, 2)
            },
            "zones": zones_to_dict(zones),
            "profile": profile.to_dict(),
            "chart": chart_data,
            "validation": validation,
            "control": control_plan.to_dict(),
            "quality_criteria": {
                "Uo_min": 0.40,
                "Ul_min": 0.60,
                "TI_max": 15.0,
                "wall_ratio_min": 0.60,
                "note": "Criterios de uniformidad y deslumbramiento requieren calculo fotometrico completo con LDT"
            }
        }

    except Exception as e:
        import traceback
        return {
            "success": False,
            "errors": [str(e)],
            "warnings": warnings,
            "traceback": traceback.format_exc()
        }
