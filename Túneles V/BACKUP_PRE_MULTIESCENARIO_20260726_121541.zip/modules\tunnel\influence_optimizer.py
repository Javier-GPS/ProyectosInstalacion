"""Optimizacion global de flujo mediante matriz de influencia fotometrica.

Para geometria, optica y tilt fijos, la luminancia directa es lineal con el
flujo de cada luminaria. Este modulo calcula esa relacion una sola vez:

    L = A @ phi

y resuelve los flujos continuos antes de asignar modelo, driver y corriente.
"""

from __future__ import annotations

import math
from typing import Iterable

import numpy as np

from photometric_engine.salvi_photometry.calculator import (
    LuminaireInstance,
    TunnelCalculator,
)
from photometric_engine.salvi_photometry.geometry import (
    LuminaireOrientation,
    Observer,
)
from photometric_engine.salvi_photometry.ldt_parser import load_ldt

from modules.tunnel.optimizer import (
    CHAIN_ORDER,
    _LDT_DIR,
    _OPTIC_LDT,
    flux_power_at_current,
    select_model_for_flux,
)
from modules.tunnel.required_luminance import build_requirement_samples


_UNIT_FLUX_LM = 10000.0


def _default_y_positions(arrangement: str, w: float, wall_offset: float) -> list[float]:
    if arrangement == "lateral_left":
        return [wall_offset]
    if arrangement in ("lateral_right", "unilateral"):
        return [w - wall_offset]
    if arrangement in ("bilateral_sym", "bilateral", "staggered"):
        return [wall_offset, w - wall_offset]
    if arrangement == "central_double":
        return [w / 2.0 - 0.30, w / 2.0 + 0.30]
    return [w / 2.0]


def _transition_blocks(groups: list[dict]) -> list[list[int]]:
    """Indices ordenados hacia el portal para imponer flujo no decreciente."""
    buckets: dict[tuple, list[tuple[float, int]]] = {}
    for i, group in enumerate(groups):
        zd = group["zd"]
        sp = group["sp"]
        zt = str(zd.zone_type or "")
        if "transition" not in zt:
            continue
        key = (
            id(zd),
            int(sp.get("spacing_stage", 0) or 0),
            round(float(sp.get("spacing_m", zd.d_used) or 0), 3),
            str(sp.get("optic") or zd.optic or ""),
            round(float(sp.get("tilt_deg", zd.tilt_deg) or 0), 2),
        )
        distance = float(
            sp.get("distance_from_interior_m", abs(float(sp["s"]))) or 0
        )
        buckets.setdefault(key, []).append((distance, i))
    return [
        [idx for _, idx in sorted(items)]
        for items in buckets.values()
        if len(items) > 1
    ]


def _constant_flux_blocks(groups: list[dict]) -> list[list[int]]:
    """Luminarias del vano tipo Interior que deben compartir regulacion."""
    buckets: dict[tuple, list[int]] = {}
    for index, group in enumerate(groups):
        zd = group["zd"]
        sp = group["sp"]
        zone_type = str(zd.zone_type or "").lower()
        if "interior" not in zone_type or sp.get("support_candidate"):
            continue
        key = (
            id(zd),
            str(sp.get("optic") or zd.optic or ""),
            round(float(sp.get("tilt_deg", zd.tilt_deg) or 0), 2),
            round(float(sp.get("spacing_m", zd.d_used) or 0), 3),
        )
        buckets.setdefault(key, []).append(index)
    return [indices for indices in buckets.values() if len(indices) > 1]


def _project_monotonic(phi: np.ndarray, blocks: Iterable[list[int]]) -> None:
    for block in blocks:
        values = np.maximum.accumulate(phi[block])
        phi[block] = values


def _monotonic_inequalities(
    n_fluxes: int,
    blocks: Iterable[list[int]],
    n_variables: int,
) -> tuple[list[np.ndarray], list[float]]:
    rows: list[np.ndarray] = []
    bounds: list[float] = []
    for block in blocks:
        for previous, current in zip(block, block[1:]):
            row = np.zeros(n_variables, dtype=float)
            row[previous] = 1.0
            row[current] = -1.0
            rows.append(row)
            bounds.append(0.0)
    return rows, bounds


def _solve_fluxes_numpy(
    A: np.ndarray,
    target: np.ndarray,
    phi_initial: np.ndarray,
    max_flux: float,
    monotonic_blocks: Iterable[list[int]],
    max_iters: int,
    fixed_fluxes: np.ndarray | None = None,
) -> tuple[np.ndarray, bool, str]:
    """Ruta de emergencia cuando SciPy no esta disponible."""
    phi = np.clip(np.asarray(phi_initial, dtype=float), 0.0, max_flux)
    fixed = (
        np.full(phi.shape, np.nan, dtype=float)
        if fixed_fluxes is None
        else np.asarray(fixed_fluxes, dtype=float)
    )
    fixed_mask = np.isfinite(fixed)
    phi[fixed_mask] = np.clip(fixed[fixed_mask], 0.0, max_flux)
    _project_monotonic(phi, monotonic_blocks)
    converged = False
    for _ in range(max(1, int(max_iters))):
        calculated = A @ phi
        deficit = target - calculated
        worst_idx = int(np.argmax(deficit))
        worst = float(deficit[worst_idx])
        if worst <= 1e-9:
            converged = True
            break
        row = A[worst_idx]
        available = np.where(
            (row > 0.0) & (phi < max_flux - 1e-6) & ~fixed_mask
        )[0]
        if not len(available):
            break
        best_col = int(available[np.argmax(row[available])])
        needed = worst / max(row[best_col], 1e-12)
        relative_deficit = worst / max(target[worst_idx], 1e-9)
        step_fraction = (
            0.20 if relative_deficit > 0.10
            else 0.10 if relative_deficit > 0.05
            else 0.05 if relative_deficit > 0.02
            else 0.01
        )
        adaptive_cap = max(
            max_flux * 0.005,
            max(phi[best_col], max_flux * 0.05) * step_fraction,
        )
        delta = min(needed, adaptive_cap, max_flux - phi[best_col])
        if delta <= 1e-9:
            break
        phi[best_col] += delta
        _project_monotonic(phi, monotonic_blocks)
        np.minimum(phi, max_flux, out=phi)

    if converged:
        calculated = A @ phi
        for col in np.argsort(-phi):
            if fixed_mask[col]:
                continue
            affected = A[:, col] > 0
            if not np.any(affected):
                phi[col] = 0.0
                continue
            removable = float(np.min(
                (calculated[affected] - target[affected])
                / A[affected, col]
            ))
            if removable <= 1e-6:
                continue
            delta = min(float(phi[col]), removable)
            phi[col] -= delta
            calculated -= A[:, col] * delta
        _project_monotonic(phi, monotonic_blocks)
    return phi, converged, "numpy"


def _solve_fluxes_minimax(
    A: np.ndarray,
    required: np.ndarray,
    target: np.ndarray,
    min_flux: float,
    max_flux: float,
    monotonic_blocks: Iterable[list[int]],
    constant_blocks: Iterable[list[int]],
    upper_mask: np.ndarray | None,
    phi_initial: np.ndarray,
    max_iters: int,
    fixed_fluxes: np.ndarray | None = None,
) -> tuple[np.ndarray, bool, str, float]:
    """LP en dos etapas: menor exceso maximo y despues menor flujo total."""
    try:
        import highspy
    except ImportError:
        phi, feasible, method = _solve_fluxes_numpy(
            A, target, phi_initial, max_flux, monotonic_blocks, max_iters,
            fixed_fluxes,
        )
        for block in constant_blocks:
            phi[block] = np.max(phi[block])
        if fixed_fluxes is not None:
            fixed = np.asarray(fixed_fluxes, dtype=float)
            fixed_mask = np.isfinite(fixed)
            phi[fixed_mask] = np.clip(
                fixed[fixed_mask], 0.0, max_flux,
            )
        ratios = (A @ phi) / np.maximum(required, 1e-9)
        return phi, feasible, method, max(0.0, float(np.max(ratios) - 1.0))

    n_fluxes = A.shape[1]
    n_variables = n_fluxes + 1
    # HiGHS trabaja mejor con x=phi/max_flux en [0,1] que mezclando
    # coeficientes fotometricos ~1e-4 con flujos ~1e5 lm.
    B = A * float(max_flux)
    lower_rows = np.hstack((-B, np.zeros((A.shape[0], 1))))
    if upper_mask is None:
        upper_mask = np.ones(A.shape[0], dtype=bool)
    else:
        upper_mask = np.asarray(upper_mask, dtype=bool)
    if not np.any(upper_mask):
        upper_mask[:] = True
    B_upper = B[upper_mask]
    required_upper = required[upper_mask]
    upper_rows = np.hstack((B_upper, -required_upper[:, None]))
    mono_rows, mono_bounds = _monotonic_inequalities(
        n_fluxes, monotonic_blocks, n_variables,
    )
    matrices = [lower_rows, upper_rows]
    rhs = [-target, required_upper]
    if mono_rows:
        matrices.append(np.vstack(mono_rows))
        rhs.append(np.asarray(mono_bounds, dtype=float))
    A_ub = np.vstack(matrices)
    b_ub = np.concatenate(rhs)
    equality_rows: list[np.ndarray] = []
    for block in constant_blocks:
        anchor = block[0]
        for index in block[1:]:
            row = np.zeros(n_variables, dtype=float)
            row[index] = 1.0
            row[anchor] = -1.0
            equality_rows.append(row)
    min_fraction = float(min_flux) / max(float(max_flux), 1e-9)

    objective = np.zeros(n_variables, dtype=float)
    objective[-1] = 1.0
    col_lower = np.concatenate((
        np.full(n_fluxes, min_fraction),
        np.array([0.0]),
    ))
    col_upper = np.concatenate((
        np.ones(n_fluxes),
        np.array([highspy.kHighsInf]),
    ))
    if fixed_fluxes is not None:
        fixed = np.asarray(fixed_fluxes, dtype=float)
        fixed_mask = np.isfinite(fixed)
        fixed_fraction = np.clip(
            fixed[fixed_mask] / max(float(max_flux), 1e-9),
            0.0,
            1.0,
        )
        col_lower[np.flatnonzero(fixed_mask)] = fixed_fraction
        col_upper[np.flatnonzero(fixed_mask)] = fixed_fraction
    row_matrix = A_ub
    row_lower = np.full(len(A_ub), -highspy.kHighsInf)
    row_upper = b_ub
    if equality_rows:
        equality_matrix = np.vstack(equality_rows)
        row_matrix = np.vstack((row_matrix, equality_matrix))
        row_lower = np.concatenate((
            row_lower, np.zeros(len(equality_rows)),
        ))
        row_upper = np.concatenate((
            row_upper, np.zeros(len(equality_rows)),
        ))

    row_indices, column_indices = np.nonzero(row_matrix)
    counts = np.bincount(row_indices, minlength=len(row_matrix))
    starts = np.concatenate(([0], np.cumsum(counts))).astype(np.int32)
    column_indices = column_indices.astype(np.int32)
    values = row_matrix[row_indices, column_indices].astype(float)

    highs = highspy.Highs()
    highs.setOptionValue("output_flag", False)
    highs.addCols(
        n_variables,
        objective,
        col_lower,
        col_upper,
        0,
        np.zeros(n_variables + 1, dtype=np.int32),
        np.empty(0, dtype=np.int32),
        np.empty(0, dtype=float),
    )
    highs.addRows(
        len(row_matrix),
        row_lower,
        row_upper,
        len(values),
        starts,
        column_indices,
        values,
    )
    highs.run()
    if highs.getModelStatus() != highspy.HighsModelStatus.kOptimal:
        fallback = np.clip(
            np.asarray(phi_initial, dtype=float), 0.0, max_flux,
        )
        if fixed_fluxes is not None:
            fixed = np.asarray(fixed_fluxes, dtype=float)
            fixed_mask = np.isfinite(fixed)
            fallback[fixed_mask] = np.clip(
                fixed[fixed_mask], 0.0, max_flux,
            )
        return fallback, False, "highspy", float("inf")

    stage1_solution = np.asarray(highs.getSolution().col_value, dtype=float)
    u_opt = max(0.0, float(stage1_solution[-1]))
    objective[:] = 0.0
    # Coste relativo: un cd/m2 de exceso en Interior pesa mas que el mismo
    # cd/m2 en Umbral. Asi se ajusta toda la curva y no solo el flujo total.
    relative_weights = np.where(upper_mask, 1.0, 0.05)
    relative_cost = B.T @ (
        relative_weights / np.maximum(required, 1e-9)
    )
    scale = max(float(np.max(relative_cost)), 1e-12)
    objective[:n_fluxes] = relative_cost / scale
    all_columns = np.arange(n_variables, dtype=np.int32)
    highs.changeColsCost(
        n_variables,
        all_columns,
        objective,
    )
    highs.changeColBounds(n_fluxes, 0.0, u_opt + 1e-7)
    highs.run()
    stage2_success = (
        highs.getModelStatus() == highspy.HighsModelStatus.kOptimal
    )
    solution = (
        np.asarray(highs.getSolution().col_value, dtype=float)
        if stage2_success else stage1_solution
    )
    phi = np.asarray(solution[:n_fluxes], dtype=float) * float(max_flux)
    feasible = bool(np.all(A @ phi >= target - 1e-7))
    method = "highspy-2stage" if stage2_success else "highspy-1stage"
    return phi, feasible, method, u_opt


def optimize_layout_fluxes(
    zone_designs,
    *,
    h: float,
    w: float,
    mf: float,
    rtable: str,
    cct: str,
    I_max_mA: float,
    I_min_pct: float,
    arrangement: str,
    wall_offset: float,
    tube_length_m: float,
    Lth: float,
    Lth_b: float,
    Lin: float,
    speed_kmh: float,
    design_margin: float = 0.003,
    max_iters: int = 1200,
) -> list[str]:
    """Resuelve flujos globales y asigna despues el hardware mas pequeno.

    La aceptacion final exige ``Lcalc >= Lreq``. ``design_margin`` no es una
    tolerancia de incumplimiento: crea una reserva positiva antes del mapeo a
    corrientes reales.
    """
    warnings_out: list[str] = []
    active_zones = [
        zd for zd in zone_designs
        if zd.n_luminaires > 0 and (zd.setpoints or [])
        and float(zd.s_end) >= 0.0
        and float(zd.s_start) <= tube_length_m
    ]
    if not active_zones:
        return warnings_out

    phot_cache = {}

    def _phot(optic_id):
        oid = optic_id or "F2MD"
        if oid not in phot_cache:
            filename = _OPTIC_LDT.get(oid, _OPTIC_LDT["F2MD"])
            phot_cache[oid] = load_ldt(_LDT_DIR / filename)
        return phot_cache[oid]

    ys_default = _default_y_positions(arrangement, w, wall_offset)

    def _ys_for_setpoint(sp):
        if arrangement == "bilateral_stag":
            idx = int(sp.get("idx", 1) or 1)
            return [
                wall_offset if (idx - 1) % 2 == 0 else (w - wall_offset)
            ]
        return ys_default

    def _tilt_for_y(tilt_base, y_pos):
        return tilt_base if y_pos < w / 2.0 else -tilt_base

    groups = []
    for zd in active_zones:
        for i, sp in enumerate(zd.setpoints or []):
            optic_id = sp.get("optic") or zd.optic or "F2MD"
            tilt_base = float(sp.get("tilt_deg", zd.tilt_deg) or 0)
            unit_lums = [
                LuminaireInstance(
                    x=float(sp["s"]),
                    y=float(y_pos),
                    H=h,
                    photometry=_phot(optic_id),
                    flux_lm=_UNIT_FLUX_LM,
                    orientation=LuminaireOrientation(
                        tilt_deg=_tilt_for_y(tilt_base, y_pos)
                    ),
                )
                for y_pos in _ys_for_setpoint(sp)
            ]
            groups.append({
                "zd": zd,
                "i": i,
                "sp": sp,
                "lums": unit_lums,
                "direction": -1.0 if str(zd.zone_type or "").endswith("_b") else 1.0,
            })
    if not groups:
        return warnings_out

    sample_meta = build_requirement_samples(
        active_zones,
        tube_length_m=tube_length_m,
        Lth=Lth,
        Lth_b=Lth_b,
        Lin=Lin,
        speed_kmh=speed_kmh,
    )
    for meta in sample_meta:
        meta["zd"] = meta.pop("zone")
    if not sample_meta:
        return warnings_out

    optics = {sp["sp"].get("optic") or "F2MD" for sp in groups}
    reach = max((_phot(oid).reach_distance(h) for oid in optics), default=300.0)
    calc = TunnelCalculator(rtable, mf, max_luminaire_dist=reach)
    observers = {
        1.0: Observer(lane_y_m=w / 2.0, d_observer_m=60.0, direction=1.0),
        -1.0: Observer(lane_y_m=w / 2.0, d_observer_m=60.0, direction=-1.0),
    }
    ys_calc = [(j + 0.5) * w / 5.0 for j in range(5)]

    n_samples = len(sample_meta)
    n_groups = len(groups)
    A = np.zeros((n_samples, n_groups), dtype=float)
    direction_indices = {
        direction: [
            i for i, meta in enumerate(sample_meta)
            if meta["direction"] == direction
        ]
        for direction in (1.0, -1.0)
    }

    all_lums = []
    group_starts = []
    for group in groups:
        group_starts.append(len(all_lums))
        all_lums.extend(group["lums"])
    group_starts = np.asarray(group_starts, dtype=int)

    # Dos llamadas vectorizadas como maximo (una por sentido), en vez de una
    # llamada por luminaria y sentido.
    for direction, indices in direction_indices.items():
        if not indices:
            continue
        pts = [
            (sample_meta[i]["s"], y_pos)
            for i in indices for y_pos in ys_calc
        ]
        physical = calc.luminance_contributions_at_points_batch(
            pts, all_lums, observers[direction],
        )
        means = physical.reshape(
            len(indices), len(ys_calc), len(all_lums),
        ).mean(axis=1)
        A[indices, :] = (
            np.add.reduceat(means, group_starts, axis=1)
            / _UNIT_FLUX_LM
        )

    peak = float(np.max(A)) if A.size else 0.0
    if peak <= 0:
        warnings_out.append(
            "🔴 Matriz de influencia nula: no se pudieron resolver los flujos."
        )
        return warnings_out
    A[A < peak * 1e-7] = 0.0

    required = np.asarray(
        [meta["target"] for meta in sample_meta], dtype=float,
    )
    target = required * (1.0 + max(0.0, float(design_margin)))
    max_flux, _ = flux_power_at_current(
        CHAIN_ORDER[-1], cct, I_max_mA, I_min_pct,
    )
    min_selection = select_model_for_flux(
        0.0, cct, I_max_mA, I_min_pct,
    )
    min_flux = min(float(min_selection["lm"]), float(max_flux))
    phi_initial = np.asarray([
        max(
            0.0,
            float(
                group["sp"].get(
                    "target_flux_lm",
                    group["sp"].get("flux_lm", 0),
                ) or 0
            ),
        )
        for group in groups
    ], dtype=float)
    # El Interior ya ha sido optimizado sobre un vano tipo y validado en
    # calidad (U0/Ul/L). La fase global puede usar su contribucion, pero no
    # debe redimensionar su flujo ni su hardware por un deficit de otra zona.
    fixed_fluxes = np.full(n_groups, np.nan, dtype=float)
    for index, group in enumerate(groups):
        if "interior" in str(group["zd"].zone_type or "").lower():
            fixed_fluxes[index] = max(
                0.0,
                float(group["sp"].get("flux_lm", phi_initial[index]) or 0.0),
            )
    monotonic_blocks = _transition_blocks(groups)
    constant_blocks = _constant_flux_blocks(groups)

    # El salto normativo Umbral->Transicion no puede seguirse de forma
    # instantanea por el alcance longitudinal de las luminarias. Se mantiene
    # el requisito inferior, pero esa pequena franja no gobierna el minimax
    # del resto del tunel.
    upper_mask = np.ones(n_samples, dtype=bool)
    boundary_buffer = max(10.0, 3.0 * float(h))
    for direction in (1.0, -1.0):
        indices = [
            i for i, meta in enumerate(sample_meta)
            if meta["direction"] == direction
        ]
        indices.sort(key=lambda i: sample_meta[i]["s"])
        for previous, current in zip(indices, indices[1:]):
            req_previous = required[previous]
            req_current = required[current]
            high = max(req_previous, req_current)
            low = max(min(req_previous, req_current), 1e-9)
            if high / low <= 1.5:
                continue
            boundary = (
                sample_meta[previous]["s"] + sample_meta[current]["s"]
            ) / 2.0
            for index in indices:
                if abs(sample_meta[index]["s"] - boundary) <= boundary_buffer:
                    upper_mask[index] = False

    # Prueba de capacidad sin alterar la solucion. El Interior permanece en su
    # flujo validado; solo el resto de zonas se prueba a su maximo. Si aun asi
    # existe deficit, se conserva integro el diseno previo. Las reducciones de
    # interdistancia pertenecen a la fase geometrica de luminaires.py, donde
    # se aplican por escalones configurables y sobre la cuadricula de 0.5 m.
    capacity_phi = np.full(n_groups, max_flux, dtype=float)
    fixed_mask = np.isfinite(fixed_fluxes)
    capacity_phi[fixed_mask] = np.clip(
        fixed_fluxes[fixed_mask], 0.0, max_flux,
    )
    maximum_deficit = target - A @ capacity_phi
    worst_capacity_idx = int(np.argmax(maximum_deficit))
    if float(maximum_deficit[worst_capacity_idx]) > 1e-7:
        meta = sample_meta[worst_capacity_idx]
        warnings_out.append(
            f"Optimizacion global no aplicada: la geometria previa no cubre "
            f"Lreq en s={meta['s']:.1f} m "
            f"(deficit de capacidad "
            f"{float(maximum_deficit[worst_capacity_idx]):.3f} cd/m2). "
            "Se conserva el diseno por zonas, incluido el Interior."
        )
        return warnings_out

    phi, converged, solver_method, max_relative_excess = (
        _solve_fluxes_minimax(
            A,
            required,
            target,
            min_flux,
            max_flux,
            monotonic_blocks,
            constant_blocks,
            upper_mask,
            phi_initial,
            max_iters,
            fixed_fluxes=fixed_fluxes,
        )
    )
    if not converged:
        warnings_out.append(
            "Optimizacion global no aplicada: el solver no encontro una "
            "solucion factible. Se conserva el diseno por zonas, incluido "
            "el Interior."
        )
        return warnings_out

    # Asignacion discreta en memoria: no se modifica ningun setpoint hasta
    # comprobar que el redondeo a hardware comercial mantiene deficit cero.
    selections: list[dict | None] = []
    actual_phi = np.zeros_like(phi)
    for col, group in enumerate(groups):
        if fixed_mask[col]:
            selections.append(None)
            actual_phi[col] = float(
                group["sp"].get("flux_lm", fixed_fluxes[col]) or 0.0
            )
            continue
        selected = select_model_for_flux(
            float(phi[col]), cct, I_max_mA, I_min_pct,
        )
        selections.append(selected)
        actual_phi[col] = float(selected["lm"])

    calculated_actual = A @ actual_phi
    actual_deficit = required - calculated_actual
    worst_actual = float(np.max(actual_deficit))
    worst_idx = int(np.argmax(actual_deficit))
    if worst_actual > 1e-9:
        meta = sample_meta[worst_idx]
        warnings_out.append(
            f"Optimizacion global no aplicada: el redondeo comercial deja "
            f"un deficit de {worst_actual:.6f} cd/m2 en "
            f"s={meta['s']:.1f} m. Se conserva el diseno por zonas."
        )
        return warnings_out

    for col, group in enumerate(groups):
        selected = selections[col]
        if selected is None:
            continue
        sp = group["sp"]
        sp["target_flux_lm"] = round(float(phi[col]), 3)
        sp["model"] = selected["model"]
        sp["current_mA"] = selected["mA"]
        sp["power_w"] = selected["W"]
        sp["flux_lm"] = selected["lm"]

    for group in groups:
        s_pos = float(group["sp"]["s"])
        nearest = min(
            range(n_samples),
            key=lambda j: abs(sample_meta[j]["s"] - s_pos),
        )
        group["sp"]["L_est"] = round(float(calculated_actual[nearest]), 3)

    profile_by_zone: dict[int, dict[str, list[float]]] = {}
    for meta, value in zip(sample_meta, calculated_actual):
        bucket = profile_by_zone.setdefault(
            id(meta["zd"]), {"values": [], "ratios": []},
        )
        bucket["values"].append(float(value))
        bucket["ratios"].append(
            float(value) / max(float(meta["target"]), 1e-9)
        )

    for zd in active_zones:
        setpoints = zd.setpoints or []
        if not setpoints:
            continue
        zd.n_luminaires = len(setpoints)
        zd.power_zone_w = round(
            sum(float(sp.get("power_w", 0) or 0) for sp in setpoints), 1,
        )
        zd.flux_zone_lm = round(
            sum(float(sp.get("flux_lm", 0) or 0) for sp in setpoints), 0,
        )
        zd.power_density_wm2 = round(
            zd.power_zone_w / max(float(zd.zone_length) * w, 1e-9), 3,
        )
        dominant = max(setpoints, key=lambda sp: float(sp.get("L_req", 0) or 0))
        zd.model = dominant.get("model", zd.model)
        zd.current_mA = round(float(dominant.get("current_mA", 0) or 0))
        zd.power_w = round(float(dominant.get("power_w", 0) or 0), 1)
        zd.flux_lm = round(float(dominant.get("flux_lm", 0) or 0), 0)
        zd.L_estimated = round(
            sum(float(sp.get("L_est", 0) or 0) for sp in setpoints)
            / len(setpoints),
            3,
        )
        profile_stats = profile_by_zone.get(id(zd))
        if profile_stats and profile_stats["values"]:
            zd.profile_L_avg = round(
                float(np.mean(profile_stats["values"])), 3,
            )
            zd.profile_L_min = round(
                float(np.min(profile_stats["values"])), 3,
            )
            zd.profile_min_ratio = round(
                float(np.min(profile_stats["ratios"])), 4,
            )
            zd.profile_median_ratio = round(
                float(np.median(profile_stats["ratios"])), 4,
            )
            zd.profile_p95_ratio = round(
                float(np.percentile(profile_stats["ratios"], 95)), 4,
            )
            zd.profile_max_ratio = round(
                float(np.max(profile_stats["ratios"])), 4,
            )

    if not converged:
        meta = sample_meta[worst_idx]
        warnings_out.append(
            f"🔴 Flujo global infactible en s={meta['s']:.1f} m: "
            f"faltan {max(0.0, worst_actual):.3f} cd/m2 incluso con "
            "las luminarias disponibles al maximo."
        )
    elif worst_actual > 1e-9:
        meta = sample_meta[worst_idx]
        warnings_out.append(
            f"🔴 Deficit residual en s={meta['s']:.1f} m: "
            f"{worst_actual:.6f} cd/m2."
        )
    else:
        min_ratio = float(np.min(
            calculated_actual / np.maximum(required, 1e-9)
        ))
        max_ratio = float(np.max(
            calculated_actual / np.maximum(required, 1e-9)
        ))
        densification_text = ""
        warnings_out.append(
            f"Optimizacion global {solver_method} convergida{densification_text}: "
            f"deficit 0 en {n_samples} puntos, "
            f"ratio Lcalc/Lreq={min_ratio:.4f}..{max_ratio:.4f}, "
            f"exceso minimax fuera de fronteras="
            f"{max_relative_excess * 100.0:.2f}%."
        )
    return warnings_out
