"""
SALVI Tunnel Engine — Módulo de Cálculo de Luminarias APHEX
Algoritmo inside-out (CIE 88:2004): diseña desde la zona interior (menor
luminancia requerida) hacia la boca de entrada (mayor luminancia), manteniendo
el espaciado fijo y aumentando corriente/modelo según sea necesario.

Cadena APHEX:  S/50G → M/100G → L/150G
Corrientes:    350 mA → 500 mA → 750 mA (≤ I_max del proyecto)
Ópticas:       F151 (w/h < 0.8)  · F2M2 (0.8 ≤ w/h < 1.6)  · F2MD (w/h ≥ 1.6)

Tablas UF/Ul: calculadas a partir de los ficheros LDT de fotometría real de
las ópticas METRO M H50 (F2M2, F2MD, F151) — cálculo por integración directa.

Referencias:
    CIE 88:2004 §15–16 (criterios de luminancia en túneles)
    Eulumdat photometry files — SALVI (Julio 2026)
"""

import math
from dataclasses import dataclass, field
from typing import List, Dict, Optional, Tuple

from modules.tunnel.required_luminance import cie88_transition_luminance


# ══════════════════════════════════════════════════════════════════════════════
# SUPERFICIES DE CALZADA
# ══════════════════════════════════════════════════════════════════════════════

ROAD_SURFACES: Dict[str, dict] = {
    "dark_asphalt":   {"label": "Asfalto oscuro (R3)",       "rho": 0.065},
    "medium_asphalt": {"label": "Asfalto medio (R2)",         "rho": 0.085},
    "light_asphalt":  {"label": "Asfalto claro (R1)",         "rho": 0.105},
    "concrete":       {"label": "Hormigón (C1/C2)",           "rho": 0.140},
    "bright_concrete":{"label": "Hormigón claro",             "rho": 0.165},
}

DEFAULT_MF = 0.70

# Longitud del cuerpo APHEX en la direccion del tunel (m) — distancia entre
# los dos del par en tandem. Las tres familias (S/M/L) miden 500 mm en esta
# direccion (confirmado por el usuario), aunque el cuerpo optico completo
# tenga distinta anchura/profundidad transversal segun el modelo.
_BODY_LEN: Dict[str, float] = {"S": 0.50, "M": 0.50, "L": 0.50}

# Motor nuevo (led_engine): 9 variantes identificadas por variant_id
# (p.ej. "APHEX_S_75W"). Mismo valor para las tres familias (ver nota arriba).
from modules.tunnel import led_engine as _led_eng
_BODY_LEN_BY_FAMILY: Dict[str, float] = {"APHEX_S": 0.50, "APHEX_M": 0.50, "APHEX_L": 0.50}

def _body_len_for(model_id: str) -> float:
    variant = _led_eng.VARIANTS_BY_ID.get(model_id)
    if variant is not None:
        return _BODY_LEN_BY_FAMILY.get(variant.family, 0.50)
    return _BODY_LEN.get(model_id, 0.50)   # compat con el motor legacy

def _commercial_name_for(model_id: str) -> str:
    variant = _led_eng.VARIANTS_BY_ID.get(model_id)
    return variant.commercial_name if variant is not None else str(model_id)

# ══════════════════════════════════════════════════════════════════════════════
# ARREGLOS DE LUMINARIAS
# ══════════════════════════════════════════════════════════════════════════════

ARRANGEMENTS = {
    "central_single": {"label": "Fila central única (eje)",           "n_rows": 1, "lut_key": "central"},
    "central_offset": {"label": "Fila central desplazada del eje",    "n_rows": 1, "lut_key": "central"},
    "central_double": {"label": "Doble fila central",                 "n_rows": 2, "lut_key": "central"},
    "lateral_left":   {"label": "Lateral izquierda (sentido marcha)", "n_rows": 1, "lut_key": "lateral_right"},
    "lateral_right":  {"label": "Lateral derecha (sentido marcha)",   "n_rows": 1, "lut_key": "lateral_right"},
    "bilateral_sym":  {"label": "Bilateral simétrico",                "n_rows": 2, "lut_key": "lateral_right"},
    "bilateral_stag": {"label": "Bilateral en tresbolillo",           "n_rows": 2, "lut_key": "lateral_right"},
    # Legacy
    "bilateral":      {"label": "Bilateral",                          "n_rows": 2, "lut_key": "lateral_right"},
    "unilateral":     {"label": "Unilateral",                         "n_rows": 1, "lut_key": "lateral_right"},
    "staggered":      {"label": "Tresbolillo",                        "n_rows": 2, "lut_key": "lateral_right"},
}


# ══════════════════════════════════════════════════════════════════════════════
# CATÁLOGO APHEX  (verificado contra hoja técnica — Julio 2026)
#
# Cadena S→M→L: sin solape en la unión S/M (M@350mA > S@750mA).
# Nota de producto: L@350mA (56.825/60.559 klm) < M@750mA (73.305/78.123 klm)
#   → el algoritmo inside-out lo gestiona correctamente: al no cubrir el requisito
#     con L@350mA pasa a L@500mA. L@350mA solo se selecciona para requisitos en
#     el rango 56.826–73.304 klm donde M@500mA tampoco llega.
# ══════════════════════════════════════════════════════════════════════════════

APHEX_CATALOG: Dict[str, dict] = {
    "S": {
        "pcb":   "50G",
        "label": "Aphex S",
        "dims_mm": (472, 400, 90),
        "operating_points": {
            "3000K": [
                {"mA": 350, "W":  97, "lm": 18941},
                {"mA": 500, "W": 143, "lm": 26057},
                {"mA": 750, "W": 223, "lm": 36652},
            ],
            "4000K": [
                {"mA": 350, "W":  97, "lm": 20186},
                {"mA": 500, "W": 143, "lm": 27769},
                {"mA": 750, "W": 223, "lm": 39061},
            ],
        },
    },
    "M": {
        "pcb":   "100G",
        "label": "Aphex M",
        "dims_mm": None,
        "operating_points": {
            "3000K": [
                {"mA": 350, "W": 194, "lm": 37883},
                {"mA": 500, "W": 286, "lm": 52114},
                {"mA": 750, "W": 446, "lm": 73305},
            ],
            "4000K": [
                {"mA": 350, "W": 194, "lm": 40372},
                {"mA": 500, "W": 286, "lm": 55539},
                {"mA": 750, "W": 446, "lm": 78123},
            ],
        },
    },
    "L": {
        "pcb":   "150G",
        "label": "Aphex L",
        "dims_mm": None,
        "operating_points": {
            "3000K": [
                {"mA": 350, "W": 292, "lm":  56825},
                {"mA": 500, "W": 429, "lm":  78122},
                {"mA": 750, "W": 670, "lm": 109958},
            ],
            "4000K": [
                {"mA": 350, "W": 292, "lm":  60559},
                {"mA": 500, "W": 429, "lm":  83309},
                {"mA": 750, "W": 670, "lm": 117184},
            ],
        },
    },
}

# Orden de la cadena S → M → L
APHEX_CHAIN_ORDER = ["S", "M", "L"]


# ══════════════════════════════════════════════════════════════════════════════
# TABLAS UF Y d/h_max  (calculadas desde LDT reales — integración directa)
#
# UF: factor de utilización por fila de luminarias (fracción de flujo que
#     llega a la calzada) — casi constante con d/h, se usa valor a d/h=2.0.
# dh_max: máximo d/h que cumple Ul ≥ 0.6 (CIE 88:2004)
#
# Clave de wh: relación ancho_calzada / altura_montaje
# ══════════════════════════════════════════════════════════════════════════════

# Factor de utilización representativo por óptica, arreglo y relación w/h
# Interpolación lineal para valores intermedios de w/h
_UF_TABLE: Dict[str, Dict[str, Dict[str, float]]] = {
    "F2M2": {
        "central": {
            "0.5": 0.2504, "0.8": 0.3819, "1.0": 0.4608,
            "1.2": 0.5334, "1.5": 0.6310, "2.0": 0.7598,
            "2.5": 0.8464, "3.0": 0.8999,
        },
        "lateral_right": {
            "0.5": 0.1993, "0.8": 0.2639, "1.0": 0.2929,
            "1.2": 0.3143, "1.5": 0.3362, "2.0": 0.3559,
            "2.5": 0.3653, "3.0": 0.3701,
        },
    },
    "F2MD": {
        "central": {
            "0.5": 0.2590, "0.8": 0.3819, "1.0": 0.4510,
            "1.2": 0.5162, "1.5": 0.6116, "2.0": 0.7525,
            "2.5": 0.8520, "3.0": 0.9120,
        },
        "lateral_right": {
            "0.5": 0.1615, "0.8": 0.1781, "1.0": 0.1840,
            "1.2": 0.1885, "1.5": 0.1935, "2.0": 0.1987,
            "2.5": 0.2015, "3.0": 0.2031,
        },
    },
    "F151": {
        "central": {
            "0.5": 0.2329, "0.8": 0.3766, "1.0": 0.4656,
            "1.2": 0.5469, "1.5": 0.6539, "2.0": 0.7850,
            "2.5": 0.8632, "3.0": 0.9094,
        },
        "lateral_right": {
            "0.5": 0.1112, "0.8": 0.1333, "1.0": 0.1435,
            "1.2": 0.1511, "1.5": 0.1588, "2.0": 0.1664,
            "2.5": 0.1713, "3.0": 0.1742,
        },
    },
}

# Máximo d/h para Ul ≥ 0.6
_DH_MAX_TABLE: Dict[str, Dict[str, Dict[str, float]]] = {
    "F2M2": {
        "central": {
            "0.5": 2.64, "0.8": 2.64, "1.0": 2.64,
            "1.2": 2.64, "1.5": 2.64, "2.0": 2.64,
            "2.5": 2.64, "3.0": 2.64,
        },
        "lateral_right": {
            "0.5": 2.67, "0.8": 2.67, "1.0": 2.67,
            "1.2": 2.67, "1.5": 2.67, "2.0": 2.67,
            "2.5": 2.67, "3.0": 2.67,
        },
    },
    "F2MD": {
        "central": {
            "0.5": 2.83, "0.8": 2.83, "1.0": 2.83,
            "1.2": 2.83, "1.5": 2.31, "2.0": 2.31,
            "2.5": 2.31, "3.0": 2.32,
        },
        "lateral_right": {
            "0.5": 2.83, "0.8": 2.31, "1.0": 2.31,
            "1.2": 2.31, "1.5": 2.31, "2.0": 2.31,
            "2.5": 2.31, "3.0": 2.31,
        },
    },
    "F151": {
        "central": {
            "0.5": 2.07, "0.8": 2.07, "1.0": 2.08,
            "1.2": 2.07, "1.5": 2.07, "2.0": 2.07,
            "2.5": 2.08, "3.0": 2.08,
        },
        "lateral_right": {
            "0.5": 2.49, "0.8": 2.49, "1.0": 2.49,
            "1.2": 2.49, "1.5": 2.49, "2.0": 2.49,
            "2.5": 2.38, "3.0": 2.38,
        },
    },
}

_WH_BREAKPOINTS = [0.5, 0.8, 1.0, 1.2, 1.5, 2.0, 2.5, 3.0]


def _interp_wh(table_by_wh: Dict[str, float], wh: float) -> float:
    """Interpolación lineal de UF o dh_max según w/h."""
    wh = max(0.5, min(wh, 3.0))
    bps = _WH_BREAKPOINTS
    if wh <= bps[0]:
        return table_by_wh[f"{bps[0]:.1f}"]
    if wh >= bps[-1]:
        return table_by_wh[f"{bps[-1]:.1f}"]
    for i in range(len(bps) - 1):
        lo, hi = bps[i], bps[i + 1]
        if lo <= wh <= hi:
            t = (wh - lo) / (hi - lo)
            v_lo = table_by_wh[f"{lo:.1f}"]
            v_hi = table_by_wh[f"{hi:.1f}"]
            return v_lo + t * (v_hi - v_lo)
    return table_by_wh[f"{bps[-1]:.1f}"]


def _lut_key(arrangement: str) -> str:
    return ARRANGEMENTS.get(arrangement, {}).get("lut_key", "central")


def lookup_uf(optic: str, wh: float, arrangement: str) -> float:
    """Devuelve el factor de utilización (UF) para óptica, geometría y arreglo."""
    key = _lut_key(arrangement)
    tbl = _UF_TABLE.get(optic, _UF_TABLE["F2M2"]).get(key, {})
    return _interp_wh(tbl, wh)


def lookup_dh_max(optic: str, wh: float, arrangement: str) -> float:
    """Devuelve el máximo d/h que cumple Ul ≥ 0.6."""
    key = _lut_key(arrangement)
    tbl = _DH_MAX_TABLE.get(optic, _DH_MAX_TABLE["F2M2"]).get(key, {})
    return _interp_wh(tbl, wh)


def auto_select_optic(optic_pref: str, wh: float) -> str:
    """Selección automática de óptica según relación w/h."""
    if optic_pref not in ("auto", ""):
        return optic_pref
    if wh < 0.8:
        return "F151"
    if wh < 1.6:
        return "F2M2"
    return "F2MD"


def _interp_op(ops: List[dict], target_lm: float) -> dict:
    """
    Interpolación lineal por tramos entre los puntos de operación (350/500/750 mA)
    para obtener la corriente exacta que produce target_lm.
    Devuelve {mA, W, lm} interpolados.
    """
    if target_lm <= ops[0]["lm"]:
        return dict(ops[0])
    if target_lm >= ops[-1]["lm"]:
        return dict(ops[-1])
    for i in range(len(ops) - 1):
        lo, hi = ops[i], ops[i + 1]
        if lo["lm"] <= target_lm <= hi["lm"]:
            t = (target_lm - lo["lm"]) / (hi["lm"] - lo["lm"])
            return {
                "mA": round(lo["mA"] + t * (hi["mA"] - lo["mA"])),
                "W":  round(lo["W"]  + t * (hi["W"]  - lo["W"]),  1),
                "lm": target_lm,
            }
    return dict(ops[-1])


def select_aphex_continuous(
    phi_required: float,
    cct:          str,
    I_max_mA:     int,
) -> dict:
    """
    Selección continua S→M→L con interpolación lineal por tramos.

    Dentro de cada modelo la corriente varía libremente entre 350 mA e I_max_mA
    (sin saltos discretos). Se usa el primer modelo cuyo rango [lm_min, lm_max]
    cubre phi_required. Si phi_required < lm_min del modelo actual se devuelve
    ese modelo a corriente mínima (350 mA). Si supera todos los modelos se
    devuelve L a I_max_mA (insuficiente → el llamador reduce el espaciado).

    Devuelve: {model, pcb, label, mA, W, lm}
    """
    for model_key in APHEX_CHAIN_ORDER:
        cat  = APHEX_CATALOG[model_key]
        ops  = cat["operating_points"].get(cct, [])
        if not ops:
            continue

        # Recortar a I_max_mA (interpolando el punto límite si queda entre dos)
        valid_ops = [op for op in ops if op["mA"] <= I_max_mA]
        if not valid_ops:
            # I_max_mA < 350 mA — usar mínimo disponible
            valid_ops = [ops[0]]

        # Si I_max_mA queda entre dos puntos de catálogo, añadir punto interpolado
        max_cat_mA = valid_ops[-1]["mA"]
        if max_cat_mA < I_max_mA and len(ops) > len(valid_ops):
            next_op = ops[len(valid_ops)]
            lo, hi  = valid_ops[-1], next_op
            t_cut   = (I_max_mA - lo["mA"]) / (hi["mA"] - lo["mA"])
            valid_ops.append({
                "mA": I_max_mA,
                "W":  round(lo["W"] + t_cut * (hi["W"] - lo["W"]), 1),
                "lm": round(lo["lm"] + t_cut * (hi["lm"] - lo["lm"]), 0),
            })

        lm_max = valid_ops[-1]["lm"]

        if phi_required <= lm_max:
            interp = _interp_op(valid_ops, phi_required)
            return {
                "model": model_key,
                "pcb":   cat["pcb"],
                "label": cat["label"],
                **interp,
            }

    # phi_required supera todos los modelos → L a I_max_mA
    cat     = APHEX_CATALOG["L"]
    ops     = cat["operating_points"].get(cct, [])
    valid_ops = [op for op in ops if op["mA"] <= I_max_mA] or [ops[0]]
    if I_max_mA < valid_ops[-1]["mA"] and len(ops) > len(valid_ops):
        next_op = ops[len(valid_ops)]
        lo, hi  = valid_ops[-1], next_op
        t_cut   = (I_max_mA - lo["mA"]) / (hi["mA"] - lo["mA"])
        valid_ops.append({
            "mA": I_max_mA,
            "W":  round(lo["W"] + t_cut * (hi["W"] - lo["W"]), 1),
            "lm": round(lo["lm"] + t_cut * (hi["lm"] - lo["lm"]), 0),
        })
    max_op = valid_ops[-1]
    return {
        "model": "L",
        "pcb":   cat["pcb"],
        "label": cat["label"],
        "mA":    max_op["mA"],
        "W":     max_op["W"],
        "lm":    max_op["lm"],
    }


def build_aphex_chain(cct: str, I_max_mA: int) -> List[dict]:
    """Compat: devuelve los extremos de cada modelo para fijar el espaciado interior."""
    chain = []
    for model in APHEX_CHAIN_ORDER:
        cat = APHEX_CATALOG[model]
        ops = [op for op in cat["operating_points"].get(cct, []) if op["mA"] <= I_max_mA]
        if ops:
            chain.append({
                "model": model, "pcb": cat["pcb"], "label": cat["label"],
                "mA": ops[0]["mA"], "W": ops[0]["W"], "lm": ops[0]["lm"],
            })
    chain.sort(key=lambda x: x["lm"])
    return chain


# ══════════════════════════════════════════════════════════════════════════════
# DATACLASSES
# ══════════════════════════════════════════════════════════════════════════════

@dataclass
class ZoneLuminaireDesign:
    """Diseño de luminarias para una zona del túnel — algoritmo inside-out."""
    zone_type:      str
    zone_name:      str
    s_start:        float
    s_end:          float
    zone_length:    float
    L_required:     float
    E_required:     float
    # Selección de luminaria
    model:          str       # S, M, L
    pcb:            str       # 50G, 100G, 150G
    current_mA:     int
    flux_lm:        float     # flujo por luminaria (lm)
    power_w:        float     # potencia por luminaria (W)
    optic:          str       # F2M2, F2MD, F151
    # Diseño espacial
    d_max_ul:       float     # máximo espaciado por Ul (m)
    d_used:         float     # espaciado efectivo (m)
    n_luminaires:   int       # luminarias en la zona
    # Resultados
    L_estimated:    float
    UF:             float
    # Potencias
    power_zone_w:   float
    flux_zone_lm:   float
    power_density_wm2: float
    # Retrocompat
    d_max:          float = 0.0   # alias de d_used (para motor de cálculo)
    # Perfil por luminaria (solo zonas de transición — DALI individual)
    setpoints:      List[dict] = field(default_factory=list)
    tilt_deg:        float = 0.0   # inclinación hacia el portal (°)
    n_tandem:        int   = 1     # luminarias físicas por posición (1=normal, 2=tándem)
    tandem_offset_m: float = 0.0   # separación entre las dos del par (m)
    Ul:              float = 0.0   # uniformidad longitudinal (U0 va en UF, ver arriba)
    # Validacion directa del layout fisico completo (incluye zonas vecinas).
    profile_L_avg:   Optional[float] = None
    profile_L_min:   Optional[float] = None
    profile_min_ratio: Optional[float] = None
    profile_median_ratio: Optional[float] = None
    profile_p95_ratio: Optional[float] = None
    profile_max_ratio: Optional[float] = None

    def to_dict(self) -> dict:
        def _s(v, d=2):
            if v is None or (isinstance(v, float) and not math.isfinite(v)):
                return None
            return round(v, d)
        return {
            "zone_type":          self.zone_type,
            "zone_name":          self.zone_name,
            "s_start":            self.s_start,
            "s_end":              self.s_end,
            "zone_length":        _s(self.zone_length, 1),
            "L_required":         _s(self.L_required, 1),
            "E_required":         _s(self.E_required, 1),
            "model":              self.model,
            "pcb":                self.pcb,
            "current_mA":         self.current_mA,
            "flux_lm":            _s(self.flux_lm, 0),
            "power_w":            _s(self.power_w, 0),
            "optic":              self.optic,
            "d_max_ul":           _s(self.d_max_ul, 2),
            "d_used":             _s(self.d_used, 2),
            "d_max":              _s(self.d_used, 2),
            "n_luminaires":       self.n_luminaires,
            "L_estimated":        _s(self.L_estimated, 1),
            "UF":                 _s(self.UF, 4),
            "Ul":                 _s(self.Ul, 4),
            "power_zone_w":       _s(self.power_zone_w, 0),
            "flux_zone_lm":       _s(self.flux_zone_lm, 0),
            "power_density_wm2":  _s(self.power_density_wm2, 2),
            "margin_pct":         round((self.L_estimated / self.L_required - 1) * 100, 1)
                                  if self.L_required > 0 else 0,
            "setpoints":          self.setpoints,   # lista vacía salvo en transiciones
            "tilt_deg":           _s(self.tilt_deg, 1),
            "n_tandem":           self.n_tandem,
            "tandem_offset_m":    round(self.tandem_offset_m, 2),
            "profile_L_avg":      _s(self.profile_L_avg, 2),
            "profile_L_min":      _s(self.profile_L_min, 2),
            "profile_min_ratio":  _s(self.profile_min_ratio, 4),
            "profile_median_ratio": _s(self.profile_median_ratio, 4),
            "profile_p95_ratio":  _s(self.profile_p95_ratio, 4),
            "profile_max_ratio":  _s(self.profile_max_ratio, 4),
        }


@dataclass
class LuminaireSpec:
    """Parámetros de la luminaria (compat con API existente)."""
    flux_lm:           float
    power_w:           float
    efficiency:        float
    mounting_height_m: float
    arrangement:       str
    maintenance_factor: float = DEFAULT_MF
    name:              str = ""

    @property
    def n_rows(self) -> int:
        return ARRANGEMENTS.get(self.arrangement, {}).get("n_rows", 1)

    @property
    def efficacy_lm_w(self) -> float:
        return self.flux_lm / self.power_w if self.power_w > 0 else 0.0

    def to_dict(self) -> dict:
        return {
            "name":              self.name,
            "flux_lm":           self.flux_lm,
            "power_w":           self.power_w,
            "efficiency":        self.efficiency,
            "mounting_height_m": self.mounting_height_m,
            "arrangement":       self.arrangement,
            "arrangement_label": ARRANGEMENTS.get(self.arrangement, {}).get("label", self.arrangement),
            "n_rows":            self.n_rows,
            "maintenance_factor":self.maintenance_factor,
            "efficacy_lm_w":     round(self.efficacy_lm_w, 1),
        }


@dataclass
class TunnelLuminaireResult:
    """Resultado completo del cálculo de luminarias."""
    tube_id:            str
    luminaire:          Optional[LuminaireSpec]
    road_surface_type:  str
    rho_eff:            float
    road_width_m:       float
    tube_length_m:      float
    optic:              str = ""
    cct:                str = ""
    I_max_mA:           int = 750
    arrangement:        str = ""
    zones:              List[ZoneLuminaireDesign] = field(default_factory=list)
    total_luminaires:   int   = 0
    total_power_w:      float = 0.0
    total_flux_lm:      float = 0.0
    avg_power_density_wm2: float = 0.0
    total_power_kw:     float = 0.0
    warnings:           List[str] = field(default_factory=list)

    def _compute_totals(self):
        self.total_luminaires = sum(z.n_luminaires for z in self.zones)
        self.total_power_w    = sum(z.power_zone_w  for z in self.zones)
        self.total_flux_lm    = sum(z.flux_zone_lm  for z in self.zones)
        self.total_power_kw   = round(self.total_power_w / 1000, 2)
        area = self.tube_length_m * self.road_width_m
        self.avg_power_density_wm2 = round(self.total_power_w / area if area > 0 else 0, 2)

    def to_dict(self) -> dict:
        return {
            "tube_id":       self.tube_id,
            "luminaire":     self.luminaire.to_dict() if self.luminaire else None,
            "optic":         self.optic,
            "cct":           self.cct,
            "I_max_mA":      self.I_max_mA,
            "arrangement":   self.arrangement,
            "road_surface":  {
                "type":  self.road_surface_type,
                "label": ROAD_SURFACES.get(self.road_surface_type, {}).get("label", ""),
                "rho":   self.rho_eff,
            },
            "road_width_m":  self.road_width_m,
            "tube_length_m": self.tube_length_m,
            "zones":         [z.to_dict() for z in self.zones],
            "totals": {
                "n_luminaires":      self.total_luminaires,
                "power_kw":          self.total_power_kw,
                "flux_lm":           round(self.total_flux_lm, 0),
                "power_density_wm2": self.avg_power_density_wm2,
                "installed_lm_per_m": round(
                    self.total_flux_lm / self.tube_length_m
                    if self.tube_length_m > 0 else 0, 1
                ),
            },
            "warnings": self.warnings,
        }


# ══════════════════════════════════════════════════════════════════════════════
# ALGORITMO INSIDE-OUT
# ══════════════════════════════════════════════════════════════════════════════

def _luminance(flux_lm: float, n_rows: int, uf: float, mf: float,
               rho_eff: float, d: float, w: float) -> float:
    """
    L [cd/m²] = Φ × n_rows × UF × MF × ρ_eff / (π × d × w)
    Fórmula de luminancia media CIE para calzada Lambertiana.
    """
    denom = math.pi * d * w
    return (flux_lm * n_rows * uf * mf * rho_eff / denom) if denom > 0 else 0.0


def _cie_L_transition(s: float, s_start: float, Lth: float, Lin: float,
                      speed_kmh: float) -> float:
    """
    Luminancia requerida en la zona de transición según CIE 88:2004 Fig. 6.6.
        L(t) = Lth × (1.9 + t)^(−1.4)
    donde t = tiempo desde inicio de transición = (s − s_start) / v_ms.
    Garantiza L ≥ Lin.
    """
    return cie88_transition_luminance(
        s, s_start, Lth, Lin, speed_kmh,
    )



def _zone_tilt_deg(zone_type: str, L_required: float = 0.0, L_interior: float = 0.0) -> float:
    """Inclinación recomendada de luminarias APHEX por tipo de zona (grados).
    Las zonas de umbral y transición se inclinan hacia el portal para
    aumentar la luminancia efectiva en la zona de adaptación visual.
    """
    t = zone_type.lower()
    if 'interior' in t:
        return 0.0
    if 'exit' in t or 'salida' in t or 'access' in t or 'parting' in t:
        return 0.0
    if 'transition' in t:
        return 5.0
    if 'threshold' in t:
        ratio = L_required / max(L_interior, 1.0)
        if ratio >= 15: return 20.0
        if ratio >= 8:  return 15.0
        if ratio >= 3:  return 10.0
        return 5.0
    return 0.0


def _design_zone_aphex(
    zone_type:   str,
    zone_name:   str,
    s_start:     float,
    s_end:       float,
    L_required:  float,
    chain:       List[dict],   # solo se usa para fallback de zona nula
    d_global:    float,
    d_max_ul:    float,
    uf:          float,
    n_rows:      int,
    mf:          float,
    rho_eff:     float,
    w:           float,
    optic:       str,
    warnings:    List[str],
    cct:         str   = "4000K",
    I_max_mA:    int   = 750,
    speed_kmh:   float = 80.0,
    Lth:         float = 0.0,
    Lin:         float = 0.0,
    L_interior:    float = 0.0,
    tandem_override: Optional[bool] = None,  # None=auto, True=forzar, False=desactivar
) -> ZoneLuminaireDesign:
    """
    Diseña una zona con selección CONTINUA de corriente (S→M→L).

    Zonas uniformes (umbral, interior, salida):
        Misma corriente en todas las luminarias. Espaciado = d_global; si la
        luminaria máxima no alcanza se reduce el espaciado.

    Zona de transición:
        Espaciado fijo = d_global (DALI permite dimming individual).
        Cada luminaria recibe la corriente exacta para producir la luminancia
        que indica la curva CIE 88:2004 en su posición.
        El ZoneLuminaireDesign retorna el perfil completo en `setpoints`.
    """
    zone_length = max(0.0, s_end - s_start)

    # Zona sin requisito de luminancia
    if L_required <= 0 or zone_length <= 0:
        op = chain[0] if chain else {"model": "S", "pcb": "50G", "mA": 350, "W": 97, "lm": 0, "label": "Aphex S"}
        return ZoneLuminaireDesign(
            zone_type=zone_type, zone_name=zone_name, s_start=s_start, s_end=s_end,
            zone_length=zone_length, L_required=L_required, E_required=0,
            model=op["model"], pcb=op["pcb"], current_mA=op["mA"],
            flux_lm=op["lm"], power_w=op["W"], optic=optic,
            d_max_ul=d_max_ul, d_used=0, n_luminaires=0,
            L_estimated=0, UF=uf, power_zone_w=0, flux_zone_lm=0, power_density_wm2=0,
            tilt_deg=0.0,
        )

    def phi_needed(d: float, L_req: float) -> float:
        denom = n_rows * uf * mf * rho_eff
        return (L_req * math.pi * d * w) / denom if denom > 0 else 1e9

    # Flujo máximo disponible (L @ I_max_mA)
    _ops_L   = APHEX_CATALOG["L"]["operating_points"].get(cct, [])
    _vops_L  = [op for op in _ops_L if op["mA"] <= I_max_mA] or [_ops_L[0]]
    lm_max_avail = _vops_L[-1]["lm"]

    # ── ZONA DE TRANSICIÓN: corriente individual CIE 88 por luminaria ──────
    is_transition = "transition" in zone_type.lower()
    if is_transition and Lth > 0 and Lin > 0 and speed_kmh > 0:

        # Determinar la corriente máxima necesaria (inicio de transición ~ Lth)
        phi_start  = phi_needed(d_global, Lth)
        auto_tandem = phi_start > lm_max_avail
        use_tandem  = (tandem_override if tandem_override is not None else auto_tandem)
        t_offset    = _BODY_LEN.get("L", 1.00) if use_tandem else 0.0  # par al inicio = modelo L

        if use_tandem and auto_tandem:
            # Tándem: 2× flujo → d_global es alcanzable
            d_try = d_global
            warnings.append(
                f"Zona {zone_name}: TÁNDEM AUTOMÁTICO — Lth={Lth:.0f} cd/m² no alcanzable "
                f"individual; par de luminarias por posición (offset {t_offset:.2f} m)"
            )
        elif auto_tandem:
            # Tándem forzado OFF: reducir d como antes
            denom = math.pi * w * Lth
            num   = lm_max_avail * n_rows * uf * mf * rho_eff
            d_try = max(0.5, min(num / denom if denom > 0 else d_global, d_max_ul))
            warnings.append(
                f"Zona {zone_name}: Lth={Lth:.0f} cd/m² no alcanzable con Aphex L "
                f"{I_max_mA} mA al espaciado global — d reducido a {d_try:.1f} m"
            )
        elif use_tandem:
            # Tándem FORZADO sobre zona que no lo necesitaba
            d_try    = d_global
            t_offset = _BODY_LEN.get("S", 0.50)
            warnings.append(f"Zona {zone_name}: TÁNDEM MANUAL activado")
        else:
            d_try = d_global

        n_groups = max(1, math.ceil(zone_length / d_try))
        d_actual = zone_length / n_groups
        n_lum    = n_groups * (2 if use_tandem else 1)  # físicas por lado

        # CIE 88 sentido de la transición (Portal A: Lth→Lin; Portal B: Lin→Lth)
        is_b = zone_type.lower() in ("transition_b",)

        setpoints = []
        pwr_zone  = 0.0
        flux_zone = 0.0
        L_sum     = 0.0

        for i in range(n_groups):
            # Posición central del hueco del grupo i
            if not is_b:
                s_i = s_start + (i + 0.5) * d_actual
                L_i = _cie_L_transition(s_i, s_start, Lth, Lin, speed_kmh)
            else:
                # Portal B: curva espejada → t medido desde el final
                s_i_mirror = s_end - (i + 0.5) * d_actual
                s_i = s_i_mirror   # posición central real (usada en s_phys más abajo)
                L_i = _cie_L_transition(s_end - s_i_mirror, s_start,
                                        Lth, Lin, speed_kmh)

            L_i   = max(L_i, Lin)
            n_ph  = 2 if use_tandem else 1
            phi_i = phi_needed(d_actual, L_i) / n_ph
            op_i  = select_aphex_continuous(phi_i, cct, I_max_mA)
            body  = _BODY_LEN.get(op_i["model"], 0.70) if use_tandem else 0.0

            pwr_zone  += op_i["W"] * n_ph
            flux_zone += op_i["lm"] * n_ph
            L_sum     += L_i

            if use_tandem:
                for idx_t, tag in enumerate(("A", "B")):
                    s_phys = round(s_i + (idx_t * 2 - 1) * body / 2, 2)
                    setpoints.append({
                        "idx":        i * 2 + idx_t + 1,
                        "s":          s_phys,
                        "L_req":      round(L_i, 1),
                        "model":      op_i["model"],
                        "current_mA": op_i["mA"],
                        "power_w":    op_i["W"],
                        "flux_lm":    round(op_i["lm"], 0),
                        "tandem":     tag,
                        "pair":       i,
                    })
            else:
                setpoints.append({
                    "idx":        i + 1,
                    "s":          round(s_start + (i + 0.5) * d_actual, 1),
                    "L_req":      round(L_i, 1),
                    "model":      op_i["model"],
                    "current_mA": op_i["mA"],
                    "power_w":    op_i["W"],
                    "flux_lm":    round(op_i["lm"], 0),
                })

        # Representativo: luminaria del extremo de mayor luminancia (inicio)
        dom   = setpoints[0] if not is_b else setpoints[-1]
        L_avg = L_sum / n_groups
        area  = zone_length * w
        E_req = L_required / rho_eff if rho_eff > 0 else 0.0

        return ZoneLuminaireDesign(
            zone_type=zone_type, zone_name=zone_name, s_start=s_start, s_end=s_end,
            zone_length=zone_length, L_required=L_required, E_required=round(E_req, 1),
            model=dom["model"], pcb=APHEX_CATALOG[dom["model"]]["pcb"],
            current_mA=dom["current_mA"],
            flux_lm=dom["flux_lm"], power_w=round(dom["power_w"], 1), optic=optic,
            d_max_ul=round(d_max_ul, 2), d_used=round(d_actual, 2),
            n_luminaires=n_lum, L_estimated=round(L_avg, 1),
            UF=round(uf, 4),
            power_zone_w=round(pwr_zone, 0),
            flux_zone_lm=round(flux_zone, 0),
            power_density_wm2=round(pwr_zone / area if area > 0 else 0, 3),
            d_max=round(d_actual, 2),
            setpoints=setpoints,
            tilt_deg=_zone_tilt_deg(zone_type, L_required, L_interior),
            n_tandem=2 if use_tandem else 1,
            tandem_offset_m=round(t_offset, 2),
        )

    # ── ZONAS UNIFORMES (umbral, interior, salida) ──────────────────────────
    D_MIN = 2.5   # m — espaciado mínimo práctico para luminarias de túnel

    # Decisión tándem —————————————————————————————————————————————————————
    phi_at_global = phi_needed(d_global, L_required)
    flux_shortage = phi_at_global > lm_max_avail

    if flux_shortage:
        denom            = math.pi * w * L_required
        num              = lm_max_avail * n_rows * uf * mf * rho_eff
        d_optimal_single = num / denom if denom > 0 else d_global
        auto_tandem      = (d_optimal_single < D_MIN)
    else:
        d_optimal_single = d_global
        auto_tandem      = False

    use_tandem = (tandem_override if tandem_override is not None else auto_tandem)

    if use_tandem:
        if flux_shortage:
            d_optimal_tandem = min(2.0 * d_optimal_single, d_max_ul)
        else:
            d_optimal_tandem = d_global
        d_try = max(D_MIN, d_optimal_tandem)
        phi   = phi_needed(d_try, L_required) / 2   # por luminaria física del par
        if auto_tandem and tandem_override is None:
            warnings.append(
                f"Zona {zone_name}: TÁNDEM AUTOMÁTICO "
                f"(d_opt={d_optimal_single:.1f} m < D_MIN={D_MIN} m) — "
                f"espaciado inter-par {d_try:.1f} m"
            )
        else:
            warnings.append(f"Zona {zone_name}: TÁNDEM MANUAL activado — inter-par {d_try:.1f} m")
    else:
        if flux_shortage:
            d_try = max(D_MIN, min(d_optimal_single, d_max_ul))
            if d_optimal_single < D_MIN:
                L_max_dmin   = _luminance(lm_max_avail, n_rows, uf, mf, rho_eff, D_MIN, w)
                L_max_tandem = 2.0 * L_max_dmin
                warnings.append(
                    f"⚠️ ZONA {zone_name}: L_req={L_required:.0f} cd/m² NO ALCANZABLE "
                    f"individual (máx ~{L_max_dmin:.0f} cd/m²). "
                    f"En tándem alcanzaría ~{L_max_tandem:.0f} cd/m². "
                    f"Activar modo TÁNDEM."
                )
            else:
                warnings.append(
                    f"Zona {zone_name}: luminaria máxima insuficiente al espaciado global — "
                    f"se reduce a {d_try:.1f} m (L_req={L_required:.0f} cd/m²)"
                )
        else:
            d_try = min(d_global, d_max_ul)
        phi = phi_needed(d_try, L_required)

    selected_op   = select_aphex_continuous(phi, cct, I_max_mA)
    tandem_offset = _BODY_LEN.get(selected_op["model"], 0.70) if use_tandem else 0.0

    n_positions = max(1, math.ceil(zone_length / d_try))
    d_actual    = zone_length / n_positions
    n_lum       = n_positions * (2 if use_tandem else 1)   # físicas por lado
    n_ph        = 2 if use_tandem else 1

    L_est     = _luminance(selected_op["lm"] * n_ph, n_rows, uf, mf, rho_eff, d_actual, w)
    E_req     = L_required / rho_eff if rho_eff > 0 else 0.0
    area      = zone_length * w
    pwr_zone  = n_lum * selected_op["W"]
    flux_zone = n_lum * selected_op["lm"]
    pwr_dens  = pwr_zone / area if area > 0 else 0.0

    # Setpoints con posiciones físicas reales (necesario para tándem)
    unif_setpoints = []
    if use_tandem:
        tlt = _zone_tilt_deg(zone_type, L_required, L_interior)
        for i in range(n_positions):
            x_c = s_start + (i + 0.5) * d_actual
            for idx_t, tag in enumerate(("A", "B")):
                x_phys = round(x_c + (idx_t * 2 - 1) * tandem_offset / 2, 2)
                unif_setpoints.append({
                    "idx":        i * 2 + idx_t + 1,
                    "s":          x_phys,
                    "L_req":      round(L_required, 1),
                    "model":      selected_op["model"],
                    "current_mA": selected_op["mA"],
                    "power_w":    selected_op["W"],
                    "flux_lm":    round(selected_op["lm"], 0),
                    "tilt_deg":   tlt,
                    "tandem":     tag,
                    "pair":       i,
                })

    return ZoneLuminaireDesign(
        zone_type=zone_type, zone_name=zone_name, s_start=s_start, s_end=s_end,
        zone_length=zone_length, L_required=L_required, E_required=round(E_req, 1),
        model=selected_op["model"], pcb=selected_op["pcb"], current_mA=selected_op["mA"],
        flux_lm=selected_op["lm"], power_w=selected_op["W"], optic=optic,
        d_max_ul=round(d_max_ul, 2), d_used=round(d_actual, 2),
        n_luminaires=n_lum, L_estimated=round(L_est, 1),
        UF=round(uf, 4), power_zone_w=round(pwr_zone, 0),
        flux_zone_lm=round(flux_zone, 0), power_density_wm2=round(pwr_dens, 3),
        d_max=round(d_actual, 2),
        setpoints=unif_setpoints,
        tilt_deg=_zone_tilt_deg(zone_type, L_required, L_interior),
        n_tandem=2 if use_tandem else 1,
        tandem_offset_m=round(tandem_offset, 2),
    )


def _zone_label(z_type: str, tr_count: int) -> str:
    """Etiqueta normalizada de zona.
    Las zonas bidireccionales del Portal B llevan sufijo ·B.
    """
    t = z_type.lower()
    if t == "threshold_b":              return "CTH·B"
    if t == "transition_b":             return f"CTR{tr_count}·B"
    if "threshold" in t:                return "CTH"
    if "transition" in t:               return f"CTR{tr_count}"
    if "interior" in t:                 return "CIN"
    if "exit" in t or "salida" in t:    return "CEX"
    if "access" in t or "parting" in t: return "ACC"
    return t.upper()[:4]


# ══════════════════════════════════════════════════════════════════════════════
# FUNCIÓN PRINCIPAL — DISEÑO INSIDE-OUT APHEX
# ══════════════════════════════════════════════════════════════════════════════

def design_aphex_tunnel(
    zones_list:    list,
    params:        dict,
    road_width_m:  float,
    tube_length_m: float,
    tube_id:       str = "T1",
) -> TunnelLuminaireResult:
    """
    Algoritmo inside-out CIE 88:2004 con cadena APHEX S→M→L.

    Parámetros relevantes en `params`:
        I_max_mA         : corriente máxima global DALI (int, default 750)
        cct              : temperatura de color "3000K" / "4000K" (default "4000K")
        arrangement      : clave de ARRANGEMENTS (default "central_single")
        mounting_height_m: altura de montaje (m, default 5.0)
        maintenance_factor: MF (default 0.70)
        road_surface     : clave de ROAD_SURFACES (default "medium_asphalt")
        rho_eff          : reflectancia efectiva (si se especifica, sobreescribe road_surface)
        optic            : "F2M2" / "F2MD" / "F151" / "auto" (default "auto")
    """
    warnings: List[str] = []

    # ── Parámetros ──────────────────────────────────────────────────────────
    I_max_mA   = int(params.get("I_max_mA", 750))
    cct        = str(params.get("cct", "4000K"))
    if cct not in ("3000K", "4000K"):
        cct = "4000K"
        warnings.append("CCT no reconocida — se usa 4000K")

    arrangement = str(params.get("arrangement", "central_single"))
    if arrangement not in ARRANGEMENTS:
        arrangement = "central_single"
        warnings.append("Arreglo no reconocido — se usa central_single")

    h    = float(params.get("mounting_height_m", 4.5))
    mf   = float(params.get("maintenance_factor", DEFAULT_MF))
    w    = max(road_width_m, 1.0)
    wh   = w / h if h > 0 else 1.0
    n_rows = ARRANGEMENTS[arrangement]["n_rows"]

    surface_key = str(params.get("road_surface", "medium_asphalt"))
    rho_eff = float(params.get("rho_eff",
                   ROAD_SURFACES.get(surface_key, ROAD_SURFACES["medium_asphalt"])["rho"]))

    optic_pref = str(params.get("optic", "auto"))
    optic      = auto_select_optic(optic_pref, wh)

    # Parámetros CIE 88 para la curva de transición
    speed_kmh = float(params.get("speed_kmh", 80.0))
    Lth_cie   = float(params.get("Lth", 0.0))
    Lin_cie   = float(params.get("Lin", 0.0))

    # ── Tablas fotométricas ─────────────────────────────────────────────────
    uf      = lookup_uf(optic, wh, arrangement)
    dh_max  = lookup_dh_max(optic, wh, arrangement)
    d_max_ul = dh_max * h

    # Límite práctico (túneles grandes) — nunca > 20 m
    d_interior = min(d_max_ul, 20.0)

    # ── Cadena APHEX ─────────────────────────────────────────────────────────
    chain = build_aphex_chain(cct, I_max_mA)
    if not chain:
        warnings.append(f"No hay puntos de operación con I_max={I_max_mA} mA y CCT={cct}")
        chain = build_aphex_chain(cct, 750)

    # ── Diseño por zona ──────────────────────────────────────────────────────
    zone_designs: List[ZoneLuminaireDesign] = []
    tr_count = 0

    # Zona interior = menor L_req → fija el espaciado global
    valid_zones = [z for z in zones_list if float(z.get("L_min_required", 0)) > 0 and
                   float(z.get("s_end", 0)) > float(z.get("s_start", 0))]

    if valid_zones:
        L_interior = min(float(z.get("L_min_required", 0)) for z in valid_zones)
        # Verificar que S/350mA cumple en zona interior con d_interior
        op0 = chain[0]
        L0  = _luminance(op0["lm"], n_rows, uf, mf, rho_eff, d_interior, w)
        if L0 < L_interior:
            # Recalcular d_interior para que el mínimo punto de operación cubra la interior
            denom = math.pi * w * L_interior
            num   = op0["lm"] * n_rows * uf * mf * rho_eff
            d_possible = num / denom if denom > 0 else d_interior
            d_interior = max(2.5, min(d_possible, d_max_ul))
            warnings.append(
                f"El espaciado máximo de uniformidad ({d_max_ul:.1f} m) es demasiado grande "
                f"para cumplir L_int={L_interior:.0f} cd/m² con el menor punto de operación. "
                f"Se usa d={d_interior:.1f} m."
            )
    else:
        warnings.append("No hay zonas con L_req > 0 — se usa espaciado por Ul.")

    for z in zones_list:
        z_type  = str(z.get("zone_type") or z.get("type") or "interior").lower()
        z_start = float(z.get("s_start", 0))
        z_end   = float(z.get("s_end",   0))
        L_req   = float(z.get("L_min_required", 0))

        if "transition" in z_type:
            tr_count += 1
        z_name = _zone_label(z_type, tr_count)

        _tilt_ov   = params.get("tilt_overrides", {})
        _tandem_ov = params.get("tandem_overrides", {})
        tandem_ov_zone = _tandem_ov.get(z_name)   # True / False / None

        zd = _design_zone_aphex(
            zone_type=z_type, zone_name=z_name,
            s_start=z_start, s_end=z_end, L_required=L_req,
            chain=chain, d_global=d_interior, d_max_ul=d_max_ul,
            uf=uf, n_rows=n_rows, mf=mf, rho_eff=rho_eff, w=w,
            optic=optic, warnings=warnings,
            cct=cct, I_max_mA=I_max_mA,
            speed_kmh=speed_kmh, Lth=Lth_cie, Lin=Lin_cie,
            L_interior=L_interior if valid_zones else 0.0,
            tandem_override=tandem_ov_zone,
        )
        # Aplicar override de tilt del usuario si existe
        if zd.zone_name in _tilt_ov:
            zd.tilt_deg = float(_tilt_ov[zd.zone_name])
        zone_designs.append(zd)

        # Avisos de diseño
        if zd.d_used < 2.5 and zd.n_luminaires > 0 and zd.n_tandem == 1:
            warnings.append(
                f"Zona {z_name}: espaciado {zd.d_used:.2f} m muy reducido — "
                "verificar si es posible la instalación"
            )

    # ── Resultado ────────────────────────────────────────────────────────────
    # LuminaireSpec representativa (zona con mayor L_req)
    if zone_designs:
        dominant = max(zone_designs, key=lambda zd: zd.L_required)
        lum_spec = LuminaireSpec(
            flux_lm           = dominant.flux_lm,
            power_w           = dominant.power_w,
            efficiency        = uf,
            mounting_height_m = h,
            arrangement       = arrangement,
            maintenance_factor= mf,
            name              = f"Aphex {dominant.model}/{dominant.pcb} {dominant.current_mA}mA {cct}",
        )
    else:
        lum_spec = None

    result = TunnelLuminaireResult(
        tube_id           = tube_id,
        luminaire         = lum_spec,
        road_surface_type = surface_key,
        rho_eff           = rho_eff,
        road_width_m      = w,
        tube_length_m     = tube_length_m,
        optic             = optic,
        cct               = cct,
        I_max_mA          = I_max_mA,
        arrangement       = arrangement,
        zones             = zone_designs,
        warnings          = list(set(warnings)),  # deduplicate
    )
    result._compute_totals()
    return result


# ══════════════════════════════════════════════════════════════════════════════
# BACKWARD COMPAT — calculate_luminaire_layout
# Mantiene la interfaz existente del motor; detecta si se usan parámetros
# legacy (flux_lm / efficiency) o nuevos (I_max_mA / cct).
# ══════════════════════════════════════════════════════════════════════════════



# ══════════════════════════════════════════════════════════════════════════════
# MOTOR OPTIMIZADOR — design_aphex_tunnel_optimized
# Sustituye a design_aphex_tunnel cuando se pasan U0_obj/Ul_obj.
# Usa optimizer.py: max d para U0/Ul → corriente para L_req.
# ══════════════════════════════════════════════════════════════════════════════

_SURFACE_RTABLE = {
    "dark_asphalt":    "R3",
    "medium_asphalt":  "R2",
    "light_asphalt":   "R1",
    "concrete":        "C1",
    "bright_concrete": "C2",
}


def _y_positions_for_validation(arrangement: str, w: float, wall_offset: float) -> list:
    """Posiciones y [m] de las luminarias para validación de sección."""
    wo = max(0.05, wall_offset)
    if arrangement in ("bilateral_sym","bilateral_stag","bilateral","staggered"):
        return [wo, w - wo]
    elif arrangement == "central_double":
        return [w/2 - 0.30, w/2 + 0.30]
    elif arrangement == "central_offset":
        return [w/2 + wo]
    elif arrangement == "lateral_left":
        return [wo]
    elif arrangement in ("lateral_right","unilateral"):
        return [w - wo]
    return [w/2]  # central


def is_inside_tunnel(y_m: float, z_m: float, W: float, H_total: float,
                    shape: str = "horseshoe", H_pared: float = 3.0) -> bool:
    """
    Comprueba si el punto (y_m, z_m) está dentro del contorno de la sección transversal.
    Road: y ∈ [0, W], z ∈ [0, H_total] (z=0 en la calzada).
    Para herradura: tramo recto hasta H_pared + bóveda semi-elíptica hasta H_total.
    """
    if y_m < 0 or y_m > W or z_m < 0:
        return False
    if shape == "rectangular":
        return z_m <= H_total
    if shape == "circular":
        # Galería circular: R = ((W/2)² + H_total²) / (2·H_total)
        R = ((W / 2.0) ** 2 + H_total ** 2) / (2.0 * H_total)
        z_ctr = H_total - R   # centro puede estar por debajo de la calzada
        return (y_m - W / 2.0) ** 2 + (z_m - z_ctr) ** 2 <= R ** 2 * 1.02  # 2% margen
    # Herradura: tramo recto
    Hp = min(H_pared, H_total)
    if z_m <= Hp:
        return True
    # Bóveda semi-elíptica: centro en (W/2, Hp), semi-ejes a=W/2, b=H_total-Hp
    a = W / 2.0
    b = H_total - Hp
    if b <= 0:
        return z_m <= H_total
    return ((y_m - W / 2.0) ** 2 / a ** 2 + (z_m - Hp) ** 2 / b ** 2) <= 1.02  # 2% margen


def _relax_setpoints_for_zone_spillover(
    zone_designs, h, w, mf, rtable, cct, I_max_mA, I_min_pct,
    arrangement, wall_offset, tolerance=0.10, max_iters=4,
):
    """
    Correccion posterior al diseño aislado por zona: una luminaria de
    Transicion cercana a un Umbral (mucho mas brillante) recibe luz real de
    ese vecino que el diseño de su propia zona no tuvo en cuenta (cada zona
    se dimensiona asumiendo solo su propio array periodico infinito, sin
    vecinos). El resultado es una L real muy por encima de L_req cerca del
    limite entre zonas (hallazgo verificado: a 2 m del Umbral el spillover
    por si solo ya superaba a L_req en un ~5x).

    Esta pasada NO toca espaciado/optica/tilt (gobernados por U0/Ul, que no
    empeoran por el spillover — si acaso mejoran la uniformidad aparente).
    Solo atenua el flujo de cada posicion cuya L real (con TODAS las zonas
    juntas) supere L_req x (1+tolerance), respetando el suelo de corriente
    I_min_pct — nunca se fuerza por debajo de ese minimo, aunque el spillover
    por si solo ya supere el objetivo (ahi no hay nada que optimizar: ya es
    imposible bajar mas, y no supone ningun problema de seguridad).

    Gauss-Seidel secuencial (no por lotes): las posiciones se recorren una a
    una, ordenadas por posicion a lo largo del tunel, y cada correccion se
    aplica de inmediato antes de evaluar la siguiente -- de forma que la
    contribucion EXACTA de la propia luminaria se aisla usando siempre el
    valor mas reciente de sus vecinas (ya corregidas si les tocaba antes en
    esta misma pasada). Corregir todas las posiciones a la vez asumiendo que
    las demas se quedan fijas (por lotes) se probo inestable: varias
    posiciones vecinas se atenuan a la vez por el mismo exceso mutuo y el
    efecto combinado se pasa de frenada muy por debajo de L_req. La
    actualizacion secuencial e inmediata evita ese problema. Varias pasadas
    (max_iters) por si hace falta que la correccion se propague varias veces.

    Muta zone_designs in-place (setpoints y agregados de zona). Devuelve una
    lista de mensajes de aviso (vacia si no hizo falta corregir nada).
    """
    from photometric_engine.salvi_photometry.ldt_parser import load_ldt
    from photometric_engine.salvi_photometry.geometry import Observer, LuminaireOrientation
    from photometric_engine.salvi_photometry.calculator import TunnelCalculator, LuminaireInstance
    from modules.tunnel.optimizer import select_model_for_flux, _OPTIC_LDT, _LDT_DIR

    warnings_out = []

    zones_with_sp = [zd for zd in zone_designs if zd.n_luminaires > 0 and (zd.setpoints or [])]
    if not zones_with_sp:
        return warnings_out

    if arrangement == 'lateral_left':
        ys_default = [wall_offset]
    elif arrangement in ('lateral_right', 'unilateral'):
        ys_default = [w - wall_offset]
    elif arrangement in ('bilateral_sym', 'bilateral', 'staggered'):
        ys_default = [wall_offset, w - wall_offset]
    elif arrangement == 'central_double':
        ys_default = [w / 2 - 0.30, w / 2 + 0.30]
    else:
        ys_default = [w / 2]

    def _tilt_for_y(tilt_base, y_pos):
        return tilt_base if y_pos < w / 2 else -tilt_base

    def _y_for_setpoint(sp):
        if arrangement == 'bilateral_stag':
            idx = sp.get('idx', 1)
            return wall_offset if (idx - 1) % 2 == 0 else (w - wall_offset)
        return ys_default[0]

    _phot_cache = {}
    def _phot(optic_id):
        if optic_id not in _phot_cache:
            fname = _OPTIC_LDT.get(optic_id, _OPTIC_LDT['F2MD'])
            _phot_cache[optic_id] = load_ldt(_LDT_DIR / fname)
        return _phot_cache[optic_id]

    def _lum_for_setpoint(sp):
        x_pos = float(sp['s'])
        y_pos = _y_for_setpoint(sp)
        tilt0 = float(sp.get('tilt_deg', 0) or 0)
        optic_id = sp.get('optic') or 'F2MD'
        flux = float(sp.get('flux_lm', 0) or 0)
        return LuminaireInstance(x=x_pos, y=y_pos, H=h, photometry=_phot(optic_id), flux_lm=flux,
                                 orientation=LuminaireOrientation(tilt_deg=_tilt_for_y(tilt0, y_pos)))

    # Solo se corrigen posiciones de Transicion. Umbral/Interior/Acceso/Salida
    # son zonas UNIFORMES (mismo flujo en todas sus posiciones): su diseño
    # aislado ya es autoconsistente (verificado: L_est del diseño coincide con
    # la L real de la zona construida con sus vecinas reales, una vez
    # corregido n_side/max_lum_dist — ver optimizer._reach_for). Si se
    # "corrigen" tambien esas posiciones, cada una ve como spillover fijo la
    # contribucion de sus vecinas — que en una zona uniforme son casi toda la
    # señal — y todas se atenuan entre si en cascada hacia el suelo. Solo
    # Transicion, con flujo variable posicion a posicion y un vecino de OTRO
    # tipo (Umbral, mucho mas brillante) al lado, tiene un exceso real que
    # corregir aqui.
    targets = []  # (zd, sp_index)
    for zd in zones_with_sp:
        if 'transition' not in str(zd.zone_type or ''):
            continue
        for i, sp in enumerate(zd.setpoints):
            if float(sp.get('flux_lm', 0) or 0) > 0 and float(sp.get('L_req', 0) or 0) > 0:
                targets.append((zd, i))
    if not targets:
        return warnings_out

    def _direction_for_zone(zd_obj) -> float:
        zt = str(getattr(zd_obj, 'zone_type', '') or '')
        return -1.0 if zt.endswith('_b') else 1.0

    # Alcance conservador (maximo entre las opticas realmente usadas) para el
    # corte de luminarias lejanas -- mismo criterio que optimizer._reach_for.
    optics_in_use = {sp.get('optic') or 'F2MD' for zd in zones_with_sp for sp in zd.setpoints}
    reach = max((_phot(o).reach_distance(h) for o in optics_in_use), default=300.0)
    calc = TunnelCalculator(rtable, mf, max_luminaire_dist=reach)
    obs_fwd = Observer(lane_y_m=w / 2, d_observer_m=60.0, direction=1.0)
    obs_bwd = Observer(lane_y_m=w / 2, d_observer_m=60.0, direction=-1.0)

    # L_req representa una media en la malla CIE 140 (5 puntos a lo ancho de
    # la calzada — mismo criterio que _calc_grid/_ys_profile en optimizer.py
    # y photometric_verify.py), NO el valor en un unico punto. Medir L_now/
    # own_only solo en la linea bajo la luminaria (disposicion central) da un
    # valor sistematicamente mas alto que la media real del carril -- ese
    # punto es, por construccion, el mas brillante de la seccion transversal
    # -- lo que hacia parecer "exceso" en casi cualquier posicion (no solo
    # las que de verdad reciben spillover de una zona vecina) y recortaba
    # flujo de mas en toda la Transicion.
    _N_AVG  = 5
    _ys_avg = [(j + 0.5) * w / _N_AVG for j in range(_N_AVG)]

    def _L_avg(x_pos, lums, obs):
        pts = [(x_pos, y) for y in _ys_avg]
        vals = calc.luminance_at_points_batch(pts, lums, obs)
        return float(sum(vals) / len(vals))

    # ── Correccion secuencial (Gauss-Seidel real) ───────────────────────────
    # Se recorren las posiciones de Transicion UNA A UNA (ordenadas por x) y
    # cada correccion se aplica de inmediato sobre el mismo array de
    # luminarias -- las posiciones siguientes de esta misma pasada YA ven el
    # valor corregido, en vez de asumir que todas las vecinas se quedan fijas
    # y aplicar todas las correcciones a la vez (eso, probado, oscila: varias
    # posiciones cercanas se atenuan simultaneamente por exceso mutuo y el
    # efecto combinado se pasa de frenada muy por debajo de L_req). Con
    # actualizacion inmediata cada correccion es exacta con la informacion
    # disponible en ese momento y no hace falta amortiguar.
    flat_refs = []
    lums_all  = []
    for zd in zones_with_sp:
        for i, sp in enumerate(zd.setpoints):
            flat_refs.append((zd, i))
            lums_all.append(_lum_for_setpoint(sp))
    index_of = {(id(zd), i): k for k, (zd, i) in enumerate(flat_refs)}

    targets_sorted = sorted(targets, key=lambda t: float(t[0].setpoints[t[1]]['s']))

    n_corrected  = 0
    power_before = {}  # (id(zd), i) -> W antes de tocar nada, para el resumen final

    for _sweep in range(max_iters):
        any_change = False
        for zd, i in targets_sorted:
            sp    = zd.setpoints[i]
            key   = (id(zd), i)
            if key not in power_before:
                power_before[key] = float(sp.get('power_w', 0) or 0)

            L_req    = float(sp['L_req'])
            x_pos    = float(sp['s'])
            obs_use  = obs_bwd if _direction_for_zone(zd) < 0 else obs_fwd

            L_now = _L_avg(x_pos, lums_all, obs_use)
            if L_now <= L_req * (1.0 + tolerance):
                continue

            idx      = index_of[key]
            own_only = _L_avg(x_pos, [lums_all[idx]], obs_use)
            if own_only <= 1e-9:
                continue  # esta posicion no depende de si misma (ya la cubre solo el vecino)

            spillover       = L_now - own_only
            own_only_target = max(0.0, L_req - spillover)
            flux_old        = float(sp['flux_lm'])
            sel             = select_model_for_flux(flux_old * (own_only_target / own_only),
                                                     cct, I_max_mA, I_min_pct)
            flux_new        = sel['lm']
            if flux_new >= flux_old * 0.999:
                continue  # ya en el suelo de corriente, o no hace falta bajar mas

            sp['flux_lm']    = round(flux_new, 0)
            sp['model']      = sel['model']
            sp['current_mA'] = round(sel['mA'], 1)
            sp['power_w']    = sel['W']
            lums_all[idx]    = _lum_for_setpoint(sp)  # visible de inmediato al resto de la pasada
            n_corrected += 1
            any_change = True

        if not any_change:
            break

    if n_corrected == 0:
        return warnings_out

    # ── Pasada final de seguridad: nunca por debajo de L_req ────────────────
    # Tras converger, alguna posicion puede haber quedado un poco por debajo
    # de L_req (la correccion de una vecina posterior en la misma pasada
    # puede dejar a una anterior justo debajo). El exceso es seguro (nunca se
    # corrige de mas), pero un defecto no lo es -- una unica pasada secuencial
    # que SOLO sube flujo, partiendo ya del estado casi convergido de arriba
    # (por eso no hace falta iterarla ni amortiguarla: los ajustes que quedan
    # son pequeños).
    for zd, i in targets_sorted:
        sp = zd.setpoints[i]
        obs_use = obs_bwd if _direction_for_zone(zd) < 0 else obs_fwd
        x_pos = float(sp['s'])
        L_req = float(sp['L_req'])
        L_now = _L_avg(x_pos, lums_all, obs_use)
        if L_now >= L_req * 0.999:
            continue
        idx = index_of[(id(zd), i)]
        own_only = _L_avg(x_pos, [lums_all[idx]], obs_use)
        if own_only <= 1e-9:
            continue
        spillover = L_now - own_only
        own_only_target = max(0.0, L_req - spillover)
        flux_old = float(sp['flux_lm'])
        if own_only_target <= own_only:
            continue
        sel = select_model_for_flux(flux_old * (own_only_target / own_only), cct, I_max_mA, I_min_pct)
        if sel['lm'] <= flux_old * 1.001:
            continue
        sp['flux_lm']    = round(sel['lm'], 0)
        sp['model']      = sel['model']
        sp['current_mA'] = round(sel['mA'], 1)
        sp['power_w']    = sel['W']
        lums_all[idx]    = _lum_for_setpoint(sp)

    # Recalculo final de L real (con el flujo ya corregido) para reportar en
    # cada setpoint, y agregados de zona afectados por el cambio de potencia.
    for zd, i in targets:
        sp = zd.setpoints[i]
        obs_use = obs_bwd if _direction_for_zone(zd) < 0 else obs_fwd
        L_now = _L_avg(float(sp['s']), lums_all, obs_use)
        sp['L_est'] = round(float(L_now), 1)

    total_saving_w = 0.0
    for (zd, i) in targets:
        key = (id(zd), i)
        if key in power_before:
            total_saving_w += power_before[key] - float(zd.setpoints[i].get('power_w', 0) or 0)

    corrected_zones = {id(zd): zd for zd, _ in targets}.values()
    for zd in corrected_zones:
        sps = zd.setpoints
        zd.power_zone_w        = round(sum(float(sp.get('power_w', 0) or 0) for sp in sps), 0)
        zd.flux_zone_lm         = round(sum(float(sp.get('flux_lm', 0) or 0) for sp in sps), 0)
        area = zd.zone_length * w
        zd.power_density_wm2   = round(zd.power_zone_w / area, 3) if area > 0 else 0.0
        zd.L_estimated          = round(sum(float(sp.get('L_est', 0) or 0) for sp in sps) / len(sps), 1) if sps else zd.L_estimated
        dominant = max(sps, key=lambda sp: float(sp.get('L_req', 0) or 0))
        zd.model      = dominant['model']
        zd.current_mA = round(float(dominant.get('current_mA', 0) or 0))
        zd.flux_lm    = round(float(dominant.get('flux_lm', 0) or 0), 0)
        zd.power_w    = round(float(dominant.get('power_w', 0) or 0), 1)

    warnings_out.append(
        f"Ajuste por interferencia entre zonas: {n_corrected} luminarias atenuadas porque ya reciben "
        f"suficiente luz de una zona vecina mas brillante (ahorro estimado: {total_saving_w/1000:.2f} kW)."
    )
    return warnings_out


def _enforce_required_luminance_profile(
    zone_designs, h, w, mf, rtable, cct, I_max_mA, I_min_pct,
    arrangement, wall_offset, tube_length_m, Lth, Lth_b, Lin,
    speed_kmh, tolerance=0.0, max_iters=40, spacing_quantum=0.5,
):
    """
    Cierre fotometrico del layout fisico completo.

    El dimensionado local usa celdas periodicas CIE 140 para maximizar la
    interdistancia. Esta pasada evalua despues todas las luminarias reales
    juntas, a intervalos de 1 m y en cinco puntos transversales, y aumenta
    modelo/corriente donde Lcalc < Lreq. Si todas las luminarias vecinas han
    alcanzado su limite, anade una posicion de refuerzo en el punto deficitario.

    La optica y el tilt no se modifican aqui: ya fueron elegidos por U0/Ul.
    """
    import numpy as np
    from photometric_engine.salvi_photometry.ldt_parser import load_ldt
    from photometric_engine.salvi_photometry.geometry import Observer, LuminaireOrientation
    from photometric_engine.salvi_photometry.calculator import TunnelCalculator, LuminaireInstance
    from modules.tunnel.optimizer import (
        select_model_for_flux, cie88_L_transition,
        _OPTIC_LDT, _LDT_DIR,
    )
    from modules.tunnel.required_luminance import build_requirement_samples

    warnings_out = []
    active_zones = [
        zd for zd in zone_designs
        if zd.n_luminaires > 0 and (zd.setpoints or [])
        and float(zd.s_end) >= 0.0 and float(zd.s_start) <= tube_length_m
    ]
    if not active_zones:
        return warnings_out

    if arrangement == 'lateral_left':
        ys_default = [wall_offset]
    elif arrangement in ('lateral_right', 'unilateral'):
        ys_default = [w - wall_offset]
    elif arrangement in ('bilateral_sym', 'bilateral', 'staggered'):
        ys_default = [wall_offset, w - wall_offset]
    elif arrangement == 'central_double':
        ys_default = [w / 2 - 0.30, w / 2 + 0.30]
    else:
        ys_default = [w / 2]

    def _tilt_for_y(tilt_base, y_pos):
        return tilt_base if y_pos < w / 2 else -tilt_base

    def _ys_for_setpoint(sp):
        if arrangement == 'bilateral_stag':
            idx = int(sp.get('idx', 1) or 1)
            return [wall_offset if (idx - 1) % 2 == 0 else (w - wall_offset)]
        return ys_default

    phot_cache = {}

    def _phot(optic_id):
        oid = optic_id or 'F2MD'
        if oid not in phot_cache:
            phot_cache[oid] = load_ldt(_LDT_DIR / _OPTIC_LDT.get(oid, _OPTIC_LDT['F2MD']))
        return phot_cache[oid]

    optics_in_use = {
        sp.get('optic') or 'F2MD'
        for zd in active_zones for sp in (zd.setpoints or [])
    }
    reach = max((_phot(oid).reach_distance(h) for oid in optics_in_use), default=300.0)
    calc = TunnelCalculator(rtable, mf, max_luminaire_dist=reach)
    obs_fwd = Observer(lane_y_m=w / 2, d_observer_m=60.0, direction=1.0)
    obs_bwd = Observer(lane_y_m=w / 2, d_observer_m=60.0, direction=-1.0)
    ys_calc = [(j + 0.5) * w / 5 for j in range(5)]

    transition_ranges = {}
    for zd in active_zones:
        zt = str(zd.zone_type or '')
        if 'transition' not in zt:
            continue
        if zt not in transition_ranges:
            transition_ranges[zt] = [float(zd.s_start), float(zd.s_end)]
        else:
            transition_ranges[zt][0] = min(transition_ranges[zt][0], float(zd.s_start))
            transition_ranges[zt][1] = max(transition_ranges[zt][1], float(zd.s_end))

    def _target_for_zone(zd, s_val):
        zt = str(zd.zone_type or '')
        if 'transition' not in zt:
            return max(0.0, float(zd.L_required))
        s0, s1 = transition_ranges[zt]
        if zt.endswith('_b'):
            return cie88_L_transition(
                s1 - s_val, 0.0, Lth_b, Lin, speed_kmh,
            )
        return cie88_L_transition(s_val, s0, Lth, Lin, speed_kmh)

    def _zone_and_target(s_val):
        candidates = [
            zd for zd in active_zones
            if float(zd.s_start) - 1e-6 <= s_val <= float(zd.s_end) + 1e-6
        ]
        if not candidates:
            return None, 0.0
        evaluated = [(zd, _target_for_zone(zd, s_val)) for zd in candidates]
        return max(evaluated, key=lambda item: item[1])

    def _build_groups():
        groups = []
        lums = []
        for zd in active_zones:
            for i, sp in enumerate(zd.setpoints or []):
                flux = float(sp.get('flux_lm', 0) or 0)
                if flux <= 0:
                    continue
                optic_id = sp.get('optic') or zd.optic or 'F2MD'
                tilt0 = float(sp.get('tilt_deg', zd.tilt_deg) or 0)
                group_lums = []
                for y_pos in _ys_for_setpoint(sp):
                    group_lums.append(LuminaireInstance(
                        x=float(sp['s']), y=y_pos, H=h,
                        photometry=_phot(optic_id), flux_lm=flux,
                        orientation=LuminaireOrientation(
                            tilt_deg=_tilt_for_y(tilt0, y_pos)
                        ),
                    ))
                groups.append({'zd': zd, 'i': i, 'sp': sp, 'lums': group_lums})
                lums.extend(group_lums)
        return groups, lums

    canonical_samples = build_requirement_samples(
        active_zones,
        tube_length_m=tube_length_m,
        Lth=Lth,
        Lth_b=Lth_b,
        Lin=Lin,
        speed_kmh=speed_kmh,
    )
    sample_meta = [
        (item["s"], item["zone"], item["target"], item["direction"])
        for item in canonical_samples
    ]

    def _evaluate(lums, meta):
        values = [0.0] * len(meta)
        for direction, obs in ((1.0, obs_fwd), (-1.0, obs_bwd)):
            indices = [
                i for i, (_, _, _, sample_direction) in enumerate(meta)
                if sample_direction == direction
            ]
            if not indices:
                continue
            pts = [
                (meta[i][0], y_pos)
                for i in indices for y_pos in ys_calc
            ]
            raw = np.asarray(calc.luminance_at_points_batch(pts, lums, obs))
            means = raw.reshape(len(indices), len(ys_calc)).mean(axis=1)
            for local_i, meta_i in enumerate(indices):
                values[meta_i] = float(means[local_i])
        return values

    initial_count = sum(len(zd.setpoints or []) for zd in active_zones)
    # Los extremos fisicos no reciben la mitad del array periodico "virtual"
    # usado para dimensionar el vano. En opticas longitudinales el refuerzo
    # necesario puede superar el 10 % aun con una solucion correcta; el
    # limite sigue siendo una salvaguarda, no un criterio de diseno.
    booster_limit = max(20, int(math.ceil(initial_count * 0.25)))
    boosters_added = 0

    for _ in range(max_iters):
        groups, lums = _build_groups()
        if not lums:
            break
        calc_values = _evaluate(lums, sample_meta)
        deficits = [
            (target / max(L_calc, 1e-9), i)
            for i, ((_, _, target, _), L_calc) in enumerate(zip(sample_meta, calc_values))
            if L_calc < target * (1.0 - tolerance)
        ]
        if not deficits:
            break

        factors = {}
        factor_sources = {}
        for ratio, meta_i in deficits:
            s_val, zd, _, _ = sample_meta[meta_i]
            same_zone = [
                (abs(float(g['sp']['s']) - s_val), gi)
                for gi, g in enumerate(groups)
                if g['zd'] is zd
            ]
            if not same_zone and 'transition' in str(zd.zone_type or ''):
                same_zone = [
                    (abs(float(g['sp']['s']) - s_val), gi)
                    for gi, g in enumerate(groups)
                    if str(g['zd'].zone_type or '') == str(zd.zone_type or '')
                ]
            if not same_zone:
                continue
            _, nearest = min(same_zone)
            key = nearest
            factors[key] = max(factors.get(key, 1.0), ratio * 1.01)
            factor_sources.setdefault(key, []).append((ratio, meta_i))

        changed = False
        unresolved = []
        for gi, factor in factors.items():
            group = groups[gi]
            sp = group['sp']
            flux_old = float(sp.get('flux_lm', 0) or 0)
            selected = select_model_for_flux(
                flux_old * factor, cct, I_max_mA, I_min_pct,
            )
            if selected['lm'] <= flux_old * 1.001:
                unresolved.extend(factor_sources.get(gi, []))
                continue
            sp['model'] = selected['model']
            sp['current_mA'] = round(selected['mA'], 1)
            sp['power_w'] = selected['W']
            sp['flux_lm'] = round(selected['lm'], 0)
            changed = True

        # Un deficit cuyo punto mas cercano ya esta al limite no debe quedar
        # bloqueado por el hecho de que, en otra zona, aun se pueda aumentar
        # corriente. Resolver ambos problemas en la misma iteracion evita que
        # los portales esperen a que converja todo el resto del tunel.
        if not unresolved:
            if not changed:
                break
            continue

        # Las posiciones candidatas de estos puntos ya estan al limite.
        # Incorporar varios refuerzos en una misma pasada cuando el deficit es
        # grande evita recalcular todo el tunel una vez por cada unidad. Al
        # final se podan individualmente los que resulten redundantes.
        if boosters_added >= booster_limit:
            if changed:
                continue
            break
        max_sel = select_model_for_flux(1e12, cct, I_max_mA, I_min_pct)
        unresolved.sort(reverse=True)
        worst_ratio = unresolved[0][0]
        n_boost_round = min(
            6,
            booster_limit - boosters_added,
            max(1, int(math.ceil((worst_ratio - 1.0) * 8.0))),
        )
        for add_idx in range(n_boost_round):
            _, worst_i = unresolved[min(add_idx, len(unresolved) - 1)]
            s_worst, zd_worst, target_worst, _ = sample_meta[worst_i]
            existing = sorted(
                zd_worst.setpoints or [],
                key=lambda sp: abs(float(sp['s']) - s_worst),
            )
            if not existing:
                continue
            template = existing[0]
            quantum = max(0.5, float(spacing_quantum))
            s_boost = round(s_worst / quantum) * quantum
            s_boost = min(
                max(s_boost, float(zd_worst.s_start)),
                float(zd_worst.s_end),
            )
            occupied = {round(float(sp['s']), 3) for sp in zd_worst.setpoints}
            if round(s_boost, 3) in occupied:
                for step in range(1, 65):
                    delta = quantum * ((step + 1) // 2) * (1 if step % 2 else -1)
                    candidate = min(
                        max(
                            s_boost + delta,
                            float(zd_worst.s_start),
                        ),
                        float(zd_worst.s_end),
                    )
                    if round(candidate, 3) not in occupied:
                        s_boost = candidate
                        break
            booster = {
                'idx': len(zd_worst.setpoints) + 1,
                's': round(s_boost, 2),
                'L_req': round(target_worst, 1),
                'model': max_sel['model'],
                'optic': template.get('optic') or zd_worst.optic,
                'tilt_deg': float(template.get('tilt_deg', zd_worst.tilt_deg) or 0),
                'current_mA': round(max_sel['mA'], 1),
                'power_w': max_sel['W'],
                'flux_lm': round(max_sel['lm'], 0),
                'target_flux_lm': round(max_sel['lm'], 3),
                'U0': template.get('U0', zd_worst.UF),
                'L_est': 0.0,
                'booster': True,
                'spacing_m': round(
                    min(
                        abs(float(sp['s']) - s_boost)
                        for sp in existing
                    ),
                    3,
                ),
                'spacing_stage': int(
                    template.get('spacing_stage', 0) or 0
                ) + 1,
            }
            if 'transition' in str(zd_worst.zone_type or ''):
                inner_edge = (
                    float(zd_worst.s_start)
                    if str(zd_worst.zone_type or '').endswith('_b')
                    else float(zd_worst.s_end)
                )
                booster['distance_from_interior_m'] = round(
                    abs(s_boost - inner_edge), 3,
                )
            zd_worst.setpoints.append(booster)
            boosters_added += 1

    groups, lums = _build_groups()
    final_values = _evaluate(lums, sample_meta) if lums else []

    # Eliminar cualquier refuerzo que el ajuste por lotes haya dejado
    # redundante. La luminancia directa es lineal con el flujo, por lo que su
    # contribucion puede restarse sin recalcular el resto del layout.
    for group in reversed([g for g in groups if g['sp'].get('booster')]):
        contribution = _evaluate(group['lums'], sample_meta)
        candidate_values = [
            total - own for total, own in zip(final_values, contribution)
        ]
        if all(
            L_calc >= target * (1.0 - tolerance)
            for (_, _, target, _), L_calc in zip(sample_meta, candidate_values)
        ):
            group['zd'].setpoints.remove(group['sp'])
            final_values = candidate_values
            boosters_added -= 1

    groups, lums = _build_groups()

    # En los refuerzos que siguen siendo necesarios, bajar modelo/corriente
    # hasta el minimo que conserva simultaneamente todas las restricciones.
    # Se calcula por superposicion lineal y luego se redondea al punto fisico
    # disponible mediante select_model_for_flux.
    for group in reversed([g for g in groups if g['sp'].get('booster')]):
        sp = group['sp']
        flux_old = float(sp.get('flux_lm', 0) or 0)
        if flux_old <= 0:
            continue
        contribution = _evaluate(group['lums'], sample_meta)
        base_values = [
            total - own for total, own in zip(final_values, contribution)
        ]
        required_scale = 0.0
        for (_, _, target, _), base, own in zip(sample_meta, base_values, contribution):
            if own <= 1e-12:
                continue
            required_scale = max(
                required_scale,
                (target * (1.0 - tolerance) - base) / own,
            )
        required_scale = min(1.0, max(0.0, required_scale))
        selected = select_model_for_flux(
            flux_old * required_scale * 1.001,
            cct, I_max_mA, I_min_pct,
        )
        flux_new = float(selected['lm'])
        if flux_new >= flux_old * 0.999:
            continue
        sp['model'] = selected['model']
        sp['current_mA'] = round(selected['mA'], 1)
        sp['power_w'] = selected['W']
        sp['flux_lm'] = round(flux_new, 0)
        scale_new = flux_new / flux_old
        final_values = [
            base + own * scale_new
            for base, own in zip(base_values, contribution)
        ]

    groups, lums = _build_groups()
    final_deficits = [
        (target / max(L_calc, 1e-9), s_val, L_calc, target)
        for (s_val, _, target, _), L_calc in zip(sample_meta, final_values)
        if L_calc < target * (1.0 - tolerance)
    ]

    # Actualizar L_est de cada setpoint y agregados de zona con el layout
    # definitivo. Esto hace que la tabla compare magnitudes homogeneas.
    sp_meta = []
    for zd in active_zones:
        for sp in zd.setpoints or []:
            sp_meta.append((
                float(sp['s']),
                zd,
                _target_for_zone(zd, float(sp['s'])),
                -1.0 if str(zd.zone_type or '').endswith('_b') else 1.0,
            ))
    sp_values = _evaluate(lums, sp_meta) if sp_meta and lums else []
    for (_, _, _, _), L_calc, group in zip(sp_meta, sp_values, groups):
        group['sp']['L_est'] = round(L_calc, 1)

    profile_by_zone = {}
    for (s_val, zd, target, _), L_calc in zip(sample_meta, final_values):
        bucket = profile_by_zone.setdefault(id(zd), {
            'values': [], 'ratios': [],
        })
        bucket['values'].append(float(L_calc))
        bucket['ratios'].append(float(L_calc) / max(float(target), 1e-9))

    for zd in active_zones:
        sps = zd.setpoints or []
        if not sps:
            continue
        sps.sort(key=lambda sp: float(sp['s']))
        for idx, sp in enumerate(sps, start=1):
            sp['idx'] = idx
        zd.n_luminaires = len(sps)
        zd.power_zone_w = round(sum(float(sp.get('power_w', 0) or 0) for sp in sps), 0)
        zd.flux_zone_lm = round(sum(float(sp.get('flux_lm', 0) or 0) for sp in sps), 0)
        area = zd.zone_length * w
        zd.power_density_wm2 = round(zd.power_zone_w / area, 3) if area > 0 else 0.0
        zd.L_estimated = round(
            sum(float(sp.get('L_est', 0) or 0) for sp in sps) / len(sps), 1
        )
        dominant = max(sps, key=lambda sp: float(sp.get('L_req', 0) or 0))
        zd.model = dominant['model']
        zd.current_mA = round(float(dominant.get('current_mA', 0) or 0))
        zd.flux_lm = round(float(dominant.get('flux_lm', 0) or 0), 0)
        zd.power_w = round(float(dominant.get('power_w', 0) or 0), 1)
        profile_stats = profile_by_zone.get(id(zd))
        if profile_stats and profile_stats['values']:
            zd.profile_L_avg = round(
                sum(profile_stats['values']) / len(profile_stats['values']), 2
            )
            zd.profile_L_min = round(min(profile_stats['values']), 2)
            zd.profile_min_ratio = round(min(profile_stats['ratios']), 4)

    if boosters_added:
        warnings_out.append(
            f"Cierre Lcalc>=Lreq: añadidas {boosters_added} posiciones de refuerzo "
            "solo donde modelo/corriente ya habian alcanzado su limite."
        )
    if final_deficits:
        worst = max(final_deficits)
        warnings_out.append(
            f"🔴 Cierre fotometrico incompleto: {len(final_deficits)} puntos siguen por "
            f"debajo de Lreq; peor punto s={worst[1]:.1f} m, "
            f"Lcalc={worst[2]:.1f}, Lreq={worst[3]:.1f} cd/m2."
        )
    else:
        warnings_out.append(
            f"Perfil fisico validado: Lcalc >= Lreq en {len(sample_meta)} puntos "
            "longitudinales (media de 5 puntos transversales)."
        )
    return warnings_out



def design_aphex_tunnel_optimized(
    zones_list:    list,
    params:        dict,
    road_width_m:  float,
    tube_length_m: float,
    tube_id:       str = "T1",
) -> TunnelLuminaireResult:
    """
    Motor inside-out con optimizacion U0/Ul via CIE 140 real.

    Fase 1 — Interior:
        Celda periodica sobre malla instalable. Prioridad
        F151 -> F2MD -> F2M2 y objetivo configurable de numero o potencia.

    Fase 2 — Transicion continua:
        Desde Interior hacia cada portal, con reducciones discretas de
        interdistancia. Optica y tilt se resuelven antes del hardware.

    Fase 3 — Acoplamiento global:
        Matriz de influencia L=A@phi, monotonia por escalon y asignacion
        posterior del modelo-driver menor compatible con Imin/Imax.

    Modo retrofit (d_fixed != None): d fijo en todas las zonas.
    """
    from modules.tunnel.optimizer import (
        optimize_interior, optimize_single_luminaire, find_dmax_for_zone,
        cie88_L_transition, flux_power_at_current,
        L_from_flux, phi_for_luminance, eval_quality,
        select_geometry_for_spacing, select_model_for_flux,
        set_design_ambient_temperature,
    )

    warnings_out: List[str] = []

    # ── Parametros ─────────────────────────────────────────────────────────
    set_design_ambient_temperature(float(params.get('ta_design_c', 20.0)))
    I_max_mA    = float(params.get('I_max_mA', 750))
    _I_min_raw  = params.get('I_min_pct', 0.30)
    I_min_pct   = float(_I_min_raw) / 100.0 if float(_I_min_raw) > 1.0 else float(_I_min_raw)

    cct         = str(params.get('cct', '4000K'))
    if cct not in ('3000K', '4000K'):
        cct = '4000K'

    arrangement = str(params.get('arrangement', 'central_single'))
    if arrangement not in ARRANGEMENTS:
        arrangement = 'central_single'

    h          = float(params.get('mounting_height_m', 4.5))
    wall_offset = float(params.get('wall_offset_m', 0.30))
    axis_offset = float(params.get('axis_offset_m', 0.30))
    if arrangement == 'central_offset':
        wall_offset = axis_offset   # fila central desplazada: offset medido desde el eje
    mf  = float(params.get('maintenance_factor', DEFAULT_MF))
    w   = max(road_width_m, 1.0)

    # ── Validación de posición de luminaria dentro de la sección ────────────
    _H_total  = float(params.get('height_m', 5.5))
    _shape    = str(params.get('tunnel_shape', 'horseshoe'))
    _H_pared  = float(params.get('H_pared_m', 3.0))
    arrangement_val = str(params.get('arrangement', 'central_single'))
    _ys_check = _y_positions_for_validation(arrangement_val, w, wall_offset)
    for _y in _ys_check:
        if not is_inside_tunnel(_y, h, w, _H_total, _shape, _H_pared):
            warnings_out.append(
                f"⚠️ POSICIÓN DE LUMINARIA FUERA DEL CONTORNO: "
                f"y={_y:.2f} m, altura={h:.2f} m — "
                f"ajusta la distancia a pared o altura de montaje."
            )

    surface_key = str(params.get('road_surface', 'medium_asphalt'))
    rtable      = _SURFACE_RTABLE.get(surface_key, 'R2')

    U0_obj   = float(params.get('U0_obj',  0.40))
    Ul_obj   = float(params.get('Ul_obj',  0.60))
    tilt_max = float(params.get('tilt_max', 20.0))
    tilt_grid = [float(t) for t in range(0, int(tilt_max)+1, 5)]
    if tilt_max not in tilt_grid:
        tilt_grid.append(tilt_max)

    _df     = params.get('d_fixed', None)
    d_fixed = float(_df) if _df not in (None, '', 0, '0') else None

    _dm     = params.get('d_min', 2.5)
    D_MIN   = float(_dm) if _dm not in (None, '', 0) else 2.5
    D_MIN   = max(0.3, min(D_MIN, 10.0))  # clamp 0.3–10 m

    optimization_goal = str(
        params.get('optimization_goal', 'min_luminaires')
    ).lower()
    if optimization_goal not in ('min_luminaires', 'min_power'):
        optimization_goal = 'min_luminaires'
    spacing_quantum = max(
        0.5, float(params.get('spacing_quantum_m', 0.5) or 0.5)
    )
    D_MIN = (
        math.ceil(D_MIN / spacing_quantum - 1e-9)
        * spacing_quantum
    )
    transition_spacing_step = max(
        spacing_quantum,
        float(params.get('transition_spacing_step_m', 2.0) or 2.0),
    )
    transition_spacing_step = (
        math.ceil(transition_spacing_step / spacing_quantum - 1e-9)
        * spacing_quantum
    )

    speed_kmh = float(params.get('speed_kmh', 80.0))
    Lth_cie   = float(params.get('Lth', 0.0))
    Lth_b_cie = float(params.get('Lth_b', Lth_cie))   # luminancia umbral portal B
    Lin_cie   = float(params.get('Lin', 0.0))

    # ── Zonas validas ───────────────────────────────────────────────────────
    valid_zones = [z for z in zones_list
                   if float(z.get('L_min_required', 0)) > 0
                   and float(z.get('s_end', 0)) > float(z.get('s_start', 0))]

    if not valid_zones:
        warnings_out.append('No hay zonas con L_req > 0.')
        result = TunnelLuminaireResult(
            tube_id=tube_id, luminaire=None,
            road_surface_type=surface_key, rho_eff=0.085,
            road_width_m=w, tube_length_m=tube_length_m,
            optic='F2M2', cct=cct, I_max_mA=int(I_max_mA),
            arrangement=arrangement, zones=[], warnings=warnings_out,
        )
        result._compute_totals()
        return result

    # El ancla inside-out es la zona INTERIOR y, si el tunel es corto y no
    # llega a existir geometricamente, el Lin normativo. Tomar el minimo de
    # todas las zonas incluia salida/parting (habitualmente 0.5*Lin) y
    # dimensionaba el centro por debajo de su requisito real.
    interior_zone = next(
        (z for z in valid_zones
         if 'interior' in str(z.get('zone_type') or z.get('type') or '').lower()),
        None,
    )
    L_interior = (
        float(interior_zone.get('L_min_required', Lin_cie))
        if interior_zone is not None
        else (Lin_cie if Lin_cie > 0 else min(
            float(z.get('L_min_required', 0)) for z in valid_zones
        ))
    )

    # ── Fase 1: Optimizar interior ─────────────────────────────────────────
    if d_fixed is not None:
        # Modo retrofit: d fijo, optimizar (optica, tilt, I) para L_int
        from modules.tunnel.optimizer import optimize_single_luminaire as _opt_single
        int_res = _opt_single(
            L_req=L_interior, d=d_fixed, h=h, w=w,
            U0_obj=U0_obj, Ul_obj=Ul_obj, I_max_mA=I_max_mA, cct=cct,
            rtable=rtable, mf=mf, arrangement=arrangement,
            I_min_pct=I_min_pct, tilt_grid=tilt_grid,
            wall_offset=wall_offset,
        )
        d_interior  = d_fixed
        int_optic   = int_res['optic']
        int_tilt    = int_res['tilt_deg']
        int_model   = int_res['model']
        int_mA      = int_res['mA']
        int_lm      = int_res['lm']
        int_W       = int_res['W']
        int_U0      = int_res['U0']
        int_Ul      = 0.0  # en retrofit no se garantiza Ul a priori
        int_L_est   = int_res['L_est']
        if int_res.get('warning'):
            warnings_out.append(f"🔴 INTERIOR (retrofit d={d_fixed:.1f}m): {int_res['warning']}")
    else:
        int_res = optimize_interior(
            h=h, w=w, L_int=L_interior,
            U0_obj=U0_obj, Ul_obj=Ul_obj,
            I_max_mA=I_max_mA, cct=cct,
            rtable=rtable, mf=mf, arrangement=arrangement,
            I_min_pct=I_min_pct, tilt_grid=tilt_grid,
            d_min=D_MIN, wall_offset=wall_offset,
            optimization_goal=optimization_goal,
            spacing_quantum_m=spacing_quantum,
        )
        d_interior = int_res['d_opt']
        int_optic  = int_res['optic']
        int_tilt   = int_res['tilt_deg']
        int_model  = int_res['model']
        int_mA     = int_res['mA']
        int_lm     = int_res['lm']
        int_W      = int_res['W']
        int_U0     = int_res['U0']
        int_Ul     = int_res['Ul']
        int_L_est  = int_res['L_est']
        warnings_out.extend(int_res.get('warnings', []))

    # ── Fase 2-3: Diseno por zona ──────────────────────────────────────────
    zone_designs: List[ZoneLuminaireDesign] = []
    tr_count = 0

    for z in zones_list:
        z_type  = str(z.get('zone_type') or z.get('type') or 'interior').lower()
        z_start = float(z.get('s_start', 0))
        z_end   = float(z.get('s_end',   0))
        z_len   = max(0.0, z_end - z_start)
        L_req   = float(z.get('L_min_required', 0))

        if 'transition' in z_type:
            tr_count += 1
        z_name = _zone_label(z_type, tr_count)

        # Aplicar override de tilt si existe
        _tilt_ov = params.get('tilt_overrides', {})

        # Zona sin luminarias
        if z_len <= 0 or L_req <= 0:
            zone_designs.append(ZoneLuminaireDesign(
                zone_type=z_type, zone_name=z_name,
                s_start=z_start, s_end=z_end,
                zone_length=z_len, L_required=L_req, E_required=0,
                model=int_model, pcb=_commercial_name_for(int_model),
                current_mA=int(int_mA), flux_lm=int_lm, power_w=int_W,
                optic=int_optic, d_max_ul=round(d_interior,2),
                d_used=0, n_luminaires=0, L_estimated=0,
                UF=0, power_zone_w=0, flux_zone_lm=0,
                power_density_wm2=0, tilt_deg=int_tilt,
            ))
            continue

        # ── Zona interior ─────────────────────────────────────────────────
        if 'interior' in z_type:
            n_lum    = max(1, math.ceil(z_len / d_interior))
            d_actual = d_interior
            edge_margin = max(0.0, (z_len - (n_lum - 1) * d_actual) / 2.0)
            tilt_use = float(_tilt_ov.get(z_name, int_tilt))
            optic_use = int_optic
            mA_use    = int_mA
            lm_use    = int_lm
            W_use     = int_W
            # Re-estimar L con d_actual real
            L_est = L_from_flux(optic_use, d_actual, h, w, tilt_use,
                                 lm_use, arrangement, rtable, mf, wall_offset=wall_offset)

            pwr_zone  = n_lum * W_use
            flux_zone = n_lum * lm_use
            area      = z_len * w

            int_setpoints = []
            for i in range(n_lum):
                int_setpoints.append({
                    'idx':        i + 1,
                    's':          round(z_start + edge_margin + i * d_actual, 2),
                    'L_req':      round(L_req, 1),
                    'model':      int_model,
                    'optic':      optic_use,
                    'tilt_deg':   tilt_use,
                    'current_mA': round(mA_use, 1),
                    'power_w':    W_use,
                    'flux_lm':    round(lm_use, 0),
                    'target_flux_lm': round(float(int_res.get('phi_lm', lm_use)), 3),
                    'spacing_m':  round(d_actual, 3),
                    'spacing_stage': 0,
                    'U0':         round(int_U0, 4),
                    'L_est':      round(L_est, 1),
                })

            zone_designs.append(ZoneLuminaireDesign(
                zone_type=z_type, zone_name=z_name,
                s_start=z_start, s_end=z_end,
                zone_length=z_len, L_required=L_req,
                E_required=round(L_req / 0.085, 1),
                model=int_model, pcb=_commercial_name_for(int_model),
                current_mA=round(mA_use), flux_lm=round(lm_use,0),
                power_w=round(W_use,1), optic=optic_use,
                d_max_ul=round(d_interior,2), d_used=round(d_actual,2),
                n_luminaires=n_lum, L_estimated=round(L_est,1),
                UF=round(int_U0,4), Ul=round(int_Ul,4),
                power_zone_w=round(pwr_zone,0), flux_zone_lm=round(flux_zone,0),
                power_density_wm2=round(pwr_zone/area if area>0 else 0,3),
                d_max=round(d_actual,2), setpoints=int_setpoints, tilt_deg=tilt_use,
            ))
            continue

        # ── Transicion continua: desde Interior hacia el portal ────────────
        # La cadena mantiene una distancia concreta hasta que ninguna
        # combinacion optica+tilt puede cubrir el siguiente nivel con la
        # variante mayor. Solo entonces baja un escalon instalable.
        if 'transition' in z_type:
            is_b = z_type == 'transition_b'
            direction = -1.0 if is_b else 1.0
            outward_sign = 1.0 if is_b else -1.0
            inner_edge = z_start if is_b else z_end
            _tilt_probe = float(_tilt_ov.get(z_name, -1))
            tilt_candidates = (
                [_tilt_probe] if _tilt_probe >= 0 else tilt_grid
            )

            d_stage = (
                math.floor(d_interior / spacing_quantum + 1e-9)
                * spacing_quantum
            )
            d_stage = max(D_MIN, d_stage)
            stage_idx = 0
            setpoints = []
            previous_s = None
            previous_phi_in_stage = 0.0
            max_attempts = max(
                20, int(math.ceil(z_len / max(D_MIN, 0.3))) + 20,
            )

            for _ in range(max_attempts):
                if previous_s is None:
                    s_candidate = inner_edge + outward_sign * d_stage / 2.0
                else:
                    s_candidate = previous_s + outward_sign * d_stage
                if s_candidate < z_start - 1e-9 or s_candidate > z_end + 1e-9:
                    break

                if not is_b:
                    L_i = cie88_L_transition(
                        s_candidate, z_start, Lth_cie, Lin_cie, speed_kmh,
                    )
                else:
                    L_i = cie88_L_transition(
                        z_end - s_candidate, 0.0,
                        Lth_b_cie, Lin_cie, speed_kmh,
                    )
                L_i = max(float(L_i), Lin_cie)

                geometry = select_geometry_for_spacing(
                    L_req=L_i, d=d_stage, h=h, w=w,
                    U0_obj=U0_obj, Ul_obj=Ul_obj,
                    I_max_mA=I_max_mA, cct=cct,
                    rtable=rtable, mf=mf, arrangement=arrangement,
                    I_min_pct=I_min_pct, tilt_grid=tilt_candidates,
                    wall_offset=wall_offset, direction=direction,
                )

                while geometry is None and d_stage > D_MIN + 1e-9:
                    d_next = max(
                        D_MIN,
                        math.floor(
                            (d_stage - transition_spacing_step)
                            / spacing_quantum + 1e-9
                        ) * spacing_quantum,
                    )
                    if d_next >= d_stage - 1e-9:
                        d_next = max(D_MIN, d_stage - spacing_quantum)
                    d_stage = round(d_next, 3)
                    stage_idx += 1
                    previous_phi_in_stage = 0.0
                    if previous_s is None:
                        s_candidate = inner_edge + outward_sign * d_stage / 2.0
                    else:
                        s_candidate = previous_s + outward_sign * d_stage
                    if s_candidate < z_start - 1e-9 or s_candidate > z_end + 1e-9:
                        break
                    if not is_b:
                        L_i = cie88_L_transition(
                            s_candidate, z_start, Lth_cie, Lin_cie, speed_kmh,
                        )
                    else:
                        L_i = cie88_L_transition(
                            z_end - s_candidate, 0.0,
                            Lth_b_cie, Lin_cie, speed_kmh,
                        )
                    L_i = max(float(L_i), Lin_cie)
                    geometry = select_geometry_for_spacing(
                        L_req=L_i, d=d_stage, h=h, w=w,
                        U0_obj=U0_obj, Ul_obj=Ul_obj,
                        I_max_mA=I_max_mA, cct=cct,
                        rtable=rtable, mf=mf, arrangement=arrangement,
                        I_min_pct=I_min_pct, tilt_grid=tilt_candidates,
                        wall_offset=wall_offset, direction=direction,
                    )

                if s_candidate < z_start - 1e-9 or s_candidate > z_end + 1e-9:
                    break
                if geometry is None:
                    warnings_out.append(
                        f"🔴 {z_name}: L={L_i:.1f} cd/m2 no es alcanzable "
                        f"a d={d_stage:.1f} m con ninguna optica+tilt."
                    )
                    fallback = optimize_single_luminaire(
                        L_req=L_i, d=d_stage, h=h, w=w,
                        U0_obj=U0_obj, Ul_obj=Ul_obj,
                        I_max_mA=I_max_mA, cct=cct,
                        rtable=rtable, mf=mf, arrangement=arrangement,
                        I_min_pct=I_min_pct, tilt_grid=tilt_candidates,
                        wall_offset=wall_offset, direction=direction,
                    )
                    geometry = {
                        'optic': fallback['optic'],
                        'tilt_deg': fallback['tilt_deg'],
                        'phi_lm': fallback['lm'],
                        'U0': fallback['U0'],
                        'Ul': fallback.get('Ul', 0.0),
                    }

                # Dentro de una misma distancia la curva CIE creciente no
                # permite que el flujo continuo retroceda hacia el portal.
                phi_target = max(
                    float(geometry['phi_lm']),
                    previous_phi_in_stage,
                )
                previous_phi_in_stage = phi_target
                sel_i = select_model_for_flux(
                    phi_target, cct, I_max_mA, I_min_pct,
                )
                L_est_i = L_from_flux(
                    geometry['optic'], d_stage, h, w,
                    geometry['tilt_deg'], sel_i['lm'],
                    arrangement, rtable, mf,
                    wall_offset=wall_offset, direction=direction,
                )

                setpoints.append({
                    'idx': len(setpoints) + 1,
                    's': round(s_candidate, 2),
                    'L_req': round(L_i, 3),
                    'model': sel_i['model'],
                    'optic': geometry['optic'],
                    'tilt_deg': geometry['tilt_deg'],
                    'current_mA': round(sel_i['mA'], 1),
                    'power_w': sel_i['W'],
                    'flux_lm': round(sel_i['lm'], 0),
                    'target_flux_lm': round(phi_target, 3),
                    'U0': round(geometry['U0'], 4),
                    'Ul': round(geometry['Ul'], 4),
                    'L_est': round(L_est_i, 3),
                    'spacing_m': round(d_stage, 3),
                    'spacing_stage': stage_idx,
                    'distance_from_interior_m': round(
                        abs(s_candidate - inner_edge), 3,
                    ),
                })
                previous_s = s_candidate

            setpoints.sort(key=lambda sp: float(sp['s']))
            for idx, sp in enumerate(setpoints, start=1):
                sp['idx'] = idx

            if not setpoints:
                warnings_out.append(
                    f"🔴 {z_name}: no se pudo colocar ninguna luminaria."
                )
                continue

            dominant = max(setpoints, key=lambda sp: float(sp['L_req']))
            pwr_zone = sum(float(sp['power_w']) for sp in setpoints)
            flux_zone = sum(float(sp['flux_lm']) for sp in setpoints)
            L_avg = sum(float(sp['L_req']) for sp in setpoints) / len(setpoints)
            L_est_avg = (
                sum(float(sp['L_est']) for sp in setpoints) / len(setpoints)
            )
            area = z_len * w
            min_u0 = min(float(sp['U0']) for sp in setpoints)
            min_ul = min(float(sp['Ul']) for sp in setpoints)
            min_spacing = min(float(sp['spacing_m']) for sp in setpoints)

            zone_designs.append(ZoneLuminaireDesign(
                zone_type=z_type, zone_name=z_name,
                s_start=z_start, s_end=z_end,
                zone_length=z_len, L_required=round(L_avg, 3),
                E_required=round(L_avg / 0.085, 1),
                model=dominant['model'],
                pcb=_commercial_name_for(dominant['model']),
                current_mA=round(dominant['current_mA']),
                flux_lm=round(dominant['flux_lm'], 0),
                power_w=round(dominant['power_w'], 1),
                optic=dominant['optic'],
                d_max_ul=round(d_interior, 2),
                d_used=round(min_spacing, 2),
                n_luminaires=len(setpoints),
                L_estimated=round(L_est_avg, 3),
                UF=round(min_u0, 4), Ul=round(min_ul, 4),
                power_zone_w=round(pwr_zone, 1),
                flux_zone_lm=round(flux_zone, 0),
                power_density_wm2=round(
                    pwr_zone / area if area > 0 else 0, 3,
                ),
                d_max=round(d_interior, 2),
                setpoints=setpoints,
                tilt_deg=dominant['tilt_deg'],
            ))
            continue


        # ── Zona umbral / salida / acceso (uniforme) ─────────────────────
        # threshold_b = trafico entrando por el portal B (viaja en -x) -> el
        # observador CIE 140 60 m "por delante" tambien va en -x. access/exit/
        # threshold(A) son trafico A->B, direccion +1 normal.
        zone_direction = -1.0 if z_type == 'threshold_b' else 1.0
        tilt_use = float(_tilt_ov.get(z_name, -1))
        _tilt_grid_zone = [tilt_use] if tilt_use >= 0 else tilt_grid
        tandem_overrides = params.get('tandem_overrides', {}) or {}
        tandem_ov_zone   = tandem_overrides.get(z_name)   # True/False/None

        use_tandem    = False
        tandem_offset = 0.0

        def _zone_unit_count(zr, is_tandem):
            """Numero de luminarias fisicas de la zona."""
            if not zr or not zr.get('feasible'):
                return None
            n_ph  = 2 if is_tandem else 1
            n_pos = max(1, math.ceil(z_len / zr['d']))
            return n_pos * n_ph

        # ── Busqueda real de d que satisface U0/Ul Y flujo para L_req ──────
        zres = None
        if tandem_ov_zone is not True:
            zres = find_dmax_for_zone(
                L_req=L_req, h=h, w=w, U0_obj=U0_obj, Ul_obj=Ul_obj,
                I_max_mA=I_max_mA, cct=cct, rtable=rtable, mf=mf,
                arrangement=arrangement, I_min_pct=I_min_pct,
                tilt_grid=_tilt_grid_zone, d_min=D_MIN, d_max_hard=d_interior,
                wall_offset=wall_offset, tandem=False, direction=zone_direction,
            )
            # Ademas de "individual infactible", tambien merece la pena comprobar
            # tandem cuando individual SI es factible pero a una d muy comprimida
            # respecto de la d optima de calidad — ahi el individual puede ganar
            # "tecnicamente" siendo en realidad peor en potencia Y en numero de
            # luminarias que un tandem a la d de calidad (ver hallazgo real:
            # individual d=4.62m/31 luminarias/20.7kW vs tandem d=15m/20
            # luminarias/12.3kW para el mismo L_req).
            zres_comprimido = zres['feasible'] and zres['d'] < 0.7 * d_interior
            if (not zres['feasible'] or zres_comprimido) and tandem_ov_zone is None:
                zres_t = find_dmax_for_zone(
                    L_req=L_req, h=h, w=w, U0_obj=U0_obj, Ul_obj=Ul_obj,
                    I_max_mA=I_max_mA, cct=cct, rtable=rtable, mf=mf,
                    arrangement=arrangement, I_min_pct=I_min_pct,
                    tilt_grid=_tilt_grid_zone, d_min=D_MIN, d_max_hard=d_interior,
                    wall_offset=wall_offset, tandem=True, direction=zone_direction,
                )
                if not zres['feasible']:
                    if zres_t['feasible']:
                        use_tandem = True
                        zres = zres_t
                        warnings_out.append(
                            f'{z_name}: TÁNDEM AUTOMÁTICO — L_req={L_req:.0f} cd/m2 no alcanzable '
                            f'individual con U0>={U0_obj}/Ul>={Ul_obj} — espaciado {zres["d"]:.1f} m'
                        )
                    else:
                        # Infactible incluso en tándem — pero el par entrega ~2x el flujo
                        # de una sola luminaria a igual d, así que sigue siendo la mejor
                        # opción disponible (nunca peor que caer a 1x individual).
                        zres = zres_t
                        use_tandem = True
                else:
                    # Si ambas soluciones cumplen, manda el numero de unidades
                    # fisicas. A igualdad se conserva la individual.
                    count_i = _zone_unit_count(zres, False)
                    count_t = _zone_unit_count(zres_t, True)
                    d_ind = zres['d']
                    if count_t is not None and count_t < count_i:
                        warnings_out.append(
                            f'{z_name}: TÁNDEM AUTOMÁTICO — individual factible pero comprimido a '
                            f'd={d_ind:.1f} m ({count_i} luminarias); tándem a d={zres_t["d"]:.1f} m '
                            f'necesita {count_t} luminarias — se usa tándem.'
                        )
                        use_tandem = True
                        zres = zres_t

        if tandem_ov_zone is True:
            use_tandem = True
            zres = find_dmax_for_zone(
                L_req=L_req, h=h, w=w, U0_obj=U0_obj, Ul_obj=Ul_obj,
                I_max_mA=I_max_mA, cct=cct, rtable=rtable, mf=mf,
                arrangement=arrangement, I_min_pct=I_min_pct,
                tilt_grid=_tilt_grid_zone, d_min=D_MIN, d_max_hard=d_interior,
                wall_offset=wall_offset, tandem=True, direction=zone_direction,
            )
            warnings_out.append(f'{z_name}: TÁNDEM MANUAL activado — espaciado {zres["d"]:.1f} m')

        if zres is None or not zres['feasible']:
            tandem_note = " (con tándem — igualmente insuficiente, es la mejor opción disponible)" if use_tandem else ""
            warnings_out.append(
                f"🔴🔴 {z_name}: {(zres or {}).get('warning', 'INFACTIBLE')} "
                f"— usando d={D_MIN:.1f} m (espaciado minimo){tandem_note}. El resultado puede "
                f"NO cumplir U0_obj={U0_obj}/Ul_obj={Ul_obj}."
            )
            d_use = D_MIN
            L_target_fb = (L_req / 2.0) if use_tandem else L_req
            sel = optimize_single_luminaire(
                L_req=L_target_fb, d=d_use, h=h, w=w,
                U0_obj=U0_obj, Ul_obj=Ul_obj, I_max_mA=I_max_mA, cct=cct,
                rtable=rtable, mf=mf, arrangement=arrangement,
                I_min_pct=I_min_pct, tilt_grid=_tilt_grid_zone,
                wall_offset=wall_offset, direction=zone_direction,
            )
            if sel.get('warning'):
                warnings_out.append(f"🔴🔴 {z_name}: {sel['warning']}")
            tandem_offset = _body_len_for(sel['model']) if use_tandem else 0.0
            _, sel['Ul'] = eval_quality(sel['optic'], d_use, h, w, sel['tilt_deg'],
                                        rtable, mf, arrangement, wall_offset=wall_offset,
                                        direction=zone_direction)
        else:
            d_use = zres['d']
            sel = {
                'model': zres['model'], 'mA': zres['mA'], 'W': zres['W'],
                'lm': zres['lm'], 'optic': zres['optic'], 'tilt_deg': zres['tilt_deg'],
                'U0': zres['U0'], 'Ul': zres['Ul'],
                'L_est': (zres['L_est'] / 2.0) if use_tandem else zres['L_est'],
            }
            tandem_offset = _body_len_for(sel['model']) if use_tandem else 0.0

        d_actual = max(
            D_MIN,
            math.floor(d_use / spacing_quantum + 1e-9) * spacing_quantum,
        )
        n_ph        = 2 if use_tandem else 1
        portal_anchor_offset = tandem_offset / 2.0 if use_tandem else 0.0
        if z_type == 'threshold':
            centers = []
            x_c = z_start + portal_anchor_offset
            while x_c <= z_end + 1e-9:
                centers.append(x_c)
                x_c += d_actual
        elif z_type == 'threshold_b':
            centers = []
            x_c = z_end - portal_anchor_offset
            while x_c >= z_start - 1e-9:
                centers.append(x_c)
                x_c -= d_actual
            centers.sort()
        else:
            n_positions_guess = max(1, math.ceil(z_len / d_actual))
            edge_margin = max(
                0.0,
                (z_len - (n_positions_guess - 1) * d_actual) / 2.0,
            )
            centers = [
                z_start + edge_margin + i * d_actual
                for i in range(n_positions_guess)
            ]
        n_positions = len(centers)
        n_lum       = n_positions * n_ph
        area        = z_len * w
        pwr_zone    = n_lum * sel['W']
        flux_zone   = n_lum * sel['lm']
        L_est       = 2.0 * sel['L_est'] if use_tandem else sel['L_est']

        # Setpoints con posiciones físicas reales — siempre se generan (A/B
        # si es tándem, una única posición por lugar si no) para que la
        # gráfica L(s) tenga datos punto a punto en cualquier zona uniforme.
        unif_setpoints = []
        target_flux_unif = phi_for_luminance(
            sel['optic'], d_actual, h, w, sel['tilt_deg'],
            L_req / n_ph, arrangement, rtable, mf,
            wall_offset=wall_offset, direction=zone_direction,
        )
        for i, x_c in enumerate(centers):
            if use_tandem:
                for idx_t, tag in enumerate(("A", "B")):
                    x_phys = round(x_c + (idx_t * 2 - 1) * tandem_offset / 2, 2)
                    unif_setpoints.append({
                        "idx":        i * 2 + idx_t + 1,
                        "s":          x_phys,
                        "L_req":      round(L_req, 1),
                        "model":      sel['model'],
                        "optic":      sel['optic'],
                        "tilt_deg":   sel['tilt_deg'],
                        "current_mA": round(sel['mA'], 1),
                        "power_w":    sel['W'],
                        "flux_lm":    round(sel['lm'], 0),
                        "target_flux_lm": round(target_flux_unif, 3),
                        "spacing_m":  round(d_actual, 3),
                        "spacing_stage": 0,
                        "U0":         round(sel['U0'], 4),
                        "L_est":      round(sel['L_est'] * n_ph, 1),
                        "tandem":     tag,
                        "pair":       i,
                    })
            else:
                unif_setpoints.append({
                    "idx":        i + 1,
                    "s":          round(x_c, 2),
                    "L_req":      round(L_req, 1),
                    "model":      sel['model'],
                    "optic":      sel['optic'],
                    "tilt_deg":   sel['tilt_deg'],
                    "current_mA": round(sel['mA'], 1),
                    "power_w":    sel['W'],
                    "flux_lm":    round(sel['lm'], 0),
                    "target_flux_lm": round(target_flux_unif, 3),
                    "spacing_m":  round(d_actual, 3),
                    "spacing_stage": 0,
                    "U0":         round(sel['U0'], 4),
                    "L_est":      round(sel['L_est'], 1),
                })

        zone_designs.append(ZoneLuminaireDesign(
            zone_type=z_type, zone_name=z_name,
            s_start=z_start, s_end=z_end,
            zone_length=z_len, L_required=L_req,
            E_required=round(L_req/0.085, 1),
            model=sel['model'], pcb=_commercial_name_for(sel['model']),
            current_mA=round(sel['mA']), flux_lm=round(sel['lm'],0),
            power_w=round(sel['W'],1), optic=sel['optic'],
            d_max_ul=round(d_interior,2), d_used=round(d_actual,2),
            n_luminaires=n_lum, L_estimated=round(L_est,1),
            UF=round(sel['U0'],4), Ul=round(sel.get('Ul',0.0),4),
            power_zone_w=round(pwr_zone,0), flux_zone_lm=round(flux_zone,0),
            power_density_wm2=round(pwr_zone/area if area>0 else 0,3),
            d_max=round(d_actual,2), tilt_deg=sel['tilt_deg'],
            setpoints=unif_setpoints,
            n_tandem=2 if use_tandem else 1,
            tandem_offset_m=round(tandem_offset, 2),
        ))

    # ── Resolucion global mediante matriz de influencia ────────────────────
    # Geometria/optica/tilt ya estan fijados. Se resuelven ahora todos los
    # flujos continuos de forma acoplada y solo despues se asigna el
    # modelo-driver menor compatible con Imin/Imax.
    try:
        from modules.tunnel.influence_optimizer import optimize_layout_fluxes
        matrix_messages = optimize_layout_fluxes(
            zone_designs,
            h=h, w=w, mf=mf, rtable=rtable, cct=cct,
            I_max_mA=I_max_mA, I_min_pct=I_min_pct,
            arrangement=arrangement, wall_offset=wall_offset,
            tube_length_m=tube_length_m,
            Lth=Lth_cie, Lth_b=Lth_b_cie, Lin=Lin_cie,
            speed_kmh=speed_kmh,
            design_margin=(
                float(params.get('luminance_margin_pct', 0.3) or 0.3)
                / 100.0
            ),
        )
        warnings_out.extend(matrix_messages)
    except Exception as _matrix_err:
        warnings_out.append(
            f"🔴 Optimizacion global por matriz omitida por error: {_matrix_err}"
        )

    # Restaurar la regla de montaje despues del ajuste continuo: dentro de
    # cada escalon con igual geometria, el flujo no disminuye al acercarse al
    # portal.
    for zd in zone_designs:
        if 'transition' not in str(zd.zone_type or ''):
            continue
        buckets = {}
        for sp in zd.setpoints or []:
            if 'distance_from_interior_m' not in sp:
                continue
            key = (
                int(sp.get('spacing_stage', 0) or 0),
                round(float(sp.get('spacing_m', zd.d_used) or 0), 3),
                str(sp.get('optic') or zd.optic or ''),
                round(float(sp.get('tilt_deg', zd.tilt_deg) or 0), 2),
            )
            buckets.setdefault(key, []).append(sp)
        for items in buckets.values():
            previous_flux = 0.0
            for sp in sorted(
                items,
                key=lambda item: float(item['distance_from_interior_m']),
            ):
                current_flux = float(sp.get('flux_lm', 0) or 0)
                if current_flux + 1e-6 < previous_flux:
                    selected = select_model_for_flux(
                        previous_flux, cct, I_max_mA, I_min_pct,
                    )
                    sp['model'] = selected['model']
                    sp['current_mA'] = selected['mA']
                    sp['power_w'] = selected['W']
                    sp['flux_lm'] = selected['lm']
                    current_flux = float(selected['lm'])
                previous_flux = current_flux
        if zd.setpoints:
            zd.power_zone_w = round(sum(
                float(sp.get('power_w', 0) or 0) for sp in zd.setpoints
            ), 1)
            zd.flux_zone_lm = round(sum(
                float(sp.get('flux_lm', 0) or 0) for sp in zd.setpoints
            ), 0)
            zd.power_density_wm2 = round(
                zd.power_zone_w / max(zd.zone_length * w, 1e-9), 3,
            )

    # ── Resultado ──────────────────────────────────────────────────────────
    dominant = max(zone_designs, key=lambda zd: zd.L_required) if zone_designs else None
    lum_spec = LuminaireSpec(
        flux_lm           = dominant.flux_lm if dominant else 0,
        power_w           = dominant.power_w if dominant else 0,
        efficiency        = dominant.UF if dominant else 0,
        mounting_height_m = h,
        arrangement       = arrangement,
        maintenance_factor= mf,
        name              = (f"Aphex {dominant.model}/{dominant.pcb} "
                             f"{dominant.current_mA}mA {cct}") if dominant else '',
    ) if dominant else None

    result = TunnelLuminaireResult(
        tube_id           = tube_id,
        luminaire         = lum_spec,
        road_surface_type = surface_key,
        rho_eff           = 0.085,
        road_width_m      = w,
        tube_length_m     = tube_length_m,
        optic             = int_optic,
        cct               = cct,
        I_max_mA          = int(I_max_mA),
        arrangement       = arrangement,
        zones             = zone_designs,
        warnings          = list(set(warnings_out)),
    )
    result._compute_totals()
    return result


def calculate_luminaire_layout(
    zones_list:       list,
    luminaire_params: dict,
    road_width_m:     float,
    tube_length_m:    float,
    tube_id:          str = "T1",
) -> TunnelLuminaireResult:
    """
    Punto de entrada compatible con el motor existente.
    Si luminaire_params contiene 'I_max_mA' delega a design_aphex_tunnel (APHEX).
    Caso contrario usa flujo/eficiencia directamente (modo legacy).
    """
    params = dict(luminaire_params)
    params.setdefault('road_width_m',  road_width_m)
    params.setdefault('tube_length_m', tube_length_m)

    # ── Modo APHEX optimizado (U0/Ul objetivos via CIE 140 real) ─────────────
    if params.get('I_max_mA') or params.get('cct'):
        try:
            return design_aphex_tunnel_optimized(
                zones_list    = zones_list,
                params        = params,
                road_width_m  = road_width_m,
                tube_length_m = tube_length_m,
                tube_id       = tube_id,
            )
        except Exception as _opt_err:
            import traceback, warnings as _w
            _w.warn(f"Optimizador fallido, usando motor clasico: {_opt_err}")
            return design_aphex_tunnel(
                zones_list    = zones_list,
                params        = params,
                road_width_m  = road_width_m,
                tube_length_m = tube_length_m,
                tube_id       = tube_id,
            )

    # ── Modo legacy (flux_lm / efficiency) ───────────────────────────────────
    warnings: list = []
    flux_lm    = float(params.get('flux_lm',  15000))
    uf         = float(params.get('efficiency', 0.60))
    mf         = float(params.get('maintenance_factor', 0.70))
    h          = float(params.get('mounting_height_m', 5.0))
    w          = road_width_m
    n_rows     = int(params.get('n_rows', 1))
    arrangement = str(params.get('arrangement', 'central_single'))
    rho_eff    = float(params.get('rho_eff', 0.07))
    power_w    = float(params.get('power_w', 200))
    optic      = str(params.get('optic', 'F2MD'))
    cct        = str(params.get('cct', '4000K'))
    I_max_mA   = int(params.get('I_max_mA', 500))

    zone_designs: list = []
    tr_count = 0

    _v_leg = [z for z in zones_list if float(z.get("L_min_required",0)) > 0
              and float(z.get("s_end",0)) > float(z.get("s_start",0))]
    L_interior_legacy = min((float(z.get("L_min_required",0)) for z in _v_leg), default=0.0)

    for z in zones_list:
        z_type   = str(z.get('zone_type') or z.get('type') or 'interior').lower()
        z_start  = float(z.get('s_start', 0))
        z_end    = float(z.get('s_end',   0))
        z_length = max(0.0, z_end - z_start)
        L_req    = float(z.get('L_min_required', 0))

        if 'transition' in z_type:
            tr_count += 1
        z_name = _zone_label(z_type, tr_count)

        if z_length <= 0 or L_req <= 0:
            zone_designs.append(ZoneLuminaireDesign(
                zone_type=z_type, zone_name=z_name,
                s_start=z_start, s_end=z_end,
                zone_length=z_length, L_required=L_req, E_required=0,
                model='M', pcb='F2MD', current_mA=I_max_mA,
                flux_lm=flux_lm, power_w=power_w, optic=optic,
                d_max_ul=10.0, d_used=0, n_luminaires=0,
                L_estimated=0, UF=uf, power_zone_w=0,
                flux_zone_lm=0, power_density_wm2=0, d_max=0,
                tilt_deg=0.0,
            ))
            continue

        denom = math.pi * w * L_req
        num   = flux_lm * n_rows * uf * mf * rho_eff
        d_try = max(2.5, min(num / denom if denom > 0 else 10.0, 20.0))
        n_lum    = max(1, math.ceil(z_length / d_try))
        d_actual = z_length / n_lum
        L_est    = _luminance(flux_lm, n_rows, uf, mf, rho_eff, d_actual, w)
        area     = z_length * w
        pwr_zone = n_lum * power_w

        zone_designs.append(ZoneLuminaireDesign(
            zone_type=z_type, zone_name=z_name,
            s_start=z_start, s_end=z_end,
            zone_length=z_length, L_required=L_req, E_required=0,
            model='M', pcb=optic, current_mA=I_max_mA,
            flux_lm=flux_lm, power_w=power_w, optic=optic,
            d_max_ul=round(d_actual, 2), d_used=round(d_actual, 2),
            n_luminaires=n_lum, L_estimated=round(L_est, 1),
            UF=round(uf, 4), power_zone_w=round(pwr_zone, 0),
            flux_zone_lm=round(n_lum * flux_lm, 0),
            power_density_wm2=round(pwr_zone / area if area > 0 else 0, 3),
            d_max=round(d_actual, 2),
            tilt_deg=_zone_tilt_deg(z_type, L_req, L_interior_legacy),
        ))

    lum_spec = None
    if zone_designs:
        dom = max(zone_designs, key=lambda z: z.L_required)
        lum_spec = LuminaireSpec(
            flux_lm=dom.flux_lm, power_w=dom.power_w,
            efficiency=uf, mounting_height_m=h,
            arrangement=arrangement, maintenance_factor=mf,
            name=f"Legacy {optic} {cct}",
        )

    result = TunnelLuminaireResult(
        tube_id=tube_id, luminaire=lum_spec,
        road_surface_type='medium_asphalt', rho_eff=rho_eff,
        road_width_m=w, tube_length_m=tube_length_m,
        optic=optic, cct=cct, I_max_mA=I_max_mA,
        arrangement=arrangement, zones=zone_designs,
        warnings=warnings,
    )
    result._compute_totals()
    return result
