"""
modules/tunnel/photometric_verify.py
=====================================
CIE 140:2019 photometric verification for APHEX tunnel zone designs.

After design_aphex_tunnel() selects luminaires for each zone using the
inside-out UF-table algorithm, this module verifies the actual luminance
quality (L_avg, U0, Ul, TI) using the full CIE 140:2019 point-by-point
calculation with real LDT angular distributions and CIE 144:2001 r-tables.

All S/M/L APHEX models share the same photometric distribution (same optics
F2MD/F2M2/F151). The LDT files for APHEX M are used as reference; flux is
scaled to the operating point of each zone's selected luminaire.

Road surface -> r-table mapping (CIE 144:2001):
    dark_asphalt   -> R3
    medium_asphalt -> R2
    light_asphalt  -> R1
    concrete       -> C1
    bright_concrete-> C2
"""
from __future__ import annotations

import sys
import math
import numpy as np
from pathlib import Path
from typing import Optional

# ── Resolve project root so photometric_engine is importable ─────────────────
_HERE        = Path(__file__).resolve()
_PROJECT_ROOT = _HERE.parents[2]          # .../CALCULO FOTOMETRICO SALVI/
if str(_PROJECT_ROOT) not in sys.path:
    sys.path.insert(0, str(_PROJECT_ROOT))

_LDT_DIR = _PROJECT_ROOT / "photometric_engine" / "data" / "photometries"

# ── Road surface → CIE 144 r-table ──────────────────────────────────────────
_SURFACE_RTABLE: dict[str, str] = {
    "dark_asphalt":    "R3",
    "medium_asphalt":  "R2",
    "light_asphalt":   "R1",
    "concrete":        "C1",
    "bright_concrete": "C2",
}

# ── Optic → APHEX M LDT filename (all models share the same distribution) ───
_OPTIC_LDT: dict[str, str] = {
    "F2MD": "APHEX_M_H10_40K_F2MD_VDR_SPUW_200W.ldt",
    "F2M2": "APHEX_M_H10_40K_F2M2_VDR_SPUW_200W.ldt",
    "F151": "APHEX_M_H10_40K_F151_VDR_SPUW_200W.ldt",
}

# CIE 140 compliance thresholds
_U0_MIN  = 0.40
_UL_MIN  = 0.60
_TI_MAX  = 15.0

_REACH_CACHE: dict = {}


def _max_reach_for_h(H: float) -> float:
    """Distancia [m] mas alla de la cual NINGUNA de las opticas Aphex
    contribuye de forma apreciable a esta altura de montaje — envolvente
    conservadora (maximo de las 3 opticas) usada como max_luminaire_dist,
    para que el corte de luminarias lejanas coincida con el mismo criterio
    fotometrico que ya usa el diseño (ver optimizer._reach_for). Una zona
    puede usar cualquiera de las 3 opticas, y aqui no sabemos cual sin
    reconstruir antes el layout, asi que se toma el maximo de las 3 —
    conservador (nunca corta de menos), no afecta a la precision."""
    key = round(float(H), 2)
    if key not in _REACH_CACHE:
        from photometric_engine.salvi_photometry.ldt_parser import load_ldt
        reaches = []
        for fname in _OPTIC_LDT.values():
            try:
                reaches.append(load_ldt(_LDT_DIR / fname).reach_distance(float(H)))
            except Exception:
                continue
        _REACH_CACHE[key] = max(reaches) if reaches else 300.0
    return _REACH_CACHE[key]

# Diffuse reflectance of road surface (Lambertian component, for radiosity)
_RHO_ROAD: dict[str, float] = {
    "dark_asphalt":    0.07,
    "medium_asphalt":  0.10,
    "light_asphalt":   0.15,
    "concrete":        0.28,
    "bright_concrete": 0.40,
}


def _is_available() -> bool:
    """Check that photometric_engine can be imported."""
    try:
        import photometric_engine.salvi_photometry.ldt_parser  # noqa: F401
        return True
    except ImportError:
        return False


def verify_luminaire_result(lum_result, params: dict, use_radiosity: bool = False) -> dict:
    """
    Run CIE 140:2019 photometric verification for every zone in a
    TunnelLuminaireResult produced by design_aphex_tunnel().

    Parameters
    ----------
    lum_result : TunnelLuminaireResult
        Output of design_aphex_tunnel() / calculate_luminaire_layout().
    params : dict
        Original luminaire params dict (needs mounting_height_m, maintenance_factor).

    Returns
    -------
    dict with structure:
        {
          "available": bool,
          "error": str | None,
          "rtable": "R2",
          "zones": {
            "CIN": {
              "L_avg": 12.94, "L_min": 7.45,
              "U0": 0.576, "Ul": 0.970, "TI": 1.3,
              "E_h_avg": 165.3,
              "compliant": true, "L_req": 10.0,
              "checks": {"L_avg": true, "U0": true, "Ul": true, "TI": true}
            },
            ...
          },
          "overall_compliant": bool
        }
    """
    out: dict = {"available": False, "error": None, "zones": {}, "overall_compliant": False}

    if not _is_available():
        out["error"] = "photometric_engine no disponible (importación fallida)"
        return out

    try:
        from photometric_engine.salvi_photometry.ldt_parser import load_ldt
        from photometric_engine.salvi_photometry.geometry   import Observer
        from photometric_engine.salvi_photometry.calculator import TunnelCalculator, LuminaireInstance, LuminaireOrientation
        from photometric_engine.salvi_photometry.radiosity  import TunnelSection, build_patches, solve_radiosity, indirect_illuminance_on_road
    except ImportError as exc:
        out["error"] = f"Error importando photometric_engine: {exc}"
        return out

    # ── Parámetros generales ─────────────────────────────────────────────────
    # NOTA: cada zona puede haber sido diseñada con una óptica distinta
    # (Umbral/Transición se optimizan independientemente de Interior y pueden
    # elegir F2M2/F2MD/F151 diferentes) — lum_result.optic es solo la óptica
    # de la zona Interior, usada aquí unicamente como fallback si a una zona
    # le faltara el campo. Usar siempre zd.optic por zona (ver _phot() abajo)
    # es lo que corrige que la verificación CIE 140 comprobara la distribución
    # fotométrica equivocada en zonas con óptica distinta a la de Interior.
    optic   = lum_result.optic or "F2MD"
    surface = lum_result.road_surface_type or "medium_asphalt"
    rtable  = _SURFACE_RTABLE.get(surface, "R2")
    W       = float(lum_result.road_width_m)
    H       = float(params.get("mounting_height_m", 5.0))
    mf      = float(params.get("maintenance_factor", 0.70))

    # ── LDT por óptica, cacheado (cada zona puede usar una distinta) ─────────
    _phot_cache: dict = {}

    def _phot(optic_id: str):
        oid = optic_id or optic
        if oid not in _phot_cache:
            fname = _OPTIC_LDT.get(oid, _OPTIC_LDT["F2MD"])
            fpath = _LDT_DIR / fname
            if not fpath.exists():
                raise FileNotFoundError(f"LDT no encontrado: {fname}")
            _phot_cache[oid] = load_ldt(fpath)
        return _phot_cache[oid]

    try:
        _phot(optic)   # valida que la óptica por defecto carga correctamente
    except Exception as exc:
        out["error"] = str(exc)
        return out

    calc = TunnelCalculator(rtable, mf, max_luminaire_dist=_max_reach_for_h(H))
    # Observer at road centre, 60 m ahead (CIE 140 §6.2.2). El sentido de
    # circulacion se fija por zona mas abajo (zonas "_b" = trafico entrando
    # por el portal B, observador 60 m por delante en -x en vez de +x).
    def _obs_for_zone(zd_obj) -> "Observer":
        zt = str(getattr(zd_obj, "zone_type", "") or "")
        direction = -1.0 if zt.endswith("_b") else 1.0
        return Observer(lane_y_m=W / 2, d_observer_m=60.0, direction=direction)

    out["available"] = True
    out["rtable"]    = rtable
    out["optic"]     = optic
    out["H_m"]       = H

    zone_results: dict = {}
    all_compliant = True

    for zd in lum_result.zones:
        if zd.n_luminaires <= 0 or zd.zone_length <= 0:
            continue

        S        = float(zd.d_used)
        flux_lm  = float(zd.flux_lm)
        L_req    = float(zd.L_required)
        zone_key = zd.zone_name

        if S <= 0.1 or flux_lm <= 0:
            continue

        try:
            zone_phot = _phot(getattr(zd, "optic", None))
        except Exception as exc:
            zone_results[zone_key] = {"error": str(exc), "compliant": False}
            all_compliant = False
            continue

        # ── Luminaire array: replicas suficientes para cubrir el alcance real
        #    de esta optica a esta altura (ver Photometry.reach_distance) ────
        n_side  = max(2, math.ceil(zone_phot.reach_distance(H) / max(S, 0.1)))
        WALL_Y  = float(params.get('wall_offset_m', 0.30))  # m from wall to luminaire
        arr     = params.get('arrangement', 'central_single') or 'central_single'

        # ── Tandem support: 2 physical luminaires per position, offset along x ──
        # ZoneLuminaireDesign.n_tandem==2 means each nominal position i*S actually
        # holds a real A/B pair separated by tandem_offset_m (each carrying zd.flux_lm,
        # matching the per-unit flux convention used when the zone was designed).
        is_tandem   = int(getattr(zd, 'n_tandem', 1) or 1) == 2
        tandem_off  = float(getattr(zd, 'tandem_offset_m', 0.0) or 0.0)

        def _x_positions(i: int) -> list:
            """Physical x offsets for nominal position i (single, or A/B tandem pair)."""
            if is_tandem and tandem_off > 0:
                return [i * S - tandem_off / 2.0, i * S + tandem_off / 2.0]
            return [i * S]

        tilt_base = float(getattr(zd, "tilt_deg", 0) or 0)

        # El tilt (rotacion transversal, CIE 140 Anexo A) se espeja segun el
        # lado: cada fila se inclina hacia el eje del tunel, nunca ambas hacia
        # el mismo lado — igual que optimizer._build_lums y la vista previa.
        def _tilt_for_y(y_pos: float) -> float:
            return tilt_base if y_pos < W / 2 else -tilt_base

        if arr == 'bilateral_stag':
            # Alternating sides: even index → left wall, odd → right wall
            lums = [
                LuminaireInstance(
                    x           = x_p,
                    y           = (y_pos := (WALL_Y if abs(i) % 2 == 0 else W - WALL_Y)),
                    H           = H,
                    photometry  = zone_phot,
                    flux_lm     = flux_lm,
                    orientation = LuminaireOrientation(tilt_deg=_tilt_for_y(y_pos)),
                )
                for i in range(-n_side, n_side + 1)
                for x_p in _x_positions(i)
            ]
        else:
            # Determine y positions per arrangement
            if arr == 'lateral_left':
                ys = [WALL_Y]
            elif arr == 'lateral_right':
                ys = [W - WALL_Y]
            elif arr == 'bilateral_sym':
                ys = [WALL_Y, W - WALL_Y]
            elif arr == 'central_double':
                ys = [W / 2 - 0.30, W / 2 + 0.30]
            else:                        # central_single / central_offset / auto
                ys = [W / 2]
            lums = [
                LuminaireInstance(
                    x           = x_p,
                    y           = y,
                    H           = H,
                    photometry  = zone_phot,
                    flux_lm     = flux_lm,
                    orientation = LuminaireOrientation(tilt_deg=_tilt_for_y(y)),
                )
                for i in range(-n_side, n_side + 1)
                for y in ys
                for x_p in _x_positions(i)
            ]

        # ── CIE 140 §6.3 calculation grid over one representative span ───────
        n_long, n_trans = 10, 5
        xs  = [(-S / 2) + (i + 0.5) * S / n_long for i in range(n_long)]
        ys  = [(j + 0.5) * W / n_trans             for j in range(n_trans)]
        pts = [(x, y) for x in xs for y in ys]

        try:
            zr = calc.calculate_zone(
                zone_name   = zd.zone_type,
                zone_type   = zd.zone_type,
                s_start     = -S / 2,
                s_end       =  S / 2,
                L_req       = L_req,
                calc_points = pts,
                luminaires  = lums,
                observer    = _obs_for_zone(zd),
            )
            # ── Optional radiosity pass ───────────────────────────────────
            L_indirect = 0.0
            rad_info = {}
            if use_radiosity:
                try:
                    import math as _math
                    rho_road    = _RHO_ROAD.get(surface, 0.10)
                    rho_wall    = float(params.get('rho_wall',    0.40))
                    rho_ceiling = float(params.get('rho_ceiling', 0.25))
                    H_t         = float(params.get('height_m', H + 1.0))
                    section = TunnelSection(
                        width_m=W, height_m=H_t,
                        rho_road=rho_road, rho_wall=rho_wall,
                        rho_ceiling=rho_ceiling,
                    )
                    patches = build_patches(section)
                    # Compute direct E on each patch from luminaire array
                    n_side_rad = 5
                    for p in patches:
                        e_direct = 0.0
                        for lum in lums:
                            for xi in range(-n_side_rad, n_side_rad+1):
                                x_l = lum.x + xi * S
                                dy = p.y_center - lum.y
                                dz = p.z_center - lum.H
                                dx = 0.0 - x_l
                                r2 = dx*dx + dy*dy + dz*dz
                                if r2 < 0.01: continue
                                r  = _math.sqrt(r2)
                                # cos of angle of incidence on patch
                                cos_inc = -(dy*p.normal[0] + dz*p.normal[1]) / r
                                if cos_inc <= 0: continue
                                # photometric angles (3D generalization)
                                d_plan = _math.sqrt(dx*dx + dy*dy)
                                g_rad  = _math.atan2(d_plan, max(0.001, lum.H - p.z_center))
                                g_deg  = _math.degrees(g_rad)
                                c_deg  = (_math.degrees(_math.atan2(dy, dx)) + 360) % 360
                                I_cd   = lum.photometry.intensity(c_deg, g_deg,
                                            scale_flux_lm=lum.flux_lm)
                                e_direct += I_cd * cos_inc / r2 * mf
                        p.E_direct = e_direct
                    solve_radiosity(patches)
                    # Indirect luminance on road = E_indirect * rho_road / pi
                    y_pts = list(set(yP for _, yP in pts))
                    e_ind_avg = _math.fsum(
                        indirect_illuminance_on_road(patches, yP) for yP in y_pts
                    ) / max(1, len(y_pts))
                    L_indirect = e_ind_avg * rho_road / _math.pi
                    rad_info = {
                        'rho_wall': rho_wall, 'rho_ceiling': rho_ceiling,
                        'L_indirect': round(L_indirect, 3),
                        'pct': round(100*L_indirect/max(zr.L_avg,0.01), 1),
                    }
                except Exception as rad_err:
                    rad_info = {'error': str(rad_err)}

            # La celda periodica de la zona sigue siendo la referencia para
            # U0/Ul/TI. Para L, en cambio, usar el cierre del layout fisico
            # completo cuando este disponible: en transicion la contribucion
            # de las zonas vecinas es real y una celda aislada puede declarar
            # falsamente Lavg<Lreq aunque el perfil completo cumpla.
            profile_L_avg = getattr(zd, "profile_L_avg", None)
            profile_L_min = getattr(zd, "profile_L_min", None)
            profile_ratio = getattr(zd, "profile_min_ratio", None)
            has_profile = profile_L_avg is not None and profile_ratio is not None

            L_direct_display = float(profile_L_avg) if has_profile else zr.L_avg
            L_min_direct_display = (
                float(profile_L_min)
                if has_profile and profile_L_min is not None
                else zr.L_min
            )
            L_avg_total = L_direct_display + L_indirect
            L_min_total = L_min_direct_display + L_indirect

            # La uniformidad no se calcula sobre todo el gradiente de una
            # transicion; se conserva la rejilla CIE 140 de la celda local.
            U0_rad = (
                (zr.L_min + L_indirect) / (zr.L_avg + L_indirect)
                if zr.L_avg + L_indirect > 0 else zr.U0
            )
            Ul_rad = zr.Ul  # Ul shape unchanged by uniform indirect term

            L_ok = (
                float(profile_ratio) >= 0.995
                if has_profile
                else (L_avg_total >= L_req if L_req > 0 else True)
            )
            U0_ok = U0_rad >= _U0_MIN
            Ul_ok = Ul_rad >= _UL_MIN
            TI_ok = zr.TI  <= _TI_MAX

            compliant = all([L_ok, U0_ok, Ul_ok, TI_ok])
            if not compliant:
                all_compliant = False

            zone_results[zone_key] = {
                "L_avg":      round(L_avg_total, 2),
                "L_min":      round(L_min_total, 2),
                "L_direct":   round(L_direct_display, 2),
                "L_indirect": round(L_indirect, 3),
                "U0":         round(U0_rad, 3),
                "Ul":         round(Ul_rad, 3),
                "TI":         round(zr.TI,  1),
                "E_h_avg":    round(zr.E_h_avg, 1),
                "L_req":      round(L_req, 1),
                "profile_min_ratio": round(float(profile_ratio), 4) if has_profile else None,
                "compliant":  compliant,
                "radiosity":  rad_info,
                "checks": {
                    "L_avg": L_ok,
                    "U0":    U0_ok,
                    "Ul":    Ul_ok,
                    "TI":    TI_ok,
                },
            }
        except Exception as exc:
            zone_results[zone_key] = {
                "error": str(exc),
                "compliant": False,
            }
            all_compliant = False

    out["zones"]            = zone_results
    out["overall_compliant"] = all_compliant and bool(zone_results)
    return out


def compute_real_luminance_profile(lum_result, params: dict, road_width_m: float,
                                    step_size: float = 1.0) -> dict:
    """
    Perfil normativo Lavg(s). Cada valor es la media aritmetica de una malla
    bidimensional CIE 140 completa: N puntos longitudinales y tres puntos
    transversales por carril. Se calcula con cada observador de carril y se
    representa el caso mas desfavorable, usando el layout fisico completo.
    """
    _ = step_size  # Conservado por compatibilidad con la API anterior.
    out: dict = {"available": False, "error": None, "points": []}

    if not _is_available():
        out["error"] = "photometric_engine no disponible (importación fallida)"
        return out

    try:
        from photometric_engine.salvi_photometry.ldt_parser import load_ldt
        from photometric_engine.salvi_photometry.geometry   import Observer, LuminaireOrientation
        from photometric_engine.salvi_photometry.calculator import TunnelCalculator, LuminaireInstance
    except ImportError as exc:
        out["error"] = f"Error importando photometric_engine: {exc}"
        return out

    surface = lum_result.road_surface_type or "medium_asphalt"
    rtable  = _SURFACE_RTABLE.get(surface, "R2")
    W       = float(road_width_m)
    H       = float(params.get("mounting_height_m", 5.0))
    mf      = float(params.get("maintenance_factor", 0.70))
    arr     = params.get('arrangement', 'central_single') or 'central_single'
    WALL_Y  = float(params.get('wall_offset_m', 0.30))

    if arr == 'lateral_left':
        ys_default = [WALL_Y]
    elif arr in ('lateral_right', 'unilateral'):
        ys_default = [W - WALL_Y]
    elif arr in ('bilateral_sym', 'bilateral', 'staggered'):
        ys_default = [WALL_Y, W - WALL_Y]
    elif arr == 'central_double':
        ys_default = [W / 2 - 0.30, W / 2 + 0.30]
    else:
        ys_default = [W / 2]

    _phot_cache: dict = {}

    def _phot(optic: str):
        if optic not in _phot_cache:
            fname = _OPTIC_LDT.get(optic, _OPTIC_LDT["F2MD"])
            _phot_cache[optic] = load_ldt(_LDT_DIR / fname)
        return _phot_cache[optic]

    def _tilt_for_y(tilt_base: float, y_pos: float) -> float:
        return tilt_base if y_pos < W / 2 else -tilt_base

    # ── Reconstruir el layout físico completo del túnel a partir de los
    #    setpoints reales de cada zona (posición, óptica, tilt, flujo) ──────
    lums: list = []
    row_positions: dict[float, list[float]] = {}

    def _register_row_position(y_pos: float, x_pos: float) -> None:
        row_positions.setdefault(round(float(y_pos), 4), []).append(float(x_pos))

    tube_length = 0.0
    try:
        for zd in lum_result.zones:
            if zd.n_luminaires <= 0:
                continue
            tube_length = max(tube_length, float(getattr(zd, 's_end', 0) or 0))
            sps = zd.setpoints or []
            for sp in sps:
                x_pos    = float(sp['s'])
                optic_id = sp.get('optic') or 'F2MD'
                flux     = float(sp.get('flux_lm', 0) or 0)
                tilt0    = float(sp.get('tilt_deg', 0) or 0)
                if flux <= 0:
                    continue
                if arr == 'bilateral_stag':
                    # Lado alternado por índice de posición física (par A/B
                    # incluido, ya expandido en 's' individuales).
                    y_pos = WALL_Y if (sp.get('idx', 1) - 1) % 2 == 0 else (W - WALL_Y)
                    lums.append(LuminaireInstance(
                        x=x_pos, y=y_pos, H=H, photometry=_phot(optic_id), flux_lm=flux,
                        orientation=LuminaireOrientation(tilt_deg=_tilt_for_y(tilt0, y_pos)),
                    ))
                    _register_row_position(y_pos, x_pos)
                else:
                    for y_pos in ys_default:
                        lums.append(LuminaireInstance(
                            x=x_pos, y=y_pos, H=H, photometry=_phot(optic_id), flux_lm=flux,
                            orientation=LuminaireOrientation(tilt_deg=_tilt_for_y(tilt0, y_pos)),
                        ))
                        _register_row_position(y_pos, x_pos)
    except Exception as exc:
        out["error"] = f"Error reconstruyendo el layout de luminarias: {exc}"
        return out

    if not lums or tube_length <= 0:
        out["error"] = "Sin luminarias posicionadas para calcular el perfil"
        return out

    calc = TunnelCalculator(rtable, mf, max_luminaire_dist=_max_reach_for_h(H))

    # Sentido de circulacion por zona: las zonas "_b" (transition_b,
    # threshold_b) son trafico entrando por el portal B, que viaja en -x, asi
    # que su observador CIE 140 (60 m "por delante") va en -x en vez de +x —
    # ver Observer.direction. Sin esto, el beta usado para TODO el tunel
    # asumia trafico A->B tambien en las zonas ancladas a B, sesgando
    # sistematicamente su luminancia calculada (la tabla r no es simetrica
    # en beta).
    zones_sorted = sorted(lum_result.zones, key=lambda z: float(z.s_start))

    def _zone_for_s(s_val):
        for z in zones_sorted:
            if float(z.s_start) - 1e-6 <= s_val <= float(z.s_end) + 1e-6:
                return z
        return None

    def _direction_for_zone(zd_obj) -> float:
        zt = str(getattr(zd_obj, "zone_type", "") or "") if zd_obj is not None else ""
        return -1.0 if zt.endswith("_b") else 1.0

    # ── Lavg CIE 140 a lo largo del tunel ─────────────────────────────────
    # Lth/Ltr/Lin son luminancias medias sobre un campo de evaluacion. Cada
    # ordenada debe proceder de una malla bidimensional completa, nunca de la
    # media transversal de una sola seccion.
    # CIE 140: tres puntos transversales por carril. Los arcenes quedan fuera
    # de la malla de luminancia de la calzada.
    _N_LONG_PROFILE = 10
    _n_lanes = max(1, int(params.get("num_lanes", 1) or 1))
    _lane_width = max(
        0.1, float(params.get("lane_width_m", W / _n_lanes) or 0.1),
    )
    _shoulder_left = max(
        0.0, float(params.get("shoulder_left_m", 0.0) or 0.0),
    )
    _shoulder_right = max(
        0.0, float(params.get("shoulder_right_m", 0.0) or 0.0),
    )
    _available_width = max(0.1, W - _shoulder_left - _shoulder_right)
    if _n_lanes * _lane_width > _available_width + 1e-6:
        _lane_width = _available_width / _n_lanes
    elif (
        _shoulder_left + _shoulder_right <= 1e-9
        and _n_lanes * _lane_width < W
    ):
        _shoulder_left = (W - _n_lanes * _lane_width) / 2.0

    _lane_starts = [
        _shoulder_left + lane_index * _lane_width
        for lane_index in range(_n_lanes)
    ]
    _lane_centres = [
        lane_start + _lane_width / 2.0
        for lane_start in _lane_starts
    ]
    _ys_profile = [
        lane_start + (j + 0.5) * _lane_width / 3.0
        for lane_start in _lane_starts
        for j in range(3)
    ]
    _N_TRANS_PROFILE = len(_ys_profile)
    _has_portal_b = any(
        str(getattr(zone, "zone_type", "") or "").endswith("_b")
        for zone in lum_result.zones
    )

    def _directions_for_zone(zd_obj) -> list[float]:
        zone_type = str(
            getattr(zd_obj, "zone_type", "") or "",
        ).lower()
        if _has_portal_b and "interior" in zone_type:
            return [1.0, -1.0]
        return [_direction_for_zone(zd_obj)]

    def _observers_for_direction(direction: float):
        return [
            Observer(
                lane_y_m=lane_y,
                d_observer_m=60.0,
                direction=direction,
            )
            for lane_y in _lane_centres
        ]

    def _n_long_for_spacing(spacing: float) -> int:
        return 10 if spacing <= 30.0 else int(math.ceil(spacing / 3.0))

    # ── Campos de calculo normativos ───────────────────────────────────────
    # CIE 140 define la Lavg de un campo comprendido entre dos luminarias
    # consecutivas de una misma fila. Por tanto la representacion longitudinal
    # es una sucesion de resultados de campo, no una media transversal ni una
    # malla deslizante arbitraria cada `step_size` metros.
    interval_sources: dict[tuple[float, float], set[float]] = {}
    for row_y, positions in row_positions.items():
        ordered = sorted(set(round(x, 6) for x in positions))
        for field_start, field_end in zip(ordered, ordered[1:]):
            if field_end - field_start <= 0.05:
                continue
            key = (field_start, field_end)
            interval_sources.setdefault(key, set()).add(row_y)

    fields = []
    for (field_start, field_end), source_rows in sorted(interval_sources.items()):
        field_centre = (field_start + field_end) / 2.0
        zone = _zone_for_s(field_centre)
        if zone is None:
            continue
        spacing = field_end - field_start
        n_long = _n_long_for_spacing(spacing)
        xs = [
            field_start + (j + 0.5) * spacing / n_long
            for j in range(n_long)
        ]
        fields.append({
            "s": field_centre,
            "field_start": field_start,
            "field_end": field_end,
            "spacing": spacing,
            "source_rows": tuple(sorted(source_rows)),
            "zone": zone,
            "points": [(x, y) for x in xs for y in _ys_profile],
            "directions": _directions_for_zone(zone),
            "observer_results": [],
        })

    if not fields:
        out["error"] = "No hay dos posiciones consecutivas para formar un campo CIE 140"
        return out

    # Los campos interiores de una zona estrictamente periodica son
    # traslaciones exactas. Se resuelve uno por cada fase/fila y se reutiliza;
    # los bordes y toda configuracion variable se calculan individualmente.
    uniform_zones: set[int] = set()
    for zone in lum_result.zones:
        sps = zone.setpoints or []
        if len(sps) < 4:
            continue
        fluxes = {round(float(sp.get("flux_lm", 0) or 0), 1) for sp in sps}
        tilts = {round(float(sp.get("tilt_deg", 0) or 0), 2) for sp in sps}
        optics = {sp.get("optic") or "F2MD" for sp in sps}
        spacings = {
            round(float(sp.get("spacing_m", zone.d_used) or zone.d_used), 3)
            for sp in sps
        }
        if len(fluxes) == len(tilts) == len(optics) == len(spacings) == 1:
            uniform_zones.add(id(zone))

    representative_by_key: dict[tuple, int] = {}
    aliases: dict[int, int] = {}
    solve_indices: list[int] = []
    buffer = calc.max_lum_dist
    for index, field in enumerate(fields):
        zone = field["zone"]
        safely_periodic = (
            id(zone) in uniform_zones
            and field["field_start"] >= float(zone.s_start) + buffer
            and field["field_end"] <= float(zone.s_end) - buffer
        )
        cache_key = None
        if safely_periodic:
            cache_key = (
                id(zone),
                round(field["spacing"], 3),
                tuple(round(y, 3) for y in field["source_rows"]),
            )
        if cache_key is not None and cache_key in representative_by_key:
            aliases[index] = representative_by_key[cache_key]
        else:
            solve_indices.append(index)
            if cache_key is not None:
                representative_by_key[cache_key] = index

    # Resolver campos completos en lotes. El minimo de las Lavg obtenidas con
    # todos los observadores de carril y sentidos aplicables es el gobernante.
    for direction in (1.0, -1.0):
        indices = [
            index for index in solve_indices
            if direction in fields[index]["directions"]
        ]
        for chunk_start in range(0, len(indices), 20):
            chunk_indices = indices[chunk_start:chunk_start + 20]
            batch_points = []
            slices = []
            for index in chunk_indices:
                begin = len(batch_points)
                batch_points.extend(fields[index]["points"])
                slices.append((begin, len(batch_points)))
            for observer in _observers_for_direction(direction):
                raw = calc.luminance_at_points_batch(
                    batch_points, lums, observer,
                )
                for index, (begin, end) in zip(chunk_indices, slices):
                    values = np.asarray(raw[begin:end], dtype=float)
                    fields[index]["observer_results"].append({
                        "mean": float(np.mean(values)),
                        "lane_y_m": float(observer.lane_y_m),
                        "direction": float(direction),
                        "values": values.tolist(),
                    })

    for alias_index, representative_index in aliases.items():
        fields[alias_index]["observer_results"] = list(
            fields[representative_index]["observer_results"],
        )

    points = []
    field_details = []
    for field in fields:
        if not field["observer_results"]:
            continue
        governing = min(
            field["observer_results"],
            key=lambda result: result["mean"],
        )
        point_summary = {
            "s": round(field["s"], 3),
            "field_start": round(field["field_start"], 3),
            "field_end": round(field["field_end"], 3),
            "L": round(governing["mean"], 3),
        }
        points.append(point_summary)
        field_details.append({
            **point_summary,
            "zone_type": str(getattr(field["zone"], "zone_type", "") or ""),
            "zone_name": str(getattr(field["zone"], "zone_name", "") or ""),
            "observer_lane_y_m": round(governing["lane_y_m"], 3),
            "observer_direction": int(governing["direction"]),
            "grid_points": [
                {
                    "x": round(x, 3),
                    "y": round(y, 3),
                    "L": round(float(value), 3),
                }
                for (x, y), value in zip(
                    field["points"],
                    governing["values"],
                )
            ],
        })

    out["available"]    = True
    out["points"]       = points
    out["fields"]       = field_details
    out["n_luminaires"] = len(lums)
    out["metric"] = "CIE140_Lavg"
    out["grid"] = {
        "longitudinal": "N=10 si S<=30 m; si no, D<=3 m",
        "transverse_points_per_lane": 3,
        "num_lanes": _n_lanes,
        "num_observers": _n_lanes,
        "observers_per_direction": _n_lanes,
        "directions_in_bidirectional_interior": 2 if _has_portal_b else 1,
        "selection": "peor observador",
        "representation": "un valor Lavg por campo entre luminarias consecutivas",
    }
    return out
