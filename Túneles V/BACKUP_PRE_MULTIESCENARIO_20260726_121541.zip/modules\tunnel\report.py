"""
SALVI Tunnel Engine — Generador de Informe Técnico Word
Produce un .docx con el resultado completo del cálculo CIE 88:2004.
Requiere: python-docx
"""

import io
import datetime
from typing import Optional

from docx import Document
from docx.shared import Pt, Cm, RGBColor, Inches
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.oxml.ns import qn
from docx.oxml import OxmlElement


# ══════════════════════════════════════════════════════════════════
# CONSTANTES DE ESTILO
# ══════════════════════════════════════════════════════════════════

BLUE_DARK   = "1A3A6B"   # Cabeceras principales
BLUE_MED    = "1A56B0"   # Cabeceras de tabla
BLUE_LIGHT  = "D5E8F5"   # Filas alternas de tabla
BLUE_BRAND  = "0066CC"   # Textos destacados
GRAY_LIGHT  = "F5F5F5"   # Fondo alternativo gris
WHITE       = "FFFFFF"
BLACK       = "000000"


# ══════════════════════════════════════════════════════════════════
# UTILIDADES DOCX
# ══════════════════════════════════════════════════════════════════

def _set_cell_bg(cell, hex_color: str) -> None:
    """Establece el color de fondo de una celda."""
    tc = cell._tc
    tcPr = tc.get_or_add_tcPr()
    shd = OxmlElement('w:shd')
    shd.set(qn('w:val'), 'clear')
    shd.set(qn('w:color'), 'auto')
    shd.set(qn('w:fill'), hex_color)
    # Remove existing shd if present
    existing = tcPr.find(qn('w:shd'))
    if existing is not None:
        tcPr.remove(existing)
    tcPr.append(shd)


def _cell_text(cell, text: str, bold: bool = False, color: str = None,
               size_pt: float = 9.5, align=WD_ALIGN_PARAGRAPH.LEFT) -> None:
    """Escribe texto en una celda con formato."""
    cell.text = ""
    p = cell.paragraphs[0]
    p.alignment = align
    run = p.add_run(str(text))
    run.bold = bold
    run.font.size = Pt(size_pt)
    if color:
        run.font.color.rgb = RGBColor.from_string(color)


def _add_separator(doc: Document, color: str = BLUE_MED) -> None:
    """Línea horizontal separadora."""
    p = doc.add_paragraph()
    p.paragraph_format.space_before = Pt(4)
    p.paragraph_format.space_after = Pt(4)
    pPr = p._p.get_or_add_pPr()
    pBdr = OxmlElement('w:pBdr')
    bottom = OxmlElement('w:bottom')
    bottom.set(qn('w:val'), 'single')
    bottom.set(qn('w:sz'), '8')
    bottom.set(qn('w:space'), '1')
    bottom.set(qn('w:color'), color)
    pBdr.append(bottom)
    pPr.append(pBdr)


def _section_heading(doc: Document, title: str, level: int = 1) -> None:
    """Encabezado de sección con estilo SALVI."""
    p = doc.add_paragraph()
    p.paragraph_format.space_before = Pt(14 if level == 1 else 8)
    p.paragraph_format.space_after = Pt(4)
    run = p.add_run(title)
    run.bold = True
    run.font.size = Pt(12 if level == 1 else 10.5)
    run.font.color.rgb = RGBColor.from_string(BLUE_DARK if level == 1 else BLUE_MED)
    _add_separator(doc, BLUE_DARK if level == 1 else BLUE_MED)


def _kv_table(doc: Document, rows: list, col_widths=(5.5, 8.5)) -> None:
    """Tabla de dos columnas clave→valor."""
    table = doc.add_table(rows=len(rows), cols=2)
    table.style = 'Table Grid'
    for i, (key, val) in enumerate(rows):
        bg = GRAY_LIGHT if i % 2 == 0 else WHITE
        c0, c1 = table.rows[i].cells
        _set_cell_bg(c0, bg)
        _set_cell_bg(c1, bg)
        _cell_text(c0, key, bold=True, size_pt=9)
        _cell_text(c1, str(val), size_pt=9)
        # Column widths
        c0.width = Cm(col_widths[0])
        c1.width = Cm(col_widths[1])


def _header_row(row, headers: list, bg: str = BLUE_MED) -> None:
    """Fila de cabecera de tabla (fondo azul, texto blanco)."""
    for cell, h in zip(row.cells, headers):
        _set_cell_bg(cell, bg)
        _cell_text(cell, h, bold=True, color=WHITE,
                   size_pt=8.5, align=WD_ALIGN_PARAGRAPH.CENTER)


def _set_page_margins(doc: Document,
                      top=2.0, bottom=2.0, left=2.5, right=2.0) -> None:
    for section in doc.sections:
        section.top_margin    = Cm(top)
        section.bottom_margin = Cm(bottom)
        section.left_margin   = Cm(left)
        section.right_margin  = Cm(right)


def _add_page_break(doc: Document) -> None:
    p = doc.add_paragraph()
    run = p.add_run()
    run.add_break(__import__('docx.enum.text', fromlist=['WD_BREAK']).WD_BREAK.PAGE)


# ══════════════════════════════════════════════════════════════════
# PORTADA
# ══════════════════════════════════════════════════════════════════

def _build_cover(doc: Document, result: dict, params: dict) -> None:
    summary        = result.get('summary', {})
    classification = result.get('classification', {})

    # Cabecera azul
    p = doc.add_paragraph()
    p.paragraph_format.space_before = Pt(0)
    p.paragraph_format.space_after = Pt(0)
    run = p.add_run("SALVI TUNNEL ENGINE")
    run.bold = True
    run.font.size = Pt(22)
    run.font.color.rgb = RGBColor.from_string(BLUE_DARK)

    p2 = doc.add_paragraph()
    p2.paragraph_format.space_before = Pt(2)
    p2.paragraph_format.space_after = Pt(2)
    run2 = p2.add_run("Informe Técnico de Iluminación de Túneles")
    run2.font.size = Pt(14)
    run2.font.color.rgb = RGBColor.from_string(BLUE_MED)

    _add_separator(doc, BLUE_DARK)

    # Subtítulo norma
    p3 = doc.add_paragraph()
    p3.paragraph_format.space_before = Pt(4)
    r3 = p3.add_run("Norma: CIE 88:2004 — Guide for the Lighting of Road Tunnels and Underpasses")
    r3.italic = True
    r3.font.size = Pt(9.5)
    r3.font.color.rgb = RGBColor.from_string("555555")

    doc.add_paragraph()  # Espacio

    # Tabla de proyecto
    table = doc.add_table(rows=8, cols=2)
    table.style = 'Table Grid'
    fields = [
        ("Proyecto",              summary.get('project', params.get('project_name', '—'))),
        ("Tubo",                  summary.get('tube_id', '—')),
        ("Longitud total",        f"{summary.get('length_m', '—')} m"),
        ("Velocidad de diseño",   f"{summary.get('speed_kmh', '—')} km/h"),
        ("Tráfico de diseño",     f"{params.get('traffic_veh_h', '—')} veh/h"),
        ("Clasificación óptica",  classification.get('optical', '—').replace('_', ' ')),
        ("Iluminación diurna",    classification.get('daylighting', '—')),
        ("Fecha del informe",     datetime.date.today().strftime("%d/%m/%Y")),
    ]
    for i, (k, v) in enumerate(fields):
        bg = BLUE_LIGHT if i % 2 == 0 else WHITE
        c0, c1 = table.rows[i].cells
        _set_cell_bg(c0, bg)
        _set_cell_bg(c1, bg)
        _cell_text(c0, k, bold=True, size_pt=10)
        _cell_text(c1, str(v), size_pt=10)
        c0.width = Cm(6)
        c1.width = Cm(8)

    doc.add_paragraph()
    p_note = doc.add_paragraph()
    rn = p_note.add_run(
        "Redactado con SALVI Tunnel Engine (STE) — Motor de cálculo conforme a CIE 88:2004."
    )
    rn.font.size = Pt(8)
    rn.font.color.rgb = RGBColor.from_string("888888")
    rn.italic = True


# ══════════════════════════════════════════════════════════════════
# SECCIONES DEL INFORME
# ══════════════════════════════════════════════════════════════════

def _build_classification(doc: Document, result: dict) -> None:
    cls   = result.get('classification', {})
    speed = result.get('speed', {})
    _section_heading(doc, "1. Clasificación del Túnel (CIE 88:2004 §6)")

    _kv_table(doc, [
        ("Clasificación geométrica",    cls.get('geometric', '—').replace('_', ' ')),
        ("Clasificación óptica",        cls.get('optical', '—').replace('_', ' ')),
        ("Necesidad de ilum. diurna",   cls.get('daylighting', '—')),
        ("Distancia de parada (SD)",    f"{speed.get('SD_m', '—')} m"),
        ("Distancia de reacción (dr)",  f"{speed.get('d_reaction_m', '—')} m"),
        ("Distancia de frenado (df)",   f"{speed.get('d_braking_m', '—')} m"),
    ])

    if cls.get('justification'):
        p = doc.add_paragraph()
        p.paragraph_format.space_before = Pt(6)
        run = p.add_run("Justificación: ")
        run.bold = True
        run.font.size = Pt(9)
        p.add_run(cls['justification']).font.size = Pt(9)


def _build_luminances(doc: Document, result: dict) -> None:
    s   = result.get('summary', {})
    l20 = result.get('l20', {})
    lth = result.get('lth', {})

    _section_heading(doc, "2. Luminancias de Diseño (CIE 88:2004 §12–16)")

    _kv_table(doc, [
        ("L₂₀ — Luminancia campo 20°",     f"{s.get('L20', '—')} cd/m²"),
        ("Método de cálculo L₂₀",          l20.get('method', '—')),
        ("Confianza del valor L₂₀",         l20.get('confidence', '—')),
        ("Lth — Luminancia de umbral",      f"{s.get('Lth', '—')} cd/m²"),
        ("Factor k (Lth = k · L₂₀)",       s.get('k_factor', '—')),
        ("Coef. revelación contraste qc",   s.get('qc', '—')),
        ("Lseq — Luminancia equivalente",   f"{s.get('Lseq', '—')} cd/m²"),
        ("Lin — Luminancia interior",       f"{s.get('Lin', '—')} cd/m²"),
        ("L_noche — Luminancia nocturna",   f"{s.get('L_night', '—')} cd/m²"),
    ])

    if l20.get('note'):
        p = doc.add_paragraph()
        p.paragraph_format.space_before = Pt(4)
        r = p.add_run(f"Nota L₂₀: {l20['note']}")
        r.italic = True
        r.font.size = Pt(8.5)
        r.font.color.rgb = RGBColor.from_string("666666")


def _build_zones(doc: Document, result: dict) -> None:
    zones_raw = result.get('zones', {})
    _section_heading(doc, "3. Zonas Normativas CIE 88:2004")

    # Extraer lista de zonas del dict
    zones_list = []
    if isinstance(zones_raw, dict):
        # Puede venir como {threshold: {...}, transition: {...}, ...}
        # o como {zones: [...]}
        if 'zones' in zones_raw:
            zones_list = zones_raw['zones']
        else:
            for key, val in zones_raw.items():
                if isinstance(val, dict) and 's_start' in val:
                    zones_list.append(val)
    elif isinstance(zones_raw, list):
        zones_list = zones_raw

    if not zones_list:
        doc.add_paragraph("(Datos de zonas no disponibles)")
        return

    headers = ["Zona", "s inicio (m)", "s fin (m)", "Longitud (m)",
               "L inicio (cd/m²)", "L fin (cd/m²)", "L mín. req. (cd/m²)"]
    col_widths_cm = [3.0, 2.2, 2.2, 2.3, 2.8, 2.8, 3.2]

    table = doc.add_table(rows=1 + len(zones_list), cols=len(headers))
    table.style = 'Table Grid'
    _header_row(table.rows[0], headers)
    for j, w in enumerate(col_widths_cm):
        table.rows[0].cells[j].width = Cm(w)

    ZONE_BG = {
        'threshold':  'FFF3CD',
        'transition': 'CFF4FC',
        'interior':   'D1E7DD',
        'exit':       'E2D9F3',
        'access':     'F8D7DA',
        'parting':    'F8D7DA',
    }

    for i, z in enumerate(zones_list):
        row = table.rows[i + 1]
        zone_type = str(z.get('zone_type', z.get('type', '—'))).lower()
        bg = ZONE_BG.get(zone_type, WHITE)
        values = [
            zone_type.replace('_', ' ').title(),
            f"{z.get('s_start', 0):.1f}",
            f"{z.get('s_end', 0):.1f}",
            f"{z.get('length', z.get('s_end', 0) - z.get('s_start', 0)):.1f}",
            f"{z.get('L_start', z.get('L_min_required', 0)):.2f}",
            f"{z.get('L_end', z.get('L_min_required', 0)):.2f}",
            f"{z.get('L_min_required', 0):.2f}",
        ]
        for j, (cell, val) in enumerate(zip(row.cells, values)):
            _set_cell_bg(cell, bg)
            bold = (j == 3 or j == 6)
            _cell_text(cell, val, bold=bold, size_pt=9,
                       align=WD_ALIGN_PARAGRAPH.CENTER if j > 0 else WD_ALIGN_PARAGRAPH.LEFT)
            cell.width = Cm(col_widths_cm[j])


def _build_control(doc: Document, result: dict) -> None:
    control = result.get('control')
    if not control:
        return

    _section_heading(doc, "4. Plan de Control (CIE 88:2004 §87–111)")

    groups = control.get('groups', [])
    scenes = control.get('scenes', [])
    protocol = control.get('protocol', 'DALI')

    if not groups or not scenes:
        doc.add_paragraph("(Plan de control no disponible)")
        return

    # Info del plan
    _kv_table(doc, [
        ("Protocolo de control", protocol),
        ("Nº de grupos",         control.get('n_groups', len(groups))),
        ("Nº de escenas",        control.get('n_scenes', len(scenes))),
    ], col_widths=(5.5, 4.0))

    doc.add_paragraph()

    _section_heading(doc, "Tabla de Regulación (grupos × escenas)", level=2)

    # Columnas: Grupo | L diseño | Escena1 | Escena2 | ...
    n_cols = 2 + len(scenes)
    headers = ["Grupo", "L diseño\n(cd/m²)"] + [
        f"{s['name']}\nL₂₀={s['L20']:.0f}" for s in scenes
    ]

    table = doc.add_table(rows=1 + len(groups), cols=n_cols)
    table.style = 'Table Grid'
    _header_row(table.rows[0], headers)

    # Anchos de columna
    col_w = [5.0, 2.0] + [2.0] * len(scenes)
    for j, w in enumerate(col_w):
        table.rows[0].cells[j].width = Cm(w)

    # Colores de escena
    SCENE_BG = {
        'sunny':    'FFFDE7',
        'normal':   'F5F5F5',
        'overcast': 'ECEFF1',
        'dusk':     'FCE4EC',
        'night':    'E8EAF6',
    }

    ZONE_BG = {
        'threshold':  'FFF3CD',
        'transition': 'CFF4FC',
        'interior':   'D1E7DD',
        'exit':       'E2D9F3',
    }

    for i, g in enumerate(groups):
        row = table.rows[i + 1]
        zone_type = g.get('zone_type', '').lower()
        zone_bg = ZONE_BG.get(zone_type, WHITE)

        # Nombre del grupo
        _set_cell_bg(row.cells[0], zone_bg)
        _cell_text(row.cells[0], g['name'], bold=True, size_pt=8.5)
        row.cells[0].width = Cm(col_w[0])

        # L diseño
        _set_cell_bg(row.cells[1], zone_bg)
        _cell_text(row.cells[1], str(g.get('L_design', '—')),
                   bold=True, color=BLUE_BRAND, size_pt=9,
                   align=WD_ALIGN_PARAGRAPH.CENTER)
        row.cells[1].width = Cm(col_w[1])

        # Niveles por escena
        for j, scene in enumerate(scenes):
            sid  = str(scene['scene_id'])
            pct  = g.get('dimming_levels', {}).get(sid, '—')
            dali = g.get('dali_levels', {}).get(sid, '')
            scene_bg = SCENE_BG.get(scene.get('scene_type', ''), WHITE)

            cell = row.cells[2 + j]
            _set_cell_bg(cell, scene_bg)
            cell.width = Cm(col_w[2 + j])

            # Pct en bold + DALI level pequeño debajo
            cell.text = ""
            p = cell.paragraphs[0]
            p.alignment = WD_ALIGN_PARAGRAPH.CENTER
            r1 = p.add_run(f"{pct}%")
            r1.bold = True
            r1.font.size = Pt(9)
            r1.font.color.rgb = RGBColor.from_string(BLUE_DARK)
            if protocol == 'DALI' and dali:
                r2 = p.add_run(f"\nDALI {dali}")
                r2.font.size = Pt(7.5)
                r2.font.color.rgb = RGBColor.from_string("666666")

    p_note = doc.add_paragraph()
    p_note.paragraph_format.space_before = Pt(4)
    rn = p_note.add_run(
        "CTH=Umbral · CTRn=Transición · CIN=Interior · CEX=Salida. "
        "Niveles DALI según IEC 62386 (curva logarítmica, rango 0–254)."
    )
    rn.italic = True
    rn.font.size = Pt(8)
    rn.font.color.rgb = RGBColor.from_string("666666")


def _build_quality(doc: Document, result: dict, photometric: dict = None) -> None:
    validation = result.get('validation', {})
    ph       = photometric or {}
    ph_avail = ph.get('available', False)

    _section_heading(doc, "5. Criterios de Calidad CIE 88:2004 / CIE 140:2019")

    if ph_avail:
        # ── CIE 140:2019 — tabla por zona ─────────────────────────────────
        p_inf = doc.add_paragraph()
        r_inf = p_inf.add_run(
            f"CIE 140:2019  ·  Tabla {ph.get('rtable','--')}  ·  "
            f"Optica {ph.get('optic','--')}  ·  H = {ph.get('H_m','--')} m"
        )
        r_inf.italic = True
        r_inf.font.size = Pt(8.5)
        r_inf.font.color.rgb = RGBColor.from_string("444444")

        zones  = ph.get('zones', {})
        col_w  = [2.2, 2.5, 1.7, 1.7, 1.7, 2.0]
        tbl    = doc.add_table(rows=1 + len(zones), cols=6)
        tbl.style = 'Table Grid'
        _header_row(tbl.rows[0],
                    ["Zona", "L_avg / L_req", "U0 >=0.40", "Ul >=0.60", "TI <=15%", "Estado"])
        for j, w in enumerate(col_w):
            tbl.rows[0].cells[j].width = Cm(w)

        for i, (zk, zv) in enumerate(zones.items()):
            row = tbl.rows[i + 1]
            bg  = GRAY_LIGHT if i % 2 == 0 else WHITE
            for c in row.cells:
                _set_cell_bg(c, bg)
            for j, w in enumerate(col_w):
                row.cells[j].width = Cm(w)
            _cell_text(row.cells[0], zk, bold=True, size_pt=9)
            if 'error' in zv:
                _cell_text(row.cells[1], str(zv['error']), size_pt=8, color="C0392B")
            else:
                chk = zv.get('checks', {})
                _cell_text(row.cells[1],
                           f"{zv['L_avg']} / {zv['L_req']}",
                           size_pt=9, align=WD_ALIGN_PARAGRAPH.CENTER,
                           color="1A7A3C" if chk.get('L_avg') else "C0392B")
                _cell_text(row.cells[2], str(zv['U0']), size_pt=9,
                           align=WD_ALIGN_PARAGRAPH.CENTER,
                           color="1A7A3C" if chk.get('U0') else "C0392B")
                _cell_text(row.cells[3], str(zv['Ul']), size_pt=9,
                           align=WD_ALIGN_PARAGRAPH.CENTER,
                           color="1A7A3C" if chk.get('Ul') else "C0392B")
                _cell_text(row.cells[4], str(zv['TI']), size_pt=9,
                           align=WD_ALIGN_PARAGRAPH.CENTER,
                           color="1A7A3C" if chk.get('TI') else "C0392B")
                st = "CUMPLE" if zv['compliant'] else "REVISAR"
                _cell_text(row.cells[5], st, bold=True, size_pt=9,
                           align=WD_ALIGN_PARAGRAPH.CENTER,
                           color="1A7A3C" if zv['compliant'] else "C0392B")

        doc.add_paragraph()
        overall       = ph.get('overall_compliant', False)
        criteria_extra = [
            ("CIE 140:2019 global",          "todas las zonas",
             "CUMPLE" if overall else "REVISAR"),
            ("Perfil longitudinal normativo", "CIE 88:2004",
             "CUMPLE" if validation.get('valid') else "REVISAR"),
            ("Ratios de transicion",         "<= 3:1",
             "CUMPLE" if validation.get('valid') else "REVISAR"),
        ]
    else:
        criteria_extra = [
            ("Uniformidad general Uo",           ">= 0.40",       "Requiere LDT"),
            ("Uniformidad longitudinal Ul",       ">= 0.60",       "Requiere LDT"),
            ("Deslumbramiento TI",               "<= 15 %",       "Requiere LDT"),
            ("Ratio luminancia pared/calzada",    ">= 0.60",       "Requiere LDT"),
            ("Perfil longitudinal normativo",     "CIE 88:2004",
             "CUMPLE" if validation.get('valid') else "REVISAR"),
            ("Ratios de transicion",             "<= 3:1",
             "CUMPLE" if validation.get('valid') else "REVISAR"),
        ]

    table = doc.add_table(rows=1 + len(criteria_extra), cols=3)
    table.style = 'Table Grid'
    _header_row(table.rows[0], ["Criterio", "Requisito", "Estado"])
    for j, w in enumerate([8.0, 2.8, 2.8]):
        table.rows[0].cells[j].width = Cm(w)

    for i, (crit, req, state) in enumerate(criteria_extra):
        row  = table.rows[i + 1]
        bg   = GRAY_LIGHT if i % 2 == 0 else WHITE
        _set_cell_bg(row.cells[0], bg)
        _set_cell_bg(row.cells[1], bg)
        _set_cell_bg(row.cells[2], bg)

        _cell_text(row.cells[0], crit, size_pt=9)
        _cell_text(row.cells[1], req, size_pt=9, align=WD_ALIGN_PARAGRAPH.CENTER)

        if "CUMPLE" in state:
            st_color = "1A7A3C"
        elif "REVISAR" in state:
            st_color = "C0392B"
        else:
            st_color = "666666"
        _cell_text(row.cells[2], state, bold=("CUMPLE" in state or "REVISAR" in state),
                   color=st_color, size_pt=9, align=WD_ALIGN_PARAGRAPH.CENTER)

        for j, w in enumerate([8.0, 2.8, 2.8]):
            row.cells[j].width = Cm(w)

    # Warnings
    warnings = result.get('warnings', [])
    if warnings:
        doc.add_paragraph()
        _section_heading(doc, "Advertencias del cálculo", level=2)
        for w in warnings:
            p = doc.add_paragraph(style='List Bullet')
            run = p.add_run(w)
            run.font.size = Pt(9)
            run.font.color.rgb = RGBColor.from_string("C0392B")

    # Validation errors
    val_errors = (validation or {}).get('errors', [])
    if val_errors:
        for e in val_errors:
            p = doc.add_paragraph(style='List Bullet')
            run = p.add_run(f"ERROR: {e}")
            run.font.size = Pt(9)
            run.font.color.rgb = RGBColor.from_string("C0392B")


def _build_footer(doc: Document) -> None:
    """Pie de página con número de página y referencia."""
    for section in doc.sections:
        footer = section.footer
        p = footer.paragraphs[0]
        p.alignment = WD_ALIGN_PARAGRAPH.CENTER
        run = p.add_run("SALVI Tunnel Engine (STE) — CIE 88:2004 — ")
        run.font.size = Pt(7.5)
        run.font.color.rgb = RGBColor.from_string("888888")

        # Campo de número de página
        fldChar1 = OxmlElement('w:fldChar')
        fldChar1.set(qn('w:fldCharType'), 'begin')
        instrText = OxmlElement('w:instrText')
        instrText.text = 'PAGE'
        fldChar2 = OxmlElement('w:fldChar')
        fldChar2.set(qn('w:fldCharType'), 'end')

        run2 = p.add_run()
        run2.font.size = Pt(7.5)
        run2.font.color.rgb = RGBColor.from_string("888888")
        run2._r.append(fldChar1)
        run2._r.append(instrText)
        run2._r.append(fldChar2)


# ══════════════════════════════════════════════════════════════════
# FUNCIÓN PRINCIPAL
# ══════════════════════════════════════════════════════════════════

def generate_report(result: dict, params: dict = None, photometric: dict = None) -> bytes:
    """
    Genera el informe técnico Word a partir del resultado del motor.

    Args:
        result: dict devuelto por run_tunnel_calculation()
        params: dict con los parámetros originales del formulario (opcional)

    Returns:
        bytes del .docx listo para enviar como descarga
    """
    if params is None:
        params = {}

    doc = Document()
    _set_page_margins(doc, top=2.0, bottom=2.0, left=2.5, right=2.0)

    # Estilo base
    style = doc.styles['Normal']
    style.font.name = 'Calibri'
    style.font.size = Pt(10)

    # Pie de página
    _build_footer(doc)

    # ── PORTADA ──────────────────────────────────────────────────
    _build_cover(doc, result, params)

    doc.add_paragraph()  # Espacio antes del salto
    _add_page_break(doc)

    # ── SECCIÓN 1: CLASIFICACIÓN ─────────────────────────────────
    _build_classification(doc, result)

    # ── SECCIÓN 2: LUMINANCIAS ───────────────────────────────────
    _build_luminances(doc, result)

    # ── SECCIÓN 3: ZONAS ─────────────────────────────────────────
    _build_zones(doc, result)

    # ── SECCIÓN 4: CONTROL ───────────────────────────────────────
    if result.get('control'):
        _build_control(doc, result)

    # ── SECCIÓN 5: CALIDAD ───────────────────────────────────────
    _build_quality(doc, result, photometric=photometric)

    # Serializar a bytes
    buf = io.BytesIO()
    doc.save(buf)
    buf.seek(0)
    return buf.read()

def generate_combined_report(tubes_data: list, project_name: str = "") -> bytes:
    """
    Genera un informe Word combinado con múltiples tubos.
    """
    if not tubes_data:
        raise ValueError("Se necesita al menos un tubo para el informe combinado")

    if len(tubes_data) == 1:
        t = tubes_data[0]
        return generate_report(t["result"], t.get("params", {}), photometric=t.get("photometric"))

    doc = Document()
    _set_page_margins(doc, top=2.0, bottom=2.0, left=2.5, right=2.0)

    style = doc.styles['Normal']
    style.font.name = 'Calibri'
    style.font.size = Pt(10)

    _build_footer(doc)

    first_result = tubes_data[0]["result"]
    first_params  = tubes_data[0].get("params", {})
    if project_name:
        first_params = dict(first_params)
        first_params["project_name"] = project_name

    _build_cover(doc, first_result, first_params)

    doc.add_paragraph()
    _add_page_break(doc)

    p_idx = doc.add_paragraph()
    p_idx.alignment = WD_ALIGN_PARAGRAPH.LEFT
    run = p_idx.add_run("INDICE DE TUBOS")
    run.bold = True
    run.font.size = Pt(13)
    run.font.color.rgb = RGBColor.from_string(BLUE_DARK)

    for i, t in enumerate(tubes_data, 1):
        res  = t["result"]
        prm  = t.get("params", {})
        tid  = res.get("summary", {}).get("tube_id", f"T{i}")
        lm   = res.get("summary", {}).get("length_m", "---")
        vkm  = res.get("summary", {}).get("speed_kmh", "---")
        pi   = doc.add_paragraph(style="List Bullet")
        pi.add_run(f"Tubo {tid}").bold = True
        pi.add_run(f"  ---  {lm} m - {vkm} km/h - portal {prm.get('portal_orientation','---')}")

    doc.add_paragraph()

    for i, t in enumerate(tubes_data):
        result = t["result"]
        params = t.get("params", {})
        tid    = result.get("summary", {}).get("tube_id", f"T{i+1}")

        if i > 0:
            _add_page_break(doc)

        p_sec = doc.add_paragraph()
        p_sec.alignment = WD_ALIGN_PARAGRAPH.CENTER
        run = p_sec.add_run(f"-- TUBO {tid} --")
        run.bold = True
        run.font.size = Pt(16)
        run.font.color.rgb = RGBColor.from_string(BLUE_DARK)
        doc.add_paragraph()

        _build_classification(doc, result)
        _build_luminances(doc, result)
        _build_zones(doc, result)
        if result.get('control'):
            _build_control(doc, result)
        _build_quality(doc, result, photometric=t.get("photometric"))

    buf = io.BytesIO()
    doc.save(buf)
    buf.seek(0)
    return buf.read()
