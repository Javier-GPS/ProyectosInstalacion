import numpy as np
import pytest

from modules.tunnel.influence_optimizer import _solve_fluxes_minimax


def test_minimax_solver_finds_zero_excess_solution():
    A = np.array([
        [1.0, 0.0],
        [0.0, 1.0],
        [0.5, 0.5],
    ])
    required = np.ones(3)
    phi, feasible, method, excess = _solve_fluxes_minimax(
        A,
        required,
        required,
        min_flux=0.0,
        max_flux=2.0,
        monotonic_blocks=[],
        constant_blocks=[],
        upper_mask=None,
        phi_initial=np.zeros(2),
        max_iters=100,
    )
    assert feasible
    assert method.startswith("highs")
    assert np.allclose(phi, [1.0, 1.0], atol=1e-7)
    assert excess <= 1e-7


def test_minimax_solver_respects_transition_monotonicity():
    A = np.eye(2)
    required = np.array([0.5, 1.0])
    phi, feasible, _, _ = _solve_fluxes_minimax(
        A,
        required,
        required,
        min_flux=0.0,
        max_flux=2.0,
        monotonic_blocks=[[0, 1]],
        constant_blocks=[],
        upper_mask=None,
        phi_initial=np.zeros(2),
        max_iters=100,
    )
    assert feasible
    assert phi[1] >= phi[0] - 1e-9
    assert np.all(A @ phi >= required - 1e-8)


def test_minimax_solver_keeps_validated_interior_flux_fixed():
    A = np.eye(2)
    required = np.array([0.5, 1.0])
    fixed_fluxes = np.array([0.75, np.nan])
    phi, feasible, _, _ = _solve_fluxes_minimax(
        A,
        required,
        required,
        min_flux=0.0,
        max_flux=2.0,
        monotonic_blocks=[],
        constant_blocks=[],
        upper_mask=None,
        phi_initial=np.array([0.75, 0.0]),
        max_iters=100,
        fixed_fluxes=fixed_fluxes,
    )
    assert feasible
    assert phi[0] == pytest.approx(0.75)
    assert phi[1] == pytest.approx(1.0)


def test_infeasible_solver_preserves_initial_flux_instead_of_using_maximum():
    A = np.zeros((1, 2))
    required = np.ones(1)
    initial = np.array([0.25, 0.40])
    phi, feasible, _, _ = _solve_fluxes_minimax(
        A,
        required,
        required,
        min_flux=0.0,
        max_flux=2.0,
        monotonic_blocks=[],
        constant_blocks=[],
        upper_mask=None,
        phi_initial=initial,
        max_iters=10,
    )
    assert not feasible
    assert np.allclose(phi, initial)
