from types import SimpleNamespace

from modules.tunnel.photometric_verify import compute_real_luminance_profile


def test_profile_reports_cie140_field_average_metadata():
    setpoints = [
        {
            "idx": index + 1,
            "s": float(s),
            "optic": "F151",
            "flux_lm": 11535.0,
            "tilt_deg": 5.0,
            "spacing_m": 20.0,
        }
        for index, s in enumerate(range(0, 101, 20))
    ]
    zone = SimpleNamespace(
        n_luminaires=len(setpoints),
        s_start=0.0,
        s_end=100.0,
        zone_type="interior",
        setpoints=setpoints,
        d_used=20.0,
    )
    lum_result = SimpleNamespace(
        road_surface_type="dark_asphalt",
        optic="F151",
        zones=[zone],
    )
    params = {
        "mounting_height_m": 4.5,
        "maintenance_factor": 0.70,
        "arrangement": "bilateral_sym",
        "wall_offset_m": 1.25,
        "num_lanes": 2,
        "lane_width_m": 3.5,
        "shoulder_left_m": 1.0,
        "shoulder_right_m": 1.0,
    }

    result = compute_real_luminance_profile(
        lum_result,
        params,
        road_width_m=9.0,
        step_size=20.0,
    )

    assert result["available"]
    assert result["metric"] == "CIE140_Lavg"
    assert result["grid"]["transverse_points_per_lane"] == 3
    assert result["grid"]["num_lanes"] == 2
    assert result["grid"]["num_observers"] == 2
    assert result["grid"]["selection"] == "peor observador"
    assert result["grid"]["representation"].startswith("un valor Lavg por campo")
    assert result["points"]
    assert len(result["points"]) == len(setpoints) - 1
    assert result["points"][0]["field_start"] == 0.0
    assert result["points"][0]["field_end"] == 20.0
    assert result["points"][0]["s"] == 10.0
    assert all(point["L"] > 0.0 for point in result["points"])
    assert len(result["fields"]) == len(result["points"])
    assert len(result["fields"][0]["grid_points"]) == 60
    assert result["fields"][0]["observer_lane_y_m"] in (2.75, 6.25)
    assert result["fields"][0]["observer_direction"] == 1
    assert all(point["L"] > 0.0 for point in result["fields"][0]["grid_points"])
