"""Motor fotometrico SALVI."""
