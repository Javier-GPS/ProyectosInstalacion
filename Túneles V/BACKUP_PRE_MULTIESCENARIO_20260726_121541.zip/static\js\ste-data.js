/* ============================================================
   SALVI Tunnel Engine — i18n + Help Content Data  v1.2
   Languages: es · en · fr · ca · it
   Loaded as a plain <script> before the React/Babel script.
   ============================================================ */

// ── Language definitions ──────────────────────────────────────
window.STE_LANGS = {
  es: { label: 'Español',  flag: 'ES' },
  en: { label: 'English',  flag: 'EN' },
  fr: { label: 'Français', flag: 'FR' },
  ca: { label: 'Català',   flag: 'CA' },
  it: { label: 'Italiano', flag: 'IT' },
};

// ── UI Translation strings ────────────────────────────────────
// Format: "key": { es, en, fr, ca, it }
window.STE_TR = {

  // App chrome
  'app.title':    { es:'SALVI Tunnel Engine', en:'SALVI Tunnel Engine', fr:'SALVI Tunnel Engine', ca:'SALVI Tunnel Engine', it:'SALVI Tunnel Engine' },
  'app.badge':    { es:'CIE 88:2004', en:'CIE 88:2004', fr:'CIE 88:2004', ca:'CIE 88:2004', it:'CIE 88:2004' },
  'app.back':     { es:'← Volver a LuxStudio', en:'← Back to LuxStudio', fr:'← Retour à LuxStudio', ca:'← Tornar a LuxStudio', it:'← Torna a LuxStudio' },
  'app.unnamed':  { es:'Sin nombre', en:'Unnamed', fr:'Sans nom', ca:'Sense nom', it:'Senza nome' },
  'app.calc_ok':  { es:'✓ Calculado', en:'✓ Calculated', fr:'✓ Calculé', ca:'✓ Calculat', it:'✓ Calcolato' },
  'app.help':     { es:'❓ Ayuda', en:'❓ Help', fr:'❓ Aide', ca:'❓ Ajuda', it:'❓ Aiuto' },

  // Project bar
  'proj.new':     { es:'🆕 Nuevo', en:'🆕 New', fr:'🆕 Nouveau', ca:'🆕 Nou', it:'🆕 Nuovo' },
  'proj.open':    { es:'📂 Abrir', en:'📂 Open', fr:'📂 Ouvrir', ca:'📂 Obrir', it:'📂 Apri' },
  'proj.save':    { es:'💾 Guardar', en:'💾 Save', fr:'💾 Sauvegarder', ca:'💾 Guardar', it:'💾 Salva' },
  'proj.add_tube':{ es:'+ Tubo', en:'+ Tube', fr:'+ Tube', ca:'+ Tub', it:'+ Tubo' },
  'proj.confirm_new': { es:'¿Crear nuevo proyecto? Se perderán los datos no guardados.', en:'Create new project? Unsaved data will be lost.', fr:'Créer un nouveau projet ? Les données non sauvegardées seront perdues.', ca:'Crear nou projecte? Es perdran les dades no guardades.', it:'Creare un nuovo progetto? I dati non salvati andranno persi.' },
  'proj.confirm_del': { es:'¿Eliminar el Tubo $1? Se perderán sus datos.', en:'Delete Tube $1? All data will be lost.', fr:'Supprimer le Tube $1 ? Les données seront perdues.', ca:'Eliminar el Tub $1? Es perdran les dades.', it:'Eliminare il Tubo $1? I dati andranno persi.' },
  'proj.saved':   { es:'💾 Proyecto guardado', en:'💾 Project saved', fr:'💾 Projet sauvegardé', ca:'💾 Projecte guardat', it:'💾 Progetto salvato' },
  'proj.new_msg': { es:'🆕 Nuevo proyecto', en:'🆕 New project', fr:'🆕 Nouveau projet', ca:'🆕 Nou projecte', it:'🆕 Nuovo progetto' },
  'proj.load_ok': { es:'📂 Proyecto cargado:', en:'📂 Project loaded:', fr:'📂 Projet chargé :', ca:'📂 Projecte carregat:', it:'📂 Progetto caricato:' },
  'proj.bad_file':{ es:'❌ Archivo inválido — no es un proyecto STE', en:'❌ Invalid file — not an STE project', fr:'❌ Fichier invalide — pas un projet STE', ca:'❌ Arxiu invàlid — no és un projecte STE', it:'❌ File non valido — non è un progetto STE' },

  // Step labels
  'step.0': { es:'Geometría',   en:'Geometry',    fr:'Géométrie',     ca:'Geometria',   it:'Geometria'  },
  'step.1': { es:'Entorno',     en:'Environment', fr:'Environnement', ca:'Entorn',      it:'Ambiente'   },
  'step.2': { es:'Tráfico',     en:'Traffic',     fr:'Trafic',        ca:'Trànsit',     it:'Traffico'   },
  'step.3': { es:'Calcular',    en:'Calculate',   fr:'Calculer',      ca:'Calcular',    it:'Calcola'    },
  'step.4': { es:'Resultados',  en:'Results',     fr:'Résultats',     ca:'Resultats',   it:'Risultati'  },
  'step.5': { es:'Control',     en:'Control',     fr:'Contrôle',      ca:'Control',     it:'Controllo'  },
  'step.6': { es:'Luminarias',  en:'Luminaires',  fr:'Luminaires',    ca:'Lluminàries', it:'Lampade'    },
  'step.7': { es:'Informe',     en:'Report',      fr:'Rapport',       ca:'Informe',     it:'Rapporto'   },

  // Navigation buttons
  'btn.prev':    { es:'← Anterior',   en:'← Back',      fr:'← Précédent',  ca:'← Anterior',  it:'← Indietro' },
  'btn.next':    { es:'Siguiente →',  en:'Next →',       fr:'Suivant →',    ca:'Següent →',   it:'Avanti →'   },
  'btn.calc':    { es:'⚡ Calcular según CIE 88:2004', en:'⚡ Calculate per CIE 88:2004', fr:'⚡ Calculer selon CIE 88:2004', ca:'⚡ Calcular segons CIE 88:2004', it:'⚡ Calcola secondo CIE 88:2004' },
  'btn.recalc':  { es:'🔄 Recalcular', en:'🔄 Recalculate', fr:'🔄 Recalculer', ca:'🔄 Recalcular', it:'🔄 Ricalcola' },
  'btn.calcing': { es:'⏳ Calculando...', en:'⏳ Calculating...', fr:'⏳ Calcul en cours...', ca:'⏳ Calculant...', it:'⏳ Calcolo in corso...' },
  'btn.ctrl':    { es:'🎛️ Plan de Control →', en:'🎛️ Control Plan →', fr:'🎛️ Plan de Contrôle →', ca:'🎛️ Pla de Control →', it:'🎛️ Piano di Controllo →' },
  'btn.lum':     { es:'💡 Cálculo de Luminarias →', en:'💡 Luminaire Design →', fr:'💡 Calcul des Luminaires →', ca:'💡 Càlcul de Lluminàries →', it:'💡 Progetto Lampade →' },
  'btn.report':  { es:'📄 Generar Informe →', en:'📄 Generate Report →', fr:'📄 Générer le Rapport →', ca:'📄 Generar Informe →', it:'📄 Genera Rapporto →' },

  // Help navigation labels
  'help.title':        { es:'Ayuda — STE v1.2', en:'Help — STE v1.2', fr:'Aide — STE v1.2', ca:'Ajuda — STE v1.2', it:'Aiuto — STE v1.2' },
  'help.sub':          { es:'SALVI Tunnel Engine · CIE 88:2004', en:'SALVI Tunnel Engine · CIE 88:2004', fr:'SALVI Tunnel Engine · CIE 88:2004', ca:'SALVI Tunnel Engine · CIE 88:2004', it:'SALVI Tunnel Engine · CIE 88:2004' },
  'help.close':        { es:'✕ Cerrar', en:'✕ Close', fr:'✕ Fermer', ca:'✕ Tancar', it:'✕ Chiudi' },
  'help.nav.overview': { es:'Presentación', en:'Overview', fr:'Présentation', ca:'Presentació', it:'Presentazione' },
  'help.nav.guide':    { es:'Guía de uso', en:'User Guide', fr:'Guide d\'utilisation', ca:'Guia d\'ús', it:'Guida all\'uso' },
  'help.nav.normativa':{ es:'Normativa', en:'Standards', fr:'Normes', ca:'Normativa', it:'Normativa' },
  'help.nav.concepts': { es:'Conceptos CIE', en:'CIE Concepts', fr:'Concepts CIE', ca:'Conceptes CIE', it:'Concetti CIE' },
  'help.nav.limits':   { es:'Limitaciones', en:'Limitations', fr:'Limitations', ca:'Limitacions', it:'Limitazioni' },
  'help.nav.faq':      { es:'Preguntas frecuentes', en:'FAQ', fr:'FAQ', ca:'Preguntes freqüents', it:'Domande frequenti' },
  'help.nav.ai':       { es:'SALVI IA', en:'SALVI AI', fr:'SALVI IA', ca:'SALVI IA', it:'SALVI IA' },
  'help.nav.shortcuts':{ es:'Atajos', en:'Shortcuts', fr:'Raccourcis', ca:'Dreceres', it:'Scorciatoie' },
};

// ── Help Content Data ─────────────────────────────────────────
// Block types: h1, h2, p, ul, tip, warn, table{heads,rows}, keys[{k,d}]
window.STE_HELP_DATA = {

  // ── PRESENTACIÓN / OVERVIEW ──────────────────────────────────
  overview: {
    es: [
      { h1: '🎯 SALVI Tunnel Engine v1.2' },
      { p: 'SALVI Tunnel Engine (STE) es el módulo de cálculo normativo de iluminación de túneles de carretera del ecosistema LuxStudio. Implementa íntegramente la norma CIE 88:2004 — Guide for the Lighting of Road Tunnels and Underpasses.' },
      { h2: 'Qué calcula STE' },
      { ul: [
        'Luminancias de diseño: L₂₀, Lth (umbral), Lin (interior), L_noche',
        'Distancia de parada SD y factor k según tablas CIE 88',
        'Zonas normativas: umbral, transición, interior, salida',
        'Perfil longitudinal de luminancia requerida',
        'Plan de control DALI / Smartec / 0-10V con escenas y grupos',
        'Dimensionado de luminarias (número, espaciado, potencia) por zona',
        'Informes técnicos en Word (.docx) y Excel (.xlsx)',
        'Soporte multi-tubo para túneles bidireccionales (T1/T2/T3/T4)',
      ]},
      { h2: 'Integración LuxStudio' },
      { p: 'STE se integra en el flujo de trabajo de LuxStudio como módulo independiente. La integración con el motor fotométrico de LuxStudio (servidor Imaginning) —que permite calcular uniformidades Uo/Ul, deslumbramiento TI y ratio de luminancia de paredes con archivos LDT reales— está actualmente en desarrollo.' },
      { tip: 'STE realiza el cálculo normativo completo según CIE 88:2004. Para el cálculo fotométrico punto-a-punto (Uo, Ul, TI, luminancia paredes) use el módulo fotométrico de LuxStudio con el archivo LDT de la luminaria.' },
      { h2: 'Flujo de trabajo' },
      { p: 'El wizard de 8 pasos guía desde la geometría hasta el informe final: Geometría → Entorno → Tráfico → Calcular → Resultados → Control → Luminarias → Informe. Puede moverse libremente entre pasos usando el menú superior.' },
    ],
    en: [
      { h1: '🎯 SALVI Tunnel Engine v1.2' },
      { p: 'SALVI Tunnel Engine (STE) is the normative road tunnel lighting calculation module of the LuxStudio ecosystem. It fully implements the CIE 88:2004 standard — Guide for the Lighting of Road Tunnels and Underpasses.' },
      { h2: 'What STE calculates' },
      { ul: [
        'Design luminances: L₂₀, Lth (threshold), Lin (interior), L_night',
        'Stopping distance SD and k-factor per CIE 88 tables',
        'Normative zones: threshold, transition, interior, exit',
        'Longitudinal luminance profile',
        'DALI / Smartec / 0-10V control plan with scenes and groups',
        'Luminaire sizing (count, spacing, power) per zone',
        'Technical reports in Word (.docx) and Excel (.xlsx)',
        'Multi-tube support for bidirectional tunnels (T1/T2/T3/T4)',
      ]},
      { h2: 'LuxStudio Integration' },
      { p: 'STE integrates into the LuxStudio workflow as a standalone module. Integration with the LuxStudio photometric engine (Imaginning server) — which enables calculation of uniformities Uo/Ul, glare TI and wall luminance ratio with actual LDT files — is currently under development.' },
      { tip: 'STE performs complete normative calculation per CIE 88:2004. For point-by-point photometric calculation (Uo, Ul, TI, wall luminance) use the LuxStudio photometric module with the luminaire LDT file.' },
      { h2: 'Workflow' },
      { p: 'The 8-step wizard guides you from geometry to the final report: Geometry → Environment → Traffic → Calculate → Results → Control → Luminaires → Report. You can navigate freely between steps using the top menu.' },
    ],
    fr: [
      { h1: '🎯 SALVI Tunnel Engine v1.2' },
      { p: 'SALVI Tunnel Engine (STE) est le module de calcul normatif d\'éclairage de tunnels routiers de l\'écosystème LuxStudio. Il implémente intégralement la norme CIE 88:2004 — Guide pour l\'éclairage des tunnels routiers.' },
      { h2: 'Ce que STE calcule' },
      { ul: [
        'Luminances de conception : L₂₀, Lth (seuil), Lin (intérieur), L_nuit',
        'Distance d\'arrêt SD et facteur k selon les tableaux CIE 88',
        'Zones normatives : seuil, transition, intérieur, sortie',
        'Profil longitudinal de luminance requise',
        'Plan de contrôle DALI / Smartec / 0-10V avec scènes et groupes',
        'Dimensionnement des luminaires (nombre, espacement, puissance) par zone',
        'Rapports techniques en Word (.docx) et Excel (.xlsx)',
        'Support multi-tube pour les tunnels bidirectionnels (T1/T2/T3/T4)',
      ]},
      { tip: 'STE effectue le calcul normatif complet selon CIE 88:2004. Pour le calcul photométrique point par point (Uo, Ul, TI, luminance des parois), utilisez le module photométrique LuxStudio avec le fichier LDT du luminaire.' },
    ],
    ca: [
      { h1: '🎯 SALVI Tunnel Engine v1.2' },
      { p: 'SALVI Tunnel Engine (STE) és el mòdul de càlcul normatiu d\'il·luminació de túnels de carretera de l\'ecosistema LuxStudio. Implementa íntegrament la norma CIE 88:2004 — Guide for the Lighting of Road Tunnels and Underpasses.' },
      { h2: 'Què calcula STE' },
      { ul: [
        'Lluminàncies de disseny: L₂₀, Lth (llindar), Lin (interior), L_nit',
        'Distància de parada SD i factor k segons taules CIE 88',
        'Zones normatives: llindar, transició, interior, sortida',
        'Perfil longitudinal de lluminància requerida',
        'Pla de control DALI / Smartec / 0-10V amb escenes i grups',
        'Dimensionament de lluminàries (nombre, espaiat, potència) per zona',
        'Informes tècnics en Word (.docx) i Excel (.xlsx)',
        'Suport multi-tub per a túnels bidireccionals (T1/T2/T3/T4)',
      ]},
      { tip: 'STE realitza el càlcul normatiu complet segons CIE 88:2004. Per al càlcul fotomètric punt a punt (Uo, Ul, TI, lluminància parets) useu el mòdul fotomètric de LuxStudio amb l\'arxiu LDT de la lluminària.' },
    ],
    it: [
      { h1: '🎯 SALVI Tunnel Engine v1.2' },
      { p: 'SALVI Tunnel Engine (STE) è il modulo di calcolo normativo dell\'illuminazione di gallerie stradali dell\'ecosistema LuxStudio. Implementa integralmente la norma CIE 88:2004 — Guide for the Lighting of Road Tunnels and Underpasses.' },
      { h2: 'Cosa calcola STE' },
      { ul: [
        'Luminanze di progetto: L₂₀, Lth (soglia), Lin (interno), L_notte',
        'Distanza di arresto SD e fattore k secondo le tabelle CIE 88',
        'Zone normative: soglia, transizione, interno, uscita',
        'Profilo longitudinale di luminanza richiesta',
        'Piano di controllo DALI / Smartec / 0-10V con scene e gruppi',
        'Dimensionamento apparecchi (numero, interasse, potenza) per zona',
        'Relazioni tecniche in Word (.docx) ed Excel (.xlsx)',
        'Supporto multi-tubo per gallerie bidirezionali (T1/T2/T3/T4)',
      ]},
      { tip: 'STE esegue il calcolo normativo completo secondo CIE 88:2004. Per il calcolo fotometrico punto per punto (Uo, Ul, TI, luminanza pareti) usa il modulo fotometrico LuxStudio con il file LDT dell\'apparecchio.' },
    ],
  },

  // ── GUÍA DE USO / USER GUIDE ─────────────────────────────────
  guide: {
    es: [
      { h1: '📋 Guía de uso' },
      { h2: 'Paso 0 — Geometría' },
      { p: 'Introduce el nombre del proyecto, el ID del tubo (T1, T2…), la longitud del túnel en metros, la velocidad de diseño en km/h, la pendiente longitudinal y el radio de curvatura si aplica. STE muestra automáticamente la longitud mínima recomendada basada en la distancia de parada SD.' },
      { h2: 'Paso 1 — Entorno' },
      { p: 'Define las condiciones visuales del portal de entrada: orientación (N, S, E, W, NE, SW…), tipo de entorno (campo abierto, forestal, urbano, montaña…), condición de cielo de diseño (despejado es el más exigente), penetración de luz diurna y reflectancia de paredes. Selecciona si la salida es visible desde la distancia de parada y si la carretera exterior está iluminada.' },
      { h2: 'Paso 2 — Tráfico' },
      { p: 'Introduce el volumen de tráfico de diseño (veh/h), el número de carriles y el método de cálculo de Lth: factor k (método estándar CIE 88, tablas §14) o Lseq/contraste percibido (método alternativo §15). Activa el perfil escalonado si quieres una transición en escalones en lugar de curva continua.' },
      { h2: 'Paso 3 — Calcular' },
      { p: 'Revisa el resumen de parámetros y pulsa "Calcular". STE ejecuta el cálculo completo CIE 88:2004: clasificación geométrica y óptica, distancia de parada, L₂₀, Lth, Lin, perfil longitudinal y plan de control. El cálculo dura menos de un segundo.' },
      { h2: 'Paso 4 — Resultados' },
      { p: 'Muestra el esquema de zonas a escala, los KPIs principales (L₂₀, Lth, Lin, k, qc, SD), la clasificación CIE 88, el perfil longitudinal de luminancia y la tabla de zonas normativas con posiciones y luminancias mínimas requeridas.' },
      { h2: 'Paso 5 — Control' },
      { p: 'Configura el protocolo de control (DALI, Smartec, 0-10V), el número de grupos de transición y visualiza el plan de escenas. La tabla muestra el nivel de regulación (%) y el valor DALI (0-254) por grupo y escena. Se emiten avisos si alguna ratio de cambio entre escenas supera 3:1 (CIE 88 §9.3). Exporta el plan en JSON o CSV.' },
      { h2: 'Paso 6 — Luminarias' },
      { p: 'Introduce los parámetros de la luminaria (flujo, potencia, factor de utilización η, altura de montaje, disposición, factor de mantenimiento MF y superficie de calzada). STE calcula el número de luminarias, el espaciado máximo y la densidad de potencia por zona.' },
      { h2: 'Paso 7 — Informe' },
      { p: 'Genera el informe técnico completo en Word (.docx) o en Excel (.xlsx) con 6 hojas (Portada, Zonas, Resultados, Control, Luminarias y Perfil). En modo multi-tubo, aparecen los botones de informe/Excel combinado con todos los tubos calculados.' },
      { tip: 'Guarda el proyecto en cualquier momento (💾 Guardar) en formato .ste.json. El archivo incluye todos los tubos y sus formularios. Los resultados se recalculan automáticamente al reabrir.' },
    ],
    en: [
      { h1: '📋 User Guide' },
      { h2: 'Step 0 — Geometry' },
      { p: 'Enter the project name, tube ID (T1, T2…), tunnel length in metres, design speed in km/h, longitudinal gradient and curvature radius if applicable. STE automatically shows the minimum recommended length based on stopping distance SD.' },
      { h2: 'Step 1 — Environment' },
      { p: 'Define the visual conditions at the entry portal: orientation (N, S, E, W, NE, SW…), environment type (open country, forest, urban, mountain…), design sky condition (clear is most demanding), daylight penetration and wall reflectance. Select whether the exit is visible from the stopping distance and whether the outer road is lit.' },
      { h2: 'Step 2 — Traffic' },
      { p: 'Enter the design traffic volume (veh/h), number of lanes and the Lth calculation method: k-factor (standard CIE 88 method, §14 tables) or Lseq/perceived contrast (alternative method §15). Enable the stepped profile if you want a stepped transition rather than a continuous curve.' },
      { h2: 'Step 3 — Calculate' },
      { p: 'Review the parameter summary and click "Calculate". STE runs the full CIE 88:2004 calculation: geometric and optical classification, stopping distance, L₂₀, Lth, Lin, longitudinal profile and control plan. The calculation takes less than a second.' },
      { h2: 'Step 4 — Results' },
      { p: 'Shows the scaled zone layout, main KPIs (L₂₀, Lth, Lin, k, qc, SD), CIE 88 classification, luminance longitudinal profile and normative zone table with positions and minimum required luminances.' },
      { h2: 'Step 5 — Control' },
      { p: 'Set the control protocol (DALI, Smartec, 0-10V), number of transition groups and view the scene plan. The table shows dimming level (%) and DALI value (0-254) per group and scene. Warnings are issued if any scene change ratio exceeds 3:1 (CIE 88 §9.3). Export the plan as JSON or CSV.' },
      { h2: 'Step 6 — Luminaires' },
      { p: 'Enter luminaire parameters (flux, power, utilisation factor η, mounting height, arrangement, maintenance factor MF and road surface). STE calculates the number of luminaires, maximum spacing and power density per zone.' },
      { h2: 'Step 7 — Report' },
      { p: 'Generate the complete technical report in Word (.docx) or Excel (.xlsx) with 6 sheets (Cover, Zones, Results, Control, Luminaires and Profile). In multi-tube mode, combined report/Excel buttons appear with all calculated tubes.' },
      { tip: 'Save the project at any time (💾 Save) as a .ste.json file. The file includes all tubes and their forms. Results are recalculated automatically when reopened.' },
    ],
    fr: [
      { h1: '📋 Guide d\'utilisation' },
      { h2: 'Étape 0 — Géométrie' },
      { p: 'Saisissez le nom du projet, l\'ID du tube (T1, T2…), la longueur du tunnel en mètres, la vitesse de conception en km/h, la pente longitudinale et le rayon de courbure le cas échéant. STE affiche automatiquement la longueur minimale recommandée basée sur la distance d\'arrêt SD.' },
      { h2: 'Étape 1 — Environnement' },
      { p: 'Définissez les conditions visuelles au portail d\'entrée : orientation (N, S, E, W, NE, SW…), type d\'environnement (rase campagne, forêt, urbain, montagne…), condition de ciel de conception (clair est la plus contraignante), pénétration de lumière naturelle et réflectance des parois.' },
      { h2: 'Étape 2 — Trafic' },
      { p: 'Saisissez le volume de trafic de conception (véh/h), le nombre de voies et la méthode de calcul de Lth : facteur k (méthode standard CIE 88, tableaux §14) ou Lseq/contraste perçu (méthode alternative §15).' },
      { h2: 'Étape 3 — Calculer' },
      { p: 'Vérifiez le résumé des paramètres et cliquez sur « Calculer ». STE exécute le calcul complet CIE 88:2004 en moins d\'une seconde.' },
      { h2: 'Étapes 4 à 7' },
      { p: 'Les étapes suivantes affichent les résultats (zones, KPIs, profil), le plan de contrôle DALI/Smartec, le dimensionnement des luminaires et génèrent le rapport Word/Excel.' },
      { tip: 'Sauvegardez le projet à tout moment (💾 Sauvegarder) au format .ste.json. Le fichier inclut tous les tubes et leurs formulaires.' },
    ],
    ca: [
      { h1: '📋 Guia d\'ús' },
      { h2: 'Pas 0 — Geometria' },
      { p: 'Introduïu el nom del projecte, l\'ID del tub (T1, T2…), la longitud del túnel en metres, la velocitat de disseny en km/h, el pendent longitudinal i el radi de curvatura si escau. STE mostra automàticament la longitud mínima recomanada basada en la distància de parada SD.' },
      { h2: 'Pas 1 — Entorn' },
      { p: 'Definiu les condicions visuals al portal d\'entrada: orientació, tipus d\'entorn, condició de cel de disseny, penetració de llum diürna i reflectància de parets.' },
      { h2: 'Passos 2 a 7' },
      { p: 'Trànsit (volum, carrils, mètode Lth) → Calcular (càlcul CIE 88:2004 complet) → Resultats (zones, KPIs, perfil) → Control (pla DALI/Smartec) → Lluminàries (dimensionament) → Informe (Word/Excel).' },
      { tip: 'Guardeu el projecte en qualsevol moment (💾 Guardar) en format .ste.json. L\'arxiu inclou tots els tubs i els seus formularis.' },
    ],
    it: [
      { h1: '📋 Guida all\'uso' },
      { h2: 'Passo 0 — Geometria' },
      { p: 'Inserite il nome del progetto, l\'ID del tubo (T1, T2…), la lunghezza della galleria in metri, la velocità di progetto in km/h, la pendenza longitudinale e il raggio di curvatura se applicabile. STE mostra automaticamente la lunghezza minima raccomandata basata sulla distanza di arresto SD.' },
      { h2: 'Passo 1 — Ambiente' },
      { p: 'Definite le condizioni visive al portale d\'ingresso: orientamento, tipo di ambiente, condizione di cielo di progetto, penetrazione di luce diurna e riflettanza delle pareti.' },
      { h2: 'Passi 2-7' },
      { p: 'Traffico (volume, corsie, metodo Lth) → Calcola (calcolo CIE 88:2004 completo) → Risultati (zone, KPI, profilo) → Controllo (piano DALI/Smartec) → Lampade (dimensionamento) → Rapporto (Word/Excel).' },
      { tip: 'Salvate il progetto in qualsiasi momento (💾 Salva) in formato .ste.json. Il file include tutti i tubi e i relativi moduli.' },
    ],
  },

  // ── NORMATIVA / STANDARDS ────────────────────────────────────
  normativa: {
    es: [
      { h1: '📐 Normativa aplicada' },
      { h2: 'CIE 88:2004 — Norma principal' },
      { p: 'La norma de referencia es CIE Publication 88:2004 «Guide for the Lighting of Road Tunnels and Underpasses», publicada por la International Commission on Illumination. Es la norma internacional de facto para iluminación de túneles de carretera, adoptada como base por las normas nacionales de la mayoría de países europeos.' },
      { p: 'STE implementa íntegramente los capítulos: Clasificación (§5), Velocidad y distancia de parada (§6), Luminancia del campo de adaptación L₂₀ (§12), Lseq/contraste (§15), Luminancia umbral Lth (§14), Luminancia interior Lin (§16), Zonas normativas (§7), Perfil longitudinal (§8-9), y Plan de control (§9.3).' },
      { h2: 'Normas relacionadas' },
      { ul: [
        'EN 13201:2015 — Road lighting (uniformidades, TI, iluminancia)',
        'IEC 62386 — DALI protocol (digital dimming)',
        'CIE 140:2000 — Road lighting calculations',
        'CIE 115:2010 — Lighting of roads for motor and pedestrian traffic',
        'EN 12665 — Basic terms and criteria for specifying lighting requirements',
      ]},
      { h2: 'Parámetros principales CIE 88:2004' },
      { table: {
        heads: ['Parámetro', 'Definición', 'Referencia'],
        rows: [
          ['L₂₀', 'Luminancia media del campo de adaptación visual (cono de 20°) ante el portal', '§12'],
          ['Lth', 'Luminancia mínima de diseño en zona umbral', '§14'],
          ['Lin', 'Luminancia mínima en zona interior', '§16'],
          ['k', 'Factor de reducción Lth/L₂₀ (tablas CIE 88 §14)', '§14'],
          ['qc', 'Coeficiente de luminancia de calzada (m²·sr/lm)', '§14'],
          ['SD', 'Distancia de parada (t_r=1.5s, a=3.5 m/s²)', '§6'],
          ['TH', 'Longitud zona umbral = SD', '§7.2'],
          ['TR', 'Longitud zona transición: según curva o escalones', '§7.3'],
        ]
      }},
      { h2: 'Ecuaciones fundamentales' },
      { p: 'Distancia de parada: SD = v·t_r + v²/(2·a) con t_r=1.5 s, a=3.5 m/s²' },
      { p: 'Luminancia umbral: Lth = k · L₂₀, donde k = f(v, q_c, tráfico)' },
      { p: 'Curva de transición: L(s) = Lin · (Lth/Lin)^((Ltr-s)/Ltr) con s desde inicio de transición' },
      { warn: 'CIE 88:2004 está en proceso de revisión por el Comité Técnico TC 4-53. STE se actualizará cuando se publique la nueva edición.' },
    ],
    en: [
      { h1: '📐 Applicable Standards' },
      { h2: 'CIE 88:2004 — Main Standard' },
      { p: 'The reference standard is CIE Publication 88:2004 «Guide for the Lighting of Road Tunnels and Underpasses», published by the International Commission on Illumination. It is the de facto international standard for road tunnel lighting, adopted as the basis for national standards in most European countries.' },
      { p: 'STE fully implements the following chapters: Classification (§5), Speed and stopping distance (§6), Adaptation field luminance L₂₀ (§12), Lseq/contrast (§15), Threshold luminance Lth (§14), Interior luminance Lin (§16), Normative zones (§7), Longitudinal profile (§8-9), and Control plan (§9.3).' },
      { h2: 'Related Standards' },
      { ul: [
        'EN 13201:2015 — Road lighting (uniformities, TI, illuminance)',
        'IEC 62386 — DALI protocol (digital dimming)',
        'CIE 140:2000 — Road lighting calculations',
        'CIE 115:2010 — Lighting of roads for motor and pedestrian traffic',
        'EN 12665 — Basic terms and criteria for specifying lighting requirements',
      ]},
      { h2: 'Key CIE 88:2004 Parameters' },
      { table: {
        heads: ['Parameter', 'Definition', 'Reference'],
        rows: [
          ['L₂₀', 'Mean luminance of the visual adaptation field (20° cone) in front of the portal', '§12'],
          ['Lth', 'Minimum design luminance in the threshold zone', '§14'],
          ['Lin', 'Minimum luminance in the interior zone', '§16'],
          ['k', 'Reduction factor Lth/L₂₀ (CIE 88 §14 tables)', '§14'],
          ['qc', 'Road luminance coefficient (m²·sr/lm)', '§14'],
          ['SD', 'Stopping distance (t_r=1.5s, a=3.5 m/s²)', '§6'],
        ]
      }},
      { warn: 'CIE 88:2004 is currently under revision by Technical Committee TC 4-53. STE will be updated when the new edition is published.' },
    ],
    fr: [
      { h1: '📐 Normes applicables' },
      { h2: 'CIE 88:2004 — Norme principale' },
      { p: 'La norme de référence est la Publication CIE 88:2004 «Guide for the Lighting of Road Tunnels and Underpasses», publiée par la Commission Internationale de l\'Éclairage. C\'est la norme internationale de facto pour l\'éclairage des tunnels routiers.' },
      { h2: 'Normes connexes' },
      { ul: [
        'EN 13201:2015 — Éclairage public (uniformités, éblouissement TI)',
        'IEC 62386 — Protocole DALI (variation numérique)',
        'CIE 140:2000 — Calculs d\'éclairage routier',
        'CIE 115:2010 — Éclairage des routes pour la circulation motorisée',
      ]},
      { warn: 'La CIE 88:2004 est en cours de révision par le Comité Technique TC 4-53. STE sera mis à jour lors de la publication de la nouvelle édition.' },
    ],
    ca: [
      { h1: '📐 Normativa aplicada' },
      { h2: 'CIE 88:2004 — Norma principal' },
      { p: 'La norma de referència és la Publicació CIE 88:2004 «Guide for the Lighting of Road Tunnels and Underpasses». És la norma internacional de facto per a la il·luminació de túnels de carretera, adoptada com a base per les normes nacionals de la majoria de països europeus.' },
      { h2: 'Normes relacionades' },
      { ul: [
        'EN 13201:2015 — Il·luminació viària (uniformitats, TI)',
        'IEC 62386 — Protocol DALI (regulació digital)',
        'CIE 140:2000 — Càlculs d\'il·luminació viària',
      ]},
      { warn: 'La CIE 88:2004 està en procés de revisió pel Comitè Tècnic TC 4-53. STE s\'actualitzarà quan es publiqui la nova edició.' },
    ],
    it: [
      { h1: '📐 Normativa applicata' },
      { h2: 'CIE 88:2004 — Norma principale' },
      { p: 'La norma di riferimento è la Pubblicazione CIE 88:2004 «Guide for the Lighting of Road Tunnels and Underpasses». È lo standard internazionale de facto per l\'illuminazione di gallerie stradali, adottato come base dalle norme nazionali della maggior parte dei paesi europei.' },
      { h2: 'Norme correlate' },
      { ul: [
        'EN 13201:2015 — Illuminazione stradale (uniformità, TI)',
        'IEC 62386 — Protocollo DALI (regolazione digitale)',
        'CIE 140:2000 — Calcoli di illuminazione stradale',
      ]},
      { warn: 'La CIE 88:2004 è in fase di revisione da parte del Comitato Tecnico TC 4-53. STE sarà aggiornato alla pubblicazione della nuova edizione.' },
    ],
  },

  // ── CONCEPTOS CIE / CIE CONCEPTS ────────────────────────────
  concepts: {
    es: [
      { h1: '💡 Conceptos clave CIE 88:2004' },

      { h2: 'L₂₀ — Luminancia del campo de adaptación' },
      { p: 'L₂₀ es la luminancia media del campo visual (cono de 20° de semiapertura) que el conductor ve al aproximarse al portal a una distancia de parada SD. Es el parámetro de entrada más crítico: determina directamente Lth. STE puede calcularlo por modelo de entorno (parámetros: tipo de entorno, orientación, cielo) o por tabla de referencia CIE 88.' },

      { h2: 'Lth — Luminancia umbral (Threshold)' },
      { p: 'Lth es la luminancia mínima de diseño en la zona de umbral. Garantiza que el ojo, adaptado al nivel exterior L₂₀, pueda detectar obstáculos. Lth = k · L₂₀, donde k es el factor de reducción (tabla §14, función de velocidad, volumen de tráfico y coeficiente de calzada qc).' },

      { h2: 'Lin — Luminancia interior' },
      { p: 'Lin es la luminancia mínima en la zona interior. No depende de L₂₀ sino de la velocidad de diseño y el volumen de tráfico. Típicamente Lin ≈ 2-10 cd/m².' },

      { h2: 'SD — Distancia de parada' },
      { p: 'Distancia total de parada de emergencia: SD = v·t_r + v²/(2a), con t_r=1.5 s (tiempo de reacción) y a=3.5 m/s² (deceleración). Determina la longitud de las zonas de umbral y acceso.' },

      { h2: 'Factor k' },
      { p: 'Factor de reducción de luminancia en la zona umbral. Depende de la velocidad (mayor velocidad → mayor k), del tráfico (mayor tráfico → mayor k) y del coeficiente de calzada qc. Valores típicos: 0.035–0.10.' },

      { h2: 'qc — Coeficiente de calzada' },
      { p: 'qc = L_calzada / E_incidente (m²·sr/lm). Relaciona la luminancia de calzada con la iluminancia vertical incidente. Varía con el tipo de pavimento: asfalto oscuro qc≈0.065, hormigón qc≈0.14.' },

      { h2: 'Zonas normativas CIE 88' },
      { table: {
        heads: ['Zona', 'Longitud', 'Nivel luminancia'],
        rows: [
          ['Acceso (Access)', '= SD (exterior)', 'L₂₀ (natural)'],
          ['Umbral (Threshold)', '= SD', 'Lth (máxima, inicio zona)'],
          ['Transición (Transition)', 'Curva de Lth→Lin', 'Decae según curva CIE 88'],
          ['Interior', 'Longitud restante (si >0)', 'Lin (mínima constante)'],
          ['Salida (Exit)', '= SD/2 mínimo', 'Lin o Lnight'],
          ['Parting', '= SD (exterior)', 'L exterior natural'],
        ]
      }},

      { h2: 'Túnel corto (§6.4)' },
      { p: 'Un túnel se clasifica como "ópticamente corto" cuando la suma de las zonas umbral + transición + salida supera la longitud total. En este caso, la zona de transición se trunca o no aparece zona interior. STE gestiona automáticamente este caso.' },

      { h2: 'DALI IEC 62386' },
      { p: 'DALI (Digital Addressable Lighting Interface) es el protocolo estándar para la regulación digital de luminarias en instalaciones. Cada luminaria tiene una dirección de 0-63. Los grupos agrupan luminarias por función (umbral, transición, interior). Las escenas (0-15) definen el nivel de regulación (0-254 DALI = 0-100%) para cada momento del día.' },

      { h2: 'Ratio 3:1 entre escenas (§9.3)' },
      { p: 'CIE 88 §9.3 establece que la variación de luminancia entre dos escenas consecutivas no debe superar un ratio de 3:1 (es decir, la luminancia en ninguna zona debe caer más de 3 veces en un solo escalón). STE emite un aviso cuando este límite se supera en el plan de control.' },

      { h2: 'Uniformidades Uo, Ul y TI (no calculadas por STE)' },
      { p: 'La uniformidad general Uo (mín/media ≥ 0.40), la uniformidad longitudinal Ul (mín/máx ≥ 0.60) y el índice de deslumbramiento TI (≤ 15%) no pueden calcularse sin el archivo LDT de la luminaria y el cálculo fotométrico punto-a-punto. Estas verificaciones se realizan en el módulo fotométrico LuxStudio.' },
    ],
    en: [
      { h1: '💡 Key CIE 88:2004 Concepts' },

      { h2: 'L₂₀ — Adaptation field luminance' },
      { p: 'L₂₀ is the mean luminance of the visual field (20° half-angle cone) seen by the driver approaching the portal at stopping distance SD. It is the most critical input parameter: it directly determines Lth. STE can calculate it via an environment model (parameters: environment type, orientation, sky) or from the CIE 88 reference table.' },

      { h2: 'Lth — Threshold luminance' },
      { p: 'Lth is the minimum design luminance in the threshold zone. It ensures that the eye, adapted to the external level L₂₀, can detect obstacles. Lth = k · L₂₀, where k is the reduction factor (§14 table, function of speed, traffic volume and road coefficient qc).' },

      { h2: 'Lin — Interior luminance' },
      { p: 'Lin is the minimum luminance in the interior zone. It depends not on L₂₀ but on design speed and traffic volume. Typically Lin ≈ 2–10 cd/m².' },

      { h2: 'SD — Stopping distance' },
      { p: 'Total emergency stopping distance: SD = v·t_r + v²/(2a), with t_r=1.5 s (reaction time) and a=3.5 m/s² (deceleration). Determines the length of the threshold and access zones.' },

      { h2: 'k factor' },
      { p: 'Luminance reduction factor for the threshold zone. Depends on speed (higher speed → higher k), traffic (higher traffic → higher k) and road coefficient qc. Typical values: 0.035–0.10.' },

      { h2: 'Normative zones CIE 88' },
      { table: {
        heads: ['Zone', 'Length', 'Luminance level'],
        rows: [
          ['Access', '= SD (exterior)', 'L₂₀ (natural)'],
          ['Threshold', '= SD', 'Lth (maximum, zone start)'],
          ['Transition', 'Curve Lth→Lin', 'Decreases per CIE 88 curve'],
          ['Interior', 'Remaining length (if >0)', 'Lin (constant minimum)'],
          ['Exit', '≥ SD/2', 'Lin or Lnight'],
        ]
      }},

      { h2: 'Short tunnel (§6.4)' },
      { p: 'A tunnel is classified as "optically short" when the sum of threshold + transition + exit zones exceeds the total length. In this case the transition zone is truncated or no interior zone appears. STE handles this automatically.' },

      { h2: 'DALI IEC 62386' },
      { p: 'DALI (Digital Addressable Lighting Interface) is the standard protocol for digital dimming in lighting installations. Groups cluster luminaires by function (threshold, transition, interior). Scenes (0-15) define the dimming level (0-254 DALI = 0-100%) for each time of day.' },

      { h2: '3:1 ratio between scenes (§9.3)' },
      { p: 'CIE 88 §9.3 requires that the luminance change between two consecutive scenes must not exceed a ratio of 3:1. STE issues a warning when this limit is exceeded in the control plan.' },
    ],
    fr: [
      { h1: '💡 Concepts clés CIE 88:2004' },
      { h2: 'L₂₀ — Luminance du champ d\'adaptation' },
      { p: 'L₂₀ est la luminance moyenne du champ visuel (cône de 20° de demi-ouverture) vu par le conducteur s\'approchant du portail à une distance d\'arrêt SD. C\'est le paramètre d\'entrée le plus critique.' },
      { h2: 'Lth — Luminance de seuil' },
      { p: 'Lth est la luminance minimale de conception dans la zone de seuil : Lth = k · L₂₀. Elle garantit que l\'œil, adapté au niveau extérieur L₂₀, peut détecter les obstacles.' },
      { h2: 'Lin — Luminance intérieure' },
      { p: 'Lin est la luminance minimale dans la zone intérieure. Elle dépend de la vitesse de conception et du volume de trafic, typiquement 2-10 cd/m².' },
      { h2: 'SD — Distance d\'arrêt' },
      { p: 'Distance totale d\'arrêt d\'urgence : SD = v·t_r + v²/(2a), avec t_r=1.5 s et a=3.5 m/s².' },
      { h2: 'Zones normatives CIE 88' },
      { ul: ['Seuil (Threshold) : longueur = SD, niveau = Lth', 'Transition : de Lth à Lin selon courbe CIE 88', 'Intérieur : Lin constant', 'Sortie : Lin ou L_nuit'] },
      { h2: 'Rapport 3:1 entre scènes (§9.3)' },
      { p: 'La CIE 88 §9.3 exige que la variation de luminance entre deux scènes consécutives ne dépasse pas un rapport de 3:1. STE émet un avertissement si cette limite est dépassée.' },
    ],
    ca: [
      { h1: '💡 Conceptes clau CIE 88:2004' },
      { h2: 'L₂₀ — Lluminància del camp d\'adaptació' },
      { p: 'L₂₀ és la lluminància mitjana del camp visual (con de 20°) que el conductor veu en apropar-se al portal a una distància de parada SD. És el paràmetre d\'entrada més crític: determina directament Lth.' },
      { h2: 'Lth — Lluminància llindar' },
      { p: 'Lth = k · L₂₀. Garanteix que l\'ull, adaptat al nivell exterior L₂₀, pugui detectar obstacles.' },
      { h2: 'Lin — Lluminància interior' },
      { p: 'Lin és la lluminància mínima a la zona interior. Depèn de la velocitat i el volum de trànsit. Típicament Lin ≈ 2-10 cd/m².' },
      { h2: 'Ràtio 3:1 entre escenes (§9.3)' },
      { p: 'La CIE 88 §9.3 estableix que la variació de lluminància entre dues escenes consecutives no ha de superar un ràtio de 3:1. STE emet un avís quan es supera aquest límit.' },
    ],
    it: [
      { h1: '💡 Concetti chiave CIE 88:2004' },
      { h2: 'L₂₀ — Luminanza del campo di adattamento' },
      { p: 'L₂₀ è la luminanza media del campo visivo (cono di 20°) vista dal conducente avvicinandosi al portale alla distanza di arresto SD. È il parametro di ingresso più critico: determina direttamente Lth.' },
      { h2: 'Lth — Luminanza di soglia' },
      { p: 'Lth = k · L₂₀. Garantisce che l\'occhio, adattato al livello esterno L₂₀, possa rilevare ostacoli.' },
      { h2: 'Lin — Luminanza interna' },
      { p: 'Lin è la luminanza minima nella zona interna. Dipende dalla velocità e dal volume di traffico. Tipicamente Lin ≈ 2-10 cd/m².' },
      { h2: 'Rapporto 3:1 tra scene (§9.3)' },
      { p: 'La CIE 88 §9.3 stabilisce che la variazione di luminanza tra due scene consecutive non deve superare un rapporto di 3:1. STE emette un avviso quando questo limite viene superato.' },
    ],
  },

  // ── LIMITACIONES / LIMITATIONS ───────────────────────────────
  limits: {
    es: [
      { h1: '⚠️ Limitaciones actuales' },
      { p: 'STE v1.2 realiza el cálculo normativo CIE 88:2004 completo. Las siguientes funcionalidades no están disponibles en esta versión y se desarrollarán en próximas versiones:' },
      { h2: 'Cálculo fotométrico (requiere LDT)' },
      { ul: [
        'Uniformidad general Uo (≥ 0.40) — requiere distribución fotométrica de la luminaria',
        'Uniformidad longitudinal Ul (≥ 0.60) — requiere cálculo punto-a-punto',
        'Índice de deslumbramiento TI (≤ 15%) — requiere luminancia de velo',
        'Ratio de luminancia de paredes (≥ 0.60) — requiere LDT y geometría de paredes',
      ]},
      { warn: 'Estos criterios requieren el motor fotométrico LuxStudio con el archivo LDT real de la luminaria. La integración está pendiente del endpoint del servidor Imaginning.' },
      { h2: 'Otras limitaciones' },
      { ul: [
        'No se calcula la iluminancia de carretera exterior (pre-túnel)',
        'La curva de Lseq es una estimación; para mayor precisión usar medición fotométrica real del entorno',
        'El cálculo de luminarias es simplificado (luminancia media); no incluye uniformidad',
        'No se genera informe PDF directamente (solo Word y Excel)',
        'La ventana de apertura de portal (portal opening) no está modelizada',
        'No se incluyen escenarios de emergencia (iluminación de evacuación)',
      ]},
      { h2: 'Alcance geográfico' },
      { p: 'STE implementa la norma internacional CIE 88:2004, usada en Europa, América Latina y la mayoría de países de Asia. No implementa las normas AASHTO (USA), BS EN (UK específico) ni las normativas chinas GB/T.' },
      { tip: 'Para el cálculo de uniformidades y deslumbramiento, use el paso Luminarias para obtener el espaciado y luego cargue el proyecto en el módulo fotométrico LuxStudio.' },
    ],
    en: [
      { h1: '⚠️ Current Limitations' },
      { p: 'STE v1.2 performs the complete CIE 88:2004 normative calculation. The following features are not yet available and will be developed in future versions:' },
      { h2: 'Photometric calculation (requires LDT)' },
      { ul: [
        'Overall uniformity Uo (≥ 0.40) — requires luminaire photometric distribution',
        'Longitudinal uniformity Ul (≥ 0.60) — requires point-by-point calculation',
        'Glare index TI (≤ 15%) — requires veiling luminance',
        'Wall luminance ratio (≥ 0.60) — requires LDT and wall geometry',
      ]},
      { warn: 'These criteria require the LuxStudio photometric engine with the actual luminaire LDT file. Integration is pending the Imaginning server endpoint.' },
      { h2: 'Other limitations' },
      { ul: [
        'No exterior road illuminance calculation (pre-tunnel)',
        'Lseq curve is an estimate; for higher accuracy use real photometric measurement of the environment',
        'Luminaire calculation is simplified (average luminance); does not include uniformity',
        'No direct PDF report generation (only Word and Excel)',
        'Portal opening is not modelled',
        'Emergency/evacuation lighting scenarios are not included',
      ]},
    ],
    fr: [
      { h1: '⚠️ Limitations actuelles' },
      { ul: [
        'Uniformités Uo, Ul et éblouissement TI — nécessitent un fichier LDT',
        'Rapport de luminance des parois — nécessite le moteur photométrique LuxStudio',
        'Calcul de l\'illuminance de la chaussée extérieure',
        'Génération directe de rapport PDF',
        'Scénarios d\'éclairage d\'urgence/évacuation',
      ]},
      { warn: 'L\'intégration avec le serveur photométrique Imaginning (LuxStudio) est en cours de développement.' },
    ],
    ca: [
      { h1: '⚠️ Limitacions actuals' },
      { ul: [
        'Uniformitats Uo, Ul i enlluernament TI — requereixen arxiu LDT',
        'Ràtio de lluminància de parets — requereix el motor fotomètric LuxStudio',
        'Càlcul de la il·luminació exterior de carretera',
        'Generació directa d\'informe PDF',
        'Escenaris d\'il·luminació d\'emergència/evacuació',
      ]},
      { warn: 'La integració amb el servidor fotomètric Imaginning (LuxStudio) està en desenvolupament.' },
    ],
    it: [
      { h1: '⚠️ Limitazioni attuali' },
      { ul: [
        'Uniformità Uo, Ul e abbagliamento TI — richiedono file LDT',
        'Rapporto di luminanza delle pareti — richiede il motore fotometrico LuxStudio',
        'Calcolo dell\'illuminamento della carreggiata esterna',
        'Generazione diretta di rapporto PDF',
        'Scenari di illuminazione di emergenza/evacuazione',
      ]},
      { warn: 'L\'integrazione con il server fotometrico Imaginning (LuxStudio) è in fase di sviluppo.' },
    ],
  },

  // ── PREGUNTAS FRECUENTES / FAQ ───────────────────────────────
  faq: {
    es: [
      { h1: '❓ Preguntas frecuentes' },

      { h2: '¿Por qué no aparece zona interior en los resultados?' },
      { p: 'Si la suma de las zonas umbral + transición + salida supera la longitud del túnel, estamos ante un túnel "ópticamente corto" (§6.4). En este caso la zona de transición se trunca para que quepa en el túnel y no existe zona interior. STE lo indica con una advertencia y el badge "Ópticamente corto".' },

      { h2: '¿Qué significa "Lth < Lin"?' },
      { p: 'Ocurre cuando el nivel de umbral calculado (Lth = k·L₂₀) es menor que el interior (Lin). Normalmente indica L₂₀ muy bajo (túnel en zona cubierta o interior). STE ajusta automáticamente Lth = max(Lth, Lin×2) y emite una advertencia.' },

      { h2: '¿Cómo calculo un túnel bidireccional con dos tubos?' },
      { p: 'Pulsa "+ Tubo" en la barra de proyecto para añadir T2. STE copia el formulario de T1 con la orientación invertida (N→S, E→W, etc.). Cada tubo se calcula independientemente. La comparativa aparece automáticamente en el paso Resultados cuando ambos tubos tienen resultado.' },

      { h2: '¿Qué protocolo de control elegir, DALI o Smartec?' },
      { p: 'DALI (IEC 62386) es el estándar internacional, soportado por la mayoría de fabricantes. Smartec es el protocolo propietario de SALVI Lighting, con mayor granularidad de dirección (hasta 512 luminarias por bus) y funcionalidades avanzadas de diagnóstico. Para proyectos con luminarias SALVI se recomienda Smartec.' },

      { h2: '¿Qué es el ratio 3:1 y por qué recibo ese aviso?' },
      { p: 'CIE 88 §9.3 establece que la variación de luminancia entre dos escenas consecutivas no debe superar 3:1 (es decir, máximo triplicar o dividir por tres en un paso). STE analiza todos los pares de escenas en grupos de umbral y transición. El aviso indica qué par de escenas supera el límite y sugiere añadir una escena intermedia.' },

      { h2: '¿Por qué L₂₀ varía con la orientación?' },
      { p: 'L₂₀ depende de la luminancia del cielo y del entorno visible en el cono de 20° ante el portal. La orientación sur (S) recibe radiación solar directa en latitudes europeas → L₂₀ mayor. La norte (N) está en sombra → L₂₀ menor. Esto afecta directamente a Lth y al requerimiento total de instalación.' },

      { h2: '¿Puedo usar el proyecto guardado (.ste.json) en otra instalación?' },
      { p: 'Sí. El archivo .ste.json es portable y contiene todos los parámetros de todos los tubos. Al abrirlo en otra instalación de STE se cargan los formularios y se puede recalcular. Los resultados no se guardan (son recalculables en segundos).' },

      { h2: '¿STE calcula la iluminación de emergencia?' },
      { p: 'No en esta versión. La iluminación de emergencia/evacuación en túneles tiene requisitos específicos (EN 16276, EN 1838) y requerimientos de luminancia de paredes distintos. Está previsto para una versión futura.' },

      { h2: '¿Cómo se determina la longitud de la zona de transición?' },
      { p: 'La transición sigue la curva de la ecuación CIE 88: L(s) = Lin × (Lth/Lin)^((Ltr-s)/Ltr). La longitud Ltr es la distancia necesaria para que la curva caiga de Lth a Lin respetando el ratio 3:1 entre cada par de puntos a distancia SD. Si se usa perfil escalonado, Ltr = (n_steps - 1) × SD.' },
    ],
    en: [
      { h1: '❓ Frequently Asked Questions' },

      { h2: 'Why is there no interior zone in the results?' },
      { p: 'If the sum of threshold + transition + exit zones exceeds the tunnel length, it is an "optically short" tunnel (§6.4). The transition zone is truncated and there is no interior zone. STE indicates this with a warning and the "Optically short" badge.' },

      { h2: 'What does "Lth < Lin" mean?' },
      { p: 'This occurs when the calculated threshold level (Lth = k·L₂₀) is lower than the interior (Lin). It usually indicates a very low L₂₀ (tunnel in a covered or indoor area). STE automatically adjusts Lth = max(Lth, Lin×2) and issues a warning.' },

      { h2: 'How do I calculate a bidirectional tunnel with two tubes?' },
      { p: 'Click "+ Tube" in the project bar to add T2. STE copies the T1 form with inverted orientation (N→S, E→W, etc.). Each tube is calculated independently. The comparison table appears automatically in the Results step when both tubes have results.' },

      { h2: 'Which control protocol to choose, DALI or Smartec?' },
      { p: 'DALI (IEC 62386) is the international standard, supported by most manufacturers. Smartec is SALVI Lighting\'s proprietary protocol, with higher address granularity (up to 512 luminaires per bus) and advanced diagnostic features. For projects with SALVI luminaires, Smartec is recommended.' },

      { h2: 'What is the 3:1 ratio and why do I get that warning?' },
      { p: 'CIE 88 §9.3 requires that the luminance change between two consecutive scenes must not exceed 3:1. STE analyses all scene pairs in threshold and transition groups. The warning indicates which scene pair exceeds the limit and suggests adding an intermediate scene.' },

      { h2: 'Can I use the saved project (.ste.json) in another installation?' },
      { p: 'Yes. The .ste.json file is portable and contains all parameters for all tubes. When opened in another STE installation, the forms load and can be recalculated. Results are not saved (they recalculate in seconds).' },

      { h2: 'Does STE calculate emergency lighting?' },
      { p: 'Not in this version. Emergency/evacuation lighting in tunnels has specific requirements (EN 16276, EN 1838). Planned for a future version.' },
    ],
    fr: [
      { h1: '❓ Questions fréquentes' },
      { h2: 'Pourquoi n\'y a-t-il pas de zone intérieure ?' },
      { p: 'Si la somme des zones seuil + transition + sortie dépasse la longueur du tunnel, c\'est un tunnel « optiquement court » (§6.4). STE l\'indique avec un avertissement.' },
      { h2: 'Comment calculer un tunnel bidirectionnel à deux tubes ?' },
      { p: 'Cliquez sur « + Tube » dans la barre de projet pour ajouter T2. STE copie le formulaire T1 avec l\'orientation inversée. Chaque tube est calculé indépendamment.' },
      { h2: 'Quel protocole de contrôle choisir ?' },
      { p: 'DALI (IEC 62386) est le standard international. Smartec est le protocole propriétaire SALVI, recommandé pour les projets avec luminaires SALVI.' },
      { h2: 'Que signifie le rapport 3:1 ?' },
      { p: 'La CIE 88 §9.3 exige que la variation entre deux scènes consécutives ne dépasse pas 3:1. STE émet un avertissement et suggère d\'ajouter une scène intermédiaire.' },
    ],
    ca: [
      { h1: '❓ Preguntes freqüents' },
      { h2: 'Per què no apareix zona interior als resultats?' },
      { p: 'Si la suma de les zones llindar + transició + sortida supera la longitud del túnel, és un túnel "òpticament curt" (§6.4). STE ho indica amb un avís.' },
      { h2: 'Com calculo un túnel bidireccional amb dos tubs?' },
      { p: 'Premeu "+ Tub" a la barra de projecte per afegir T2. STE copia el formulari T1 amb l\'orientació invertida. Cada tub es calcula independentment.' },
      { h2: 'Quin protocol de control triar?' },
      { p: 'DALI (IEC 62386) és l\'estàndard internacional. Smartec és el protocol propi de SALVI, recomanat per a projectes amb lluminàries SALVI.' },
    ],
    it: [
      { h1: '❓ Domande frequenti' },
      { h2: 'Perché non appare la zona interna nei risultati?' },
      { p: 'Se la somma delle zone soglia + transizione + uscita supera la lunghezza della galleria, si tratta di una galleria "otticamente corta" (§6.4). STE lo segnala con un avviso.' },
      { h2: 'Come si calcola una galleria bidirezionale a due tubi?' },
      { p: 'Fare clic su "+ Tubo" nella barra del progetto per aggiungere T2. STE copia il modulo T1 con l\'orientamento invertito. Ogni tubo viene calcolato indipendentemente.' },
      { h2: 'Quale protocollo di controllo scegliere?' },
      { p: 'DALI (IEC 62386) è lo standard internazionale. Smartec è il protocollo proprietario SALVI, raccomandato per progetti con apparecchi SALVI.' },
    ],
  },

  // ── SALVI IA ─────────────────────────────────────────────────
  ai: {
    es: [
      { h1: '🤖 SALVI IA' },
      { p: 'SALVI IA es el asistente de inteligencia artificial integrado en el ecosistema LuxStudio. En el contexto de SALVI Tunnel Engine, la IA asistirá en las siguientes tareas:' },
      { h2: 'Funcionalidades previstas' },
      { ul: [
        'Recomendación de luminaria SALVI óptima por zona según los requerimientos de Lth y Lin calculados',
        'Análisis automático del plan de control: detección de ratios >3:1 y propuesta de escenas intermedias',
        'Generación de narrativa del informe técnico (texto explicativo de los resultados)',
        'Optimización del número de luminarias: ajuste automático de flujo y espaciado para minimizar potencia instalada',
        'Sugerencias basadas en proyectos similares del historial de LuxStudio',
        'Traducción automática del informe técnico entre los 5 idiomas soportados',
      ]},
      { h2: 'Estado actual' },
      { p: 'SALVI IA está en desarrollo activo. La primera funcionalidad disponible será la recomendación de luminaria, que consultará el catálogo SALVI filtrado por las necesidades fotométricas calculadas por STE.' },
      { tip: 'Cuando SALVI IA esté disponible, aparecerá el botón "✨ Recomendación IA" en el paso Luminarias.' },
      { h2: 'Privacidad y datos' },
      { p: 'Los datos de proyectos procesados por SALVI IA se utilizan únicamente para el servicio solicitado y no se almacenan en servidores de terceros. Los cálculos se realizan localmente en el servidor LuxStudio de tu organización.' },
    ],
    en: [
      { h1: '🤖 SALVI AI' },
      { p: 'SALVI AI is the artificial intelligence assistant integrated into the LuxStudio ecosystem. In the context of SALVI Tunnel Engine, AI will assist with the following tasks:' },
      { h2: 'Planned features' },
      { ul: [
        'Recommendation of the optimal SALVI luminaire per zone based on calculated Lth and Lin requirements',
        'Automatic control plan analysis: detection of >3:1 ratios and proposal of intermediate scenes',
        'Generation of technical report narrative (explanatory text for results)',
        'Luminaire number optimisation: automatic flux and spacing adjustment to minimise installed power',
        'Suggestions based on similar projects in LuxStudio history',
        'Automatic report translation between the 5 supported languages',
      ]},
      { h2: 'Current status' },
      { p: 'SALVI AI is under active development. The first available feature will be luminaire recommendation, which will query the SALVI catalogue filtered by the photometric requirements calculated by STE.' },
      { tip: 'When SALVI AI is available, the "✨ AI Recommendation" button will appear in the Luminaires step.' },
    ],
    fr: [
      { h1: '🤖 SALVI IA' },
      { p: 'SALVI IA est l\'assistant d\'intelligence artificielle intégré à l\'écosystème LuxStudio.' },
      { h2: 'Fonctionnalités prévues' },
      { ul: [
        'Recommandation du luminaire SALVI optimal par zone',
        'Analyse automatique du plan de contrôle',
        'Génération de la narration du rapport technique',
        'Optimisation du nombre de luminaires',
        'Traduction automatique du rapport dans les 5 langues supportées',
      ]},
      { tip: 'Lorsque SALVI IA sera disponible, le bouton « ✨ Recommandation IA » apparaîtra à l\'étape Luminaires.' },
    ],
    ca: [
      { h1: '🤖 SALVI IA' },
      { p: 'SALVI IA és l\'assistent d\'intel·ligència artificial integrat a l\'ecosistema LuxStudio.' },
      { h2: 'Funcionalitats previstes' },
      { ul: [
        'Recomanació de lluminària SALVI òptima per zona',
        'Anàlisi automàtica del pla de control',
        'Generació de la narrativa de l\'informe tècnic',
        'Optimització del nombre de lluminàries',
        'Traducció automàtica de l\'informe als 5 idiomes suportats',
      ]},
      { tip: 'Quan SALVI IA estigui disponible, apareixerà el botó "✨ Recomanació IA" al pas Lluminàries.' },
    ],
    it: [
      { h1: '🤖 SALVI IA' },
      { p: 'SALVI IA è l\'assistente di intelligenza artificiale integrato nell\'ecosistema LuxStudio.' },
      { h2: 'Funzionalità previste' },
      { ul: [
        'Raccomandazione dell\'apparecchio SALVI ottimale per zona',
        'Analisi automatica del piano di controllo',
        'Generazione della narrativa della relazione tecnica',
        'Ottimizzazione del numero di apparecchi',
        'Traduzione automatica del rapporto nelle 5 lingue supportate',
      ]},
      { tip: 'Quando SALVI IA sarà disponibile, il pulsante "✨ Raccomandazione IA" apparirà nel passo Lampade.' },
    ],
  },

  // ── ATAJOS / SHORTCUTS ───────────────────────────────────────
  shortcuts: {
    es: [
      { h1: '⌨️ Atajos y consejos' },
      { h2: 'Navegación del wizard' },
      { keys: [
        { k: 'Clic en paso',     d: 'Ir directamente a cualquier paso del wizard' },
        { k: '← Anterior',      d: 'Retroceder un paso' },
        { k: 'Siguiente →',     d: 'Avanzar al siguiente paso' },
        { k: '⚡ Calcular',      d: 'Ejecutar cálculo CIE 88:2004 completo' },
        { k: '🔄 Recalcular',    d: 'Volver a calcular con los parámetros actuales' },
      ]},
      { h2: 'Gestión del proyecto' },
      { keys: [
        { k: '💾 Guardar',       d: 'Descarga el proyecto como .ste.json' },
        { k: '📂 Abrir',         d: 'Carga un proyecto .ste.json guardado anteriormente' },
        { k: '🆕 Nuevo',         d: 'Crea un nuevo proyecto (pide confirmación si hay datos)' },
        { k: '+ Tubo',           d: 'Añade un nuevo tubo (hasta T4) con parámetros copiados de T1' },
        { k: '✕ (tubo)',         d: 'Elimina el tubo activo (requiere confirmación)' },
      ]},
      { h2: 'Plan de control' },
      { keys: [
        { k: 'Exportar JSON',    d: 'Descarga el plan de control completo en formato JSON' },
        { k: 'Exportar CSV',     d: 'Descarga el plan de control en formato CSV (Excel-compatible)' },
      ]},
      { h2: 'Informes' },
      { keys: [
        { k: '⬇️ Word',          d: 'Genera informe técnico .docx del tubo activo' },
        { k: '📊 Excel',         d: 'Genera libro .xlsx del tubo activo (6 hojas)' },
        { k: '📑 Word (T1+T2)',  d: 'Genera informe combinado multi-tubo (solo si ≥2 tubos calculados)' },
        { k: '📊 Excel (T1+T2)', d: 'Genera libro Excel combinado multi-tubo' },
      ]},
      { h2: 'Consejos de productividad' },
      { ul: [
        'Guarda el proyecto antes de hacer cambios importantes — los resultados no se guardan, solo los parámetros',
        'Para túneles bidireccionales, calcula T1 primero y luego añade T2 (heredará automáticamente los parámetros)',
        'El perfil escalonado es más fácil de implementar en obra pero puede requerir más escenas en el plan de control',
        'El método "Lseq" para Lth es más conservador que el método k; usa k-factor para cálculo estándar CIE 88',
        'Para el cálculo de luminarias, introduce el flujo del archivo LDT de la luminaria, no el flujo de la fuente de luz',
      ]},
    ],
    en: [
      { h1: '⌨️ Shortcuts & Tips' },
      { h2: 'Wizard navigation' },
      { keys: [
        { k: 'Click on step',    d: 'Jump directly to any wizard step' },
        { k: '← Back',          d: 'Go back one step' },
        { k: 'Next →',          d: 'Advance to next step' },
        { k: '⚡ Calculate',     d: 'Run full CIE 88:2004 calculation' },
        { k: '🔄 Recalculate',   d: 'Recalculate with current parameters' },
      ]},
      { h2: 'Project management' },
      { keys: [
        { k: '💾 Save',          d: 'Download project as .ste.json' },
        { k: '📂 Open',          d: 'Load a previously saved .ste.json project' },
        { k: '🆕 New',           d: 'Create a new project (asks confirmation if data exists)' },
        { k: '+ Tube',           d: 'Add a new tube (up to T4) with parameters copied from T1' },
        { k: '✕ (tube)',         d: 'Delete active tube (requires confirmation)' },
      ]},
      { h2: 'Reports' },
      { keys: [
        { k: '⬇️ Word',          d: 'Generate .docx technical report for active tube' },
        { k: '📊 Excel',         d: 'Generate .xlsx workbook for active tube (6 sheets)' },
        { k: '📑 Word (T1+T2)',  d: 'Generate combined multi-tube report (only if ≥2 tubes calculated)' },
      ]},
      { h2: 'Productivity tips' },
      { ul: [
        'Save the project before making important changes — results are not saved, only parameters',
        'For bidirectional tunnels, calculate T1 first then add T2 (it will automatically inherit parameters)',
        'The k-factor method for Lth is the standard CIE 88 method; use it for most projects',
        'For luminaire calculation, enter the flux from the luminaire LDT file, not the light source flux',
      ]},
    ],
    fr: [
      { h1: '⌨️ Raccourcis et conseils' },
      { h2: 'Navigation du wizard' },
      { keys: [
        { k: 'Clic sur étape',   d: 'Aller directement à n\'importe quelle étape' },
        { k: '💾 Sauvegarder',   d: 'Télécharger le projet en .ste.json' },
        { k: '⚡ Calculer',      d: 'Exécuter le calcul complet CIE 88:2004' },
        { k: '+ Tube',           d: 'Ajouter un tube (jusqu\'à T4)' },
      ]},
      { h2: 'Conseils' },
      { ul: [
        'Sauvegardez le projet avant de faire des modifications importantes',
        'Pour les tunnels bidirectionnels, calculez T1 d\'abord, puis ajoutez T2',
        'La méthode facteur k est la méthode standard CIE 88 recommandée',
      ]},
    ],
    ca: [
      { h1: '⌨️ Dreceres i consells' },
      { h2: 'Navegació del wizard' },
      { keys: [
        { k: 'Clic al pas',      d: 'Anar directament a qualsevol pas' },
        { k: '💾 Guardar',       d: 'Descarregar el projecte com a .ste.json' },
        { k: '⚡ Calcular',      d: 'Executar el càlcul complet CIE 88:2004' },
        { k: '+ Tub',            d: 'Afegir un nou tub (fins a T4)' },
      ]},
      { h2: 'Consells' },
      { ul: [
        'Guardeu el projecte abans de fer canvis importants',
        'Per a túnels bidireccionals, calculeu T1 primer i afegiu T2 a continuació',
        'El mètode factor k és el mètode estàndard CIE 88 recomanat',
      ]},
    ],
    it: [
      { h1: '⌨️ Scorciatoie e suggerimenti' },
      { h2: 'Navigazione del wizard' },
      { keys: [
        { k: 'Clic su passo',    d: 'Andare direttamente a qualsiasi passo' },
        { k: '💾 Salva',         d: 'Scarica il progetto come .ste.json' },
        { k: '⚡ Calcola',       d: 'Esegui il calcolo completo CIE 88:2004' },
        { k: '+ Tubo',           d: 'Aggiunge un nuovo tubo (fino a T4)' },
      ]},
      { h2: 'Suggerimenti' },
      { ul: [
        'Salvate il progetto prima di apportare modifiche importanti',
        'Per le gallerie bidirezionali, calcolare prima T1 e poi aggiungere T2',
        'Il metodo fattore k è il metodo standard CIE 88 raccomandato',
      ]},
    ],
  },

}; // end window.STE_HELP_DATA
