"""
SALVI Tunnel Engine — Generador de Informe Técnico Word
Produce un .docx con el resultado completo del cálculo CIE 88:2004.
Requiere: python-docx
"""

import io
import datetime
from typing import Any, Optional

from docx import Document
from docx.shared import Pt, Cm, RGBColor, Inches
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.oxml.ns import qn
from docx.oxml import OxmlElement


# ══════════════════════════════════════════════════════════════════
# CONSTANTES DE ESTILO
# ══════════════════════════════════════════════════════════════════

BLUE_DARK   = "1A3A6B"   # Cabeceras principales
BLUE_MED    = "1A56B0"   # Cabeceras de tabla
BLUE_LIGHT  = "D5E8F5"   # Filas alternas de tabla
BLUE_BRAND  = "0066CC"   # Textos destacados
GRAY_LIGHT  = "F5F5F5"   # Fondo alternativo gris
WHITE       = "FFFFFF"
BLACK       = "000000"


# ══════════════════════════════════════════════════════════════════
# UTILIDADES DOCX
# ══════════════════════════════════════════════════════════════════

def _set_cell_bg(cell, hex_color: str) -> None:
    """Establece el color de fondo de una celda."""
    tc = cell._tc
    tcPr = tc.get_or_add_tcPr()
    shd = OxmlElement('w:shd')
    shd.set(qn('w:val'), 'clear')
    shd.set(qn('w:color'), 'auto')
    shd.set(qn('w:fill'), hex_color)
    # Remove existing shd if present
    existing = tcPr.find(qn('w:shd'))
    if existing is not None:
        tcPr.remove(existing)
    tcPr.append(shd)


def _cell_text(cell, text: str, bold: bool = False, color: str = None,
               size_pt: float = 9.5, align=WD_ALIGN_PARAGRAPH.LEFT) -> None:
    """Escribe texto en una celda con formato."""
    cell.text = ""
    p = cell.paragraphs[0]
    p.alignment = align
    run = p.add_run(str(text))
    run.bold = bold
    run.font.size = Pt(size_pt)
    if color:
        run.font.color.rgb = RGBColor.from_string(color)


def _add_separator(doc: Document, color: str = BLUE_MED) -> None:
    """Línea horizontal separadora."""
    p = doc.add_paragraph()
    p.paragraph_format.space_before = Pt(4)
    p.paragraph_format.space_after = Pt(4)
    pPr = p._p.get_or_add_pPr()
    pBdr = OxmlElement('w:pBdr')
    bottom = OxmlElement('w:bottom')
    bottom.set(qn('w:val'), 'single')
    bottom.set(qn('w:sz'), '8')
    bottom.set(qn('w:space'), '1')
    bottom.set(qn('w:color'), color)
    pBdr.append(bottom)
    pPr.append(pBdr)


def _section_heading(doc: Document, title: str, level: int = 1) -> None:
    """Encabezado de sección con estilo SALVI."""
    p = doc.add_paragraph()
    p.paragraph_format.space_before = Pt(14 if level == 1 else 8)
    p.paragraph_format.space_after = Pt(4)
    run = p.add_run(title)
    run.bold = True
    run.font.size = Pt(12 if level == 1 else 10.5)
    run.font.color.rgb = RGBColor.from_string(BLUE_DARK if level == 1 else BLUE_MED)
    _add_separator(doc, BLUE_DARK if level == 1 else BLUE_MED)


def _kv_table(doc: Document, rows: list, col_widths=(5.5, 8.5)) -> None:
    """Tabla de dos columnas clave→valor."""
    table = doc.add_table(rows=len(rows), cols=2)
    table.style = 'Table Grid'
    for i, (key, val) in enumerate(rows):
        bg = GRAY_LIGHT if i % 2 == 0 else WHITE
        c0, c1 = table.rows[i].cells
        _set_cell_bg(c0, bg)
        _set_cell_bg(c1, bg)
        _cell_text(c0, key, bold=True, size_pt=9)
        _cell_text(c1, str(val), size_pt=9)
        # Column widths
        c0.width = Cm(col_widths[0])
        c1.width = Cm(col_widths[1])


def _header_row(row, headers: list, bg: str = BLUE_MED) -> None:
    """Fila de cabecera de tabla (fondo azul, texto blanco)."""
    trPr = row._tr.get_or_add_trPr()
    repeat = OxmlElement('w:tblHeader')
    repeat.set(qn('w:val'), 'true')
    trPr.append(repeat)
    for cell, h in zip(row.cells, headers):
        _set_cell_bg(cell, bg)
        _cell_text(cell, h, bold=True, color=WHITE,
                   size_pt=8.5, align=WD_ALIGN_PARAGRAPH.CENTER)


def _set_page_margins(doc: Document,
                      top=2.0, bottom=2.0, left=2.5, right=2.0) -> None:
    for section in doc.sections:
        section.top_margin    = Cm(top)
        section.bottom_margin = Cm(bottom)
        section.left_margin   = Cm(left)
        section.right_margin  = Cm(right)


def _add_page_break(doc: Document) -> None:
    p = doc.add_paragraph()
    run = p.add_run()
    run.add_break(__import__('docx.enum.text', fromlist=['WD_BREAK']).WD_BREAK.PAGE)


# ══════════════════════════════════════════════════════════════════
# PORTADA
# ══════════════════════════════════════════════════════════════════

def _build_cover(doc: Document, result: dict, params: dict) -> None:
    summary        = result.get('summary', {})
    classification = result.get('classification', {})

    # Cabecera azul
    p = doc.add_paragraph()
    p.paragraph_format.space_before = Pt(0)
    p.paragraph_format.space_after = Pt(0)
    run = p.add_run("SALVI TUNNEL ENGINE")
    run.bold = True
    run.font.size = Pt(22)
    run.font.color.rgb = RGBColor.from_string(BLUE_DARK)

    p2 = doc.add_paragraph()
    p2.paragraph_format.space_before = Pt(2)
    p2.paragraph_format.space_after = Pt(2)
    run2 = p2.add_run("Informe Técnico de Iluminación de Túneles")
    run2.font.size = Pt(14)
    run2.font.color.rgb = RGBColor.from_string(BLUE_MED)

    _add_separator(doc, BLUE_DARK)

    # Subtítulo norma
    p3 = doc.add_paragraph()
    p3.paragraph_format.space_before = Pt(4)
    r3 = p3.add_run("Norma: CIE 88:2004 — Guide for the Lighting of Road Tunnels and Underpasses")
    r3.italic = True
    r3.font.size = Pt(9.5)
    r3.font.color.rgb = RGBColor.from_string("555555")

    doc.add_paragraph()  # Espacio

    # Tabla de proyecto
    table = doc.add_table(rows=8, cols=2)
    table.style = 'Table Grid'
    fields = [
        ("Proyecto",              summary.get('project', params.get('project_name', '—'))),
        ("Tubo",                  summary.get('tube_id', '—')),
        ("Longitud total",        f"{summary.get('length_m', '—')} m"),
        ("Velocidad de diseño",   f"{summary.get('speed_kmh', '—')} km/h"),
        ("Tráfico de diseño",     f"{params.get('traffic_veh_h', '—')} veh/h"),
        ("Clasificación óptica",  classification.get('optical', '—').replace('_', ' ')),
        ("Iluminación diurna",    classification.get('daylighting', '—')),
        ("Fecha del informe",     datetime.date.today().strftime("%d/%m/%Y")),
    ]
    for i, (k, v) in enumerate(fields):
        bg = BLUE_LIGHT if i % 2 == 0 else WHITE
        c0, c1 = table.rows[i].cells
        _set_cell_bg(c0, bg)
        _set_cell_bg(c1, bg)
        _cell_text(c0, k, bold=True, size_pt=10)
        _cell_text(c1, str(v), size_pt=10)
        c0.width = Cm(6)
        c1.width = Cm(8)

    doc.add_paragraph()
    p_note = doc.add_paragraph()
    rn = p_note.add_run(
        "Redactado con SALVI Tunnel Engine (STE) — Motor de cálculo conforme a CIE 88:2004."
    )
    rn.font.size = Pt(8)
    rn.font.color.rgb = RGBColor.from_string("888888")
    rn.italic = True


# ══════════════════════════════════════════════════════════════════
# SECCIONES DEL INFORME
# ══════════════════════════════════════════════════════════════════

def _build_classification(doc: Document, result: dict,
                          title: str = "1. Clasificación del Túnel (CIE 88:2004 §6)") -> None:
    cls   = result.get('classification', {})
    speed = result.get('speed', {})
    _section_heading(doc, title)

    _kv_table(doc, [
        ("Clasificación geométrica",    cls.get('geometric', '—').replace('_', ' ')),
        ("Clasificación óptica",        cls.get('optical', '—').replace('_', ' ')),
        ("Necesidad de ilum. diurna",   cls.get('daylighting', '—')),
        ("Distancia de parada (SD)",    f"{speed.get('SD_m', '—')} m"),
        ("Distancia de reacción (dr)",  f"{speed.get('d_reaction_m', '—')} m"),
        ("Distancia de frenado (df)",   f"{speed.get('d_braking_m', '—')} m"),
    ])

    if cls.get('justification'):
        p = doc.add_paragraph()
        p.paragraph_format.space_before = Pt(6)
        run = p.add_run("Justificación: ")
        run.bold = True
        run.font.size = Pt(9)
        p.add_run(cls['justification']).font.size = Pt(9)


def _build_luminances(doc: Document, result: dict,
                      title: str = "2. Luminancias de Diseño (CIE 88:2004 §12–16)") -> None:
    s   = result.get('summary', {})
    l20 = result.get('l20', {})
    lth = result.get('lth', {})

    _section_heading(doc, title)

    _kv_table(doc, [
        ("L₂₀ — Luminancia campo 20°",     f"{s.get('L20', '—')} cd/m²"),
        ("Método de cálculo L₂₀",          l20.get('method', '—')),
        ("Confianza del valor L₂₀",         l20.get('confidence', '—')),
        ("Lth — Luminancia de umbral",      f"{s.get('Lth', '—')} cd/m²"),
        ("Factor k (Lth = k · L₂₀)",       s.get('k_factor', '—')),
        ("Coef. revelación contraste qc",   s.get('qc', '—')),
        ("Lseq — Luminancia equivalente",   f"{s.get('Lseq', '—')} cd/m²"),
        ("Lin — Luminancia interior",       f"{s.get('Lin', '—')} cd/m²"),
        (
            "L_noche normal",
            f"{s.get('L_night_normal', s.get('Lin', '—'))} cd/m²",
        ),
        (
            "L_noche reducida",
            f"{s.get('L_night_reduced', s.get('L_night', '—'))} cd/m²",
        ),
    ])

    if l20.get('note'):
        p = doc.add_paragraph()
        p.paragraph_format.space_before = Pt(4)
        r = p.add_run(f"Nota L₂₀: {l20['note']}")
        r.italic = True
        r.font.size = Pt(8.5)
        r.font.color.rgb = RGBColor.from_string("666666")


def _build_zones(doc: Document, result: dict,
                 title: str = "3. Zonas Normativas CIE 88:2004") -> None:
    zones_raw = result.get('zones', {})
    _section_heading(doc, title)

    # Extraer lista de zonas del dict
    zones_list = []
    if isinstance(zones_raw, dict):
        # Puede venir como {threshold: {...}, transition: {...}, ...}
        # o como {zones: [...]}
        if 'zones' in zones_raw:
            zones_list = zones_raw['zones']
        else:
            for key, val in zones_raw.items():
                if isinstance(val, dict) and 's_start' in val:
                    zones_list.append(val)
    elif isinstance(zones_raw, list):
        zones_list = zones_raw

    if not zones_list:
        doc.add_paragraph("(Datos de zonas no disponibles)")
        return

    headers = ["Zona", "s inicio (m)", "s fin (m)", "Longitud (m)",
               "L inicio (cd/m²)", "L fin (cd/m²)", "L mín. req. (cd/m²)"]
    col_widths_cm = [3.0, 2.2, 2.2, 2.3, 2.8, 2.8, 3.2]

    table = doc.add_table(rows=1 + len(zones_list), cols=len(headers))
    table.style = 'Table Grid'
    _header_row(table.rows[0], headers)
    for j, w in enumerate(col_widths_cm):
        table.rows[0].cells[j].width = Cm(w)

    ZONE_BG = {
        'threshold':  'FFF3CD',
        'transition': 'CFF4FC',
        'interior':   'D1E7DD',
        'exit':       'E2D9F3',
        'access':     'F8D7DA',
        'parting':    'F8D7DA',
    }

    for i, z in enumerate(zones_list):
        row = table.rows[i + 1]
        zone_type = str(z.get('zone_type', z.get('type', '—'))).lower()
        bg = ZONE_BG.get(zone_type, WHITE)
        values = [
            _zone_label_es(zone_type),
            f"{z.get('s_start', 0):.1f}",
            f"{z.get('s_end', 0):.1f}",
            f"{z.get('length', z.get('s_end', 0) - z.get('s_start', 0)):.1f}",
            f"{z.get('L_start', z.get('L_min_required', 0)):.2f}",
            f"{z.get('L_end', z.get('L_min_required', 0)):.2f}",
            f"{z.get('L_min_required', 0):.2f}",
        ]
        for j, (cell, val) in enumerate(zip(row.cells, values)):
            _set_cell_bg(cell, bg)
            bold = (j == 3 or j == 6)
            _cell_text(cell, val, bold=bold, size_pt=9,
                       align=WD_ALIGN_PARAGRAPH.CENTER if j > 0 else WD_ALIGN_PARAGRAPH.LEFT)
            cell.width = Cm(col_widths_cm[j])


def _build_control(doc: Document, result: dict,
                   title: str = "4. Plan de Control (CIE 88:2004 §87–111)") -> None:
    control = result.get('control')
    if not control:
        return

    _section_heading(doc, title)

    groups = control.get('groups', [])
    scenes = control.get('scenes', [])
    protocol = control.get('protocol', 'DALI')

    if not groups or not scenes:
        doc.add_paragraph("(Plan de control no disponible)")
        return

    # Info del plan
    _kv_table(doc, [
        ("Protocolo de control", protocol),
        ("Nº de grupos",         control.get('n_groups', len(groups))),
        ("Nº de escenas",        control.get('n_scenes', len(scenes))),
    ], col_widths=(5.5, 4.0))

    doc.add_paragraph()

    _section_heading(doc, "Tabla de Regulación (grupos × escenas)", level=2)

    # Columnas: Grupo | L diseño | Escena1 | Escena2 | ...
    n_cols = 2 + len(scenes)
    headers = ["Grupo", "L diseño\n(cd/m²)"] + [
        f"{s['name']}\nL₂₀={s['L20']:.0f}" for s in scenes
    ]

    table = doc.add_table(rows=1 + len(groups), cols=n_cols)
    table.style = 'Table Grid'
    _header_row(table.rows[0], headers)

    # Anchos de columna
    col_w = [5.0, 2.0] + [2.0] * len(scenes)
    for j, w in enumerate(col_w):
        table.rows[0].cells[j].width = Cm(w)

    # Colores de escena
    SCENE_BG = {
        'sunny':    'FFFDE7',
        'normal':   'F5F5F5',
        'overcast': 'ECEFF1',
        'dusk':     'FCE4EC',
        'night':    'E8EAF6',
    }

    ZONE_BG = {
        'threshold':  'FFF3CD',
        'transition': 'CFF4FC',
        'interior':   'D1E7DD',
        'exit':       'E2D9F3',
    }

    for i, g in enumerate(groups):
        row = table.rows[i + 1]
        zone_type = g.get('zone_type', '').lower()
        zone_bg = ZONE_BG.get(zone_type, WHITE)

        # Nombre del grupo
        _set_cell_bg(row.cells[0], zone_bg)
        _cell_text(row.cells[0], g['name'], bold=True, size_pt=8.5)
        row.cells[0].width = Cm(col_w[0])

        # L diseño
        _set_cell_bg(row.cells[1], zone_bg)
        _cell_text(row.cells[1], str(g.get('L_design', '—')),
                   bold=True, color=BLUE_BRAND, size_pt=9,
                   align=WD_ALIGN_PARAGRAPH.CENTER)
        row.cells[1].width = Cm(col_w[1])

        # Niveles por escena
        for j, scene in enumerate(scenes):
            sid  = str(scene['scene_id'])
            pct  = g.get('dimming_levels', {}).get(sid, '—')
            dali = g.get('dali_levels', {}).get(sid, '')
            scene_bg = SCENE_BG.get(scene.get('scene_type', ''), WHITE)

            cell = row.cells[2 + j]
            _set_cell_bg(cell, scene_bg)
            cell.width = Cm(col_w[2 + j])

            # Pct en bold + DALI level pequeño debajo
            cell.text = ""
            p = cell.paragraphs[0]
            p.alignment = WD_ALIGN_PARAGRAPH.CENTER
            r1 = p.add_run(f"{pct}%")
            r1.bold = True
            r1.font.size = Pt(9)
            r1.font.color.rgb = RGBColor.from_string(BLUE_DARK)
            if protocol == 'DALI' and dali:
                r2 = p.add_run(f"\nDALI {dali}")
                r2.font.size = Pt(7.5)
                r2.font.color.rgb = RGBColor.from_string("666666")

    p_note = doc.add_paragraph()
    p_note.paragraph_format.space_before = Pt(4)
    rn = p_note.add_run(
        "CTH=Umbral · CTRn=Transición · CIN=Interior · CEX=Salida. "
        "Niveles DALI según IEC 62386 (curva logarítmica, rango 0–254)."
    )
    rn.italic = True
    rn.font.size = Pt(8)
    rn.font.color.rgb = RGBColor.from_string("666666")
    emergency = doc.add_paragraph()
    emergency.paragraph_format.space_before = Pt(2)
    er = emergency.add_run(
        "Emergencia: la escena de evacuación y el alumbrado de seguridad se verifican "
        "en el proyecto eléctrico específico; no se infieren de los niveles de regulación ordinaria."
    )
    er.font.size = Pt(8)
    er.font.color.rgb = RGBColor.from_string("666666")


def _as_luminaire_dict(luminaire: Any) -> dict:
    """Normaliza el resultado de diseño para que el informe no dependa de su clase."""
    if not luminaire:
        return {}
    if isinstance(luminaire, dict):
        return luminaire
    to_dict = getattr(luminaire, "to_dict", None)
    if callable(to_dict):
        return to_dict()
    return {}


def _humanize(value: Any) -> str:
    """Hace legibles valores de enumeraciones y claves internas."""
    if value in (None, ""):
        return "—"
    return str(value).replace("_", " ").replace("-", " ").strip().title()


def _zone_label_es(zone_type: Any, fallback: Any = None) -> str:
    """Etiqueta corta en español para planos y tablas de informe."""
    labels = {
        "threshold": "Umbral A", "threshold_b": "Umbral B",
        "transition": "Transición A", "transition_b": "Transición B",
        "interior": "Interior", "interior_base": "Base interior",
        "exit": "Salida", "access": "Acceso", "parting": "Partida",
    }
    value = str(zone_type or "").lower()
    return labels.get(value, str(fallback or _humanize(value)))


def _report_status(result: dict, photometric: dict = None) -> tuple[str, str]:
    """Estado único de lectura rápida; nunca declara conformidad sin CIE 140."""
    profile_ok = bool((result.get("validation") or {}).get("valid"))
    ph = photometric or {}
    if not ph.get("available"):
        return (
            "PENDIENTE DE VERIFICACIÓN FOTOMÉTRICA",
            "El perfil CIE 88 es válido, pero falta la comprobación CIE 140 con la fotometría LDT.",
        ) if profile_ok else (
            "REVISAR",
            "El perfil normativo contiene advertencias o incumplimientos que deben resolverse.",
        )
    if profile_ok and ph.get("overall_compliant"):
        return (
            "CONFORME",
            "Se cumplen el perfil CIE 88 y los criterios CIE 140 de todas las zonas verificadas.",
        )
    return (
        "REVISAR",
        "Existe al menos un criterio de perfil o de calidad fotométrica que no cumple.",
    )


def _build_executive_summary(doc: Document, result: dict,
                             photometric: dict = None,
                             luminaire: Any = None) -> None:
    """Primera página técnica: permite validar el caso sin recorrer los anexos."""
    summary = result.get("summary", {})
    lth = result.get("lth", {})
    lum = _as_luminaire_dict(luminaire)
    status, explanation = _report_status(result, photometric)
    status_color = "1A7A3C" if status == "CONFORME" else (
        "B26A00" if status.startswith("PENDIENTE") else "C0392B"
    )

    _section_heading(doc, "1. Resumen de Validación")
    banner = doc.add_table(rows=1, cols=1)
    banner.style = "Table Grid"
    _set_cell_bg(banner.cell(0, 0), "E8F5E9" if status == "CONFORME" else "FFF4E5")
    _cell_text(
        banner.cell(0, 0),
        f"{status} — {explanation}",
        bold=True,
        color=status_color,
        size_pt=10,
        align=WD_ALIGN_PARAGRAPH.CENTER,
    )

    rows = [
        ("Tubo / longitud", f"{summary.get('tube_id', '—')}  /  {summary.get('length_m', '—')} m"),
        ("Condición de diseño", f"{summary.get('speed_kmh', '—')} km/h · SD {summary.get('SD_m', '—')} m"),
        ("Portal A", f"L20 {summary.get('L20', '—')} cd/m² · Lth {summary.get('Lth', '—')} cd/m²"),
        ("Portal B", f"L20 {lth.get('L20_b', '—')} cd/m² · Lth {lth.get('Lth_b', '—')} cd/m²"),
        (
            "Interior / noche",
            f"Lin {summary.get('Lin', '—')} cd/m² · "
            f"noche normal "
            f"{summary.get('L_night_normal', summary.get('Lin', '—'))} cd/m² · "
            f"noche reducida "
            f"{summary.get('L_night_reduced', summary.get('L_night', '—'))} cd/m²",
        ),
    ]
    totals = lum.get("totals", {})
    if totals:
        rows.append((
            "Instalación calculada",
            f"{totals.get('n_luminaires', '—')} luminarias · {totals.get('power_kw', '—')} kW instalados",
        ))
    _kv_table(doc, rows)

    warnings = list(result.get("warnings") or [])
    warnings.extend(lum.get("warnings") or [])
    if warnings:
        p = doc.add_paragraph()
        p.paragraph_format.space_before = Pt(5)
        run = p.add_run("Condicionantes: ")
        run.bold = True
        run.font.size = Pt(8.5)
        detail = p.add_run(" · ".join(str(item) for item in warnings[:3]))
        detail.font.size = Pt(8.5)
        detail.font.color.rgb = RGBColor.from_string("9A4B00")


def _build_design_inputs(doc: Document, result: dict, params: dict,
                         luminaire: Any = None) -> None:
    """Datos de partida que un revisor debe localizar antes de validar resultados."""
    summary = result.get("summary", {})
    speed = result.get("speed", {})
    lth = result.get("lth", {})
    lum = _as_luminaire_dict(luminaire)

    _section_heading(doc, "2. Datos de Partida y Alcance")
    _section_heading(doc, "Geometría, tráfico y explotación", level=2)
    _kv_table(doc, [
        ("Longitud del tubo", f"{summary.get('length_m', params.get('length_m', '—'))} m"),
        ("Calzada", f"{params.get('width_m', params.get('road_width_m', '—'))} m · {params.get('num_lanes', '—')} carriles de {params.get('lane_width_m', '—')} m"),
        ("Sección / altura", f"{_humanize(params.get('tunnel_shape'))} · {params.get('height_m', '—')} m"),
        ("Circulación", _humanize(params.get('traffic_direction'))),
        ("Velocidad / distancia de parada", f"{summary.get('speed_kmh', '—')} km/h · {speed.get('SD_m', summary.get('SD_m', '—'))} m"),
        ("Pendiente / fricción", f"{params.get('gradient_pct', 0)} % · μ={speed.get('friction_coefficient', '—')}"),
        ("Tráfico de proyecto", f"{params.get('traffic_veh_h', '—')} veh/h"),
        ("Pavimento", _humanize((lum.get('road_surface') or {}).get('label') or params.get('road_surface'))),
    ])

    _section_heading(doc, "Entorno y parámetros luminotécnicos", level=2)
    rows = [
        ("Método L20 / entorno", f"{_humanize(params.get('l20_method'))} · {_humanize(params.get('environment_type'))}"),
        ("Orientación / cielo", f"{params.get('portal_orientation', '—')} · {_humanize(params.get('sky_condition'))}"),
        ("Portal A: L20 / Lth", f"{summary.get('L20', '—')} / {summary.get('Lth', '—')} cd/m²"),
        ("Portal B: L20 / Lth", f"{lth.get('L20_b', '—')} / {lth.get('Lth_b', '—')} cd/m²"),
        ("Factor de mantenimiento", str((lum.get('luminaire') or {}).get('maintenance_factor', params.get('maintenance_factor', '—')))),
        ("Reflectancias", f"Paredes ρ={params.get('rho_wall', params.get('wall_reflectance', '—'))} · Techo ρ={params.get('rho_ceiling', params.get('ceiling_reflectance', '—'))}"),
    ]
    _kv_table(doc, rows)


def _build_methodology(doc: Document, result: dict, photometric: dict = None) -> None:
    """Explicación trazable pero deliberadamente breve de la metodología."""
    _section_heading(doc, "3. Criterios y Metodología")
    paragraphs = [
        "La luminancia de adaptación se determina para cada portal con el método L20. A partir de ella se obtiene la luminancia de umbral y el perfil longitudinal exigido según CIE 88:2004.",
        "El tubo se divide en zonas de umbral, transición e interior. Cuando hay circulación bidireccional, ambos portales se calculan de forma independiente y se conserva el caso más desfavorable en cada comprobación.",
        "La instalación se dimensiona con los ficheros fotométricos de las luminarias. La verificación se realiza sobre campos bidimensionales CIE 140:2019: luminancia media, uniformidad general U0, uniformidad longitudinal Ul e incremento de umbral TI.",
    ]
    if (photometric or {}).get("radiosity", {}).get("enabled"):
        paragraphs.append(
            "La comprobación incorpora radiosidad difusa de paredes y techo con las reflectancias indicadas en los datos de partida."
        )
    for item in paragraphs:
        p = doc.add_paragraph(style="List Bullet")
        run = p.add_run(item)
        run.font.size = Pt(9)

    # Una sola figura de lectura, para explicar el hilo completo sin convertir
    # la memoria en un manual docente ni repetir la metodología por zona.
    try:
        import matplotlib
        matplotlib.use("Agg")
        import matplotlib.pyplot as plt
        from matplotlib.patches import FancyBboxPatch

        figure, axis = plt.subplots(figsize=(8.2, 2.05))
        axis.set_xlim(0, 10)
        axis.set_ylim(0, 2)
        axis.axis("off")
        steps = [
            (0.15, "Portal / L20", "campo visual exterior"),
            (2.15, "Lth", "umbral CIE 88"),
            (4.15, "Zonas", "umbral - transición - interior"),
            (6.65, "Luminarias", "LDT + implantación"),
            (8.55, "CIE 140", "Lavg · U0 · Ul · TI"),
        ]
        colors = ["#EAF1FB", "#FFF3CD", "#E0F2FE", "#F3E8FF", "#E8F5E9"]
        for index, ((x, title, subtitle), color) in enumerate(zip(steps, colors)):
            width = 1.25 if index != 2 else 1.8
            patch = FancyBboxPatch(
                (x, 0.55), width, 0.78,
                boxstyle="round,pad=0.06,rounding_size=0.08",
                linewidth=1.0, edgecolor="#1A56B0", facecolor=color,
            )
            axis.add_patch(patch)
            axis.text(x + width / 2, 1.06, title, ha="center", va="center",
                      fontsize=8.4, fontweight="bold", color="#1A3A6B")
            axis.text(x + width / 2, 0.77, subtitle, ha="center", va="center",
                      fontsize=6.4, color="#344054", wrap=True)
            if index < len(steps) - 1:
                next_x = steps[index + 1][0]
                axis.annotate("", xy=(next_x - 0.10, 0.94), xytext=(x + width + 0.06, 0.94),
                              arrowprops=dict(arrowstyle="->", color="#64748B", lw=1.2))
        axis.text(5.0, 0.16,
                  "Los portales A y B se evalúan independientemente; el resultado puede ser asimétrico.",
                  ha="center", fontsize=7.1, color="#475569", style="italic")
        figure.tight_layout(pad=0.2)
        _save_figure_to_document(doc, figure, width_cm=16.2)
    except Exception:
        # La explicación escrita anterior conserva la trazabilidad si el
        # entorno no dispone de Matplotlib.
        pass


def _build_longitudinal_profile(doc: Document, result: dict,
                                photometric: dict = None) -> None:
    """Incluye L requerida y Lavg CIE 140; no reconstruye Lavg con estimaciones."""
    _section_heading(doc, "4. Resultado Luminotécnico — Perfil Longitudinal")
    chart = result.get("chart", {})
    required = chart.get("data", []) if isinstance(chart, dict) else []
    profile = (photometric or {}).get("real_profile") or {}
    real_points = profile.get("points", []) if isinstance(profile, dict) else []

    if not required:
        doc.add_paragraph("No hay puntos disponibles para representar el perfil longitudinal requerido.")
        return
    if not profile.get("available") or profile.get("metric") != "CIE140_Lavg" or not real_points:
        p = doc.add_paragraph()
        run = p.add_run(
            "La curva de Lavg CIE 140 no está disponible. No se representa ninguna curva estimada; recalcule las luminarias con fotometría LDT para completar la validación."
        )
        run.bold = True
        run.font.size = Pt(9)
        run.font.color.rgb = RGBColor.from_string("B26A00")
        return

    try:
        import matplotlib
        matplotlib.use("Agg")
        import matplotlib.pyplot as plt

        required_x = [float(point.get("s", 0)) for point in required]
        required_y = [float(point.get("L", 0)) for point in required]
        actual_x = [float(point.get("s", 0)) for point in real_points]
        actual_y = [float(point.get("L", 0)) for point in real_points]

        fig, ax = plt.subplots(figsize=(8.2, 3.3), dpi=160)
        ax.plot(required_x, required_y, color="#1A56B0", linewidth=2.2,
                label="L requerida CIE 88")
        ax.plot(actual_x, actual_y, color="#C0392B", linewidth=1.8,
                marker="o", markersize=2.4, label="Lavg calculada CIE 140")
        ax.set_xlabel("Posición longitudinal (m)", fontsize=8)
        ax.set_ylabel("Luminancia (cd/m²)", fontsize=8)
        ax.grid(True, color="#D9E2F0", linewidth=0.6)
        ax.tick_params(labelsize=7)
        ax.legend(loc="upper right", frameon=False, fontsize=7)
        fig.tight_layout(pad=0.8)
        image = io.BytesIO()
        fig.savefig(image, format="png", transparent=False)
        plt.close(fig)
        image.seek(0)
        p = doc.add_paragraph()
        p.alignment = WD_ALIGN_PARAGRAPH.CENTER
        p.add_run().add_picture(image, width=Cm(16.0))
    except Exception as exc:
        p = doc.add_paragraph()
        run = p.add_run(f"No se pudo generar la gráfica longitudinal: {exc}")
        run.font.size = Pt(8.5)
        run.font.color.rgb = RGBColor.from_string("C0392B")
        return

    note = doc.add_paragraph()
    note.paragraph_format.space_before = Pt(2)
    run = note.add_run(
        "La curva roja procede exclusivamente de Lavg calculada en campos bidimensionales CIE 140 entre luminarias consecutivas."
    )
    run.italic = True
    run.font.size = Pt(8)
    run.font.color.rgb = RGBColor.from_string("666666")


def _save_figure_to_document(doc: Document, figure, width_cm: float = 16.0) -> None:
    """Inserta una figura Matplotlib en el Word sin crear archivos temporales."""
    image = io.BytesIO()
    figure.savefig(image, format="png", dpi=180, facecolor="white")
    import matplotlib.pyplot as plt
    plt.close(figure)
    image.seek(0)
    paragraph = doc.add_paragraph()
    paragraph.alignment = WD_ALIGN_PARAGRAPH.CENTER
    paragraph.add_run().add_picture(image, width=Cm(width_cm))


def _luminaire_y_positions(arrangement: str, width_m: float,
                           wall_offset_m: float) -> list[float]:
    """Posiciones transversales, coherentes con el motor de cálculo."""
    width = max(float(width_m or 0.0), 0.1)
    offset = min(max(0.05, float(wall_offset_m or 0.30)), width / 2.0 - 0.05)
    arrangement = str(arrangement or "central_single")
    if arrangement in {
        "bilateral_sym", "bilateral_stag", "bilateral", "staggered",
        "central_double",
    }:
        return [offset, width - offset]
    if arrangement in {"central_offset", "lateral_left"}:
        return [offset]
    if arrangement in {"lateral_right", "unilateral"}:
        return [width - offset]
    return [width / 2.0]


def _build_installation_visuals(doc: Document, result: dict, params: dict,
                                luminaire: Any) -> None:
    """Planta longitudinal y sección de montaje: el núcleo visual del proyecto."""
    lum = _as_luminaire_dict(luminaire)
    lum_zones = lum.get("zones", [])
    if not lum_zones:
        return

    _section_heading(doc, "6. Plano de Implantación de Luminarias")
    try:
        import matplotlib
        matplotlib.use("Agg")
        import matplotlib.pyplot as plt

        tube_length = float(result.get("summary", {}).get(
            "length_m", lum.get("tube_length_m", 0)
        ) or 0)
        zone_colors = {
            "threshold": "#F6C85F", "threshold_b": "#F6C85F",
            "transition": "#6FB1E8", "transition_b": "#6FB1E8",
            "interior": "#8BCB9B", "interior_base": "#8BCB9B",
            "exit": "#B9A4D8", "access": "#E8A0A0", "parting": "#E8A0A0",
        }
        layer_y = {"permanent": 0.68, "adaptation": 0.50,
                   "reinforcement": 0.32, "legacy": 0.50}
        layer_colors = {"permanent": "#1A56B0", "adaptation": "#A855F7",
                        "reinforcement": "#D97706", "legacy": "#374151"}

        figure, axis = plt.subplots(figsize=(9.0, 3.6))
        for zone in (result.get("zones") or {}).values():
            if not isinstance(zone, dict):
                continue
            start = float(zone.get("s_start", 0) or 0)
            end = float(zone.get("s_end", start) or start)
            z_type = str(zone.get("zone_type", zone.get("type", ""))).lower()
            color = zone_colors.get(z_type, "#D9E2F0")
            axis.axvspan(start, end, ymin=0.02, ymax=0.98, color=color,
                         alpha=0.40, linewidth=0)
            if end > start + max(25.0, tube_length * 0.04):
                axis.text(
                    (start + end) / 2, 0.92,
                    _zone_label_es(z_type, zone.get("zone_name")),
                    ha="center", va="top", fontsize=7, fontweight="bold",
                )

        used_layers = set()
        for zone in lum_zones:
            layer = str(zone.get("control_layer", "legacy") or "legacy")
            y = layer_y.get(layer, 0.50)
            points = zone.get("setpoints", []) or []
            positions = [float(point.get("s", 0) or 0) for point in points]
            if not positions:
                start = float(zone.get("s_start", 0) or 0)
                end = float(zone.get("s_end", start) or start)
                count = int(zone.get("n_positions", zone.get("n_luminaires", 0)) or 0)
                if count > 0 and end > start:
                    positions = [start + (index + 0.5) * (end - start) / count
                                 for index in range(count)]
            if positions:
                label = _humanize(layer) if layer not in used_layers else None
                axis.scatter(positions, [y] * len(positions), s=16,
                             color=layer_colors.get(layer, "#374151"),
                             label=label, zorder=3)
                used_layers.add(layer)

        axis.set_xlim(0, max(tube_length, 1.0))
        axis.set_ylim(0.12, 1.02)
        axis.set_yticks([0.32, 0.50, 0.68], ["Refuerzo", "Adaptación", "Base permanente"])
        axis.set_xlabel("Posición longitudinal (m)", fontsize=8)
        axis.set_title("Zonas CIE 88 y posiciones físicas de luminarias", fontsize=10,
                       fontweight="bold")
        axis.grid(axis="x", color="#D9E2F0", linewidth=0.7)
        axis.tick_params(labelsize=7)
        if used_layers:
            axis.legend(loc="lower center", bbox_to_anchor=(0.5, -0.35),
                        ncol=max(1, len(used_layers)), frameon=False, fontsize=7)
        figure.tight_layout(pad=1.0)
        _save_figure_to_document(doc, figure)

        width = float(params.get("width_m", lum.get("road_width_m", 7.0)) or 7.0)
        height = float(params.get("height_m", 5.0) or 5.0)
        mount_height = float((lum.get("luminaire") or {}).get(
            "mounting_height_m", params.get("mounting_height_m", 4.5)
        ) or 4.5)
        offset = float((lum.get("luminaire") or {}).get(
            "wall_offset_m", params.get("wall_offset_m", 0.30)
        ) or 0.30)
        positions = _luminaire_y_positions(lum.get("arrangement"), width, offset)

        figure, axis = plt.subplots(figsize=(7.5, 3.1))
        axis.add_patch(plt.Rectangle((0, 0), width, 0.10, color="#4B5563"))
        axis.plot([0, 0], [0, height], color="#374151", linewidth=2)
        axis.plot([width, width], [0, height], color="#374151", linewidth=2)
        axis.plot([0, width], [height, height], color="#374151", linewidth=1.4)
        for pos in positions:
            axis.scatter([pos], [mount_height], color="#F59E0B", marker="s", s=55,
                         edgecolors="#7C2D12", zorder=3)
            axis.plot([pos, pos], [0, mount_height], color="#D1D5DB", linewidth=0.8,
                      linestyle="--")
        axis.annotate(f"Ancho calzada: {width:.2f} m", xy=(width / 2, 0),
                      xytext=(width / 2, -0.55), ha="center", fontsize=8)
        axis.annotate(f"Altura de montaje: {mount_height:.2f} m", xy=(positions[0], mount_height),
                      xytext=(width + 0.35, mount_height), va="center", fontsize=8)
        axis.set_xlim(-0.5, width + 2.2)
        axis.set_ylim(-0.8, max(height + 0.5, mount_height + 0.5))
        axis.set_aspect("equal", adjustable="box")
        axis.axis("off")
        axis.set_title(
            f"Sección transversal — {_humanize(lum.get('arrangement'))}",
            fontsize=10, fontweight="bold",
        )
        figure.tight_layout(pad=0.8)
        _save_figure_to_document(doc, figure, width_cm=14.5)
    except Exception as exc:
        note = doc.add_paragraph()
        run = note.add_run(f"No se pudieron generar los planos de implantación: {exc}")
        run.font.size = Pt(8.5)
        run.font.color.rgb = RGBColor.from_string("C0392B")


def _operating_scenes(luminaire: Any) -> list[tuple[str, dict]]:
    """Devuelve una sola vez cada escena que el operador reconoce en obra."""
    lum = _as_luminaire_dict(luminaire)
    scenarios = lum.get("scenarios", {}) or {}
    aliases = [
        ("sunny", ("sunny",)),
        ("normal", ("normal",)),
        ("overcast", ("overcast",)),
        ("dusk", ("dusk",)),
        ("night_normal", ("night_normal", "night")),
        ("night_reduced", ("night_reduced",)),
    ]
    selected = []
    used = set()
    for canonical, candidates in aliases:
        key = next((candidate for candidate in candidates
                    if isinstance(scenarios.get(candidate), dict)
                    and scenarios[candidate].get("power_kw") is not None), None)
        if key and key not in used:
            selected.append((canonical, scenarios[key]))
            used.add(key)
    return selected


def _build_operation_chart(doc: Document, luminaire: Any) -> None:
    """Gráfica de potencia por escena para operación y eficiencia energética."""
    scenarios = [value for _key, value in _operating_scenes(luminaire)]
    if not scenarios:
        return
    try:
        import matplotlib
        matplotlib.use("Agg")
        import matplotlib.pyplot as plt

        labels = [str(item.get("name", "Escena")) for item in scenarios]
        powers = [float(item.get("power_kw", 0) or 0) for item in scenarios]
        figure, axis = plt.subplots(figsize=(7.5, 2.9))
        bars = axis.bar(labels, powers, color="#1A56B0")
        for bar, value in zip(bars, powers):
            axis.text(bar.get_x() + bar.get_width() / 2, bar.get_height(),
                      f"{value:.2f}", ha="center", va="bottom", fontsize=8)
        axis.set_ylabel("Potencia (kW)", fontsize=8)
        axis.set_title("Potencia eléctrica por escena de operación", fontsize=10,
                       fontweight="bold")
        axis.grid(axis="y", color="#D9E2F0", linewidth=0.7)
        axis.tick_params(axis="x", labelrotation=18, labelsize=7)
        axis.tick_params(axis="y", labelsize=7)
        figure.tight_layout(pad=0.8)
        _save_figure_to_document(doc, figure, width_cm=15.0)
    except Exception:
        return


def _build_cie140_field_annex(doc: Document, photometric: dict = None) -> None:
    """Anexo breve por zona: sólo los campos gobernantes, nunca una matriz completa."""
    profile = (photometric or {}).get("real_profile") or {}
    fields = profile.get("fields", []) if profile.get("available") else []
    if not fields:
        return

    grouped = {}
    for field in fields:
        name = str(field.get("zone_name") or field.get("zone_type") or "Zona")
        grouped.setdefault(name, []).append(field)

    for index, (zone_name, zone_fields) in enumerate(grouped.items(), start=1):
        _add_page_break(doc)
        _section_heading(doc, f"ANEXO B.{index}. Caso crítico CIE 140 — {zone_name}")

        def field_range(item: dict) -> str:
            return f"{float(item.get('field_start', 0) or 0):.1f}–{float(item.get('field_end', 0) or 0):.1f}"

        def observer(item: dict) -> str:
            direction = 'A→B' if int(item.get('observer_direction', 1) or 1) >= 0 else 'B→A'
            return f"C{item.get('observer_lane_number', '—')} / {direction}"

        # El informe principal ya declara el resultado por zona. Aquí se
        # conservan únicamente los cuatro campos que gobiernan la aceptación:
        # es suficiente para auditoría y evita reproducir una matriz por cada
        # observador. El detalle punto a punto queda disponible en Excel.
        critical = [
            ("Luminancia media mínima", min(zone_fields, key=lambda item: float(item.get('L', 0) or 0)), "Lavg", "cd/m²"),
            ("Uniformidad general mínima", min(zone_fields, key=lambda item: float(item.get('U0', 0) or 0)), "U0", ""),
            ("Uniformidad longitudinal mínima", min(zone_fields, key=lambda item: float(item.get('Ul', 0) or 0)), "Ul", ""),
            ("Incremento de umbral máximo", max(zone_fields, key=lambda item: float(item.get('TI', 0) or 0)), "TI", "%"),
        ]
        table = doc.add_table(rows=1 + len(critical), cols=5)
        table.style = "Table Grid"
        _header_row(table.rows[0], ["Criterio gobernante", "Campo (m)", "Valor", "Observador", "Referencia"])
        for row_index, (criterion, item, key, unit) in enumerate(critical, start=1):
            bg = GRAY_LIGHT if row_index % 2 else WHITE
            value = float(item.get(key, 0) or 0)
            values = [criterion, field_range(item), f"{value:.3f}" if key != "TI" else f"{value:.1f}", observer(item), unit or "—"]
            for cell, text in zip(table.rows[row_index].cells, values):
                _set_cell_bg(cell, bg)
                _cell_text(cell, text, bold=False, size_pt=8, align=WD_ALIGN_PARAGRAPH.CENTER)

        # Para la única imagen de esta zona se utiliza el campo con peor U0,
        # que permite revisar visualmente el patrón más sensible sin convertir
        # el anexo en una sucesión de mapas repetitivos.
        governing = critical[1][1]
        grid = governing.get("grid_points", []) or []
        if not grid:
            continue
        try:
            import matplotlib
            matplotlib.use("Agg")
            import matplotlib.pyplot as plt

            xs = [float(point.get("x", 0) or 0) for point in grid]
            ys = [float(point.get("y", 0) or 0) for point in grid]
            values = [float(point.get("L", 0) or 0) for point in grid]
            figure, axis = plt.subplots(figsize=(7.5, 3.0))
            contour = axis.tricontourf(xs, ys, values, levels=12, cmap="YlOrRd")
            figure.colorbar(contour, ax=axis, label="Luminancia (cd/m²)")
            axis.set_xlabel("Posición longitudinal (m)", fontsize=8)
            axis.set_ylabel("Posición transversal (m)", fontsize=8)
            axis.set_title(
                f"Campo crítico {governing.get('field_start', 0):.1f}–{governing.get('field_end', 0):.1f} m",
                fontsize=10, fontweight="bold",
            )
            axis.tick_params(labelsize=7)
            figure.tight_layout(pad=0.8)
            _save_figure_to_document(doc, figure, width_cm=15.5)
        except Exception:
            continue


def _build_compliance_summary(doc: Document, result: dict,
                              photometric: dict = None) -> None:
    """Matriz compacta por zona para la lectura principal del informe."""
    _section_heading(doc, "Cumplimiento por zona", level=2)
    ph = photometric or {}
    zones = ph.get("zones", {}) if ph.get("available") else {}
    if not zones:
        doc.add_paragraph(
            "No disponible: la verificación CIE 140 con LDT es necesaria para declarar U0, Ul y TI."
        )
        return

    headers = ["Zona", "Lavg / Lreq", "U0", "Ul", "TI (%)", "Estado"]
    table = doc.add_table(rows=1 + len(zones), cols=len(headers))
    table.style = "Table Grid"
    _header_row(table.rows[0], headers)
    for i, (name, data) in enumerate(zones.items()):
        row = table.rows[i + 1]
        bg = GRAY_LIGHT if i % 2 == 0 else WHITE
        for cell in row.cells:
            _set_cell_bg(cell, bg)
        checks = data.get("checks", {})
        state = "CUMPLE" if data.get("compliant") else "REVISAR"
        values = [
            name,
            f"{data.get('L_avg', '—')} / {data.get('L_req', '—')}",
            str(data.get("U0", "—")),
            str(data.get("Ul", "—")),
            str(data.get("TI", "—")),
            state,
        ]
        for col, value in enumerate(values):
            ok = col == 5 and state == "CUMPLE"
            _cell_text(
                row.cells[col], value, bold=col in (0, 5), size_pt=8.5,
                align=WD_ALIGN_PARAGRAPH.LEFT if col == 0 else WD_ALIGN_PARAGRAPH.CENTER,
                color="1A7A3C" if ok else ("C0392B" if col == 5 else None),
            )


def _build_installation_summary(doc: Document, luminaire: Any) -> None:
    """Diseño instalable agrupado por tramo; el detalle unitario se mueve al anexo."""
    _section_heading(doc, "5. Diseño de la Instalación")
    lum = _as_luminaire_dict(luminaire)
    zones = lum.get("zones", [])
    if not zones:
        doc.add_paragraph(
            "No hay diseño de luminarias asociado. Calcule las luminarias APHEX para incluir la especificación de instalación."
        )
        return

    totals = lum.get("totals", {})
    lum_spec = lum.get("luminaire") or {}
    _kv_table(doc, [
        ("Disposición", _humanize(lum.get("arrangement"))),
        ("Luminaria de referencia", lum_spec.get("name") or "APHEX configurada por zona"),
        ("Óptica / CCT / I máx.", f"{lum.get('optic', '—')} · {lum.get('cct', '—')} · {lum.get('I_max_mA', '—')} mA"),
        ("Total instalado", f"{totals.get('n_luminaires', '—')} luminarias · {totals.get('power_kw', '—')} kW"),
        ("Densidad media", f"{totals.get('power_density_wm2', '—')} W/m²"),
    ])

    doc.add_paragraph()
    headers = ["Zona", "Tramo (m)", "Modelo / óptica", "mA", "W", "d (m)", "N", "Tilt", "Capa"]
    table = doc.add_table(rows=1 + len(zones), cols=len(headers))
    table.style = "Table Grid"
    _header_row(table.rows[0], headers)
    for i, zone in enumerate(zones):
        row = table.rows[i + 1]
        bg = GRAY_LIGHT if i % 2 == 0 else WHITE
        for cell in row.cells:
            _set_cell_bg(cell, bg)
        values = [
            zone.get("zone_name", zone.get("zone_type", "—")),
            f"{zone.get('s_start', '—')}–{zone.get('s_end', '—')}",
            f"{zone.get('model', '—')} / {zone.get('optic', lum.get('optic', '—'))}",
            str(zone.get("current_mA", "—")),
            str(zone.get("power_w", "—")),
            str(zone.get("d_used", "—")),
            str(zone.get("n_luminaires", "—")),
            f"{zone.get('tilt_deg', 0)}°",
            _humanize(zone.get("control_layer")),
        ]
        for col, value in enumerate(values):
            _cell_text(
                row.cells[col], value, bold=col == 0, size_pt=7.5,
                align=WD_ALIGN_PARAGRAPH.LEFT if col in (0, 2, 8) else WD_ALIGN_PARAGRAPH.CENTER,
            )
    note = doc.add_paragraph()
    note.add_run(
        "La planta y esta tabla por tipo de tramo constituyen la especificación ordinaria de montaje. "
        "El listado unitario se incorpora sólo si existen reglajes singulares; el detalle completo queda disponible en la exportación Excel."
    ).italic = True
    note.runs[0].font.size = Pt(8.2)


def _build_operation_summary(doc: Document, luminaire: Any) -> None:
    """Potencia demandada por escena, separada de la tabla de consignas DALI."""
    _section_heading(doc, "Potencia por escena de operación", level=2)
    rows = _operating_scenes(luminaire)
    if not rows:
        return
    table = doc.add_table(rows=1 + len(rows), cols=4)
    table.style = "Table Grid"
    _header_row(table.rows[0], ["Escena", "Luminarias activas", "Potencia (kW)", "Flujo (lm)"])
    for i, (key, value) in enumerate(rows):
        row = table.rows[i + 1]
        bg = GRAY_LIGHT if i % 2 == 0 else WHITE
        for cell in row.cells:
            _set_cell_bg(cell, bg)
        for col, text in enumerate([
            value.get("name", _humanize(key)),
            str(value.get("active_luminaires", "—")),
            str(value.get("power_kw", "—")),
            str(value.get("flux_lm", "—")),
        ]):
            _cell_text(row.cells[col], text, bold=col == 0, size_pt=8.5,
                       align=WD_ALIGN_PARAGRAPH.LEFT if col == 0 else WD_ALIGN_PARAGRAPH.CENTER)


def _build_energy_and_maintenance(doc: Document, params: dict,
                                  luminaire: Any) -> None:
    """Cierra la parte operativa con una estimación energética trazable."""
    lum = _as_luminaire_dict(luminaire)
    totals = lum.get("totals", {}) or {}
    scenarios = lum.get("scenarios", {}) or {}
    installed_kw = float(totals.get("power_kw", 0) or 0)
    if not installed_kw and not scenarios:
        return

    _section_heading(doc, "8. Potencia, Energía y Mantenimiento")
    annual_hours = float(params.get("annual_operation_hours", 8760) or 8760)
    tariff = float(params.get("energy_tariff_eur_kwh", 0.15) or 0.15)
    reference_distribution = {
        "sunny": 1200, "normal": 1800, "overcast": 900,
        "dusk": 600, "night_normal": 3000, "night_reduced": 1260,
    }
    scene_aliases = {
        "sunny": ("sunny",), "normal": ("normal",),
        "overcast": ("overcast",), "dusk": ("dusk",),
        "night_normal": ("night_normal", "night"),
        "night_reduced": ("night_reduced",),
    }
    scale = annual_hours / 8760.0
    rows = []
    consumed_source_keys = set()
    for canonical_key, hours_reference in reference_distribution.items():
        source_key = next(
            (candidate for candidate in scene_aliases[canonical_key]
             if isinstance(scenarios.get(candidate), dict)
             and scenarios[candidate].get("power_kw") is not None),
            None,
        )
        if source_key is None:
            continue
        # Si el motor sólo devuelve una escena de noche, se le asigna el
        # total de horas nocturnas y no se duplica en la tabla.
        if source_key in consumed_source_keys:
            for item_index, item in enumerate(rows):
                if item[4] == source_key:
                    updated_hours = item[1] + hours_reference * scale
                    rows[item_index] = (
                        item[0], updated_hours, item[2], item[2] * updated_hours,
                        source_key,
                    )
                    break
            continue
        scenario = scenarios[source_key]
        consumed_source_keys.add(source_key)
        hours = hours_reference * scale
        power = float(scenario.get("power_kw", 0) or 0)
        rows.append((
            scenario.get("name", _humanize(canonical_key)), hours, power, power * hours,
            source_key,
        ))

    if rows:
        total_kwh = sum(item[3] for item in rows)
        represented_hours = sum(item[1] for item in rows)
        table = doc.add_table(rows=1 + len(rows) + 1, cols=4)
        table.style = "Table Grid"
        _header_row(table.rows[0], ["Escena", "Horas/año", "Potencia (kW)", "Consumo (kWh/año)"])
        for index, (name, hours, power, energy, _source_key) in enumerate(rows, start=1):
            bg = GRAY_LIGHT if index % 2 else WHITE
            for column, (cell, value) in enumerate(zip(table.rows[index].cells, [
                name, f"{hours:,.0f}", f"{power:.2f}", f"{energy:,.0f}",
            ])):
                _set_cell_bg(cell, bg)
                _cell_text(cell, value, bold=False, size_pt=8.4,
                           align=WD_ALIGN_PARAGRAPH.LEFT if column == 0 else WD_ALIGN_PARAGRAPH.CENTER)
        for cell, value in zip(table.rows[-1].cells, ["TOTAL", f"{represented_hours:,.0f}", "—", f"{total_kwh:,.0f}"]):
            _set_cell_bg(cell, BLUE_LIGHT)
            _cell_text(cell, value, bold=True, color=BLUE_DARK, size_pt=8.5,
                       align=WD_ALIGN_PARAGRAPH.CENTER)
        p = doc.add_paragraph()
        p.add_run("Coste anual de referencia: ").bold = True
        p.add_run(f"{total_kwh * tariff:,.0f} EUR/año ")
        p.add_run(f"(tarifa {tariff:.3f} EUR/kWh; distribución anual de referencia escalada a {annual_hours:,.0f} h/año).")
        p.runs[-1].italic = True
        p.runs[-1].font.size = Pt(8.2)
        if represented_hours < annual_hours - 1:
            note = doc.add_paragraph()
            note.add_run(
                "Aviso energético: faltan escenas verificadas para cubrir todas las horas adoptadas; el consumo sólo suma las escenas disponibles."
            ).font.size = Pt(8.2)
            note.runs[0].font.color.rgb = RGBColor.from_string("B26A00")
    else:
        doc.add_paragraph(
            f"Potencia instalada: {installed_kw:.2f} kW. No se ha definido una distribución de horas por escena; no se declara consumo anual."
        )

    _section_heading(doc, "Criterios de mantenimiento y explotación", level=2)
    lum_spec = lum.get("luminaire") or {}
    mf = lum_spec.get("maintenance_factor", params.get("maintenance_factor", "—"))
    _kv_table(doc, [
        ("Factor de mantenimiento aplicado", mf),
        ("Reflectancia de paredes", params.get("rho_wall", params.get("wall_reflectance", "—"))),
        ("Reflectancia de techo", params.get("rho_ceiling", "—")),
        ("Revisión en recepción", "Modelo/LDT, flujo, corriente, altura, posición, tilt, escenas DALI y mediciones finales."),
    ], col_widths=(6.0, 8.0))


def _requires_detailed_schedule(params: dict, luminaire: Any) -> bool:
    """Sólo añade listado punto a punto cuando la instalación es realmente irregular."""
    lum = _as_luminaire_dict(luminaire)
    if bool((params or {}).get("include_detailed_schedule")):
        return True
    return bool(
        (params or {}).get("tilt_overrides")
        or (params or {}).get("tandem_overrides")
        or lum.get("tilt_overrides")
        or lum.get("tandem_overrides")
    )


def _build_installation_schedule(doc: Document, luminaire: Any) -> None:
    """Anexo con una línea por posición luminaria para obra y puesta en marcha."""
    lum = _as_luminaire_dict(luminaire)
    positions = []
    for zone in lum.get("zones", []):
        for item in zone.get("setpoints", []) or []:
            positions.append((zone, item))
    if not positions:
        return

    _section_heading(doc, "ANEXO C. Listado de Luminarias y Reglajes")
    note = doc.add_paragraph()
    note.add_run(
        "Listado por posición longitudinal. Las coordenadas transversales y la configuración de filas se rigen por la disposición indicada en el informe principal."
    ).font.size = Pt(8.5)
    headers = ["Ref.", "Zona", "PK (m)", "Modelo", "Óptica", "mA", "W", "Tilt", "Capa"]
    table = doc.add_table(rows=1 + len(positions), cols=len(headers))
    table.style = "Table Grid"
    _header_row(table.rows[0], headers)
    for i, (zone, item) in enumerate(positions):
        row = table.rows[i + 1]
        bg = GRAY_LIGHT if i % 2 == 0 else WHITE
        for cell in row.cells:
            _set_cell_bg(cell, bg)
        values = [
            f"{zone.get('zone_name', zone.get('zone_type', 'Z'))}-{item.get('idx', i + 1)}",
            zone.get("zone_name", zone.get("zone_type", "—")),
            str(item.get("s", "—")),
            item.get("model", zone.get("model", "—")),
            item.get("optic", zone.get("optic", lum.get("optic", "—"))),
            str(item.get("current_mA", zone.get("current_mA", "—"))),
            str(item.get("power_w", zone.get("power_w", "—"))),
            f"{item.get('tilt_deg', zone.get('tilt_deg', 0))}°",
            _humanize(zone.get("control_layer")),
        ]
        for col, value in enumerate(values):
            _cell_text(row.cells[col], value, bold=col == 0, size_pt=7.2,
                       align=WD_ALIGN_PARAGRAPH.LEFT if col in (0, 1, 3, 4, 8) else WD_ALIGN_PARAGRAPH.CENTER)


def _build_conclusions(doc: Document, result: dict, photometric: dict = None,
                       title: str = "7. Conclusiones y Verificaciones de Recepción") -> None:
    """Cierre orientado a la aprobación y a la recepción de obra."""
    status, explanation = _report_status(result, photometric)
    _section_heading(doc, title)
    p = doc.add_paragraph()
    run = p.add_run(f"Estado del diseño: {status}. ")
    run.bold = True
    run.font.color.rgb = RGBColor.from_string("1A7A3C" if status == "CONFORME" else "B26A00")
    p.add_run(explanation)
    items = [
        "Verificar en obra la geometría efectiva, la posición transversal y la altura de montaje de cada fila.",
        "Comprobar que modelo, óptica, flujo, corriente y orientación/tilt coinciden con el listado de luminarias.",
        "Programar y ensayar las escenas y grupos DALI antes de la recepción de la instalación.",
        "Confirmar las condiciones de mantenimiento y las reflectancias adoptadas si difieren de las existentes en obra.",
    ]
    for item in items:
        bullet = doc.add_paragraph(style="List Bullet")
        bullet.add_run(item).font.size = Pt(9)


def _append_tube_report(doc: Document, result: dict, params: dict,
                        photometric: dict = None, luminaire: Any = None) -> None:
    """Informe principal seguido de anexos, siempre en el mismo documento Word."""
    _build_executive_summary(doc, result, photometric, luminaire)
    _build_design_inputs(doc, result, params, luminaire)

    _add_page_break(doc)
    _build_methodology(doc, result, photometric)
    _build_longitudinal_profile(doc, result, photometric)
    _build_compliance_summary(doc, result, photometric)

    _add_page_break(doc)
    _build_installation_summary(doc, luminaire)
    _build_installation_visuals(doc, result, params, luminaire)
    _build_control(doc, result, title="7. Control DALI y Escenas de Operación")
    _build_operation_summary(doc, luminaire)
    _build_operation_chart(doc, luminaire)
    _build_energy_and_maintenance(doc, params, luminaire)
    _build_conclusions(doc, result, photometric,
                       title="9. Conclusiones y Verificaciones de Recepción")

    _add_page_break(doc)
    _section_heading(doc, "ANEXOS DE CÁLCULO E INSTALACIÓN")
    intro = doc.add_paragraph()
    intro.add_run(
        "Los anexos conservan la trazabilidad necesaria para auditoría, dirección facultativa y puesta en marcha."
    ).italic = True
    intro.runs[0].font.size = Pt(9)

    _build_classification(doc, result, title="ANEXO A. Clasificación y Distancia de Parada")
    _build_luminances(doc, result, title="ANEXO A.2 Datos L20, Lth e Interior")
    _build_zones(doc, result, title="ANEXO A.3 Zonas y Perfil Normativo")
    _build_quality(doc, result, photometric=photometric,
                   title="ANEXO B. Verificación Fotométrica CIE 140:2019")
    _build_cie140_field_annex(doc, photometric)
    if _requires_detailed_schedule(params, luminaire):
        _add_page_break(doc)
        _build_installation_schedule(doc, luminaire)


def _build_project_summary(doc: Document, tubes_data: list) -> None:
    """Resumen de proyecto antes de las fichas individuales de cada tubo."""
    _section_heading(doc, "Resumen Comparativo de Tubos")
    headers = ["Tubo", "Longitud", "Lth A / B", "L interior", "CIE 140", "Estado"]
    table = doc.add_table(rows=1 + len(tubes_data), cols=len(headers))
    table.style = "Table Grid"
    _header_row(table.rows[0], headers)
    for i, item in enumerate(tubes_data):
        result = item["result"]
        summary = result.get("summary", {})
        lth = result.get("lth", {})
        status, _ = _report_status(result, item.get("photometric"))
        row = table.rows[i + 1]
        bg = GRAY_LIGHT if i % 2 == 0 else WHITE
        for cell in row.cells:
            _set_cell_bg(cell, bg)
        values = [
            summary.get("tube_id", f"T{i + 1}"),
            f"{summary.get('length_m', '—')} m",
            f"{summary.get('Lth', '—')} / {lth.get('Lth_b', '—')}",
            f"{summary.get('Lin', '—')} cd/m²",
            "Disponible" if (item.get("photometric") or {}).get("available") else "Pendiente",
            status,
        ]
        for col, value in enumerate(values):
            _cell_text(row.cells[col], value, bold=col in (0, 5), size_pt=8.5,
                       align=WD_ALIGN_PARAGRAPH.CENTER)


def _build_quality(doc: Document, result: dict, photometric: dict = None,
                   title: str = "5. Criterios de Calidad CIE 88:2004 / CIE 140:2019") -> None:
    validation = result.get('validation', {})
    ph       = photometric or {}
    ph_avail = ph.get('available', False)

    _section_heading(doc, title)

    if ph_avail:
        # ── CIE 140:2019 — tabla por zona ─────────────────────────────────
        p_inf = doc.add_paragraph()
        r_inf = p_inf.add_run(
            f"CIE 140:2019  ·  Tabla {ph.get('rtable','--')}  ·  "
            f"Optica {ph.get('optic','--')}  ·  H = {ph.get('H_m','--')} m"
        )
        r_inf.italic = True
        r_inf.font.size = Pt(8.5)
        r_inf.font.color.rgb = RGBColor.from_string("444444")

        zones  = ph.get('zones', {})
        col_w  = [2.2, 2.5, 1.7, 1.7, 1.7, 2.0]
        tbl    = doc.add_table(rows=1 + len(zones), cols=6)
        tbl.style = 'Table Grid'
        _header_row(tbl.rows[0],
                    ["Zona", "L_avg / L_req", "U0 >=0.40", "Ul >=0.60", "TI <=15%", "Estado"])
        for j, w in enumerate(col_w):
            tbl.rows[0].cells[j].width = Cm(w)

        for i, (zk, zv) in enumerate(zones.items()):
            row = tbl.rows[i + 1]
            bg  = GRAY_LIGHT if i % 2 == 0 else WHITE
            for c in row.cells:
                _set_cell_bg(c, bg)
            for j, w in enumerate(col_w):
                row.cells[j].width = Cm(w)
            _cell_text(row.cells[0], zk, bold=True, size_pt=9)
            if 'error' in zv:
                _cell_text(row.cells[1], str(zv['error']), size_pt=8, color="C0392B")
            else:
                chk = zv.get('checks', {})
                _cell_text(row.cells[1],
                           f"{zv['L_avg']} / {zv['L_req']}",
                           size_pt=9, align=WD_ALIGN_PARAGRAPH.CENTER,
                           color="1A7A3C" if chk.get('L_avg') else "C0392B")
                _cell_text(row.cells[2], str(zv['U0']), size_pt=9,
                           align=WD_ALIGN_PARAGRAPH.CENTER,
                           color="1A7A3C" if chk.get('U0') else "C0392B")
                _cell_text(row.cells[3], str(zv['Ul']), size_pt=9,
                           align=WD_ALIGN_PARAGRAPH.CENTER,
                           color="1A7A3C" if chk.get('Ul') else "C0392B")
                _cell_text(row.cells[4], str(zv['TI']), size_pt=9,
                           align=WD_ALIGN_PARAGRAPH.CENTER,
                           color="1A7A3C" if chk.get('TI') else "C0392B")
                st = "CUMPLE" if zv['compliant'] else "REVISAR"
                _cell_text(row.cells[5], st, bold=True, size_pt=9,
                           align=WD_ALIGN_PARAGRAPH.CENTER,
                           color="1A7A3C" if zv['compliant'] else "C0392B")

        lane_rows = [
            (zone_name, lane)
            for zone_name, zone_data in zones.items()
            for lane in zone_data.get('by_lane', [])
        ]
        if lane_rows:
            doc.add_paragraph()
            _section_heading(
                doc,
                "Verificación por carril y sentido",
                level=2,
            )
            lane_tbl = doc.add_table(
                rows=1 + len(lane_rows),
                cols=8,
            )
            lane_tbl.style = 'Table Grid'
            _header_row(
                lane_tbl.rows[0],
                [
                    "Zona", "Carril", "Sentido", "L / Lreq",
                    "U0 carril*", "Ul", "TI", "Estado",
                ],
            )
            for i, (zone_name, lane) in enumerate(lane_rows):
                row = lane_tbl.rows[i + 1]
                bg = GRAY_LIGHT if i % 2 == 0 else WHITE
                for cell in row.cells:
                    _set_cell_bg(cell, bg)
                compliant = bool(lane.get('diagnostic_compliant'))
                direction = (
                    "A → B"
                    if float(lane.get('direction', 1)) >= 0
                    else "B → A"
                )
                values = [
                    zone_name,
                    str(lane.get('lane_number', '—')),
                    direction,
                    (
                        f"{lane.get('L_avg', 0)} / "
                        f"{lane.get('L_required', 0)}"
                    ),
                    str(lane.get('U0', 0)),
                    str(lane.get('Ul', 0)),
                    str(lane.get('TI', 0)),
                    "CUMPLE" if compliant else "REVISAR",
                ]
                for column, value in enumerate(values):
                    _cell_text(
                        row.cells[column],
                        value,
                        bold=column in (0, 7),
                        size_pt=7.5,
                        align=(
                            WD_ALIGN_PARAGRAPH.LEFT
                            if column == 0
                            else WD_ALIGN_PARAGRAPH.CENTER
                        ),
                        color=(
                            "1A7A3C" if compliant else "C0392B"
                        ) if column == 7 else "222222",
                    )
            note = doc.add_paragraph(
                "* U0 por carril es un diagnóstico adicional. "
                "La conformidad normativa de U0 se calcula sobre toda la "
                "calzada para cada observador; Ul se verifica sobre el eje "
                "de cada carril. En el resumen gobierna el peor resultado."
            )
            note.runs[0].font.size = Pt(7.5)
            note.runs[0].font.color.rgb = RGBColor.from_string("666666")

        doc.add_paragraph()
        overall       = ph.get('overall_compliant', False)
        criteria_extra = [
            ("CIE 140:2019 global",          "todas las zonas",
             "CUMPLE" if overall else "REVISAR"),
            ("Perfil longitudinal normativo", "CIE 88:2004",
             "CUMPLE" if validation.get('valid') else "REVISAR"),
            ("Ratios de transicion",         "<= 3:1",
             "CUMPLE" if validation.get('valid') else "REVISAR"),
        ]
    else:
        criteria_extra = [
            ("Uniformidad general Uo",           ">= 0.40",       "Requiere LDT"),
            ("Uniformidad longitudinal Ul",       ">= 0.60",       "Requiere LDT"),
            ("Deslumbramiento TI",               "<= 15 %",       "Requiere LDT"),
            ("Ratio luminancia pared/calzada",    ">= 0.60",       "Requiere LDT"),
            ("Perfil longitudinal normativo",     "CIE 88:2004",
             "CUMPLE" if validation.get('valid') else "REVISAR"),
            ("Ratios de transicion",             "<= 3:1",
             "CUMPLE" if validation.get('valid') else "REVISAR"),
        ]

    table = doc.add_table(rows=1 + len(criteria_extra), cols=3)
    table.style = 'Table Grid'
    _header_row(table.rows[0], ["Criterio", "Requisito", "Estado"])
    for j, w in enumerate([8.0, 2.8, 2.8]):
        table.rows[0].cells[j].width = Cm(w)

    for i, (crit, req, state) in enumerate(criteria_extra):
        row  = table.rows[i + 1]
        bg   = GRAY_LIGHT if i % 2 == 0 else WHITE
        _set_cell_bg(row.cells[0], bg)
        _set_cell_bg(row.cells[1], bg)
        _set_cell_bg(row.cells[2], bg)

        _cell_text(row.cells[0], crit, size_pt=9)
        _cell_text(row.cells[1], req, size_pt=9, align=WD_ALIGN_PARAGRAPH.CENTER)

        if "CUMPLE" in state:
            st_color = "1A7A3C"
        elif "REVISAR" in state:
            st_color = "C0392B"
        else:
            st_color = "666666"
        _cell_text(row.cells[2], state, bold=("CUMPLE" in state or "REVISAR" in state),
                   color=st_color, size_pt=9, align=WD_ALIGN_PARAGRAPH.CENTER)

        for j, w in enumerate([8.0, 2.8, 2.8]):
            row.cells[j].width = Cm(w)

    # Warnings
    warnings = result.get('warnings', [])
    if warnings:
        doc.add_paragraph()
        _section_heading(doc, "Advertencias del cálculo", level=2)
        for w in warnings:
            p = doc.add_paragraph(style='List Bullet')
            run = p.add_run(w)
            run.font.size = Pt(9)
            run.font.color.rgb = RGBColor.from_string("C0392B")

    # Validation errors
    val_errors = (validation or {}).get('errors', [])
    if val_errors:
        for e in val_errors:
            p = doc.add_paragraph(style='List Bullet')
            run = p.add_run(f"ERROR: {e}")
            run.font.size = Pt(9)
            run.font.color.rgb = RGBColor.from_string("C0392B")


def _build_footer(doc: Document) -> None:
    """Pie de página con número de página y referencia."""
    for section in doc.sections:
        footer = section.footer
        p = footer.paragraphs[0]
        p.alignment = WD_ALIGN_PARAGRAPH.CENTER
        run = p.add_run("SALVI Tunnel Engine (STE) — CIE 88:2004 — ")
        run.font.size = Pt(7.5)
        run.font.color.rgb = RGBColor.from_string("888888")

        # Campo de número de página
        fldChar1 = OxmlElement('w:fldChar')
        fldChar1.set(qn('w:fldCharType'), 'begin')
        instrText = OxmlElement('w:instrText')
        instrText.text = 'PAGE'
        fldChar2 = OxmlElement('w:fldChar')
        fldChar2.set(qn('w:fldCharType'), 'end')

        run2 = p.add_run()
        run2.font.size = Pt(7.5)
        run2.font.color.rgb = RGBColor.from_string("888888")
        run2._r.append(fldChar1)
        run2._r.append(instrText)
        run2._r.append(fldChar2)


# ══════════════════════════════════════════════════════════════════
# FUNCIÓN PRINCIPAL
# ══════════════════════════════════════════════════════════════════

def generate_report(result: dict, params: dict = None, photometric: dict = None,
                    luminaire: Any = None) -> bytes:
    """
    Genera el informe técnico Word a partir del resultado del motor.

    Args:
        result: dict devuelto por run_tunnel_calculation()
        params: dict con los parámetros originales del formulario (opcional)
        photometric: verificación CIE 140 y perfil longitudinal real (opcional)
        luminaire: diseño APHEX con zonas y posiciones de montaje (opcional)

    Returns:
        bytes del .docx listo para enviar como descarga
    """
    if params is None:
        params = {}

    doc = Document()
    _set_page_margins(doc, top=2.0, bottom=2.0, left=2.5, right=2.0)

    # Estilo base
    style = doc.styles['Normal']
    style.font.name = 'Calibri'
    style.font.size = Pt(10)

    # Pie de página
    _build_footer(doc)

    # ── PORTADA ──────────────────────────────────────────────────
    _build_cover(doc, result, params)

    doc.add_paragraph()  # Espacio antes del salto
    _add_page_break(doc)

    _append_tube_report(doc, result, params, photometric=photometric,
                        luminaire=luminaire)

    # Serializar a bytes
    buf = io.BytesIO()
    doc.save(buf)
    buf.seek(0)
    return buf.read()

def generate_combined_report(tubes_data: list, project_name: str = "") -> bytes:
    """
    Genera un informe Word combinado con múltiples tubos.
    """
    if not tubes_data:
        raise ValueError("Se necesita al menos un tubo para el informe combinado")

    if len(tubes_data) == 1:
        t = tubes_data[0]
        return generate_report(
            t["result"],
            t.get("params", {}),
            photometric=t.get("photometric"),
            luminaire=t.get("luminaire"),
        )

    doc = Document()
    _set_page_margins(doc, top=2.0, bottom=2.0, left=2.5, right=2.0)

    style = doc.styles['Normal']
    style.font.name = 'Calibri'
    style.font.size = Pt(10)

    _build_footer(doc)

    first_result = tubes_data[0]["result"]
    first_params  = tubes_data[0].get("params", {})
    if project_name:
        first_params = dict(first_params)
        first_params["project_name"] = project_name

    _build_cover(doc, first_result, first_params)

    doc.add_paragraph()
    _add_page_break(doc)

    _build_project_summary(doc, tubes_data)
    _add_page_break(doc)

    for i, t in enumerate(tubes_data):
        result = t["result"]
        params = t.get("params", {})
        tid    = result.get("summary", {}).get("tube_id", f"T{i+1}")

        if i > 0:
            _add_page_break(doc)

        p_sec = doc.add_paragraph()
        p_sec.alignment = WD_ALIGN_PARAGRAPH.CENTER
        run = p_sec.add_run(f"-- TUBO {tid} --")
        run.bold = True
        run.font.size = Pt(16)
        run.font.color.rgb = RGBColor.from_string(BLUE_DARK)
        doc.add_paragraph()

        _append_tube_report(
            doc,
            result,
            params,
            photometric=t.get("photometric"),
            luminaire=t.get("luminaire"),
        )

    buf = io.BytesIO()
    doc.save(buf)
    buf.seek(0)
    return buf.read()
